import { Link, useRouterState } from "@tanstack/react-router";
import { BookOpen, Crosshair, List, ScrollText, Swords } from "lucide-react";
import { useEffect, type ReactNode } from "react";
import { Toaster } from "@/components/ui/sonner";
import { useWarStore, hydrateWarStore } from "@/lib/store";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Lists", icon: List, match: (p: string) => p === "/" || p.startsWith("/lists") },
  { to: "/battle", label: "Ledger", icon: Swords, match: (p: string) => p.startsWith("/battle") },
  { to: "/analytics", label: "Annals", icon: ScrollText, match: (p: string) => p.startsWith("/analytics") },
  { to: "/codex", label: "Codex", icon: BookOpen, match: (p: string) => p.startsWith("/codex") },
  { to: "/lab", label: "Lab", icon: Crosshair, match: (p: string) => p.startsWith("/lab") },
];

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const activeGameId = useWarStore((s) => s.activeGameId);

  useEffect(() => {
    void hydrateWarStore();
  }, []);

  return (
    <div className="tactical-grid min-h-dvh">
      <header className="sticky top-0 z-30 border-b border-border bg-background">
        <div className="mx-auto flex h-14 max-w-6xl items-center justify-between px-4">
          <Link to="/" className="flex items-baseline gap-2">
            <span className="font-display text-lg font-semibold tracking-wide">Ono40k</span>
            <span className="hidden text-[10px] tracking-[0.2em] text-muted-foreground uppercase sm:inline">11th edition</span>
          </Link>
          <nav className="hidden items-center gap-1 md:flex">
            {NAV.map((item) => {
              const active = item.match(pathname);
              const Icon = item.icon;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "relative flex h-10 items-center gap-2 rounded-md px-3 text-sm font-medium",
                    active ? "bg-accent text-foreground" : "text-muted-foreground hover:bg-accent/60 hover:text-foreground",
                  )}
                >
                  <Icon className="size-4" />
                  {item.label}
                  {item.to === "/battle" && activeGameId ? (
                    <span className="absolute top-1.5 right-1.5 size-1.5 rounded-full bg-blood" />
                  ) : null}
                </Link>
              );
            })}
          </nav>
        </div>
      </header>
      <main className="mx-auto w-full min-w-0 max-w-6xl px-4 pt-5 pb-24 md:pb-10">{children}</main>
      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-background pb-[env(safe-area-inset-bottom)] md:hidden">
        <div className="grid grid-cols-5">
          {NAV.map((item) => {
            const active = item.match(pathname);
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "relative flex min-h-14 flex-col items-center justify-center gap-0.5 text-[11px] font-medium tracking-wide uppercase",
                  active ? "text-foreground" : "text-muted-foreground",
                )}
              >
                <Icon className="size-5" />
                {item.label}
                {item.to === "/battle" && activeGameId ? (
                  <span className="absolute top-2 right-[calc(50%-18px)] size-1.5 rounded-full bg-blood" />
                ) : null}
              </Link>
            );
          })}
        </div>
      </nav>
      <Toaster />
    </div>
  );
}
