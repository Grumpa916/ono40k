import "../_runtime.mjs";
import { i as cn } from "./utils-hP9YwH9-.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { S as Check, x as ChevronDown } from "../_libs/lucide-react.mjs";
import { a as SelectItemIndicator, c as SelectTrigger$1, i as SelectItem$1, l as SelectValue$1, n as SelectContent$1, o as SelectItemText, r as SelectIcon, s as SelectPortal, t as Select$1, u as SelectViewport } from "../_libs/@radix-ui/react-select+[...].mjs";
require_react();
var import_jsx_runtime = require_jsx_runtime();
var Select = Select$1;
var SelectValue = SelectValue$1;
function SelectTrigger({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectTrigger$1, {
		className: cn("flex h-11 w-full items-center justify-between rounded-md border border-input bg-muted px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectIcon, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-4 opacity-60" }) })]
	});
}
function SelectContent({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectPortal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent$1, {
		className: cn("z-50 max-h-80 overflow-auto rounded-md border border-border bg-popover p-1 shadow-lg", className),
		position: "popper",
		sideOffset: 6,
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectViewport, { children })
	}) });
}
function SelectItem({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem$1, {
		className: cn("relative flex cursor-pointer items-center rounded-sm py-2 pr-8 pl-8 text-sm outline-none data-[highlighted]:bg-accent", className),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItemIndicator, {
			className: "absolute left-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItemText, { children })]
	});
}
function encodeRoster(roster) {
	const slim = {
		n: roster.name,
		f: roster.factionId,
		b: roster.battleSize,
		p: roster.pointsLimit,
		d: roster.detachmentIds,
		s: roster.disposition,
		u: roster.units.map((u) => [
			u.unitId,
			u.models,
			u.points,
			u.enhancementId ?? "",
			u.attachedTo ?? "",
			u.warlord ? 1 : 0,
			u.notes ?? "",
			u.wargearIds ?? []
		]),
		t: roster.notes
	};
	const json = JSON.stringify(slim);
	return `WL1.${btoa(unescape(encodeURIComponent(json))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "")}`;
}
function decodeRoster(code) {
	const raw = code.trim();
	if (!raw.startsWith("WL1.")) return null;
	try {
		const b64 = raw.slice(4).replace(/-/g, "+").replace(/_/g, "/");
		const pad = b64 + "=".repeat((4 - b64.length % 4) % 4);
		const json = decodeURIComponent(escape(atob(pad)));
		const slim = JSON.parse(json);
		return {
			name: slim.n,
			factionId: slim.f,
			battleSize: slim.b,
			pointsLimit: slim.p,
			detachmentIds: slim.d ?? [],
			disposition: slim.s ?? null,
			units: (slim.u ?? []).map((row) => ({
				id: `imp_${Math.random().toString(36).slice(2, 8)}`,
				unitId: row[0],
				models: row[1],
				points: row[2],
				enhancementId: row[3] || void 0,
				attachedTo: row[4] || void 0,
				warlord: row[5] === 1,
				notes: row[6] || void 0,
				wargearIds: Array.isArray(row[7]) && row[7].length ? row[7] : void 0
			})),
			notes: slim.t ?? ""
		};
	} catch {
		return null;
	}
}
//#endregion
export { SelectValue as a, SelectTrigger as i, SelectContent as n, decodeRoster as o, SelectItem as r, encodeRoster as s, Select as t };
