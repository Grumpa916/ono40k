import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/utils-hP9YwH9-.js
var a = (name, text) => ({
	name,
	text
});
function det(id, name, dp, disposition, uniqueTag, rule, extras = {}) {
	return {
		id,
		name,
		dp,
		disposition,
		uniqueTag,
		rule,
		stratagems: extras.stratagems ?? [],
		enhancements: extras.enhancements ?? []
	};
}
function detPack(prefix, items) {
	return items.map((d) => det(`${prefix}-${d.id}`, d.name, d.dp, d.disposition, d.tag, d.rule, {
		stratagems: d.strats,
		enhancements: d.enh
	}));
}
function u(id, name, role, points, stats, keywords, extra = {}) {
	return {
		id,
		name,
		role,
		points,
		stats,
		keywords,
		ranged: extra.r ?? [],
		melee: extra.m ?? [],
		abilities: extra.ab ?? [],
		invuln: extra.inv,
		fnp: extra.fnp,
		leaderOf: extra.lead,
		transport: extra.transport,
		wargear: extra.wargear,
		sizes: extra.sizes?.map(([models, pts]) => ({
			models,
			points: pts
		}))
	};
}
var w = (name, kind, range, attacks, skill, strength, ap, damage, keywords = []) => ({
	name,
	kind,
	range,
	attacks,
	skill,
	strength,
	ap,
	damage,
	keywords
});
var boltRifle = w("Bolt rifle — saturation", "ranged", 24, 2, 3, 5, -1, 1, ["Assault", "Rapid Fire 1"]);
var boltRifleFocused = w("Bolt rifle — focused", "ranged", 24, 1, 3, 6, -1, 2, ["Heavy", "Rapid Fire 1"]);
var boltPistol = w("Bolt pistol", "ranged", 12, 1, 3, 5, 0, 1, ["Pistol"]);
var heavyBoltPistol = w("Heavy bolt pistol", "ranged", 18, 1, 3, 5, -1, 1, ["Pistol"]);
var closeCombat = w("Close combat weapon", "melee", "Melee", 3, 3, 5, 0, 1, []);
var astartesChainsword = w("Astartes chainsword", "melee", "Melee", 4, 3, 5, -1, 1, []);
var powerFist = w("Power fist", "melee", "Melee", 4, 3, 8, -2, 2, []);
var powerWeapon = w("Power weapon", "melee", "Melee", 5, 2, 5, -2, 1, []);
var forceWeapon = w("Force weapon", "melee", "Melee", 4, 3, 6, -1, "D3", ["Psychic"]);
var KW_HA = [
	"Infantry",
	"Grenades",
	"Chaos",
	"Heretic Astartes"
];
var KW_HA_CHAR = [
	"Infantry",
	"Character",
	"Grenades",
	"Chaos",
	"Heretic Astartes"
];
var KW_HA_BL = [
	"Infantry",
	"Battleline",
	"Grenades",
	"Chaos",
	"Heretic Astartes"
];
var boltgun = w("Boltgun", "ranged", 24, 2, 3, 4, 0, 1, ["Rapid Fire 1"]);
var plasmaPistol = w("Plasma pistol", "ranged", 12, 1, 2, 8, -3, 2, ["Pistol"]);
var krak = w("Missile launcher — krak", "ranged", 48, 1, 3, 9, -2, "D6", ["Heavy"]);
var units$4 = [
	u("csm-chaos-lord", "Chaos Lord", "character", 90, {
		m: 6,
		t: 4,
		sv: 3,
		w: 5,
		ld: 6,
		oc: 1
	}, KW_HA_CHAR, {
		inv: 4,
		r: [plasmaPistol, boltPistol],
		m: [w("Daemon hammer", "melee", "Melee", 4, 3, 8, -2, 2, ["Devastating Wounds"]), powerWeapon],
		ab: [a("Lord of Chaos", "While leading a unit, each time that unit makes a Dark Pact, it automatically passes the Leadership test."), a("Glory to the Dark Gods", "While leading a unit, weapons in that unit have Sustained Hits 1.")],
		lead: [
			"csm-legionaries",
			"csm-chosen",
			"csm-havocs"
		]
	}),
	u("csm-master-of-possession", "Master of Possession", "character", 80, {
		m: 6,
		t: 4,
		sv: 3,
		w: 4,
		ld: 6,
		oc: 1
	}, [
		"Infantry",
		"Character",
		"Psyker",
		"Grenades",
		"Chaos",
		"Heretic Astartes"
	], {
		inv: 5,
		r: [w("Rite of Possession", "ranged", 18, "D6", 3, 6, -2, "D3", ["Psychic", "Devastating Wounds"]), boltPistol],
		m: [forceWeapon],
		ab: [a("Rite of Possession", "While leading a Possessed unit, that unit has a 5+ Feel No Pain and +1 to Advance and Charge rolls."), a("Pact of Flesh", "Once per turn, when a friendly Daemon or Possessed unit within 12\" is destroyed, you can return D3 destroyed models to a friendly Possessed unit within 12\".")],
		lead: ["csm-possessed", "csm-legionaries"]
	}),
	u("csm-legionaries", "Legionaries", "battleline", 90, {
		m: 6,
		t: 4,
		sv: 3,
		w: 2,
		ld: 6,
		oc: 2
	}, KW_HA_BL, {
		sizes: [[5, 90], [10, 180]],
		r: [boltgun, boltPistol],
		m: [astartesChainsword, w("Heavy melee weapon", "melee", "Melee", 3, 3, 8, -2, 2, [])],
		ab: [a("Veterans of the Long War", "Each time this unit is targeted, if it is below its Starting Strength, it has a 5+ Feel No Pain until the end of the phase."), a("Objective Secured", "This unit can perform Actions while within Engagement Range of enemy units.")]
	}),
	u("csm-cultist-mob", "Cultist Mob", "battleline", 50, {
		m: 6,
		t: 3,
		sv: 5,
		w: 1,
		ld: 8,
		oc: 1
	}, [
		"Infantry",
		"Battleline",
		"Chaos",
		"Cultist"
	], {
		sizes: [[10, 50], [20, 100]],
		r: [w("Cultist firearm", "ranged", 18, 1, 4, 3, 0, 1, []), w("Autopistol", "ranged", 12, 1, 4, 3, 0, 1, ["Pistol"])],
		m: [w("Brutal assault weapon", "melee", "Melee", 2, 4, 3, 0, 1, [])],
		ab: [a("Cannon Fodder", "Each time a ranged attack targets this unit, if this unit is wholly on or within a terrain feature, subtract 1 from the Hit roll."), a("For the Dark Gods", "This unit can be set up as a screen: friendly Heretic Astartes Character units within 3\" have the Benefit of Cover.")]
	}),
	u("csm-chosen", "Chosen", "infantry", 125, {
		m: 6,
		t: 4,
		sv: 3,
		w: 2,
		ld: 6,
		oc: 1
	}, KW_HA, {
		sizes: [[5, 125], [10, 250]],
		r: [
			boltPistol,
			w("Plasma pistol", "ranged", 12, 1, 3, 8, -3, 2, ["Pistol"]),
			boltgun
		],
		m: [w("Accursed weapon", "melee", "Melee", 4, 3, 5, -2, 1, ["Lethal Hits"])],
		ab: [a("Chosen Veterans", "This unit can re-roll Advance and Charge rolls. It can Advance and charge."), a("Mark of Favour", "Each time this unit makes a Dark Pact, you can re-roll one Hit roll and one Wound roll.")]
	}),
	u("csm-havocs", "Havocs", "infantry", 125, {
		m: 6,
		t: 4,
		sv: 3,
		w: 2,
		ld: 6,
		oc: 1
	}, KW_HA, {
		sizes: [[5, 125]],
		r: [
			w("Lascannon", "ranged", 48, 1, 3, 12, -3, "D6+1", ["Heavy"]),
			w("Havoc autocannon", "ranged", 48, 3, 3, 7, -1, 2, ["Heavy", "Sustained Hits 1"]),
			w("Reaper chaincannon", "ranged", 24, 8, 3, 5, 0, 1, ["Heavy", "Sustained Hits 1"]),
			krak
		],
		m: [closeCombat],
		ab: [a("Havoc Focus", "Each time this unit Remains Stationary, you can re-roll Hit rolls with its ranged weapons."), a("Heavy Firepower", "Ranged weapons in this unit have Heavy. If the target is a Monster or Vehicle, add 1 to the Wound roll.")]
	}),
	u("csm-possessed", "Possessed", "infantry", 140, {
		m: 9,
		t: 6,
		sv: 3,
		w: 3,
		ld: 6,
		oc: 1
	}, [
		"Infantry",
		"Daemon",
		"Chaos",
		"Heretic Astartes"
	], {
		inv: 5,
		sizes: [[5, 140], [10, 280]],
		m: [w("Hideous mutations", "melee", "Melee", 4, 3, 5, -1, 2, [])],
		ab: [a("Unholy Speed", "This unit can Advance and charge. You can re-roll Charge rolls for this unit."), a("Deep Strike", "This unit can make an Ingress move from Reserves more than 8\" from enemy models.")]
	}),
	u("csm-venomcrawler", "Venomcrawler", "vehicle", 120, {
		m: 10,
		t: 9,
		sv: 3,
		w: 9,
		ld: 6,
		oc: 3
	}, [
		"Vehicle",
		"Walker",
		"Daemon",
		"Chaos"
	], {
		inv: 5,
		r: [w("Excruciator cannon", "ranged", 36, 3, 3, 9, -2, 3, ["Twin-linked"])],
		m: [w("Soulflayer tendrils", "melee", "Melee", 8, 3, 6, -1, 1, [])],
		ab: [a("Soul Harvest", "Each time an enemy model is destroyed by this unit, this model regains 1 lost wound (to a maximum of 3 per phase)."), a("Daemon Engine", "This model has a 5+ invulnerable save. Weapons equipped by this model have Lethal Hits.")]
	}),
	u("csm-vindicator", "Chaos Vindicator", "vehicle", 175, {
		m: 10,
		t: 11,
		sv: 2,
		w: 11,
		ld: 6,
		oc: 3
	}, [
		"Vehicle",
		"Smoke",
		"Chaos",
		"Heretic Astartes"
	], {
		r: [
			w("Demolisher cannon", "ranged", 24, "D6+3", 3, 14, -3, 4, ["Blast"]),
			w("Havoc launcher", "ranged", 48, "D6", 3, 5, 0, 1, ["Blast"]),
			w("Combi-bolter", "ranged", 24, 2, 3, 4, 0, 1, ["Rapid Fire 2"])
		],
		m: [w("Armoured tracks", "melee", "Melee", 6, 4, 7, 0, 1, [])],
		ab: [a("Demolish", "Each time this model makes an attack with its demolisher cannon that targets a unit within 12\", add 1 to the Damage characteristic."), a("Siege Shield", "This model has the Benefit of Cover against ranged attacks that target it from more than 12\" away.")]
	}),
	u("csm-helbrute", "Helbrute", "vehicle", 130, {
		m: 6,
		t: 9,
		sv: 2,
		w: 8,
		ld: 6,
		oc: 3
	}, [
		"Vehicle",
		"Walker",
		"Chaos",
		"Heretic Astartes"
	], {
		r: [
			w("Multi-melta", "ranged", 18, 2, 3, 9, -4, "D6", ["Melta 2"]),
			w("Missile launcher — krak", "ranged", 48, 1, 3, 9, -2, "D6", []),
			w("Missile launcher — frag", "ranged", 48, "D6", 3, 4, 0, 1, ["Blast"]),
			w("Heavy flamer", "ranged", 12, "D6", 0, 5, -1, 1, ["Ignores Cover", "Torrent"])
		],
		m: [w("Helbrute fist", "melee", "Melee", 5, 3, 12, -2, 3, [])],
		ab: [a("Frenzy", "Each time this model is reduced to 4 wounds remaining, until the end of the battle it has +1 Attack and +1 Strength on its melee weapons."), a("Helbrute Hatred", "Each time this model makes a melee attack, if it charged this turn, add 1 to the Hit roll.")]
	})
];
var detachments$4 = detPack("csm", [
	{
		id: "veterans",
		name: "Veterans of the Long War",
		dp: 1,
		disposition: "Priority Assets",
		tag: "veterans",
		rule: a("Bitter Veterans", "Each time a unit from this army makes an attack that targets a unit on an objective marker, add 1 to the Wound roll. Heretic Astartes Infantry units have OC +1."),
		strats: [{
			id: "csm-vet-spite",
			name: "Veterans' Spite",
			cp: 1,
			when: "Your shooting",
			text: "A Heretic Astartes unit's weapons have Devastating Wounds against a target on an objective marker until the end of the phase."
		}],
		enh: [{
			id: "csm-vet-icon",
			name: "Icon of Excess",
			points: 15,
			text: "The bearer's unit can re-roll Hit rolls of 1. If it made a Dark Pact this phase, re-roll any Hit roll."
		}]
	},
	{
		id: "pactbound",
		name: "Pactbound Zealots",
		dp: 2,
		disposition: "Take and Hold",
		tag: "pactbound",
		rule: a("Profane Zeal", "Each time a unit from this army makes a Dark Pact, it has both Lethal Hits and Sustained Hits 1. If it fails the subsequent Leadership test, it suffers D3+1 mortal wounds instead of D3."),
		strats: [{
			id: "csm-pact-apoth",
			name: "Dark Apotheosis",
			cp: 1,
			when: "Fight phase",
			text: "When a Character in this army is destroyed, roll one D6: on a 2+, you can set it back up with D3 wounds remaining more than 3\" from enemy models."
		}, {
			id: "csm-pact-focus",
			name: "Focus of Hatred",
			cp: 1,
			when: "Your shooting",
			text: "A unit that made a Dark Pact this phase can re-roll the Wound roll against the closest eligible target."
		}],
		enh: [{
			id: "csm-pact-talisman",
			name: "Talisman of Burning Blood",
			points: 15,
			text: "The bearer's melee weapons have +1 Strength and +1 Attack. The bearer's unit can Advance and charge."
		}, {
			id: "csm-pact-eye",
			name: "Eye of Tzeentch",
			points: 20,
			text: "The bearer has a 4+ invulnerable save. Once per battle, after making a Dark Pact, do not take the Leadership test."
		}]
	},
	{
		id: "slaves",
		name: "Slaves to Darkness",
		dp: 3,
		disposition: "Purge the Foe",
		tag: "slaves",
		rule: a("Marks of Chaos", "At the start of the battle, select one Mark of Chaos for your army. Khorne: melee weapons have +1 Strength. Tzeentch: ranged weapons have Lethal Hits. Nurgle: models have a 6+ Feel No Pain. Slaanesh: add 1 to Advance and Charge rolls. Chaos Undivided: re-roll Hit rolls of 1."),
		strats: [
			{
				id: "csm-slv-hate",
				name: "Eternal Hate",
				cp: 1,
				when: "Fight phase",
				text: "When a model in a Heretic Astartes unit is destroyed, it can fight before being removed. If it made a Dark Pact this phase, it can also shoot before being removed if it is your Shooting phase."
			},
			{
				id: "csm-slv-gift",
				name: "Unholy Bloodshed",
				cp: 1,
				when: "Fight phase",
				text: "A unit that charged this turn has +1 to Wound with melee attacks until the end of the phase."
			},
			{
				id: "csm-slv-pact",
				name: "Skinshift Pact",
				cp: 2,
				when: "Command phase",
				text: "A Heretic Astartes Infantry unit recovers D3 lost wounds, or you can return one destroyed model (excluding Characters) to it."
			}
		],
		enh: [
			{
				id: "csm-slv-cloak",
				name: "Intoxicating Elixir",
				points: 10,
				text: "The bearer's unit has a 5+ Feel No Pain."
			},
			{
				id: "csm-slv-blade",
				name: "Blade of the Relentless",
				points: 20,
				text: "Add 1 to the Attacks, Strength, and Damage of the bearer's melee weapons."
			},
			{
				id: "csm-slv-crown",
				name: "Crown of the Crimson King",
				points: 15,
				text: "While the bearer is leading a unit, that unit has Fight First."
			}
		]
	}
]);
var chaosSpaceMarines = {
	id: "csm",
	name: "Chaos Space Marines",
	short: "Heretic Astartes",
	allegiance: "Chaos",
	accent: "#8a2e2e",
	rule: a("Dark Pacts", "Each time a Heretic Astartes unit from your army is selected to shoot or fight, it can make a Dark Pact. If it does, until the end of the phase its weapons have either Lethal Hits or Sustained Hits 1 (declare before rolling). After the unit has resolved those attacks, it must take a Leadership test: if failed, it suffers D3 mortal wounds."),
	detachments: detachments$4,
	units: units$4
};
var guardianSpearRanged = w("Guardian spear", "ranged", 24, 2, 2, 4, -1, 2, ["Assault"]);
var guardianSpearMelee = w("Guardian spear", "melee", "Melee", 5, 2, 7, -2, 2, []);
var castellanAxeRanged = w("Castellan axe", "ranged", 24, 2, 2, 4, -1, 2, ["Assault"]);
var castellanAxeMelee = w("Castellan axe", "melee", "Melee", 4, 2, 9, -1, 3, []);
var sentinelBladeRanged = w("Sentinel blade", "ranged", 12, 2, 2, 4, -1, 2, ["Assault", "Pistol"]);
var KW_CUST = [
	"Infantry",
	"Imperium",
	"Adeptus Custodes"
];
var KW_CHAR = [
	"Infantry",
	"Character",
	"Imperium",
	"Adeptus Custodes"
];
var leadGuard = ["custodes-guard", "custodes-wardens"];
var units$3 = [
	u("custodes-trajann", "Trajann Valoris", "character", 135, {
		m: 6,
		t: 6,
		sv: 2,
		w: 7,
		ld: 5,
		oc: 2
	}, [
		"Infantry",
		"Character",
		"Epic Hero",
		"Imperium",
		"Adeptus Custodes"
	], {
		inv: 4,
		fnp: 5,
		r: [w("Eagle's Scream", "ranged", 24, 2, 2, 5, -2, 3, ["Assault"])],
		m: [w("Watcher's Axe", "melee", "Melee", 6, 2, 10, -2, 3, [])],
		ab: [
			a("Captain-General", "While leading a unit, models in that unit ignore modifiers to Ballistic Skill, Weapon Skill, and Hit rolls."),
			a("Moment Shackle", "Once per battle, at the start of the Fight phase: Watcher's Axe has Attacks 12, or this model has a 2+ invulnerable save."),
			a("Supreme Commander", "If this model is in your army, it must be your Warlord.")
		],
		lead: leadGuard
	}),
	u("custodes-blade-champion", "Blade Champion", "character", 110, {
		m: 6,
		t: 6,
		sv: 2,
		w: 6,
		ld: 6,
		oc: 2
	}, KW_CHAR, {
		inv: 4,
		m: [
			w("Vaultswords — Behemor", "melee", "Melee", 6, 2, 7, -2, 2, ["Precision"]),
			w("Vaultswords — Hurricanus", "melee", "Melee", 9, 2, 5, -1, 1, ["Sustained Hits 1"]),
			w("Vaultswords — Victus", "melee", "Melee", 5, 2, 6, -3, 3, ["Devastating Wounds"])
		],
		ab: [a("Swift Onslaught", "While leading a unit, you can re-roll Charge rolls for that unit."), a("Martial Inspiration", "Once per battle, this model's unit can charge after Advancing.")],
		lead: leadGuard
	}),
	u("custodes-shield-captain", "Shield-Captain", "character", 110, {
		m: 6,
		t: 6,
		sv: 2,
		w: 6,
		ld: 6,
		oc: 2
	}, KW_CHAR, {
		inv: 4,
		r: [
			guardianSpearRanged,
			castellanAxeRanged,
			sentinelBladeRanged
		],
		m: [
			w("Guardian spear", "melee", "Melee", 7, 2, 7, -2, 2, []),
			w("Castellan axe", "melee", "Melee", 6, 2, 9, -1, 3, []),
			w("Sentinel blade", "melee", "Melee", 7, 2, 6, -2, 1, [])
		],
		ab: [a("Master of the Stances", "Once per battle, when this unit fights, both Ka'tah Stances are active for it."), a("Strategic Mastery", "Once per battle round, target this unit with a Stratagem for 1 CP less (minimum 0).")],
		lead: leadGuard
	}),
	u("custodes-guard", "Custodian Guard", "battleline", 170, {
		m: 6,
		t: 6,
		sv: 2,
		w: 3,
		ld: 6,
		oc: 2
	}, [
		"Infantry",
		"Battleline",
		"Imperium",
		"Adeptus Custodes"
	], {
		inv: 4,
		sizes: [[4, 170], [5, 215]],
		r: [guardianSpearRanged, sentinelBladeRanged],
		m: [guardianSpearMelee, w("Sentinel blade", "melee", "Melee", 5, 2, 6, -2, 1, [])],
		ab: [a("Stand Vigil", "Re-roll Wound rolls of 1. While on an objective you control, re-roll the Wound roll instead."), a("Sentinel Storm", "Once per battle, after this unit shoots, it can shoot again.")]
	}),
	u("custodes-wardens", "Custodian Wardens", "infantry", 200, {
		m: 6,
		t: 6,
		sv: 2,
		w: 3,
		ld: 6,
		oc: 2
	}, KW_CUST, {
		inv: 4,
		sizes: [[4, 200], [5, 250]],
		r: [guardianSpearRanged, castellanAxeRanged],
		m: [guardianSpearMelee, castellanAxeMelee],
		ab: [a("Resolute Will", "While a Character leads this unit, attacks with Strength greater than this unit's Toughness are −1 to Wound."), a("Living Fortress", "Once per battle, at the start of any phase, this unit has Feel No Pain 4+ until the end of the phase.")]
	}),
	u("custodes-allarus", "Allarus Custodians", "infantry", 110, {
		m: 5,
		t: 7,
		sv: 2,
		w: 4,
		ld: 6,
		oc: 2
	}, [
		"Infantry",
		"Terminator",
		"Imperium",
		"Adeptus Custodes"
	], {
		inv: 4,
		sizes: [
			[2, 110],
			[3, 165],
			[5, 280]
		],
		r: [
			w("Balistus grenade launcher", "ranged", 18, "D6", 2, 4, -1, 1, ["Blast"]),
			guardianSpearRanged,
			castellanAxeRanged
		],
		m: [guardianSpearMelee, castellanAxeMelee],
		ab: [a("Slayers of Tyrants", "Re-roll Wound rolls against Character, Monster, or Vehicle units."), a("From Golden Light", "Once per battle, at the end of your opponent's turn, if unengaged, place this unit into Strategic Reserves.")]
	}),
	u("custodes-prosecutors", "Prosecutors", "infantry", 45, {
		m: 6,
		t: 3,
		sv: 3,
		w: 1,
		ld: 6,
		oc: 2
	}, [
		"Infantry",
		"Imperium",
		"Anathema Psykana",
		"Sisters of Silence"
	], {
		sizes: [
			[4, 45],
			[5, 50],
			[10, 85]
		],
		r: [w("Boltgun", "ranged", 24, 1, 3, 4, 0, 1, ["Rapid Fire 1"])],
		m: [w("Close combat weapon", "melee", "Melee", 2, 3, 3, 0, 1, [])],
		ab: [a("Daughters of the Abyss", "Feel No Pain 3+ against Psychic attacks and mortal wounds."), a("Purity of Execution", "Ranged attacks that target a Psyker have Precision and Devastating Wounds.")]
	}),
	u("custodes-vertus", "Vertus Praetors", "mounted", 145, {
		m: 12,
		t: 7,
		sv: 2,
		w: 5,
		ld: 6,
		oc: 2
	}, [
		"Mounted",
		"Fly",
		"Imperium",
		"Adeptus Custodes"
	], {
		inv: 4,
		sizes: [[2, 145], [3, 215]],
		r: [w("Salvo launcher", "ranged", 24, 1, 2, 10, -3, "D6+1", ["Twin-linked"]), w("Vertus hurricane bolter", "ranged", 18, 3, 2, 4, -1, 2, ["Rapid Fire 3", "Twin-linked"])],
		m: [w("Interceptor lance", "melee", "Melee", 5, 2, 7, -2, 2, ["Lance"])],
		ab: [a("Turbo-boost", "When this unit Advances, add 6\" instead of rolling."), a("Quicksilver Execution", "Once per battle, after a Normal or Advance move, pick one Infantry unit it moved over. Roll one D6 per model: each 2+ inflicts 2 mortal wounds.")]
	}),
	u("custodes-caladius", "Caladius Grav-tank", "vehicle", 210, {
		m: 10,
		t: 11,
		sv: 2,
		w: 14,
		ld: 6,
		oc: 4
	}, [
		"Vehicle",
		"Fly",
		"Frame",
		"Imperium",
		"Adeptus Custodes"
	], {
		inv: 5,
		r: [w("Twin iliastus accelerator cannon", "ranged", 48, 4, 2, 10, -1, 3, ["Rapid Fire 4", "Twin-linked"]), w("Twin arachnus heavy blaze cannon", "ranged", 48, 4, 2, 12, -3, "D6+2", ["Twin-linked"])],
		m: [w("Armoured hull", "melee", "Melee", 4, 4, 6, 0, 1, [])],
		ab: [a("Advanced Firepower", "Iliastus attacks against non-Monster, non-Vehicle units have Lethal Hits. Arachnus attacks against Monsters or Vehicles have Lethal Hits.")]
	})
];
var detachments$3 = detPack("custodes", [
	{
		id: "talons",
		name: "Talons of the Emperor",
		dp: 3,
		disposition: "Take and Hold",
		tag: "talons",
		rule: a("Revered Companions", "Anathema Psykana units grant Adeptus Custodes within 6\" Feel No Pain 5+ against Psychic attacks and mortal wounds. Adeptus Custodes grant Anathema Psykana within 6\" +1 to Hit."),
		strats: [{
			id: "custodes-tal-hunt",
			name: "Hunt as One",
			cp: 1,
			when: "Your movement",
			text: "Up to two Adeptus Custodes units can shoot and charge after Falling Back (the second must be Anathema Psykana within 6\")."
		}, {
			id: "custodes-tal-sever",
			name: "Empyric Severance",
			cp: 1,
			when: "Opponent shooting or Fight",
			text: "One Adeptus Custodes unit and one Anathema Psykana unit within 6\" have Feel No Pain 4+ against Psychic attacks and mortal wounds."
		}],
		enh: [{
			id: "custodes-tal-gift",
			name: "Gift of Terran Artifice",
			points: 15,
			text: "Add 1 to the Wound roll for the bearer's melee attacks."
		}, {
			id: "custodes-tal-aegis",
			name: "Aegis Projector",
			points: 20,
			text: "Once per turn, the first failed save for the bearer's unit changes that attack's Damage to 0."
		}]
	},
	{
		id: "shield",
		name: "Shield Host",
		dp: 2,
		disposition: "Purge the Foe",
		tag: "shield",
		rule: a("Martial Mastery", "At the start of each battle round, choose one until the next: Adeptus Custodes melee scores Critical Hits on 5+, or improve the AP of those melee weapons by 1."),
		strats: [{
			id: "custodes-sh-alchemy",
			name: "Arcane Genetic Alchemy",
			cp: 1,
			when: "Any phase",
			text: "After a mortal wound is allocated to an Adeptus Custodes model, that unit has Feel No Pain 4+ against mortal wounds this phase."
		}, {
			id: "custodes-sh-avenge",
			name: "Avenge the Fallen",
			cp: 1,
			when: "Fight phase",
			text: "An Adeptus Custodes unit below Starting Strength adds 1 to melee Attacks (2 if Below Half-strength)."
		}],
		enh: [{
			id: "custodes-sh-mantle",
			name: "Auric Mantle",
			points: 15,
			text: "Shield-Captain or Blade Champion only. Add 2 to the bearer's Wounds."
		}, {
			id: "custodes-sh-armouries",
			name: "From the Hall of Armouries",
			points: 20,
			text: "Shield-Captain only. Add 1 to the Strength and Damage of the bearer's melee weapons."
		}]
	},
	{
		id: "lions",
		name: "Lions of the Emperor",
		dp: 2,
		disposition: "Disruption",
		tag: "lions",
		rule: a("Against All Odds", "Adeptus Custodes units (excluding Vehicles) add 1 to Hit and Wound while no other friendly unit is within 6\"."),
		strats: [{
			id: "custodes-li-unleash",
			name: "Unleash the Lions",
			cp: 1,
			when: "Your command",
			text: "Split one Allarus Custodians unit on the battlefield into separate 1-model units."
		}, {
			id: "custodes-li-eagle",
			name: "Swift as the Eagle",
			cp: 1,
			when: "Opponent shooting",
			text: "After an enemy unit shoots, one targeted Adeptus Custodes unit (excluding Vehicles) can make a D6\" Normal move."
		}],
		enh: [{
			id: "custodes-li-praes",
			name: "Praesidius",
			points: 25,
			text: "The bearer has Lone Operative and Stealth."
		}, {
			id: "custodes-li-super",
			name: "Superior Creation",
			points: 25,
			text: "The first time the bearer is destroyed, on a 2+ set it back up unengaged with full wounds."
		}]
	},
	{
		id: "auric",
		name: "Auric Champions",
		dp: 2,
		disposition: "Priority Assets",
		tag: "auric",
		rule: a("Assemblage of Might", "At the start of your Command phase, select one enemy unit. Adeptus Custodes Character models add 1 to Wound rolls against that unit until your next Command phase."),
		strats: [{
			id: "custodes-au-slayer",
			name: "Slayer of Champions",
			cp: 1,
			when: "Any phase",
			text: "After a Character unit destroys the Assemblage target, select a new target. If the destroyed unit was a Character, gain 1 CP."
		}, {
			id: "custodes-au-auspice",
			name: "The Emperor's Auspice",
			cp: 1,
			when: "Opponent shooting or Fight",
			text: "Character models in a targeted Adeptus Custodes Character unit have Feel No Pain 4+ this phase."
		}],
		enh: [{
			id: "custodes-au-blade",
			name: "Blade Imperator",
			points: 25,
			text: "After the bearer's unit ends a Charge, roll one D6 for one engaged enemy: 4+ inflicts D3 mortal wounds."
		}, {
			id: "custodes-au-phil",
			name: "Martial Philosopher",
			points: 30,
			text: "The bearer's unit can shoot and charge after Falling Back."
		}]
	}
]);
var custodes = {
	id: "custodes",
	name: "Adeptus Custodes",
	short: "The Ten Thousand",
	allegiance: "Imperium",
	accent: "#c9a227",
	rule: a("Martial Ka'tah", "At the start of the Fight phase, select one stance until the end of the phase: Kaptaris (−1 to Hit melee attacks that target your Adeptus Custodes units) or Dacatarai (Adeptus Custodes melee weapons have Sustained Hits 1)."),
	detachments: detachments$3,
	units: units$3
};
var AA = "Adeptus Astartes";
var KW_CHAR_TAC = [
	"Infantry",
	"Character",
	"Grenades",
	"Imperium",
	"Tacticus",
	AA
];
var KW_BL_TAC = [
	"Infantry",
	"Battleline",
	"Grenades",
	"Imperium",
	"Tacticus",
	AA
];
var KW_INF_TAC = [
	"Infantry",
	"Grenades",
	"Imperium",
	"Tacticus",
	AA
];
var KW_GRAVIS = [
	"Infantry",
	"Grenades",
	"Imperium",
	"Gravis",
	AA
];
var KW_PHOBOS_BL = [
	"Infantry",
	"Battleline",
	"Grenades",
	"Imperium",
	"Phobos",
	"Smoke",
	AA
];
var KW_PHOBOS = [
	"Infantry",
	"Grenades",
	"Imperium",
	"Phobos",
	AA
];
var KW_WALKER = [
	"Vehicle",
	"Walker",
	"Smoke",
	"Imperium",
	AA
];
var KW_VEH = [
	"Vehicle",
	"Smoke",
	"Imperium",
	AA
];
var deepStrike$1 = a("Deep Strike", "This unit can make an Ingress move from Reserves more than 8\" from enemy models.");
var infiltrate$1 = a("Infiltrators", "This unit can be set up anywhere on the battlefield more than 9\" from enemy models.");
var support = a("Support", "This model can be attached to a unit that already has a Leader.");
var objSec = a("Objective Secured", "This unit can perform Actions while within Engagement Range of enemy units.");
var stormBolter = w("Storm bolter", "ranged", 24, 2, 3, 5, 0, 1, ["Rapid Fire 2"]);
var armouredHull$1 = w("Armoured hull", "melee", "Melee", 3, 4, 6, 0, 1, []);
var fragstorm = w("Fragstorm grenade launcher", "ranged", 18, "D6", 3, 4, 0, 1, ["Blast"]);
var ironhail = w("Ironhail heavy stubber", "ranged", 36, 3, 3, 4, 0, 1, ["Rapid Fire 3"]);
var mcBoltRifle = w("Master-crafted bolt rifle", "ranged", 24, 2, 2, 5, -1, 2, ["Assault", "Heavy"]);
var tacticusLeaders = [
	"sm-intercessors",
	"sm-assault-intercessors",
	"sm-jump-intercessors",
	"sm-sternguard",
	"sm-hellblasters",
	"sm-infernus",
	"sm-bladeguard",
	"sm-company-heroes"
];
var s = {
	m: 6,
	t: 5,
	sv: 3,
	w: 2,
	ld: 6,
	oc: 1
};
var sChar = {
	m: 6,
	t: 5,
	sv: 3,
	w: 4,
	ld: 6,
	oc: 1
};
var sGravis = {
	m: 5,
	t: 6,
	sv: 3,
	w: 3,
	ld: 6,
	oc: 1
};
var units$2 = [
	u("sm-captain", "Captain", "character", 80, {
		m: 6,
		t: 5,
		sv: 3,
		w: 5,
		ld: 6,
		oc: 1
	}, KW_CHAR_TAC, {
		inv: 4,
		r: [mcBoltRifle, heavyBoltPistol],
		m: [powerFist],
		ab: [
			a("Rites of Battle", "While leading a unit, weapons in that unit have Sustained Hits 1."),
			a("Transhuman Strategist", "If this model is your Warlord and on the battlefield, you gain 1 CP at the start of your Command phase."),
			a("Doctrinal Authority", "Once per battle round, in your Command phase, select one Combat Doctrine. It is active for this model's unit until your next Command phase, in addition to the army Doctrine.")
		],
		lead: tacticusLeaders
	}),
	u("sm-lieutenant", "Lieutenant", "character", 55, sChar, KW_CHAR_TAC, {
		r: [w("Master-crafted bolter", "ranged", 24, 2, 2, 5, -1, 2, []), heavyBoltPistol],
		m: [powerWeapon],
		ab: [a("Tactical Precision", "While leading a unit, weapons in that unit have Lethal Hits."), support],
		lead: [
			"sm-intercessors",
			"sm-assault-intercessors",
			"sm-sternguard",
			"sm-hellblasters",
			"sm-bladeguard"
		]
	}),
	u("sm-librarian", "Librarian", "character", 70, sChar, [
		"Infantry",
		"Character",
		"Psyker",
		"Grenades",
		"Imperium",
		AA
	], {
		inv: 4,
		r: [w("Smite", "ranged", 24, "D6", 3, 5, -1, "D3", ["Psychic"])],
		m: [forceWeapon],
		ab: [a("Psyker Level 1", "Once per turn, use Veil of Time (this unit is eligible to shoot and charge after Advancing) or Force Dome (+1 to this unit's Save). On a 1 when you do, this unit is Battle-shocked."), a("Mental Fortress", "This unit has a 4+ invulnerable save against Psychic attacks.")],
		lead: [
			"sm-intercessors",
			"sm-sternguard",
			"sm-hellblasters"
		]
	}),
	u("sm-chaplain", "Chaplain", "character", 75, {
		m: 6,
		t: 5,
		sv: 3,
		w: 4,
		ld: 5,
		oc: 1
	}, KW_CHAR_TAC, {
		inv: 4,
		r: [w("Absolvor bolt pistol", "ranged", 18, 1, 2, 5, -1, 2, ["Pistol"])],
		m: [w("Crozius arcanum", "melee", "Melee", 5, 2, 6, -1, 2, [])],
		ab: [a("Litany of Hate", "While leading a unit, melee weapons in that unit have +1 to Wound."), a("Spiritual Leader", "This unit can re-roll Battle-shock tests.")],
		lead: [
			"sm-assault-intercessors",
			"sm-bladeguard",
			"sm-jump-intercessors"
		]
	}),
	u("sm-apothecary", "Apothecary", "character", 40, sChar, KW_CHAR_TAC, {
		r: [boltPistol],
		m: [closeCombat],
		ab: [a("Narthecium", "At the end of your Movement phase, return one destroyed model (excluding Characters) to this unit with its full wounds remaining."), support],
		lead: [
			"sm-intercessors",
			"sm-hellblasters",
			"sm-sternguard",
			"sm-assault-intercessors"
		]
	}),
	u("sm-intercessors", "Intercessor Squad", "battleline", 85, {
		...s,
		oc: 2
	}, KW_BL_TAC, {
		sizes: [[5, 85], [10, 170]],
		r: [
			boltRifle,
			boltRifleFocused,
			boltPistol
		],
		m: [closeCombat],
		ab: [objSec]
	}),
	u("sm-assault-intercessors", "Assault Intercessor Squad", "battleline", 80, {
		...s,
		oc: 2
	}, KW_BL_TAC, {
		sizes: [[5, 80], [10, 160]],
		r: [heavyBoltPistol],
		m: [astartesChainsword],
		ab: [a("Shock Assault", "Each time this unit piles in, it can move an extra 3\"."), a("On the Charge", "If this unit charged this turn, until the end of the Fight phase add 1 to the Strength and AP of melee weapons in this unit (including attached Characters).")]
	}),
	u("sm-jump-intercessors", "Jump Pack Intercessor Squad", "infantry", 95, {
		m: 12,
		t: 5,
		sv: 3,
		w: 2,
		ld: 6,
		oc: 1
	}, [
		"Infantry",
		"Jump Pack",
		"Fly",
		"Grenades",
		"Imperium",
		"Tacticus",
		AA
	], {
		sizes: [[5, 95], [10, 190]],
		r: [heavyBoltPistol],
		m: [astartesChainsword],
		ab: [a("Hammer of Wrath", "After this unit ends a Charge move, roll one D6 for each model in it: each 4+ inflicts 1 mortal wound on one engaged enemy."), deepStrike$1]
	}),
	u("sm-infiltrators", "Infiltrator Squad", "battleline", 100, {
		m: 8,
		t: 4,
		sv: 3,
		w: 2,
		ld: 6,
		oc: 1
	}, KW_PHOBOS_BL, {
		sizes: [[5, 100], [10, 200]],
		r: [w("Marksman bolt carbine", "ranged", 24, 2, 3, 5, 0, 1, [])],
		m: [closeCombat],
		ab: [a("Omni-scrambler", "Enemy units that set up as Reinforcements cannot be set up within 12\" of this unit."), infiltrate$1]
	}),
	u("sm-heavy-intercessors", "Heavy Intercessor Squad", "battleline", 110, {
		...sGravis,
		oc: 2
	}, [
		"Infantry",
		"Battleline",
		"Grenades",
		"Imperium",
		"Gravis",
		AA
	], {
		sizes: [[5, 110], [10, 220]],
		r: [w("Heavy bolt rifle", "ranged", 30, 2, 3, 5, -1, 2, [
			"Assault",
			"Heavy",
			"Rapid Fire 1"
		])],
		m: [closeCombat],
		ab: [a("Unyielding", "While this unit is within range of an objective you control, add 1 to its Save characteristic.")]
	}),
	u("sm-scouts", "Scout Squad", "infantry", 70, {
		m: 6,
		t: 4,
		sv: 4,
		w: 2,
		ld: 6,
		oc: 1
	}, [
		"Infantry",
		"Grenades",
		"Imperium",
		"Scout",
		"Smoke",
		AA
	], {
		sizes: [[5, 70], [10, 140]],
		r: [w("Boltgun", "ranged", 24, 2, 3, 5, 0, 1, ["Rapid Fire 1"]), boltPistol],
		m: [closeCombat],
		ab: [infiltrate$1, a("Guerrilla Tactics", "This unit is eligible to perform Actions in a turn in which it Advanced or Fell Back.")]
	}),
	u("sm-terminators", "Terminator Squad", "infantry", 190, {
		m: 5,
		t: 6,
		sv: 2,
		w: 3,
		ld: 6,
		oc: 1
	}, [
		"Infantry",
		"Imperium",
		"Terminator",
		AA
	], {
		inv: 4,
		sizes: [[5, 190], [10, 380]],
		r: [stormBolter],
		m: [powerFist],
		ab: [a("Fury of the First", "Each time a model in this unit makes an attack that targets a unit within 9\", improve the AP of that attack by 1."), deepStrike$1]
	}),
	u("sm-sternguard", "Sternguard Veteran Squad", "infantry", 100, s, KW_INF_TAC, {
		sizes: [[5, 100], [10, 200]],
		r: [w("Artificer firearms — anti-infantry", "ranged", 24, 2, 3, 5, -1, 2, ["Lethal Hits", "Devastating Wounds"]), w("Artificer firearms — anti-vehicle", "ranged", 24, 2, 3, 8, -2, 2, [
			"Heavy",
			"Anti-Vehicle 4+",
			"Anti-Monster 4+"
		])],
		m: [closeCombat],
		ab: [a("Bolter Drill", "Unmodified Hit rolls of 6 with ranged attacks score one additional hit.")]
	}),
	u("sm-hellblasters", "Hellblaster Squad", "infantry", 115, s, KW_INF_TAC, {
		sizes: [[5, 115], [10, 230]],
		r: [w("Plasma incinerator", "ranged", 24, 2, 3, 7, -2, 1, ["Rapid Fire 1"]), w("Plasma incinerator — supercharge", "ranged", 24, 2, 3, 8, -3, 2, ["Hazardous", "Rapid Fire 1"])],
		m: [closeCombat],
		ab: [a("Plasma Discipline", "Add 1 to Hazardous tests made for plasma weapons in this unit.")]
	}),
	u("sm-eradicators", "Eradicator Squad", "infantry", 100, sGravis, KW_GRAVIS, {
		sizes: [[3, 100], [6, 200]],
		r: [w("Melta rifle", "ranged", 18, 1, 3, 10, -4, "D6", ["Heavy", "Melta 2"])],
		m: [closeCombat],
		ab: [a("Total Obliteration", "Each time this unit targets a Monster or Vehicle, add 1 to the Hit roll, treat the weapon's Strength as 12, and you can re-roll the Damage roll.")]
	}),
	u("sm-aggressors", "Aggressor Squad", "infantry", 110, sGravis, KW_GRAVIS, {
		sizes: [[3, 110], [6, 220]],
		r: [w("Auto boltstorm gauntlets", "ranged", 18, 3, 3, 5, -1, 1, ["Twin-linked", "Pistol"]), fragstorm],
		m: [w("Power fists", "melee", "Melee", 3, 3, 8, -2, 2, ["Twin-linked"])],
		ab: [a("Close-quarters Firepower", "Ranged weapons in this unit have Assault while targets are within 12\"."), a("Point-blank", "Add 1 to the Strength of ranged attacks that target the closest eligible enemy within 9\".")]
	}),
	u("sm-infernus", "Infernus Squad", "infantry", 90, s, KW_INF_TAC, {
		sizes: [[5, 90], [10, 180]],
		r: [w("Pyreblaster", "ranged", 12, "D6", 0, 5, 0, 1, ["Ignores Cover", "Torrent"])],
		m: [closeCombat],
		ab: [a("Incinerate", "Targets of this unit's shooting do not receive the Benefit of Cover.")]
	}),
	u("sm-inceptors", "Inceptor Squad", "infantry", 110, {
		m: 10,
		t: 6,
		sv: 3,
		w: 3,
		ld: 6,
		oc: 1
	}, [
		"Infantry",
		"Fly",
		"Jump Pack",
		"Imperium",
		"Gravis",
		AA
	], {
		sizes: [[3, 110], [6, 220]],
		r: [w("Assault bolters", "ranged", 18, 3, 3, 5, -1, 2, ["Assault", "Twin-linked"])],
		m: [closeCombat],
		ab: [a("Meteoric Descent", "This unit can make an Ingress move from Reserves more than 8\" from enemy models. The first time it shoots after doing so, add 1 to Hit rolls."), a("Drop Back", "At the end of your opponent's Fight phase, if this unit is not engaged it can be placed into Strategic Reserves.")]
	}),
	u("sm-bladeguard", "Bladeguard Veteran Squad", "infantry", 90, {
		m: 6,
		t: 5,
		sv: 3,
		w: 3,
		ld: 6,
		oc: 1
	}, KW_INF_TAC, {
		inv: 4,
		sizes: [[3, 90], [6, 180]],
		r: [heavyBoltPistol],
		m: [w("Master-crafted power weapon", "melee", "Melee", 4, 3, 5, -2, 2, [])],
		ab: [a("Bladeguard", "This unit has a 4+ invulnerable save. Subtract 1 from the Attacks characteristic of melee weapons that target this unit.")]
	}),
	u("sm-company-heroes", "Company Heroes", "infantry", 125, {
		m: 6,
		t: 5,
		sv: 3,
		w: 4,
		ld: 6,
		oc: 2
	}, KW_INF_TAC, {
		sizes: [[4, 125]],
		r: [w("Master-crafted bolt rifle", "ranged", 24, 2, 3, 5, -1, 2, ["Assault", "Heavy"]), w("Heavy bolter", "ranged", 36, 3, 3, 5, -1, 2, [
			"Heavy",
			"Sustained Hits 1",
			"Rapid Fire 2"
		])],
		m: [powerWeapon, closeCombat],
		ab: [a("Honour Guard", "Each time an attack targets this unit, subtract 1 from the Wound roll."), a("Company Ancient", "At the end of your Movement phase, if this unit is within range of an objective you do not control, you take control of it.")]
	}),
	u("sm-eliminators", "Eliminator Squad", "infantry", 85, {
		m: 8,
		t: 4,
		sv: 3,
		w: 2,
		ld: 6,
		oc: 1
	}, KW_PHOBOS, {
		sizes: [[3, 85]],
		r: [w("Bolt sniper rifle", "ranged", 36, 1, 3, 5, -2, 3, ["Heavy", "Precision"])],
		m: [closeCombat],
		ab: [a("Stealth", "Each time a ranged attack targets this unit, subtract 1 from the Hit roll. This is not cumulative with the Benefit of Cover."), infiltrate$1]
	}),
	u("sm-outriders", "Outrider Squad", "mounted", 80, {
		m: 12,
		t: 6,
		sv: 3,
		w: 4,
		ld: 6,
		oc: 2
	}, [
		"Mounted",
		"Grenades",
		"Imperium",
		AA
	], {
		sizes: [[3, 80], [6, 160]],
		r: [w("Twin bolt rifle", "ranged", 24, 2, 3, 5, -1, 1, ["Twin-linked"]), heavyBoltPistol],
		m: [astartesChainsword],
		ab: [a("Turbo-boost", "When this unit Advances, add 6\" instead of rolling."), a("Shock Cavalry", "If this unit charged this turn, until the end of the Fight phase its melee weapons have Sustained Hits 1 and +1 Damage.")]
	}),
	u("sm-redemptor", "Redemptor Dreadnought", "vehicle", 210, {
		m: 8,
		t: 10,
		sv: 2,
		w: 12,
		ld: 6,
		oc: 4
	}, KW_WALKER, {
		r: [
			w("Macro plasma incinerator", "ranged", 36, "D6+1", 3, 8, -3, 2, ["Blast"]),
			w("Onslaught gatling cannon", "ranged", 24, 8, 3, 5, 0, 1, []),
			w("Icarus rocket pod", "ranged", 24, "D3", 3, 8, -1, 2, ["Anti-Fly 2+"])
		],
		m: [w("Redemptor fist", "melee", "Melee", 5, 3, 12, -2, "D6+1", [])],
		ab: [a("Duty Eternal", "Each time an attack is allocated to this model, subtract 1 from the Damage.")]
	}),
	u("sm-ballistus", "Ballistus Dreadnought", "vehicle", 140, {
		m: 8,
		t: 10,
		sv: 2,
		w: 10,
		ld: 6,
		oc: 3
	}, KW_WALKER, {
		r: [
			w("Ballistus lascannon", "ranged", 48, 2, 3, 12, -3, "D3+3", []),
			w("Ballistus missile launcher — krak", "ranged", 48, 2, 3, 10, -2, "D6", []),
			w("Ballistus missile launcher — frag", "ranged", 48, "2D6", 3, 4, 0, 1, ["Blast"])
		],
		m: [w("Armoured feet", "melee", "Melee", 4, 3, 6, 0, 1, [])],
		ab: [a("Ballistus Targeting", "Re-roll Hit rolls with ranged attacks that target a Monster or Vehicle.")]
	}),
	u("sm-gladiator-lancer", "Gladiator Lancer", "vehicle", 160, {
		m: 10,
		t: 10,
		sv: 3,
		w: 11,
		ld: 6,
		oc: 3
	}, KW_VEH, {
		r: [
			w("Lancer laser destroyer", "ranged", 72, 2, 3, 14, -4, "D6+3", ["Heavy"]),
			fragstorm,
			ironhail
		],
		m: [armouredHull$1],
		ab: [a("Aquilon Optics", "Re-roll Hit rolls with the Lancer laser destroyer.")]
	}),
	u("sm-impulsor", "Impulsor", "transport", 80, {
		m: 12,
		t: 9,
		sv: 3,
		w: 11,
		ld: 6,
		oc: 2
	}, [
		"Vehicle",
		"Transport",
		"Dedicated Transport",
		"Smoke",
		"Imperium",
		AA
	], {
		r: [stormBolter, ironhail],
		m: [armouredHull$1],
		ab: [a("Assault Vehicle", "Units can disembark after this Transport has Advanced."), a("Orbital Array", "This model has Scouts 6\".")],
		transport: 6
	})
];
var detachments$2 = detPack("sm", [
	{
		id: "gladius",
		name: "Gladius Task Force",
		dp: 3,
		disposition: "Priority Assets",
		tag: "gladius",
		rule: a("Codex Flexibility", "You can select one Combat Doctrine a second time this battle. Captains in this Detachment can activate an additional Doctrine for their unit in your Command phase."),
		strats: [
			{
				id: "sm-gla-armour",
				name: "Armour of Contempt",
				cp: 1,
				when: "Opponent shooting or Fight",
				text: "Until the end of the phase, worsen the AP of attacks that target one Adeptus Astartes unit by 1."
			},
			{
				id: "sm-gla-squad",
				name: "Squad Tactics",
				cp: 1,
				when: "Your movement",
				text: "One Adeptus Astartes unit can Fall Back and still shoot and charge this turn."
			},
			{
				id: "sm-gla-honour",
				name: "Honour the Chapter",
				cp: 1,
				when: "Fight phase",
				text: "A unit that charged this turn has +1 to Wound with melee attacks until the end of the phase."
			}
		],
		enh: [
			{
				id: "sm-gla-artificer",
				name: "Artificer Armour",
				points: 10,
				text: "Bearer has a 2+ Save and a 4+ invulnerable save."
			},
			{
				id: "sm-gla-relic",
				name: "Relic of the Chapter",
				points: 20,
				text: "Once per battle, the bearer can use a Stratagem for 0 CP."
			},
			{
				id: "sm-gla-blade",
				name: "The Honour Vehement",
				points: 15,
				text: "Add 1 to the Attacks and Strength of the bearer's melee weapons (add 1 AP as well while Assault Doctrine is active)."
			},
			{
				id: "sm-gla-ancient",
				name: "Chapter Ancient",
				points: 15,
				text: "Upgrade. Add 1 to the Attacks of melee weapons in the bearer's unit.",
				upgrade: true
			}
		]
	},
	{
		id: "assault-brethren",
		name: "Assault Brethren",
		dp: 1,
		disposition: "Purge the Foe",
		tag: "Doctrines",
		rule: a("Second Assault", "You can select the Assault Combat Doctrine one additional time this battle. While Assault Doctrine is active for an Adeptus Astartes unit, its melee weapons have Lance and improve AP by 1."),
		strats: [{
			id: "sm-ab-death",
			name: "Only in Death",
			cp: 1,
			when: "Fight phase",
			text: "When a model in one Adeptus Astartes unit is destroyed, it can fight before being removed."
		}],
		enh: [{
			id: "sm-ab-sustained",
			name: "Fury of Guilliman",
			points: 20,
			text: "While leading an Infantry unit, melee weapons in that unit have Sustained Hits 1 against non-Monster, non-Vehicle targets."
		}]
	},
	{
		id: "tactical-brethren",
		name: "Tactical Brethren",
		dp: 1,
		disposition: "Take and Hold",
		tag: "Doctrines",
		rule: a("Second Tactical", "You can select the Tactical Combat Doctrine one additional time this battle. While Tactical Doctrine is active for an Adeptus Astartes Infantry unit, it can make a 6\" reactive move when an enemy ends a move within 9\"."),
		strats: [{
			id: "sm-tb-suppress",
			name: "Suppressing Fire",
			cp: 1,
			when: "Your shooting",
			text: "After one Adeptus Astartes unit shoots, one target is −1 to Hit until the start of your next turn."
		}],
		enh: [{
			id: "sm-tb-student",
			name: "Student of the Codex",
			points: 20,
			text: "Captain model only. The Tactical Doctrine is always active for the bearer's unit in addition to any other Doctrine."
		}]
	},
	{
		id: "devastator-brethren",
		name: "Devastator Brethren",
		dp: 1,
		disposition: "Disruption",
		tag: "Doctrines",
		rule: a("Second Devastator", "You can select the Devastator Combat Doctrine one additional time this battle. While Devastator Doctrine is active for an Adeptus Astartes unit, its ranged weapons have Ignores Cover and improve AP by 1."),
		strats: [{
			id: "sm-db-return",
			name: "Return Fire",
			cp: 1,
			when: "Opponent shooting",
			text: "After an enemy unit destroys one model in an Adeptus Astartes unit, that unit can shoot as if it were your Shooting phase (it can only target that enemy)."
		}],
		enh: [{
			id: "sm-db-behemoth",
			name: "Veteran of Behemoth",
			points: 25,
			text: "While leading a unit, ranged weapons in that unit have Lethal Hits. Re-roll Advance rolls for that unit while Devastator Doctrine is active."
		}]
	},
	{
		id: "tacticus-attack",
		name: "Tacticus Attack Force",
		dp: 1,
		disposition: "Purge the Foe",
		tag: "Tacticus",
		rule: a("Shock Doctrine", "Tacticus units from your army are eligible to shoot and charge in a turn in which they Advanced. Assault Intercessor Squads add 1 to Charge rolls."),
		strats: [{
			id: "sm-ta-push",
			name: "Forward Push",
			cp: 1,
			when: "Your movement",
			text: "One Tacticus unit can Advance 6\" instead of rolling."
		}],
		enh: [{
			id: "sm-ta-champion",
			name: "Linebreaker",
			points: 15,
			text: "Add 2 to the Attacks of the bearer's melee weapons."
		}]
	},
	{
		id: "tacticus-firestorm",
		name: "Tacticus Firestorm Force",
		dp: 1,
		disposition: "Priority Assets",
		tag: "Tacticus",
		rule: a("Sustained Volley", "Rapid Fire weapons equipped by Tacticus units from your army are treated as having Rapid Fire at their full range, not half range."),
		strats: [{
			id: "sm-tf-cqb",
			name: "Close-quarters Bolters",
			cp: 1,
			when: "Your shooting",
			text: "Non-Blast ranged weapons in one Tacticus unit have Ignores Cover and, if the target is within 12\", Lethal Hits."
		}],
		enh: [{
			id: "sm-tf-redeploy",
			name: "Drop Beacon",
			points: 20,
			text: "After both sides deploy, redeploy the bearer's unit (and this model)."
		}]
	},
	{
		id: "phobos-shadow",
		name: "Phobos Shadow Force",
		dp: 1,
		disposition: "Reconnaissance",
		tag: "Phobos",
		rule: a("Shadow Doctrine", "Phobos units from your army have Stealth. Once per turn, one Phobos unit can make a Normal move of D6\" after it shoots, remaining eligible to be Hidden."),
		strats: [{
			id: "sm-ps-ghost",
			name: "Ghost Tactics",
			cp: 1,
			when: "Your shooting",
			text: "One Phobos unit can shoot while Hidden without revealing itself."
		}],
		enh: [{
			id: "sm-ps-shroud",
			name: "Shroud Halo",
			points: 15,
			text: "The bearer's unit is always eligible to be Hidden, even after shooting."
		}]
	},
	{
		id: "phobos-shock",
		name: "Phobos Shock Force",
		dp: 1,
		disposition: "Disruption",
		tag: "Phobos",
		rule: a("From the Shadows", "The first time a Phobos unit from your army is selected to shoot or fight in a turn in which it started Hidden, re-roll Wound rolls for those attacks."),
		strats: [{
			id: "sm-pk-ambush",
			name: "Ambush Strike",
			cp: 1,
			when: "Your shooting or Fight",
			text: "One Phobos unit that was Hidden this turn has +1 Strength and Lethal Hits until the end of the phase."
		}],
		enh: [{
			id: "sm-pk-react",
			name: "Prey-sight",
			points: 15,
			text: "When an enemy ends a move within 9\" of the bearer, the bearer's unit can make a 6\" Normal move."
		}]
	},
	{
		id: "gravis-line",
		name: "Gravis Linebreaker Force",
		dp: 1,
		disposition: "Purge the Foe",
		tag: "Gravis",
		rule: a("Unstoppable Advance", "Gravis units from your army can Advance and still shoot. Add 1 to Advance and Charge rolls made for Gravis units."),
		strats: [{
			id: "sm-gl-crash",
			name: "Armoured Onslaught",
			cp: 1,
			when: "Your charge",
			text: "After a Gravis unit ends a Charge move, roll 6 D6: each 4+ inflicts 1 mortal wound on one engaged enemy."
		}],
		enh: [{
			id: "sm-gl-bulk",
			name: "Indomitable",
			points: 20,
			text: "The bearer's unit has a 5+ Feel No Pain while it is below Starting Strength."
		}]
	},
	{
		id: "gravis-siege",
		name: "Gravis Siege Force",
		dp: 1,
		disposition: "Take and Hold",
		tag: "Gravis",
		rule: a("Living Bastion", "Each time an attack targets a Gravis unit from your army that is within range of an objective you control, subtract 1 from the Wound roll. That unit has OC +1."),
		strats: [{
			id: "sm-gs-hold",
			name: "Hold the Line",
			cp: 1,
			when: "Opponent shooting or Fight",
			text: "A Gravis unit on an objective has a 5+ Feel No Pain until the end of the phase."
		}],
		enh: [{
			id: "sm-gs-fort",
			name: "Siege Plate",
			points: 15,
			text: "The bearer has a 2+ Save. The bearer's unit can shoot while performing an Action."
		}]
	},
	{
		id: "terminator-storm",
		name: "Terminator Storm Force",
		dp: 1,
		disposition: "Take and Hold",
		tag: "terminator",
		rule: a("First Company", "Terminator units from your army have Deep Strike. Each time a Terminator unit is set up on the battlefield from Reserves, until the end of the turn it has Lethal Hits."),
		strats: [{
			id: "sm-ts-tele",
			name: "Teleport Homer",
			cp: 1,
			when: "Your movement",
			text: "One Terminator unit can be placed into Strategic Reserves, even if engaged (roll a D6: on a 1 it suffers 3 mortal wounds)."
		}],
		enh: [{
			id: "sm-ts-crux",
			name: "Crux Terminatus",
			points: 20,
			text: "The bearer has a 4+ Feel No Pain. Terminator only."
		}]
	},
	{
		id: "stormlance",
		name: "Stormlance Task Force",
		dp: 1,
		disposition: "Reconnaissance",
		tag: "stormlance",
		rule: a("Lightning Assault", "Mounted and Vehicle units from your army with the Fly or Speeder keyword add 2\" to their Move. Mounted units can Advance and charge."),
		strats: [{
			id: "sm-sl-boost",
			name: "Full Throttle",
			cp: 1,
			when: "Your movement",
			text: "One Mounted unit Advances 6\" instead of rolling and is −1 to Hit against ranged attacks until your next turn."
		}],
		enh: [{
			id: "sm-sl-hunt",
			name: "Hunter's Eye",
			points: 15,
			text: "The bearer's unit has Scouts 9\"."
		}]
	},
	{
		id: "ironclad",
		name: "Ironclad Champions",
		dp: 1,
		disposition: "Priority Assets",
		tag: "ironclad",
		rule: a("Ancient Wrath", "Walker units from your army have a 5+ invulnerable save. Each time a Walker is targeted, if the attack's Damage is greater than 1, subtract 1 from that Damage."),
		strats: [{
			id: "sm-ic-duty",
			name: "Duty Eternal",
			cp: 1,
			when: "Any phase",
			text: "Until the end of the phase, one Walker has a 2+ Save against Damage 1 attacks and Feel No Pain 5+ against all other attacks."
		}],
		enh: [{
			id: "sm-ic-machine",
			name: "Machine Empathy",
			points: 15,
			text: "Techmarine only. One friendly Walker within 3\" regains 3 lost wounds in your Command phase instead of 1."
		}]
	},
	{
		id: "gauntlet",
		name: "Gauntlet Task Force",
		dp: 1,
		disposition: "Disruption",
		tag: "gauntlet",
		rule: a("Armoured Spearhead", "After a Transport from your army shoots, select one enemy it hit. Until the end of the turn, Adeptus Astartes units that disembarked from that Transport this turn have Sustained Hits 1 against that enemy."),
		strats: [{
			id: "sm-ga-disembark",
			name: "Shock Disembarkation",
			cp: 1,
			when: "Your movement",
			text: "A unit that disembarked this phase can still charge, even if its Transport Advanced."
		}],
		enh: [{
			id: "sm-ga-pilot",
			name: "Tank Ace",
			points: 20,
			text: "The bearer (or their Transport, if embarked) re-rolls one Hit and one Wound roll with ranged attacks each time it shoots."
		}]
	},
	{
		id: "ironstorm",
		name: "Ironstorm Spearhead",
		dp: 1,
		disposition: "Priority Assets",
		tag: "ironstorm",
		rule: a("Targeting Augurs", "Each time a non-Walker Vehicle from your army is selected to shoot, you can re-roll one Hit roll and one Wound roll."),
		strats: [{
			id: "sm-is-salvo",
			name: "Mercy is Weakness",
			cp: 1,
			when: "Your shooting",
			text: "One Vehicle's ranged weapons have Lethal Hits and Ignores Cover until the end of the phase."
		}],
		enh: [{
			id: "sm-is-heavy",
			name: "Targeter Optics",
			points: 15,
			text: "Ranged weapons equipped by the bearer's unit have Heavy."
		}, {
			id: "sm-is-ion",
			name: "Ion Shielding",
			points: 25,
			text: "Vehicle model only. The bearer has a 5+ invulnerable save and regains 1 lost wound in each of your Command phases."
		}]
	}
]);
var spaceMarines = {
	id: "sm",
	name: "Space Marines",
	short: "Adeptus Astartes",
	allegiance: "Imperium",
	accent: "#3b6ea5",
	rule: a("Combat Doctrines", "At the start of your Command phase, select one Combat Doctrine. Until your next Command phase it applies to all Adeptus Astartes units from your army. Devastator: ranged weapons have Assault. Tactical: eligible to shoot and charge after Falling Back. Assault: eligible to charge after Advancing. You can select each Doctrine once per battle (a second time if a rule allows it). A unit can only have one Doctrine active unless a rule says otherwise."),
	detachments: detachments$2,
	units: units$2
};
var pulsePistol = w("Pulse pistol", "ranged", 12, 1, 4, 5, 0, 1, ["Pistol"]);
var battlesuitFists = w("Battlesuit fists", "melee", "Melee", 3, 5, 5, 0, 1, []);
var armouredHull = w("Armoured hull", "melee", "Melee", 3, 5, 6, 0, 1, []);
var KW_SUIT = [
	"Vehicle",
	"Walker",
	"Fly",
	"Battlesuit",
	"T'au"
];
var KW_INF$1 = [
	"Infantry",
	"Battleline",
	"Grenades",
	"T'au"
];
var cc = w("Close combat weapons", "melee", "Melee", 1, 5, 3, 0, 1, []);
var seeker = w("Seeker missile", "ranged", 48, 1, 4, 14, -3, "D6+1", ["One Shot"]);
var sms = w("Smart missile system", "ranged", 30, 3, 4, 5, 0, 1, ["Indirect Fire", "Twin-linked"]);
var units$1 = [
	u("tau-coldstar", "Commander in Coldstar Battlesuit", "character", 95, {
		m: 12,
		t: 5,
		sv: 3,
		w: 7,
		ld: 7,
		oc: 2
	}, [
		"Vehicle",
		"Walker",
		"Character",
		"Fly",
		"Battlesuit",
		"T'au"
	], {
		inv: 4,
		r: [
			w("High-output burst cannon", "ranged", 18, 8, 2, 6, -1, 1, ["Assault"]),
			w("Missile pod", "ranged", 30, 2, 2, 7, -1, 2, []),
			w("Fusion blaster", "ranged", 12, 1, 2, 9, -4, "D6", ["Melta 2"])
		],
		m: [battlesuitFists],
		ab: [a("Coldstar Array", "This model can Advance and still shoot. When it Advances, add 8\" instead of rolling."), a("Battlesuit Support", "Friendly Battlesuit units within 6\" of this model can re-roll Hit rolls of 1 with ranged attacks.")]
	}),
	u("tau-shadowsun", "Commander Shadowsun", "character", 100, {
		m: 10,
		t: 4,
		sv: 3,
		w: 7,
		ld: 6,
		oc: 1
	}, [
		"Infantry",
		"Character",
		"Epic Hero",
		"Fly",
		"Battlesuit",
		"Stealth",
		"T'au"
	], {
		inv: 5,
		r: [w("Flechette blasters", "ranged", 18, 6, 2, 3, 0, 1, ["Assault", "Pistol"]), w("High-energy fusion blaster", "ranged", 18, 1, 2, 9, -4, "D6+2", ["Melta 3"])],
		m: [w("Close combat weapons", "melee", "Melee", 4, 3, 3, 0, 1, [])],
		ab: [
			a("Advanced Stealth Field", "This model has Stealth and Lone Operative (not visible, and immune to Indirect Fire, beyond 12\"). It can be set up anywhere on the battlefield more than 9\" from enemy models."),
			a("Kauyon Master", "Once per battle, at the start of your Shooting phase, until the end of the phase friendly T'au units within 6\" have Sustained Hits 1 and can re-roll the Hit roll."),
			a("Command-link", "This model can be an Observer for For the Greater Good without forgoing its own shooting.")
		]
	}),
	u("tau-breachers", "Breacher Team", "battleline", 90, {
		m: 6,
		t: 3,
		sv: 4,
		w: 1,
		ld: 7,
		oc: 2
	}, KW_INF$1, {
		sizes: [[10, 90]],
		r: [
			w("Pulse blaster — close range", "ranged", 10, 2, 3, 6, -1, 1, ["Assault"]),
			w("Pulse blaster — standard", "ranged", 14, 2, 4, 5, 0, 1, ["Assault"]),
			pulsePistol
		],
		m: [cc],
		ab: [a("Breach and Clear", "Each time this unit makes a ranged attack that targets a unit within range of an objective marker, add 1 to the Wound roll."), a("Bonded Crew", "This unit can perform Actions while within Engagement Range of enemy units.")]
	}),
	u("tau-strike-team", "Strike Team", "battleline", 75, {
		m: 6,
		t: 3,
		sv: 4,
		w: 1,
		ld: 7,
		oc: 2
	}, KW_INF$1, {
		sizes: [[10, 75]],
		r: [w("Pulse rifle", "ranged", 30, 1, 4, 5, 0, 1, ["Rapid Fire 1"]), pulsePistol],
		m: [cc],
		ab: [a("Steady Volley", "If this unit Remained Stationary this turn, pulse rifles in this unit have Heavy and Lethal Hits."), a("Fire Warrior Cadre", "If this unit is destroyed, any objective markers it controlled remain under your control until an enemy unit controls them.")]
	}),
	u("tau-stealth", "Stealth Battlesuits", "infantry", 85, {
		m: 8,
		t: 4,
		sv: 3,
		w: 2,
		ld: 7,
		oc: 1
	}, [
		"Infantry",
		"Fly",
		"Battlesuit",
		"Stealth",
		"T'au"
	], {
		sizes: [[3, 85], [6, 170]],
		r: [w("Burst cannon", "ranged", 18, 4, 4, 5, 0, 1, ["Assault"]), w("Fusion blaster", "ranged", 12, 1, 4, 8, -4, "D6", ["Melta 2"])],
		m: [battlesuitFists],
		ab: [a("Stealth Field", "Each time a ranged attack targets this unit, subtract 1 from the Hit roll. This is not cumulative with the Benefit of Cover. This unit can be set up anywhere on the battlefield more than 9\" from enemy models."), a("Homing Beacon", "Once per battle, in your Movement phase, one friendly Battlesuit unit arriving from Reserves can be set up more than 6\" from enemy models instead of 9\", provided it is set up within 6\" of this unit.")]
	}),
	u("tau-crisis-fireknife", "Crisis Fireknife Battlesuits", "vehicle", 150, {
		m: 10,
		t: 5,
		sv: 3,
		w: 4,
		ld: 7,
		oc: 2
	}, KW_SUIT, {
		sizes: [[3, 150], [6, 300]],
		r: [w("Missile pod", "ranged", 30, 2, 4, 7, -1, 2, ["Twin-linked"]), w("Plasma rifle", "ranged", 24, 1, 4, 8, -3, 3, [])],
		m: [battlesuitFists],
		ab: [a("Deep Strike", "This unit can make an Ingress move from Reserves more than 8\" from enemy models."), a("Fireknife Protocols", "Each time this unit shoots, if it is Guided, its plasma rifles have Lethal Hits and its missile pods have Sustained Hits 1.")]
	}),
	u("tau-broadside", "Broadside Battlesuits", "vehicle", 90, {
		m: 5,
		t: 6,
		sv: 2,
		w: 8,
		ld: 7,
		oc: 2
	}, [
		"Vehicle",
		"Walker",
		"Battlesuit",
		"T'au"
	], {
		sizes: [
			[1, 90],
			[2, 180],
			[3, 270]
		],
		r: [
			w("Heavy rail rifle", "ranged", 60, 2, 4, 12, -4, "D6+1", ["Heavy", "Devastating Wounds"]),
			sms,
			seeker
		],
		m: [w("Crushing bulk", "melee", "Melee", 3, 4, 6, 0, 1, [])],
		ab: [a("Stable Firing Platform", "Each time this unit Remains Stationary, you can re-roll Hit rolls and Wound rolls of 1 with its heavy rail rifles."), a("Advanced Targeting", "Ranged weapons in this unit have Heavy. Attacks with the heavy rail rifle that target a Monster or Vehicle have +1 to Wound.")]
	}),
	u("tau-riptide", "Riptide Battlesuit", "vehicle", 190, {
		m: 10,
		t: 9,
		sv: 2,
		w: 14,
		ld: 7,
		oc: 4
	}, KW_SUIT, {
		inv: 4,
		r: [
			w("Heavy burst cannon", "ranged", 36, 12, 4, 6, -1, 2, []),
			w("Ion accelerator — standard", "ranged", 72, "D6+1", 4, 7, -2, 3, ["Blast"]),
			w("Ion accelerator — overcharge", "ranged", 72, "D6+1", 4, 8, -3, 4, ["Blast", "Hazardous"]),
			sms
		],
		m: [w("Riptide fists", "melee", "Melee", 5, 4, 8, -1, 2, [])],
		ab: [a("Nova Reactor", "Once per battle round, at the start of your Shooting phase, this model can activate its Nova Reactor: until the end of the phase its heavy burst cannon has Sustained Hits 1 and it has a 4+ invulnerable save, then roll 2D6 — on a 2 it suffers 3 mortal wounds."), a("Battlesuit Shield Generator", "This model has a 4+ invulnerable save.")]
	}),
	u("tau-hammerhead", "Hammerhead Gunship", "vehicle", 145, {
		m: 12,
		t: 10,
		sv: 3,
		w: 14,
		ld: 7,
		oc: 3
	}, [
		"Vehicle",
		"Fly",
		"Smoke",
		"T'au"
	], {
		r: [
			w("Railgun", "ranged", 72, 1, 4, 20, -5, "D6+6", ["Heavy", "Devastating Wounds"]),
			w("Accelerator burst cannon", "ranged", 18, 4, 4, 6, -1, 1, []),
			seeker
		],
		m: [armouredHull],
		ab: [a("Targeting Array", "Each time this model makes an attack with its railgun, you can re-roll the Hit roll. If the target is a Monster or Vehicle, you can also re-roll the Wound roll."), a("Hover Tank", "This model can move over terrain and other models as if they were not there.")]
	}),
	u("tau-devilfish", "Devilfish", "transport", 85, {
		m: 12,
		t: 9,
		sv: 3,
		w: 13,
		ld: 7,
		oc: 2
	}, [
		"Vehicle",
		"Transport",
		"Dedicated Transport",
		"Fly",
		"Smoke",
		"T'au"
	], {
		r: [
			w("Burst cannon", "ranged", 18, 4, 4, 5, 0, 1, []),
			seeker,
			w("Twin pulse carbine", "ranged", 20, 2, 4, 5, 0, 1, ["Assault", "Twin-linked"])
		],
		m: [armouredHull],
		ab: [a("Assault Boat", "Units can disembark from this Transport after it has Advanced. Units that disembark this way can still shoot."), a("Hover Transport", "This model can move over terrain and other models as if they were not there.")],
		transport: 12
	})
];
var detachments$1 = detPack("tau", [
	{
		id: "retaliation",
		name: "Retaliation Cadre",
		dp: 1,
		disposition: "Disruption",
		tag: "retaliation",
		rule: a("Close-range Cadre", "Battlesuit units in this army have +2\" to their Move characteristic. Each time a Battlesuit unit shoots at a target within 12\", add 1 to the Strength of those attacks."),
		strats: [{
			id: "tau-ret-volley",
			name: "Point-Blank Volley",
			cp: 1,
			when: "Your shooting",
			text: "A Battlesuit unit's ranged weapons have Assault and Pistol until the end of the phase. If the target is within 9\", those weapons also have Lethal Hits."
		}],
		enh: [{
			id: "tau-ret-stim",
			name: "Onager Gauntlet",
			points: 15,
			text: "The bearer has a melee weapon: Onager gauntlet, Melee, A4, WS3, S12, AP−3, D3. Its unit can charge after Advancing."
		}]
	},
	{
		id: "montka",
		name: "Mont'ka",
		dp: 2,
		disposition: "Purge the Foe",
		tag: "montka",
		rule: a("Killing Blow", "During the first three battle rounds, ranged weapons equipped by T'au units in this army have Assault and Lethal Hits, and T'au units can Advance and still shoot."),
		strats: [{
			id: "tau-mk-coord",
			name: "Coordinate to Fire",
			cp: 1,
			when: "Your shooting",
			text: "Select one enemy unit. Until the end of the phase, each time a T'au unit shoots at that target, it counts as Guided even if no Observer was selected."
		}, {
			id: "tau-mk-strike",
			name: "Pulse Onslaught",
			cp: 2,
			when: "Your shooting",
			text: "A T'au unit that Advanced this turn can re-roll Hit rolls and Wound rolls of 1. Pulse weapons in that unit have Sustained Hits 1."
		}],
		enh: [{
			id: "tau-mk-exemplar",
			name: "Exemplar of the Mont'ka",
			points: 20,
			text: "Once per battle, at the start of your Shooting phase, friendly T'au units within 9\" of the bearer have +1 to Hit until the end of the phase."
		}, {
			id: "tau-mk-fusion",
			name: "Thermoneutronic Projector",
			points: 15,
			text: "The bearer's ranged weapons have the Melta 2 keyword (or improve existing Melta by 1) and Ignores Cover."
		}]
	},
	{
		id: "kauyon",
		name: "Kauyon",
		dp: 3,
		disposition: "Take and Hold",
		tag: "kauyon",
		rule: a("Patient Hunter", "From the third battle round onwards, ranged weapons equipped by T'au units in this army have Sustained Hits 1 and you can re-roll Hit rolls of 1. T'au Infantry units have Stealth while they are within range of an objective marker you control."),
		strats: [
			{
				id: "tau-kau-ambush",
				name: "Patient Ambush",
				cp: 1,
				when: "Opponent movement",
				text: "When an enemy unit ends a move within 9\" of a T'au unit that is wholly within 3\" of a terrain feature, that T'au unit can shoot at it as if it were your Shooting phase (it still counts as Overwatch, but hits on 5+)."
			},
			{
				id: "tau-kau-hold",
				name: "Hold What You Have Taken",
				cp: 1,
				when: "Opponent shooting",
				text: "A T'au Infantry unit on an objective marker is −1 to be Hit and has a 5+ Feel No Pain until the end of the phase."
			},
			{
				id: "tau-kau-guide",
				name: "Focused Fire",
				cp: 1,
				when: "Your shooting",
				text: "A Guided unit's ranged weapons have Ignores Cover and Lethal Hits until the end of the phase."
			}
		],
		enh: [
			{
				id: "tau-kau-puretide",
				name: "Puretide Engram Neurochip",
				points: 15,
				text: "Once per battle round, the bearer's unit can be the target of a Stratagem for 0 CP."
			},
			{
				id: "tau-kau-shield",
				name: "Shield Generator",
				points: 20,
				text: "The bearer has a 4+ invulnerable save. Models in the bearer's unit have a 5+ invulnerable save."
			},
			{
				id: "tau-kau-marker",
				name: "Precision of the Hunter",
				points: 10,
				text: "The bearer's unit can be an Observer without forgoing its own shooting. Ranged weapons in that unit have Precision."
			}
		]
	}
]);
var tauEmpire = {
	id: "tau",
	name: "T'au Empire",
	short: "T'au",
	allegiance: "Xenos",
	accent: "#c4a574",
	rule: a("For the Greater Good", "In your Shooting phase, T'au units can act as Observers or become Guided. Select one Observer unit that is eligible to shoot and one Guided unit. Until the end of the phase, the Guided unit's ranged weapons have +1 to Hit and Ignores Cover against a target visible to the Observer, but the Observer cannot shoot this phase. A unit can only be Guided once per phase."),
	detachments: detachments$1,
	units: units$1
};
var fleshborer = w("Fleshborer", "ranged", 18, 1, 4, 5, 0, 1, ["Assault"]);
var devourer = w("Devourer", "ranged", 18, 5, 4, 4, 0, 1, ["Assault"]);
var clawsTeeth = w("Chitinous claws and teeth", "melee", "Melee", 1, 4, 3, 0, 1, []);
var stingerSalvo = w("Stinger salvoes", "ranged", 24, 8, 3, 5, 0, 1, []);
var heavyVenom = w("Heavy venom cannon", "ranged", 36, "D3", 2, 9, -2, 3, ["Blast"]);
var stranglethorn = w("Stranglethorn cannon", "ranged", 36, "D6+1", 2, 7, -1, 2, ["Blast"]);
var bonesword = w("Monstrous bonesword and lash whip", "melee", "Melee", 6, 2, 9, -2, 3, ["Twin-linked"]);
var fleshHooks = w("Flesh hooks", "ranged", 8, 2, 3, 5, -1, 1, ["Assault"]);
var lictorClaws = w("Lictor claws and talons", "melee", "Melee", 6, 2, 7, -2, 2, ["Precision"]);
var powerfulLimbs = w("Powerful limbs", "melee", "Melee", 3, 4, 7, -1, 2, []);
var scythingTalons = w("Scything talons", "melee", "Melee", 4, 3, 5, -1, 1, []);
var bioWeapons = w("Bio-weapons", "melee", "Melee", 6, 3, 5, -2, 1, ["Twin-linked"]);
var loneOp = a("Lone Operative", "This unit is not visible to enemy models more than 12\" away.");
var deepStrike = a("Deep Strike", "This unit can make an Ingress move from Reserves more than 8\" from enemy models.");
var infiltrate = a("Infiltrators", "This unit can be set up anywhere on the battlefield more than 9\" from enemy models.");
var willOfHive = a("Will of the Hive Mind", "Once per battle round, you can target this model's unit with a Stratagem for 0 CP.");
var KW_SYN = [
	"Monster",
	"Character",
	"Psyker",
	"Synapse",
	"Tyranids"
];
var KW_VANGUARD = [
	"Infantry",
	"Great Devourer",
	"Tyranids",
	"Vanguard Invader"
];
var KW_SWARM = [
	"Infantry",
	"Battleline",
	"Tyranids",
	"Endless Multitude"
];
var KW_INF = ["Infantry", "Tyranids"];
var KW_MON = ["Monster", "Tyranids"];
var sizes10 = (p10, p20) => [[10, p10], [20, p20]];
var sizes36 = (p3, p6) => [[3, p3], [6, p6]];
var units = [
	u("nids-swarmlord", "The Swarmlord", "character", 210, {
		m: 8,
		t: 10,
		sv: 2,
		w: 10,
		ld: 7,
		oc: 3
	}, [
		...KW_SYN,
		"Epic Hero",
		"Hive Tyrant"
	], {
		inv: 4,
		r: [w("Synaptic pulse", "ranged", 18, "D6+3", 0, 5, -1, 2, ["Psychic", "Torrent"])],
		m: [w("Bone sabres", "melee", "Melee", 8, 2, 9, -2, 3, ["Twin-linked"])],
		ab: [
			a("Hive Commander", "At the start of your Command phase, if this model is on the battlefield, you gain 1 CP."),
			a("Malign Presence", "Once per turn, when an enemy unit within 12\" is targeted by a Stratagem, that use costs 1 CP more."),
			willOfHive
		],
		lead: ["nids-tyrant-guard"]
	}),
	u("nids-hive-tyrant", "Hive Tyrant", "character", 195, {
		m: 8,
		t: 10,
		sv: 2,
		w: 10,
		ld: 7,
		oc: 3
	}, KW_SYN, {
		inv: 4,
		r: [heavyVenom, stranglethorn],
		m: [bonesword],
		ab: [willOfHive, a("Onslaught", "Friendly Tyranids units within 6\" have Assault and Lethal Hits on ranged weapons.")],
		lead: ["nids-tyrant-guard"]
	}),
	u("nids-winged-tyrant", "Winged Hive Tyrant", "character", 185, {
		m: 12,
		t: 9,
		sv: 2,
		w: 10,
		ld: 7,
		oc: 3
	}, [
		...KW_SYN,
		"Fly",
		"Vanguard Invader",
		"Hive Tyrant"
	], {
		inv: 4,
		r: [heavyVenom, stranglethorn],
		m: [bonesword],
		ab: [
			willOfHive,
			deepStrike,
			a("Onslaught", "Friendly Tyranids units within 6\" have Assault and Lethal Hits on ranged weapons. Enemy units within 6\" are −1 to Charge.")
		]
	}),
	u("nids-neurotyrant", "Neurotyrant", "character", 130, {
		m: 6,
		t: 8,
		sv: 4,
		w: 9,
		ld: 7,
		oc: 3
	}, [
		"Monster",
		"Character",
		"Fly",
		"Psyker",
		"Synapse",
		"Tyranids"
	], {
		inv: 4,
		r: [w("Psychic scream", "ranged", 18, "D6+3", 3, 6, -1, 1, ["Psychic", "Devastating Wounds"])],
		m: [w("Neurotyrant claws", "melee", "Melee", 6, 3, 5, -1, 1, [])],
		ab: [a("Shadow Node", "When you use Shadow in the Warp, enemy units take that Battle-shock test at −1."), a("Synaptic Amplification", "Two friendly Tyranids units within 12\" always count as being within Synapse Range.")],
		lead: [
			"nids-zoanthropes",
			"nids-neurogaunts",
			"nids-tyrant-guard"
		]
	}),
	u("nids-tervigon", "Tervigon", "character", 160, {
		m: 8,
		t: 11,
		sv: 2,
		w: 16,
		ld: 7,
		oc: 5
	}, KW_SYN, {
		r: [stingerSalvo],
		m: [w("Massive crushing claws", "melee", "Melee", 4, 4, 12, -3, "D6+1", [])],
		ab: [a("Spawn Termagants", "At the end of your Movement phase, set up a new 10-model Termagants unit wholly within 6\" of this model and more than 1\" from enemy models."), a("Brood Progenitor", "Termagants units within 6\" have Lethal Hits on ranged weapons.")]
	}),
	u("nids-broodlord", "Broodlord", "character", 80, {
		m: 8,
		t: 5,
		sv: 4,
		w: 6,
		ld: 7,
		oc: 1
	}, KW_VANGUARD.concat([
		"Character",
		"Psyker",
		"Synapse"
	]), {
		inv: 4,
		m: [w("Broodlord claws and talons", "melee", "Melee", 6, 2, 6, -2, 2, ["Twin-linked"])],
		ab: [a("Hypnotic Gaze", "While leading a unit, melee weapons in that unit have Lethal Hits. Melee attacks that target this unit are −1 to Hit."), infiltrate],
		lead: ["nids-genestealers"]
	}),
	u("nids-deathleaper", "Deathleaper", "character", 80, {
		m: 8,
		t: 6,
		sv: 3,
		w: 7,
		ld: 7,
		oc: 1
	}, [
		"Infantry",
		"Character",
		"Epic Hero",
		"Great Devourer",
		"Tyranids",
		"Vanguard Invader",
		"Lictor"
	], {
		inv: 4,
		r: [fleshHooks],
		m: [w("Lictor claws and talons", "melee", "Melee", 7, 2, 7, -2, 2, ["Precision"])],
		ab: [
			loneOp,
			infiltrate,
			a("Fear of the Unseen", "At the start of the Fight phase, one enemy unit within 6\" must take a Battle-shock test."),
			a("Stealth", "Ranged attacks that target this unit are −1 to Hit.")
		]
	}),
	u("nids-old-one-eye", "Old One Eye", "character", 140, {
		m: 8,
		t: 9,
		sv: 2,
		w: 9,
		ld: 8,
		oc: 3
	}, [
		"Monster",
		"Character",
		"Epic Hero",
		"Tyranids"
	], {
		m: [w("Claws and talons — strike", "melee", "Melee", 6, 3, 14, -3, "D6+1", []), w("Claws and talons — sweep", "melee", "Melee", 12, 3, 6, -1, 1, [])],
		ab: [a("Alpha Leader", "While leading a unit, that unit can re-roll Hit rolls."), a("Berserk Rampage", "This model regains D3 lost wounds at the start of your Command phase.")],
		lead: ["nids-carnifexes"]
	}),
	u("nids-red-terror", "The Red Terror", "character", 130, {
		m: 10,
		t: 8,
		sv: 3,
		w: 9,
		ld: 8,
		oc: 3
	}, [
		"Monster",
		"Character",
		"Epic Hero",
		"Tyranids",
		"Vanguard Invader",
		"Burrower"
	], {
		m: [w("Scything talons", "melee", "Melee", 6, 2, 7, -2, 2, []), w("Prehensile maw", "melee", "Melee", 2, 2, 5, 0, 3, [
			"Anti-Infantry 3+",
			"Devastating Wounds",
			"Extra Attacks"
		])],
		ab: [deepStrike, a("Swallow Whole", "Each time this model destroys an enemy Infantry, Mounted, or Beast model, it regains D3+2 lost wounds.")]
	}),
	u("nids-parasite", "Parasite of Mortrex", "character", 70, {
		m: 12,
		t: 5,
		sv: 4,
		w: 5,
		ld: 8,
		oc: 1
	}, KW_VANGUARD.concat([
		"Character",
		"Fly",
		"Synapse"
	]), {
		m: [scythingTalons, w("Barbed ovipositor", "melee", "Melee", 1, 2, 3, -2, 3, ["Anti-Infantry 3+", "Extra Attacks"])],
		ab: [
			loneOp,
			deepStrike,
			a("Implant Parasite", "Each time this model destroys an enemy Infantry model, you can set up a Ripper Swarms unit of 1 model within 3\" of this model.")
		]
	}),
	u("nids-winged-prime", "Winged Tyranid Prime", "character", 65, {
		m: 12,
		t: 5,
		sv: 4,
		w: 6,
		ld: 7,
		oc: 1
	}, [
		"Infantry",
		"Character",
		"Fly",
		"Synapse",
		"Tyranids",
		"Vanguard Invader"
	], {
		r: [w("Prime talons", "ranged", 12, 2, 2, 5, -1, 1, ["Assault", "Pistol"])],
		m: [w("Prime talons", "melee", "Melee", 6, 2, 6, -1, 2, [])],
		ab: [a("Alpha Warrior", "While leading a unit, weapons in that unit have Sustained Hits 1."), deepStrike],
		lead: [
			"nids-warriors-melee",
			"nids-warriors-ranged",
			"nids-gargoyles"
		]
	}),
	u("nids-prime", "Tyranid Prime with Lash Whip", "character", 75, {
		m: 10,
		t: 5,
		sv: 3,
		w: 6,
		ld: 7,
		oc: 1
	}, [
		"Infantry",
		"Character",
		"Synapse",
		"Tyranids"
	], {
		m: [w("Bonesword and lash whip", "melee", "Melee", 6, 2, 6, -2, 2, ["Twin-linked"])],
		ab: [a("Alpha Warrior", "While leading a unit, weapons in that unit have Sustained Hits 1.")],
		lead: [
			"nids-warriors-melee",
			"nids-warriors-ranged",
			"nids-termagants",
			"nids-hormagaunts"
		]
	}),
	u("nids-malanthrope", "Malanthrope", "character", 75, {
		m: 6,
		t: 5,
		sv: 4,
		w: 10,
		ld: 7,
		oc: 3
	}, [
		"Infantry",
		"Character",
		"Fly",
		"Synapse",
		"Tyranids"
	], {
		m: [w("Grasping tail", "melee", "Melee", 6, 3, 5, -1, 1, ["Anti-Infantry 2+"])],
		ab: [a("Prey Adaptation", "Venomthrope units within 6\" have Sustained Hits 1, Lance, or Lethal Hits (choose one at the start of the battle)."), a("Spore Cloud", "Friendly Tyranids units (excluding Monsters) within 6\" have Stealth. All friendly Tyranids units within 6\" have the Benefit of Cover.")],
		lead: ["nids-venomthropes"]
	}),
	u("nids-hyper-raveners", "Hyperadapted Raveners", "character", 165, {
		m: 10,
		t: 5,
		sv: 4,
		w: 3,
		ld: 7,
		oc: 1
	}, [
		"Infantry",
		"Character",
		"Synapse",
		"Tyranids",
		"Vanguard Invader",
		"Burrower"
	], {
		sizes: [[5, 165]],
		r: [w("Thorax web spitter", "ranged", 18, "D6+3", 0, 6, -1, 1, [
			"Assault",
			"Ignores Cover",
			"Torrent"
		])],
		m: [w("Hyperadapted claws", "melee", "Melee", 5, 3, 5, -1, 1, [
			"Anti-Monster 5+",
			"Anti-Vehicle 5+",
			"Sustained Hits 1"
		])],
		ab: [deepStrike, a("Tunnel Network", "Friendly Tyranids units can Ingress onto a Tunnel marker more than 8\" from enemy models.")],
		lead: ["nids-raveners"]
	}),
	u("nids-lictor", "Lictor", "character", 60, {
		m: 8,
		t: 6,
		sv: 4,
		w: 6,
		ld: 7,
		oc: 1
	}, [...KW_VANGUARD, "Lictor"], {
		r: [fleshHooks],
		m: [lictorClaws],
		ab: [
			loneOp,
			infiltrate,
			a("Feeder Tendrils", "Gain 1 CP each time this model destroys an enemy Character. Once per battle round this model can Rapid Ingress for 0 CP.")
		]
	}),
	u("nids-neurolictor", "Neurolictor", "character", 80, {
		m: 8,
		t: 5,
		sv: 4,
		w: 7,
		ld: 7,
		oc: 1
	}, [
		"Infantry",
		"Character",
		"Psyker",
		"Synapse",
		"Tyranids",
		"Vanguard Invader",
		"Neurolictor"
	], {
		inv: 4,
		r: [w("Psychostatic disruption", "ranged", 12, "D6", 3, 4, 0, 1, ["Psychic", "Devastating Wounds"])],
		m: [w("Neurolictor claws", "melee", "Melee", 5, 3, 6, -1, 2, ["Precision"])],
		ab: [
			loneOp,
			infiltrate,
			a("Neuroparasite", "Enemy units within 6\" are −1 to Hit. This unit has Stealth.")
		]
	}),
	u("nids-termagants", "Termagants", "battleline", 60, {
		m: 6,
		t: 3,
		sv: 5,
		w: 1,
		ld: 8,
		oc: 2
	}, KW_SWARM, {
		sizes: sizes10(60, 110),
		r: [fleshborer, devourer],
		m: [clawsTeeth],
		ab: [a("Skulking Horrors", "This unit can shoot after Falling Back. Stealth while within a terrain objective.")]
	}),
	u("nids-hormagaunts", "Hormagaunts", "battleline", 70, {
		m: 10,
		t: 3,
		sv: 5,
		w: 1,
		ld: 8,
		oc: 2
	}, KW_SWARM, {
		sizes: sizes10(70, 120),
		m: [w("Hormagaunt talons", "melee", "Melee", 3, 4, 3, -1, 1, [])],
		ab: [a("Bounding Leap", "Eligible to charge after Advancing. Extra 3\" when it piles in or consolidates.")]
	}),
	u("nids-gargoyles", "Gargoyles", "battleline", 80, {
		m: 12,
		t: 3,
		sv: 6,
		w: 1,
		ld: 8,
		oc: 2
	}, [
		"Infantry",
		"Battleline",
		"Fly",
		"Tyranids",
		"Endless Multitude",
		"Vanguard Invader"
	], {
		sizes: sizes10(80, 155),
		r: [fleshborer],
		m: [w("Blinding venom", "melee", "Melee", 1, 4, 3, 0, 1, [])],
		ab: [a("Winged Swarm", "Ingress from Reserves more than 8\" from enemy models. Eligible to shoot and charge after Falling Back.")]
	}),
	u("nids-neurogaunts", "Neurogaunts", "infantry", 45, {
		m: 6,
		t: 3,
		sv: 6,
		w: 1,
		ld: 8,
		oc: 1
	}, [
		"Infantry",
		"Tyranids",
		"Endless Multitude"
	], {
		sizes: [[11, 45], [22, 90]],
		m: [clawsTeeth],
		ab: [a("Neurocytes", "While within Synapse Range of a friendly Tyranids unit (excluding Neurogaunts), this unit has the Synapse keyword.")]
	}),
	u("nids-genestealers", "Genestealers", "infantry", 75, {
		m: 8,
		t: 4,
		sv: 5,
		w: 2,
		ld: 7,
		oc: 1
	}, KW_VANGUARD, {
		inv: 5,
		sizes: [[5, 75], [10, 140]],
		m: [w("Genestealer claws and talons", "melee", "Melee", 4, 2, 4, -2, 1, [])],
		ab: [a("Scouts 8\"", "This unit can make a 8\" Scout move before the first turn."), a("Vanguard Predator", "Re-roll Hit rolls of 1. If the target is on an objective, re-roll Wound rolls of 1 as well.")]
	}),
	u("nids-warriors-melee", "Tyranid Warriors with Melee Bio-weapons", "infantry", 75, {
		m: 6,
		t: 5,
		sv: 4,
		w: 3,
		ld: 7,
		oc: 2
	}, [
		"Infantry",
		"Synapse",
		"Tyranids"
	], {
		sizes: sizes36(75, 150),
		m: [bioWeapons],
		ab: [a("Adaptable Predators", "Eligible to shoot and charge after Falling Back."), a("Preservation Imperative", "Re-roll saving throws of 1.")]
	}),
	u("nids-warriors-ranged", "Tyranid Warriors with Ranged Bio-weapons", "infantry", 60, {
		m: 6,
		t: 5,
		sv: 4,
		w: 3,
		ld: 7,
		oc: 2
	}, [
		"Infantry",
		"Synapse",
		"Tyranids"
	], {
		sizes: sizes36(60, 120),
		r: [
			devourer,
			w("Deathspitter", "ranged", 24, 3, 4, 5, -1, 1, []),
			w("Venom cannon", "ranged", 36, "D3", 4, 9, -2, 2, ["Blast"])
		],
		m: [bioWeapons],
		ab: [a("Adaptable Predators", "Eligible to shoot and charge after Falling Back.")]
	}),
	u("nids-raveners", "Raveners", "infantry", 125, {
		m: 10,
		t: 5,
		sv: 4,
		w: 3,
		ld: 8,
		oc: 1
	}, [
		"Infantry",
		"Tyranids",
		"Vanguard Invader",
		"Burrower"
	], {
		sizes: [[5, 125]],
		r: [w("Thorax web spitter", "ranged", 18, "D6", 4, 4, 0, 1, ["Torrent"])],
		m: [w("Ravener claws and talons", "melee", "Melee", 5, 3, 5, -1, 1, [])],
		ab: [a("Death From Below", "Ingress from Reserves more than 8\" from enemy models, then place a Tunnel marker."), a("Tunnel Network", "Friendly Tyranids units can Ingress onto a Tunnel marker more than 8\" from enemy models.")]
	}),
	u("nids-leapers", "Von Ryan's Leapers", "infantry", 55, {
		m: 10,
		t: 5,
		sv: 4,
		w: 3,
		ld: 8,
		oc: 1
	}, KW_VANGUARD, {
		inv: 6,
		sizes: sizes36(55, 105),
		m: [w("Leaper's talons", "melee", "Melee", 6, 3, 5, -1, 1, [])],
		ab: [loneOp, a("Pouncing Leap", "Fight First. Set up more than 9\" from enemy models. Stealth.")]
	}),
	u("nids-barbgaunts", "Barbgaunts", "infantry", 55, {
		m: 6,
		t: 4,
		sv: 4,
		w: 2,
		ld: 8,
		oc: 1
	}, KW_INF, {
		sizes: [[5, 55], [10, 110]],
		r: [w("Bio-cannon", "ranged", 24, 2, 4, 5, -1, 2, ["Heavy", "Blast"])],
		m: [clawsTeeth],
		ab: [a("Disruption Bombardment", "If this unit scores a hit against an Infantry unit, that unit is −2 Move and cannot Advance until your next turn.")]
	}),
	u("nids-biovores", "Biovores", "infantry", 50, {
		m: 5,
		t: 6,
		sv: 4,
		w: 4,
		ld: 8,
		oc: 1
	}, KW_INF, {
		sizes: [
			[1, 50],
			[2, 90],
			[3, 130]
		],
		r: [w("Spore mine launcher", "ranged", 48, "D3", 4, 6, -1, 2, [
			"Blast",
			"Heavy",
			"Indirect Fire",
			"Devastating Wounds"
		])],
		m: [clawsTeeth],
		ab: [a("Seed Spore Mines", "Instead of shooting, set up a Spore Mines unit wholly within 48\" of this unit and more than 8\" from enemy models.")]
	}),
	u("nids-hive-guard", "Hive Guard", "infantry", 80, {
		m: 6,
		t: 7,
		sv: 3,
		w: 4,
		ld: 8,
		oc: 1
	}, KW_INF, {
		sizes: sizes36(80, 160),
		r: [w("Shockcannon", "ranged", 24, 2, 3, 7, -1, 3, ["Anti-Vehicle 2+"]), w("Impaler cannon", "ranged", 36, 4, 4, 5, -1, 1, ["Heavy", "Indirect Fire"])],
		m: [w("Chitinous claws and teeth", "melee", "Melee", 3, 4, 5, 0, 1, [])],
		ab: [a("Defensive Stance", "When this unit uses Fire Overwatch, hits are scored on 5+ (4+ if it is on an objective).")]
	}),
	u("nids-pyrovores", "Pyrovores", "infantry", 40, {
		m: 5,
		t: 6,
		sv: 3,
		w: 5,
		ld: 8,
		oc: 1
	}, [
		"Infantry",
		"Tyranids",
		"Harvester"
	], {
		sizes: [
			[1, 40],
			[2, 70],
			[3, 100]
		],
		r: [w("Flamespurt", "ranged", 12, "D6+1", 0, 6, -1, 1, [
			"Ignores Cover",
			"Torrent",
			"Twin-linked"
		])],
		m: [w("Chitinous claws and teeth", "melee", "Melee", 3, 4, 5, 0, 1, [])],
		ab: [a("Burning Sporecloud", "Targets of this unit's shooting do not receive the Benefit of Cover.")]
	}),
	u("nids-venomthropes", "Venomthropes", "infantry", 55, {
		m: 6,
		t: 5,
		sv: 4,
		w: 3,
		ld: 8,
		oc: 1
	}, [
		"Infantry",
		"Fly",
		"Tyranids"
	], {
		sizes: sizes36(55, 110),
		m: [w("Toxic lashes", "melee", "Melee", 6, 3, 5, -1, 1, ["Anti-Infantry 2+"])],
		ab: [a("Spore Cloud", "Friendly Tyranids units (excluding Monsters) within 6\" have Stealth. All friendly Tyranids units within 6\" have the Benefit of Cover.")]
	}),
	u("nids-tyrant-guard", "Tyrant Guard", "infantry", 80, {
		m: 6,
		t: 8,
		sv: 3,
		w: 4,
		ld: 8,
		oc: 1
	}, KW_INF, {
		sizes: sizes36(80, 170),
		m: [
			scythingTalons,
			w("Bone cleaver, lash whip and rending claws", "melee", "Melee", 4, 3, 7, -1, 2, ["Twin-linked"]),
			w("Crushing claws", "melee", "Melee", 3, 4, 10, -2, 3, [])
		],
		ab: [a("Guardian Organism", "While a Character is attached, that Character has a 5+ Feel No Pain and is not an eligible target for Precision attacks.")]
	}),
	u("nids-zoanthropes", "Zoanthropes", "infantry", 90, {
		m: 5,
		t: 5,
		sv: 5,
		w: 3,
		ld: 7,
		oc: 1
	}, [
		"Infantry",
		"Psyker",
		"Fly",
		"Synapse",
		"Tyranids"
	], {
		inv: 4,
		sizes: sizes36(90, 190),
		r: [w("Warp blast", "ranged", 24, "D3", 3, 12, -3, "D6+1", ["Blast", "Psychic"])],
		m: [clawsTeeth],
		ab: [a("Warp Field", "Friendly Tyranids units within 6\" have a 6+ invulnerable save against ranged attacks.")]
	}),
	u("nids-ripper-swarms", "Ripper Swarms", "infantry", 30, {
		m: 6,
		t: 2,
		sv: 6,
		w: 4,
		ld: 8,
		oc: 0
	}, [
		"Swarm",
		"Tyranids",
		"Harvester"
	], {
		sizes: [
			[1, 30],
			[2, 40],
			[3, 50]
		],
		m: [clawsTeeth],
		ab: [a("Chittering Horde", "Enemy units this unit is in Engagement Range of have OC halved (rounding down).")]
	}),
	u("nids-sky-slashers", "Sky-slasher Swarms", "infantry", 60, {
		m: 12,
		t: 2,
		sv: 6,
		w: 4,
		ld: 8,
		oc: 0
	}, [
		"Swarm",
		"Fly",
		"Tyranids"
	], {
		sizes: [[3, 60]],
		m: [clawsTeeth],
		ab: [deepStrike, a("Chittering Horde", "Enemy units this unit is in Engagement Range of have OC halved (rounding down).")]
	}),
	u("nids-carnifexes", "Carnifexes", "monster", 90, {
		m: 8,
		t: 9,
		sv: 2,
		w: 8,
		ld: 8,
		oc: 3
	}, KW_MON, {
		sizes: [[1, 90], [2, 180]],
		r: [
			heavyVenom,
			stranglethorn,
			w("Deathspitters with slimer maggots", "ranged", 18, 3, 4, 7, -1, 1, ["Assault", "Blast"])
		],
		m: [w("Scything talons", "melee", "Melee", 6, 4, 9, -2, 3, []), w("Crushing claws", "melee", "Melee", 4, 4, 12, -3, "D6+1", [])],
		ab: [a("Blistering Assault", "After this unit is shot, it can make a Surge move of D6+2\" toward the closest enemy.")]
	}),
	u("nids-screamer-killer", "Screamer-Killer", "monster", 125, {
		m: 8,
		t: 9,
		sv: 2,
		w: 10,
		ld: 8,
		oc: 3
	}, KW_MON, {
		r: [w("Bio-plasmic scream", "ranged", 18, "D6+3", 4, 8, -2, 1, ["Assault", "Blast"])],
		m: [w("Screamer-Killer talons", "melee", "Melee", 10, 3, 10, -2, 3, [])],
		ab: [a("Death Scream", "After this model shoots, one unit it hit must take a Battle-shock test at −1.")]
	}),
	u("nids-haruspex", "Haruspex", "monster", 125, {
		m: 8,
		t: 11,
		sv: 3,
		w: 14,
		ld: 8,
		oc: 4
	}, [
		"Monster",
		"Tyranids",
		"Harvester"
	], {
		m: [
			w("Grazing maw", "melee", "Melee", 14, 3, 7, -2, 1, []),
			w("Raking claws", "melee", "Melee", 4, 3, 14, -2, "D6+1", ["Extra Attacks"]),
			w("Grasping tongue", "melee", "Melee", 1, 3, 7, -2, 2, ["Precision", "Extra Attacks"])
		],
		ab: [a("Rapacious Hunger", "Enemy units in Engagement Range of this model must take a Battle-shock test in your opponent's Command phase.")]
	}),
	u("nids-psychophage", "Psychophage", "monster", 110, {
		m: 8,
		t: 9,
		sv: 3,
		w: 10,
		ld: 8,
		oc: 3
	}, [
		"Monster",
		"Tyranids",
		"Harvester"
	], {
		fnp: 5,
		r: [w("Psychoclastic torrent", "ranged", 12, "D6", 0, 6, -1, 1, ["Torrent", "Ignores Cover"])],
		m: [w("Talons and betentacled maw", "melee", "Melee", 6, 3, 6, -2, 2, ["Anti-Psyker 4+", "Devastating Wounds"])],
		ab: [a("Bio-acidic Bloom", "Friendly Tyranids units wholly within 6\" improve the AP of their melee weapons by 1.")]
	}),
	u("nids-maleceptor", "Maleceptor", "monster", 180, {
		m: 8,
		t: 11,
		sv: 3,
		w: 14,
		ld: 7,
		oc: 4
	}, [
		"Monster",
		"Psyker",
		"Synapse",
		"Tyranids"
	], {
		inv: 4,
		r: [w("Psychic overload", "ranged", 18, "D6+3", 3, 10, -2, 3, ["Blast", "Psychic"])],
		m: [w("Massive scything talons — strike", "melee", "Melee", 3, 3, 9, -2, "D6+1", []), w("Massive scything talons — sweep", "melee", "Melee", 6, 3, 7, -1, 2, [])],
		ab: [a("Psychic Overload", "Enemy units within 6\" that are Below Half-strength are −1 to Hit and −1 to Wound.")]
	}),
	u("nids-exocrine", "Exocrine", "monster", 135, {
		m: 8,
		t: 10,
		sv: 3,
		w: 14,
		ld: 8,
		oc: 4
	}, KW_MON, {
		r: [w("Bio-plasmic cannon", "ranged", 36, "D6+3", 3, 9, -3, 3, ["Blast", "Heavy"])],
		m: [powerfulLimbs],
		ab: [a("Symbiotic Targeting", "If this model Remains Stationary, its bio-plasmic cannon has Ignores Cover and you can re-roll Hit rolls.")]
	}),
	u("nids-tyrannofex", "Tyrannofex", "monster", 170, {
		m: 8,
		t: 12,
		sv: 2,
		w: 16,
		ld: 8,
		oc: 4
	}, KW_MON, {
		r: [
			w("Rupture cannon", "ranged", 48, 2, 3, 18, -4, "D6+6", ["Heavy"]),
			w("Acid spray", "ranged", 18, "2D6", 3, 6, -1, 2, ["Torrent", "Ignores Cover"]),
			stingerSalvo
		],
		m: [powerfulLimbs],
		ab: [a("Resilient Bio-hull", "Subtract 1 from the Damage of attacks allocated to this model.")]
	}),
	u("nids-trygon", "Trygon", "monster", 140, {
		m: 10,
		t: 10,
		sv: 3,
		w: 14,
		ld: 8,
		oc: 4
	}, [
		"Monster",
		"Tyranids",
		"Vanguard Invader",
		"Burrower"
	], {
		r: [w("Bio-electric pulse", "ranged", 12, 6, 3, 5, 0, 1, ["Sustained Hits 2"])],
		m: [w("Trygon scything talons", "melee", "Melee", 6, 3, 9, -2, 3, [])],
		ab: [a("Death From Below", "Ingress from Reserves more than 8\" from enemy models, then place a Tunnel marker."), a("Subterranean Assault", "Friendly Tyranids units can Ingress onto this model's Tunnel marker more than 8\" from enemy models.")]
	}),
	u("nids-mawloc", "Mawloc", "monster", 135, {
		m: 10,
		t: 10,
		sv: 3,
		w: 14,
		ld: 8,
		oc: 4
	}, [
		"Monster",
		"Tyranids",
		"Vanguard Invader",
		"Burrower"
	], {
		m: [w("Distensible jaw", "melee", "Melee", 16, 3, 8, -2, 1, []), w("Killriders", "melee", "Melee", 4, 3, 5, 0, 3, [
			"Anti-Infantry 3+",
			"Devastating Wounds",
			"Extra Attacks"
		])],
		ab: [deepStrike, a("Terror from the Deep", "When this model is set up from Reserves, roll one D6 for each enemy unit within 12\": 2–4 that unit suffers D3 mortal wounds; 5+ it suffers 3 mortal wounds and is Battle-shocked.")]
	}),
	u("nids-toxicrene", "Toxicrene", "monster", 160, {
		m: 8,
		t: 11,
		sv: 3,
		w: 14,
		ld: 8,
		oc: 4
	}, KW_MON, {
		r: [w("Massive toxic lashes", "ranged", 12, "2D6", 3, 6, -1, 2, ["Anti-Infantry 2+"])],
		m: [w("Massive toxic lashes", "melee", "Melee", 12, 3, 6, -1, 2, ["Anti-Infantry 2+"])],
		ab: [a("Choking Spores", "Enemy units within Engagement Range cannot Fall Back on a 3+."), a("Acid Blood", "At the end of your Movement phase, each enemy unit within 6\" suffers 1 mortal wound on a 2+ (D3 on a 6).")]
	}),
	u("nids-norn-emissary", "Norn Emissary", "monster", 250, {
		m: 10,
		t: 11,
		sv: 2,
		w: 16,
		ld: 7,
		oc: 5
	}, [
		"Monster",
		"Psyker",
		"Synapse",
		"Tyranids"
	], {
		inv: 4,
		fnp: 4,
		r: [
			w("Psychic tendril — blast", "ranged", 18, "D6+3", 2, 5, -1, 1, ["Blast", "Psychic"]),
			w("Psychic tendril — lance", "ranged", 24, 1, 2, 12, -3, "D6+3", ["Psychic"]),
			w("Psychic tendril — precision", "ranged", 24, 2, 2, 6, -2, 3, ["Precision", "Psychic"])
		],
		m: [w("Monstrous rending claws", "melee", "Melee", 6, 2, 9, -2, 3, [])],
		ab: [a("Singular Purpose", "At the start of the battle, choose an objective or an enemy unit. Against that target this model re-rolls Hit and Wound; or while within range of that objective it has a 5+ Feel No Pain and OC 15.")]
	}),
	u("nids-norn-assimilator", "Norn Assimilator", "monster", 250, {
		m: 10,
		t: 11,
		sv: 2,
		w: 16,
		ld: 7,
		oc: 5
	}, [
		"Monster",
		"Synapse",
		"Tyranids",
		"Harvester"
	], {
		inv: 4,
		r: [w("Toxinjector harpoon", "ranged", 18, 1, 3, 14, -3, "D6+6", ["Melta 2"])],
		m: [w("Monstrous scything talons", "melee", "Melee", 8, 2, 9, -2, 3, [])],
		ab: [a("Singular Purpose", "At the start of the battle, choose an objective or an enemy unit. Against that target this model re-rolls Hit and Wound; or while within range of that objective it has a 5+ Feel No Pain and OC 15."), a("Impaling Strike", "If this model's toxinjector harpoon hit a Monster or Vehicle this turn, add 2 to its Charge rolls against that unit.")]
	}),
	u("nids-harpy", "Harpy", "monster", 185, {
		m: "20+",
		t: 9,
		sv: 3,
		w: 12,
		ld: 8,
		oc: 0
	}, [
		"Monster",
		"Fly",
		"Aircraft",
		"Tyranids",
		"Vanguard Invader"
	], {
		r: [w("Twin stranglethorn cannon", "ranged", 36, "D6+1", 3, 7, -1, 2, ["Blast", "Twin-linked"]), w("Twin heavy venom cannon", "ranged", 36, "D3", 3, 9, -2, 3, ["Blast", "Twin-linked"])],
		m: [w("Scything wings", "melee", "Melee", 3, 4, 6, 0, 1, [])],
		ab: [a("Spore Mine Cysts", "At the end of your opponent's Fight phase, either set up a Spore Mines unit more than 8\" from enemy models, or pick one visible non-Lone Operative enemy within 24\" and roll 6D6: each 3+ inflicts 1 mortal wound.")]
	}),
	u("nids-hive-crone", "Hive Crone", "monster", 170, {
		m: "20+",
		t: 9,
		sv: 3,
		w: 12,
		ld: 8,
		oc: 0
	}, [
		"Monster",
		"Fly",
		"Aircraft",
		"Tyranids",
		"Vanguard Invader"
	], {
		r: [
			w("Drool cannon", "ranged", 12, "2D6", 0, 6, -1, 1, ["Torrent", "Ignores Cover"]),
			w("Tentaclids", "ranged", 24, 2, 3, 7, 0, 2, ["Anti-Vehicle 4+", "Devastating Wounds"]),
			stingerSalvo
		],
		m: [w("Thorax spur", "melee", "Melee", 3, 4, 10, -2, "D6", ["Anti-Fly 2+"])],
		ab: [a("Airborne Predator", "Each time this model makes an attack that targets a unit that can Fly, add 1 to the Hit roll.")]
	}),
	u("nids-tyrannocyte", "Tyrannocyte", "transport", 80, {
		m: 8,
		t: 9,
		sv: 3,
		w: 10,
		ld: 8,
		oc: 2
	}, [
		"Monster",
		"Fly",
		"Transport",
		"Dedicated Transport",
		"Tyranids",
		"Vanguard Invader"
	], {
		r: [w("Tyrannocyte bio-weapons", "ranged", 24, 5, 4, 5, 0, 1, [])],
		m: [w("Flensing whips", "melee", "Melee", 6, 4, 6, 0, 1, [])],
		ab: [deepStrike, a("Drop Organism", "Units can disembark after this Transport is set up this turn, and can still shoot and charge.")],
		transport: 20
	}),
	u("nids-spore-mines", "Spore Mines", "infantry", 55, {
		m: 4,
		t: 1,
		sv: 7,
		w: 1,
		ld: 8,
		oc: 0
	}, [
		"Beast",
		"Fly",
		"Tyranids"
	], {
		sizes: [[3, 55]],
		m: [],
		ab: [deepStrike, a("Living Bomb", "If an enemy unit ends a move within 3\", or if this unit is destroyed, roll one D6 per model: each 2+ inflicts 1 mortal wound on the closest enemy (each 6 inflicts D3). Then this unit is destroyed.")]
	}),
	u("nids-mucolids", "Mucolid Spores", "infantry", 30, {
		m: 4,
		t: 4,
		sv: 7,
		w: 3,
		ld: 8,
		oc: 0
	}, [
		"Beast",
		"Fly",
		"Tyranids"
	], {
		sizes: [[1, 30], [2, 60]],
		m: [],
		ab: [deepStrike, a("Living Bomb", "If an enemy unit ends a move within 6\", or if this unit is destroyed, roll 3D6: each 2+ inflicts 1 mortal wound on the closest enemy (each 6 inflicts D3). Then this unit is destroyed.")]
	}),
	u("nids-sporocyst", "Sporocyst", "monster", 145, {
		m: 0,
		t: 10,
		sv: 3,
		w: 12,
		ld: 8,
		oc: 0
	}, KW_MON, {
		r: [w("Sporocyst bio-weapons", "ranged", 24, 5, 4, 5, 0, 1, [])],
		m: [w("Flensing whips", "melee", "Melee", 6, 4, 6, 0, 1, [])],
		ab: [a("Spore Node", "This model cannot move. In your Shooting phase it can spawn a Spore Mines unit wholly within 18\" and more than 8\" from enemy models.")]
	}),
	u("nids-barbed-hierodule", "Barbed Hierodule", "monster", 340, {
		m: 12,
		t: 10,
		sv: 2,
		w: 18,
		ld: 8,
		oc: 5
	}, [
		"Monster",
		"Tyranids",
		"Frame"
	], {
		r: [w("Bio-cannon cluster", "ranged", 36, "2D6", 3, 8, -2, 2, ["Blast", "Twin-linked"])],
		m: [w("Massive scything talons", "melee", "Melee", 6, 3, 12, -2, "D6+1", [])],
		ab: [a("Titanic Bioform", "This model can move over terrain and other models as if they were not there.")]
	}),
	u("nids-scythed-hierodule", "Scythed Hierodule", "monster", 330, {
		m: 12,
		t: 12,
		sv: 2,
		w: 18,
		ld: 8,
		oc: 5
	}, [
		"Monster",
		"Tyranids",
		"Frame"
	], {
		r: [w("Bio-acid spray", "ranged", 18, "2D6", 0, 8, -2, 2, ["Torrent", "Ignores Cover"])],
		m: [w("Massive scything talons", "melee", "Melee", 8, 3, 14, -3, "D6+2", [])],
		ab: [a("Titanic Bioform", "This model can move over terrain and other models as if they were not there.")]
	}),
	u("nids-dimachaeron", "Dimachaeron", "monster", 200, {
		m: 12,
		t: 10,
		sv: 3,
		w: 16,
		ld: 7,
		oc: 5
	}, [
		"Monster",
		"Tyranids",
		"Frame"
	], {
		inv: 5,
		m: [w("Grasping talons", "melee", "Melee", 6, 2, 8, -2, 3, []), w("Sickle claws", "melee", "Melee", 4, 2, 12, -3, "D6+1", ["Extra Attacks"])],
		ab: [a("Alpha Predator", "This model can Advance and charge. Re-roll Charge rolls for this model.")]
	}),
	u("nids-harridan", "Harridan", "monster", 580, {
		m: "20+",
		t: 12,
		sv: 3,
		w: 20,
		ld: 8,
		oc: 0
	}, [
		"Monster",
		"Fly",
		"Aircraft",
		"Titanic",
		"Tyranids"
	], {
		r: [w("Bio-cannon cluster", "ranged", 48, "2D6", 3, 9, -2, 3, ["Blast"]), w("Heavy venom cannon", "ranged", 36, "D3", 3, 9, -2, 3, ["Blast"])],
		m: [w("Scything wings", "melee", "Melee", 6, 4, 8, -1, 2, [])],
		ab: [a("Sky-hive", "This model can transport Gargoyles: Gargoyles units can start the battle embarked and disembark after this model moves.")],
		transport: 20
	}),
	u("nids-hierophant", "Hierophant Bio-titan", "monster", 810, {
		m: 12,
		t: 14,
		sv: 2,
		w: 30,
		ld: 7,
		oc: 8
	}, [
		"Monster",
		"Titanic",
		"Towering",
		"Synapse",
		"Tyranids"
	], {
		inv: 5,
		r: [w("Bio-cannon cluster", "ranged", 48, "3D6", 3, 10, -3, 3, ["Blast"]), w("Dire bio-cannon", "ranged", 72, 2, 3, 16, -4, "D6+6", ["Heavy"])],
		m: [w("Lashwhip pods", "melee", "Melee", 12, 3, 10, -2, 3, [])],
		ab: [a("Bio-titan", "This model has a 5+ invulnerable save. Subtract 1 from the Damage of attacks allocated to it. It can move over terrain and other models.")]
	})
];
var detachments = detPack("nids", [
	{
		id: "invasion-fleet",
		name: "Invasion Fleet",
		dp: 3,
		disposition: "Take and Hold",
		tag: "invasion-fleet",
		rule: a("Hyper-adaptations", "At the start of the battle, choose one: Swarming (Lethal Hits against Infantry), Synaptic (Cover within 6\" of Synapse), or Apex (+1 AP in melee against Monsters and Vehicles)."),
		strats: [{
			id: "nids-if-adrenals",
			name: "Adrenal Surge",
			cp: 1,
			when: "Fight phase",
			text: "A unit that charged this turn has +1 to Wound with melee until the end of the phase."
		}, {
			id: "nids-if-endless",
			name: "Endless Swarm",
			cp: 1,
			when: "Your command",
			text: "A Battleline Endless Multitude unit returns D6 destroyed models."
		}],
		enh: [{
			id: "nids-if-adaptive",
			name: "Adaptive Biology",
			points: 25,
			text: "Bearer has a 5+ Feel No Pain. The first time it is destroyed, on a 2+ set it back up unengaged with 3 wounds."
		}, {
			id: "nids-if-synapse",
			name: "Synaptic Linchpin",
			points: 20,
			text: "Add 3\" to the bearer's Synapse range. Friendly units in that range have OC +1."
		}]
	},
	{
		id: "subterranean",
		name: "Subterranean Assault",
		dp: 3,
		disposition: "Disruption",
		tag: "subterranean",
		rule: a("Surprise Assault", "Burrower units can Ingress more than 8\" from enemy models. Each time a Tyranids model from this army makes an attack, re-roll a Hit roll of 1 if it was set up this turn."),
		strats: [{
			id: "nids-sa-tunnel",
			name: "Tunnel Network",
			cp: 1,
			when: "Your movement",
			text: "A Burrower unit that arrived this turn places a Tunnel marker. One friendly unit in Strategic Reserves can Ingress onto it more than 8\" from enemies."
		}, {
			id: "nids-sa-enfilade",
			name: "Enfilading Emergence",
			cp: 1,
			when: "Your shooting",
			text: "A unit set up this turn has Lethal Hits and Ignores Cover until the end of the phase."
		}],
		enh: [{
			id: "nids-sa-trygon",
			name: "Trygon Prime",
			points: 20,
			text: "Trygon or Mawloc only. The bearer has Synapse. Friendly units that Ingress onto its Tunnel marker can charge this turn."
		}]
	},
	{
		id: "crusher",
		name: "Crusher Stampede",
		dp: 2,
		disposition: "Purge the Foe",
		tag: "crusher",
		rule: a("Enraged Behemoths", "Monster units from this army are +1 to Hit and +1 to Wound while they are Below Starting Strength (and +1 Attack as well while Below Half-strength)."),
		strats: [{
			id: "nids-cs-impact",
			name: "Massive Impact",
			cp: 1,
			when: "Your charge",
			text: "After a Monster ends a Charge, roll 6 D6: each 4+ inflicts 1 mortal wound on one engaged enemy."
		}, {
			id: "nids-cs-roar",
			name: "Savage Roar",
			cp: 1,
			when: "Fight phase",
			text: "A Monster unit that charged this turn has Lance until the end of the phase."
		}],
		enh: [{
			id: "nids-cs-nemesis",
			name: "Monstrous Nemesis",
			points: 25,
			text: "Monster Character only. The bearer's melee weapons have +1 Strength and +1 Damage."
		}]
	},
	{
		id: "assimilation",
		name: "Assimilation Swarm",
		dp: 2,
		disposition: "Take and Hold",
		tag: "assimilation",
		rule: a("Feed the Swarm", "Harvester units regain D3 lost wounds in your Command phase. When a Harvester destroys an enemy unit, one friendly unit within 6\" returns D3 destroyed models or regains D3 wounds."),
		strats: [{
			id: "nids-as-reclaim",
			name: "Reclaim Biomass",
			cp: 1,
			when: "Your command",
			text: "A Harvester unit wholly within 6\" of an objective you control regains D3+3 lost wounds, or you return one destroyed model to it."
		}, {
			id: "nids-as-hunger",
			name: "Rapacious Hunger",
			cp: 1,
			when: "Fight phase",
			text: "A Harvester unit has Sustained Hits 1 and +1 to Wound until the end of the phase."
		}],
		enh: [{
			id: "nids-as-regen",
			name: "Regenerating Monstrosity",
			points: 20,
			text: "The bearer has a 5+ Feel No Pain. It regains 1 lost wound at the start of each player's Command phase."
		}, {
			id: "nids-as-flow",
			name: "Biophagic Flow",
			points: 10,
			text: "Aura. Harvester units within 6\" of the bearer have OC +1 and can shoot after Advancing."
		}]
	},
	{
		id: "synaptic-nexus",
		name: "Synaptic Nexus",
		dp: 2,
		disposition: "Priority Assets",
		tag: "synaptic",
		rule: a("Synaptic Imperatives", "At the start of your Command phase, select one until your next Command phase: Synapse Range is 9\", or Synapse units have a 5+ invulnerable save, or friendly units within Synapse Range have OC +1."),
		strats: [{
			id: "nids-sn-node",
			name: "Reinforced Hive Node",
			cp: 1,
			when: "Opponent shooting or Fight",
			text: "A Synapse unit has a 4+ invulnerable save against the next volley of attacks allocated to it."
		}, {
			id: "nids-sn-will",
			name: "Irresistible Will",
			cp: 1,
			when: "Your shooting or Fight",
			text: "A unit within Synapse Range re-rolls Hit rolls of 1 and Wound rolls of 1 until the end of the phase."
		}],
		enh: [{
			id: "nids-sn-control",
			name: "Synaptic Control",
			points: 20,
			text: "The bearer has a 12\" Synapse Range. Friendly units in that range can ignore Battle-shock."
		}]
	},
	{
		id: "vanguard-onslaught",
		name: "Vanguard Onslaught",
		dp: 2,
		disposition: "Reconnaissance",
		tag: "vanguard-onslaught",
		rule: a("Vanguard Organisms", "Vanguard Invader units can charge after Advancing and add 1 to Charge rolls. Infantry Vanguard Invaders can deploy more than 9\" from enemy models."),
		strats: [
			{
				id: "nids-vo-strike",
				name: "Unseen Lurkers",
				cp: 1,
				when: "Your movement",
				text: "A Vanguard Invader more than 12\" from all enemies can make a 6\" Normal move but cannot charge this turn."
			},
			{
				id: "nids-vo-pounce",
				name: "Surprise Assault",
				cp: 1,
				when: "Your charge",
				text: "A unit set up this turn re-rolls Charge. If the charge succeeds, its melee has Lethal Hits this turn."
			},
			{
				id: "nids-vo-withdraw",
				name: "Vanish into the Swarm",
				cp: 1,
				when: "End of opponent's Fight phase",
				text: "Place one unengaged Vanguard Invader into Strategic Reserves."
			}
		],
		enh: [{
			id: "nids-vo-chameleonic",
			name: "Chameleonic Mutation",
			points: 15,
			text: "Bearer's unit has Stealth and Lone Operative while more than 9\" from all enemies."
		}, {
			id: "nids-vo-adrenal",
			name: "Adrenal Override",
			points: 10,
			text: "Add 2\" Move. The bearer's unit can shoot and charge after Advancing."
		}]
	},
	{
		id: "unending",
		name: "Unending Swarm",
		dp: 2,
		disposition: "Take and Hold",
		tag: "unending",
		rule: a("Insurmountable Odds", "Endless Multitude units can Surge D6\" toward the closest enemy after they are shot. When one is destroyed, on a 4+ add a 10-model copy to Strategic Reserves."),
		strats: [{
			id: "nids-us-tide",
			name: "Bounding Tide",
			cp: 1,
			when: "Your movement",
			text: "An Endless Multitude unit can Advance and still charge. Add 2\" to that Advance."
		}, {
			id: "nids-us-bodies",
			name: "A Sea of Bodies",
			cp: 1,
			when: "Opponent shooting",
			text: "An Endless Multitude unit has a 5+ Feel No Pain until the end of the phase."
		}],
		enh: [{
			id: "nids-us-progenitor",
			name: "Brood Progenitor",
			points: 15,
			text: "Endless Multitude units within 9\" of the bearer have OC +1 and can shoot after Advancing."
		}]
	},
	{
		id: "ambush",
		name: "Ambush Predators",
		dp: 1,
		disposition: "Disruption",
		tag: "ambush",
		rule: a("Mindhunger", "Lictor, Neurolictor, and Deathleaper units can Ingress more than 8\" from enemy models. Their attacks that target a Character re-roll Hit rolls of 1."),
		strats: [{
			id: "nids-ap-counter",
			name: "Counterpredation",
			cp: 1,
			when: "Fight phase",
			text: "A Lictor, Neurolictor, Deathleaper, or Leapers unit fighting a Hidden unit has +1 Strength and +1 AP."
		}, {
			id: "nids-ap-ghost",
			name: "Scanner Gheist",
			cp: 1,
			when: "End of opponent's Fight phase",
			text: "Place one unengaged Lictor, Neurolictor, Deathleaper, or Leapers unit into Strategic Reserves."
		}],
		enh: [{
			id: "nids-ap-encircle",
			name: "Encircling Horrors",
			points: 20,
			upgrade: true,
			text: "Neurolictor, Lictor, or Leapers only. When an enemy ends a move within 8\", this unit can make a D3+3\" Normal move."
		}]
	},
	{
		id: "norn-talons",
		name: "Talons of the Norn Queen",
		dp: 1,
		disposition: "Priority Assets",
		tag: "norn",
		rule: a("Higher Imperatives", "Norn Emissary and Norn Assimilator units have a 4+ invulnerable save. Once per battle round, one of those units can be targeted with a Stratagem for 0 CP."),
		strats: [{
			id: "nids-nt-lesser",
			name: "Lesser Prey",
			cp: 1,
			when: "Your shooting or Fight",
			text: "A Norn unit's attacks have Lethal Hits against non-Monster, non-Vehicle targets until the end of the phase."
		}, {
			id: "nids-nt-catalytic",
			name: "Catalytic Biofortification",
			cp: 1,
			when: "Opponent shooting or Fight",
			text: "A Norn unit has Feel No Pain 5+ until the end of the phase."
		}],
		enh: [{
			id: "nids-nt-synapto",
			name: "Synaptoprescience",
			points: 30,
			upgrade: true,
			text: "Norn only. The bearer has a 4+ invulnerable save and can re-roll one Hit, Wound, or Save each phase."
		}]
	},
	{
		id: "warrior-bioform",
		name: "Warrior Bioform Onslaught",
		dp: 1,
		disposition: "Purge the Foe",
		tag: "warriors",
		rule: a("Synapse Brood", "Tyranid Warriors and Tyranid Prime units have OC +1 and a 6+ Feel No Pain. While a Prime leads a Warrior unit, that unit's weapons have Lethal Hits."),
		strats: [{
			id: "nids-wb-phys",
			name: "Alien Physiology",
			cp: 1,
			when: "Opponent shooting or Fight",
			text: "A Warrior or Prime unit has a 5+ Feel No Pain until the end of the phase."
		}, {
			id: "nids-wb-payload",
			name: "Parasitic Payload",
			cp: 1,
			when: "Your shooting",
			text: "Ranged weapons in a Warrior unit have Anti-Infantry 4+ and Ignores Cover until the end of the phase."
		}],
		enh: [{
			id: "nids-wb-might",
			name: "Elevated Might",
			points: 30,
			text: "Tyranid Prime only. Add 1 to the Attacks, Strength, and Damage of the bearer's melee weapons."
		}]
	}
]);
var tyranids = {
	id: "nids",
	name: "Tyranids",
	short: "Hive Mind",
	allegiance: "Xenos",
	accent: "#6b3d7a",
	rule: a("Synapse / Shadow in the Warp", "Friendly Tyranid units within 6\" of a Synapse model take Battle-shock tests on 3D6, discarding the highest, and add 1 to melee Strength. Once per battle, in your Command phase, every enemy unit takes a Battle-shock test (−1 if within 6\" of Synapse)."),
	detachments,
	units,
	updatedAt: "2026-09-20"
};
function remapId(id) {
	return id.replace(/^sm-/, "um-");
}
var extraLeaders = {
	"sm-captain": ["um-victrix", "um-wardens"],
	"sm-lieutenant": ["um-victrix", "um-wardens"],
	"sm-chaplain": ["um-victrix"],
	"sm-apothecary": ["um-victrix"]
};
var coreUnits = spaceMarines.units.map((unit) => {
	const leaderOf = [...(unit.leaderOf ?? []).map(remapId), ...extraLeaders[unit.id] ?? []];
	return {
		...unit,
		id: remapId(unit.id),
		keywords: [...unit.keywords.filter((k) => k !== "Ultramarines"), "Ultramarines"],
		leaderOf: leaderOf.length ? leaderOf : void 0
	};
});
var KW_UM_CHAR = [
	"Infantry",
	"Character",
	"Epic Hero",
	"Grenades",
	"Imperium",
	"Tacticus",
	"Ultramarines",
	"Adeptus Astartes"
];
var KW_UM_INF = [
	"Infantry",
	"Grenades",
	"Imperium",
	"Tacticus",
	"Ultramarines",
	"Adeptus Astartes"
];
var uniqueUnits = [
	u("um-guilliman", "Roboute Guilliman", "character", 415, {
		m: 8,
		t: 10,
		sv: 2,
		w: 16,
		ld: 5,
		oc: 4
	}, [
		"Monster",
		"Character",
		"Epic Hero",
		"Imperium",
		"Primarch",
		"Mobile",
		"Ultramarines",
		"Adeptus Astartes"
	], {
		inv: 4,
		fnp: 5,
		r: [w("Hand of Dominion", "ranged", 24, 4, 2, 8, -2, 2, ["Rapid Fire 2"])],
		m: [w("Emperor's Sword", "melee", "Melee", 10, 2, 10, -3, 2, ["Devastating Wounds", "Cleave 2"]), w("Hand of Dominion", "melee", "Melee", 6, 2, 14, -4, 4, ["Lethal Hits"])],
		ab: [
			a("Avenging Son", "This model always has the Devastator, Tactical, and Assault Combat Doctrines active. It can Advance, Fall Back, shoot, and charge in the same turn."),
			a("Author of the Codex", "Once per turn, in your Movement phase, select one friendly Adeptus Astartes unit within 6\". Until your next Command phase, one additional Combat Doctrine of your choice is active for that unit."),
			a("Primarch of the XIII", "Friendly Adeptus Astartes units within 6\" can re-roll Hit rolls of 1 and Wound rolls of 1."),
			a("Ultramarines Bodyguard", "While this model is within 3\" of a friendly Adeptus Astartes Infantry unit, it is Mobile and has Lone Operative."),
			a("Supreme Commander", "If this model is your Warlord and on the battlefield, you gain 1 CP at the start of your Command phase.")
		]
	}),
	u("um-calgar", "Marneus Calgar", "character", 180, {
		m: 5,
		t: 6,
		sv: 2,
		w: 7,
		ld: 5,
		oc: 2
	}, [
		"Infantry",
		"Character",
		"Epic Hero",
		"Terminator",
		"Chapter Master",
		"Imperium",
		"Ultramarines",
		"Adeptus Astartes"
	], {
		inv: 4,
		r: [w("Gauntlets of Ultramar", "ranged", 18, 4, 2, 4, -1, 2, ["Pistol", "Twin-linked"])],
		m: [w("Gauntlets of Ultramar", "melee", "Melee", 6, 2, 8, -3, 3, ["Twin-linked"])],
		ab: [
			a("Master Tactician", "At the start of your Command phase, if this model is your Warlord and on the battlefield, you gain 1 CP."),
			a("Inspiring Leader", "This model's unit always has the Devastator, Tactical, and Assault Combat Doctrines active. It is eligible to shoot and charge in a turn in which it Advanced or Fell Back."),
			a("Chapter Master", "Once per battle round you can target this model's unit with a Stratagem for 0 CP. Once per Movement phase, select one friendly Adeptus Astartes unit within 12\"; replace its active Doctrine with one of your choice until your next Command phase."),
			a("Orbital Insertion", "At the start of the battle, one friendly Gravis, Phobos, or Tacticus unit gains Deep Strike."),
			a("Deep Strike", "This unit can make an Ingress move from Reserves more than 8\" from enemy models.")
		],
		lead: [
			"um-victrix",
			"um-wardens",
			"um-terminators",
			"um-intercessors",
			"um-assault-intercessors",
			"um-sternguard",
			"um-hellblasters",
			"um-aggressors",
			"um-heavy-intercessors",
			"um-bladeguard",
			"um-company-heroes"
		]
	}),
	u("um-tigurius", "Chief Librarian Tigurius", "character", 115, {
		m: 6,
		t: 5,
		sv: 3,
		w: 4,
		ld: 5,
		oc: 1
	}, [
		"Infantry",
		"Character",
		"Epic Hero",
		"Psyker",
		"Grenades",
		"Imperium",
		"Tacticus",
		"Ultramarines",
		"Adeptus Astartes"
	], {
		inv: 4,
		r: [boltPistol, w("Storm of the Emperor's Wrath", "ranged", 18, "D3+6", 2, 6, -2, 2, ["Blast", "Psychic"])],
		m: [w("Rod of Tigurius", "melee", "Melee", 5, 2, 7, -2, "D3", ["Psychic"])],
		ab: [
			a("Psyker Level 3", "Once per turn you can use one Level 1 psychic ability and one Level 2 psychic ability. On a 1 when you do, this unit is Battle-shocked."),
			a("Prescience", "Level 2 — Movement phase: until the start of your next turn, add 1 to this unit's Save characteristic."),
			a("Telepathic Assault", "Level 2 — Shooting phase: one visible enemy within 24\" suffers 2D3 mortal wounds."),
			a("Hood of Hellfire", "While leading a unit, models in that unit have Feel No Pain 4+ against Psychic attacks and mortal wounds."),
			a("Master of Prescience", "This unit has Stealth. Melee attacks that target it are −1 to Hit.")
		],
		lead: [
			"um-intercessors",
			"um-assault-intercessors",
			"um-sternguard",
			"um-hellblasters",
			"um-company-heroes"
		]
	}),
	u("um-sicarius", "Cato Sicarius", "character", 115, {
		m: 6,
		t: 5,
		sv: 2,
		w: 5,
		ld: 6,
		oc: 1
	}, [
		...KW_UM_CHAR.slice(0, 4),
		"Captain",
		...KW_UM_CHAR.slice(4)
	], {
		inv: 4,
		r: [w("Artisan plasma pistol", "ranged", 12, 1, 2, 8, -3, 2, ["Pistol"])],
		m: [
			w("Talassarian Tempest Blade — strike", "melee", "Melee", 4, 2, 6, -3, 3, ["Devastating Wounds"]),
			w("Talassarian Tempest Blade — sweep", "melee", "Melee", 9, 2, 5, -2, 1, ["Sustained Hits 1"]),
			w("Talassarian Tempest Blade — coup de grâce", "melee", "Melee", 6, 2, 5, -2, 2, ["Precision"])
		],
		ab: [
			a("Knight Champion of Macragge", "In your opponent's Movement phase, if an enemy unit ends a move within 8\" of this unengaged unit, this unit can make a Normal move of up to 6\"."),
			a("Honour or Death", "You can target this unit with Heroic Intervention even if you have already used that Stratagem this phase, and that use is 1 CP less."),
			a("Support", "This model can be attached to a unit that already has a Leader. He can only lead Victrix Honour Guard.")
		],
		lead: ["um-victrix"]
	}),
	u("um-titus", "Captain Titus", "character", 90, {
		m: 6,
		t: 5,
		sv: 3,
		w: 5,
		ld: 6,
		oc: 1
	}, [
		...KW_UM_CHAR.slice(0, 4),
		"Captain",
		...KW_UM_CHAR.slice(4)
	], {
		inv: 4,
		fnp: 6,
		r: [w("Boltstorm gauntlets", "ranged", 12, 4, 2, 5, -1, 1, ["Pistol", "Twin-linked"])],
		m: [w("Power fists", "melee", "Melee", 5, 2, 8, -2, 2, ["Twin-linked"]), w("Chainsword", "melee", "Melee", 6, 2, 5, -1, 1, [])],
		ab: [
			a("Press the Attack", "While leading a unit, melee weapons in that unit have Sustained Hits 1 against non-Monster, non-Vehicle targets (against any target while Assault Doctrine is active for it)."),
			a("Righteous Fury", "Once per battle, until the end of the Fight phase add 1 to the Strength of this model's melee weapons. After it fights, it regains D3 lost wounds, or 2D3 if it destroyed one or more enemy models this phase."),
			a("Honour of Ultramar", "The first time a model in this unit is destroyed, roll one D6: on a 2+ that model can fight before being removed.")
		],
		lead: [
			"um-intercessors",
			"um-assault-intercessors",
			"um-bladeguard",
			"um-sternguard",
			"um-company-heroes",
			"um-wardens"
		]
	}),
	u("um-kaius", "Kaius Konorius", "character", 100, {
		m: 6,
		t: 5,
		sv: 2,
		w: 5,
		ld: 6,
		oc: 1
	}, KW_UM_CHAR, {
		inv: 4,
		r: [boltPistol],
		m: [w("Konorius warblade — strike", "melee", "Melee", 5, 2, 10, -3, 3, ["Precision"]), w("Konorius warblade — sweep", "melee", "Melee", 6, 2, 6, -3, 2, ["Cleave 2"])],
		ab: [
			a("Duelist of Macragge", "Each time this model makes a melee attack that targets a Character unit, you can re-roll the Hit roll and the Wound roll of 1."),
			a("Bodyguard", "Other Character models in this unit have Feel No Pain 4+."),
			a("Support", "This model can be attached to a unit that already has a Leader.")
		],
		lead: [
			"um-victrix",
			"um-assault-intercessors",
			"um-bladeguard",
			"um-sternguard"
		]
	}),
	u("um-victrix", "Victrix Honour Guard", "infantry", 110, {
		m: 6,
		t: 5,
		sv: 2,
		w: 3,
		ld: 6,
		oc: 2
	}, KW_UM_INF, {
		sizes: [[3, 110], [6, 220]],
		r: [w("Master-crafted bolt carbine", "ranged", 24, 2, 2, 5, -1, 2, [])],
		m: [w("Master-crafted power weapon", "melee", "Melee", 5, 2, 5, -2, 2, []), w("Blades of honour", "melee", "Melee", 6, 2, 5, -2, 2, ["Precision", "Twin-linked"])],
		ab: [a("Ultramarines Honour Guard", "Each time an attack targets this unit, subtract 1 from the Wound roll."), a("Banner of Macragge", "If equipped, this unit has Objective Secured. Once per battle at the start of the Fight phase add 1 to Strength and Attacks of melee weapons in this unit until the end of the phase.")],
		wargear: [{
			id: "um-victrix-banner",
			name: "Chapter Ancient — Banner of Macragge",
			points: 15,
			group: "extra",
			text: "Objective Secured. Once-per-battle +1 Strength and Attacks in the Fight phase."
		}, {
			id: "um-victrix-blades",
			name: "Chapter Champion — Blades of honour",
			points: 10,
			group: "extra",
			text: "One model replaces its bolt carbine with Blades of honour."
		}]
	}),
	u("um-wardens", "Wardens of Ultramar", "infantry", 90, {
		m: 6,
		t: 5,
		sv: 3,
		w: 3,
		ld: 6,
		oc: 2
	}, [
		"Infantry",
		"Epic Hero",
		"Grenades",
		"Imperium",
		"Tacticus",
		"Ultramarines",
		"Adeptus Astartes"
	], {
		sizes: [[6, 90]],
		r: [w("Bolt rifle", "ranged", 24, 2, 3, 5, -1, 1, ["Assault", "Rapid Fire 1"]), w("Astropathic blast", "ranged", 18, "D6", 3, 5, -1, 1, ["Blast", "Psychic"])],
		m: [w("Close combat weapon", "melee", "Melee", 3, 3, 5, 0, 1, []), w("Force stave", "melee", "Melee", 4, 3, 6, -1, "D3", ["Psychic"])],
		ab: [
			a("Support", "This unit must be attached to a Character's unit. It cannot be selected as an independent unit in your army."),
			a("Strategium Command", "After both sides have deployed, you can redeploy up to three Adeptus Astartes units from your army (including this one)."),
			a("Raise the Banner", "At the end of your Movement phase, if Ancient Gadriel is in this unit and the unit is within range of an objective you do not control, you take control of it.")
		]
	})
];
var uniqueDets = detPack("um", [{
	id: "blade",
	name: "Blade of Ultramar",
	dp: 3,
	disposition: "Priority Assets",
	tag: "blade",
	rule: a("Mastered Doctrines", "At the start of your Command phase you can select one Combat Doctrine (Devastator: ranged weapons have Assault; Tactical: shoot and charge after Fall Back; Assault: charge after Advance). You can select each Doctrine once per battle, or twice if a friendly Marneus Calgar or Roboute Guilliman model is on the battlefield."),
	strats: [
		{
			id: "um-blade-foresight",
			name: "Tactical Foresight",
			cp: 1,
			when: "Opponent shooting or Fight",
			text: "Until the end of the phase, each time an attack targets one Adeptus Astartes unit, if the attack's Strength is greater than or equal to that unit's Toughness, subtract 1 from the Wound roll."
		},
		{
			id: "um-blade-honour",
			name: "Courage and Honour!",
			cp: 1,
			when: "Fight phase",
			text: "Melee weapons in one Adeptus Astartes unit have Lance. If Assault Doctrine is active for it, also improve those weapons' AP by 1."
		},
		{
			id: "um-blade-adapt",
			name: "Ultramarian Adaptivity",
			cp: 1,
			when: "Your command",
			text: "Select Devastator, Tactical, or Assault Doctrine. Until your next Command phase that Doctrine is active for one Adeptus Astartes unit instead of the army Doctrine, even if already selected this battle."
		},
		{
			id: "um-blade-vigil",
			name: "Exemplary Vigilance",
			cp: 1,
			when: "Your shooting",
			text: "Ranged weapons in one Adeptus Astartes unit have Ignores Cover. If Devastator Doctrine is active for it, also improve those weapons' AP by 1."
		},
		{
			id: "um-blade-practical",
			name: "Practical Tactics",
			cp: 1,
			when: "Opponent movement",
			text: "After an enemy unit ends a move, one unengaged Adeptus Astartes Infantry or Mounted unit within 8\" can make a Normal move of D6\" (6\" if Tactical Doctrine is active for it)."
		}
	],
	enh: [
		{
			id: "um-blade-antoninus",
			name: "Armour of Antoninus",
			points: 15,
			text: "The bearer has a 2+ Save and Feel No Pain 5+."
		},
		{
			id: "um-blade-macragge",
			name: "Oath of Macragge",
			points: 20,
			text: "Add 1 to Attacks and Strength of the bearer's melee weapons (add 2 instead while Assault Doctrine is active for the bearer)."
		},
		{
			id: "um-blade-student",
			name: "Student of the Codex",
			points: 20,
			text: "Captain model only. The Tactical Doctrine is always active for the bearer's unit in addition to any other Doctrine."
		},
		{
			id: "um-blade-behemoth",
			name: "Veteran of Behemoth",
			points: 25,
			text: "While leading a unit, ranged weapons in that unit have Sustained Hits 1. Re-roll Advance rolls for that unit while Devastator Doctrine is active."
		}
	]
}, {
	id: "reclamation",
	name: "Reclamation Force",
	dp: 2,
	disposition: "Take and Hold",
	tag: "reclamation",
	rule: a("Oath of Reclamation", "Each time an Adeptus Astartes model makes a melee attack that targets a unit within range of an objective marker, improve the AP of that attack by 1. Each time an attack targets an Adeptus Astartes unit from your army that is on an objective you controlled at the start of the phase, if the attack's Strength is greater than that unit's Toughness, subtract 1 from the Wound roll."),
	strats: [{
		id: "um-rec-conquer",
		name: "Crusading Conquerors",
		cp: 1,
		when: "Your command",
		text: "Until the start of the next Command phase, add 1 to the OC of models in one Adeptus Astartes unit."
	}, {
		id: "um-rec-ground",
		name: "Reclaim the Ground",
		cp: 1,
		when: "Your command",
		text: "One Ultramarines unit within range of an objective is eligible to shoot and charge in a turn in which it Advanced or Fell Back."
	}],
	enh: [{
		id: "um-rec-scroll",
		name: "Scroll of Proclamation",
		points: 15,
		text: "Add 2\" to the Move of the bearer's unit. Once per battle that unit can Advance and charge."
	}]
}]);
var coreDets = spaceMarines.detachments.map((d) => ({
	...d,
	id: remapId(d.id),
	stratagems: d.stratagems.map((s) => ({
		...s,
		id: remapId(s.id)
	})),
	enhancements: d.enhancements.map((e) => ({
		...e,
		id: remapId(e.id)
	}))
}));
var FACTIONS = [
	spaceMarines,
	{
		id: "um",
		name: "Ultramarines",
		short: "XIII Legion",
		allegiance: "Imperium",
		accent: "#0038a8",
		rule: a("Combat Doctrines", "At the start of your Command phase, select one Combat Doctrine. Until your next Command phase it applies to all Adeptus Astartes units from your army. Devastator: ranged weapons have Assault. Tactical: eligible to shoot and charge after Falling Back. Assault: eligible to charge after Advancing. You can select each Doctrine once per battle (twice if a friendly Marneus Calgar or Roboute Guilliman model is on the battlefield). A unit can only have one Doctrine active unless a rule says otherwise."),
		detachments: [...uniqueDets, ...coreDets],
		units: [...uniqueUnits, ...coreUnits]
	},
	custodes,
	chaosSpaceMarines,
	tyranids,
	tauEmpire
];
var FACTION_BY_ID = Object.fromEntries(FACTIONS.map((f) => [f.id, f]));
var UNIT_BY_KEY = /* @__PURE__ */ new Map();
var DET_BY_KEY = /* @__PURE__ */ new Map();
for (const faction of FACTIONS) {
	for (const unit of faction.units) UNIT_BY_KEY.set(`${faction.id}:${unit.id}`, unit);
	for (const det of faction.detachments) DET_BY_KEY.set(`${faction.id}:${det.id}`, det);
}
function getFaction(id) {
	return FACTION_BY_ID[id];
}
function getUnit(factionId, unitId) {
	return UNIT_BY_KEY.get(`${factionId}:${unitId}`);
}
function getDetachment(factionId, detId) {
	return DET_BY_KEY.get(`${factionId}:${detId}`);
}
function allUnits() {
	return FACTIONS.flatMap((f) => f.units.map((u) => ({
		...u,
		factionId: f.id,
		factionName: f.name,
		accent: f.accent
	})));
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid(prefix = "id") {
	return `${prefix}_${Math.random().toString(36).slice(2, 8)}${Date.now().toString(36).slice(-4)}`;
}
function roleLabel(role) {
	return role.charAt(0).toUpperCase() + role.slice(1);
}
/** A, B, C… for duplicate datasheets, assigned in roster order. Empty if that sheet appears once. */
function unitCopyMarks(units) {
	const totals = /* @__PURE__ */ new Map();
	for (const u of units) totals.set(u.unitId, (totals.get(u.unitId) ?? 0) + 1);
	const seen = /* @__PURE__ */ new Map();
	const marks = {};
	for (const u of units) {
		if ((totals.get(u.unitId) ?? 0) < 2) continue;
		const n = seen.get(u.unitId) ?? 0;
		seen.set(u.unitId, n + 1);
		marks[u.id] = n < 26 ? String.fromCharCode(65 + n) : String(n + 1);
	}
	return marks;
}
function unitMaxWounds(w) {
	return Math.max(1, w);
}
/** Remaining wounds on the current model. 0 and not destroyed = undamaged (legacy / start of game). */
function remainingWounds(st, maxW) {
	if (st.destroyed || st.modelsRemaining <= 0) return 0;
	if (st.woundsOnCurrent <= 0) return maxW;
	return Math.min(maxW, st.woundsOnCurrent);
}
function formatClock(ms) {
	const total = Math.max(0, Math.floor(ms / 1e3));
	const h = Math.floor(total / 3600);
	const m = Math.floor(total % 3600 / 60);
	const s = total % 60;
	const mm = String(m).padStart(2, "0");
	const ss = String(s).padStart(2, "0");
	return h > 0 ? `${h}:${mm}:${ss}` : `${mm}:${ss}`;
}
function battleElapsedMs(game, now = Date.now()) {
	if (game.status === "complete") {
		if (game.elapsedMs != null) return Math.max(0, game.elapsedMs);
		return Math.max(0, (game.finishedAt ?? now) - game.startedAt);
	}
	return Math.max(0, now - game.startedAt);
}
function turnElapsedMs(game, side, now = Date.now()) {
	const base = game.turnMs?.[side] ?? 0;
	if (game.runningSince && game.status === "active" && game.activeSide === side) return Math.max(0, base + (now - game.runningSince));
	return Math.max(0, base);
}
//#endregion
export { formatClock as a, getUnit as c, turnElapsedMs as d, uid as f, cn as i, remainingWounds as l, unitMaxWounds as m, allUnits as n, getDetachment as o, unitCopyMarks as p, battleElapsedMs as r, getFaction as s, FACTIONS as t, roleLabel as u };
