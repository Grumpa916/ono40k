import { i as __toESM } from "../_runtime.mjs";
import { t as FACTIONS } from "./utils-hP9YwH9-.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { c as Search } from "../_libs/lucide-react.mjs";
import { t as Badge } from "./badge-DTfl_mpk.mjs";
import { n as RuleFold, t as Datasheet } from "./RuleFold-BYMBt6uO.mjs";
import { t as Input } from "./input-D-dBVxfd.mjs";
import { a as TabsList, i as TabsContent, n as CORE_STRATAGEMS, o as TabsTrigger, r as Tabs, t as CORE_RULES } from "./core-cuR8Fl8E.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/codex-DO-_-FaE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function formatCodexDate(iso) {
	const [y, m, d] = iso.split("-").map(Number);
	if (!y || !m || !d) return iso;
	return new Date(y, m - 1, d).toLocaleDateString("en-US", {
		month: "short",
		day: "numeric",
		year: "numeric"
	});
}
function CodexPage() {
	const [factionId, setFactionId] = (0, import_react.useState)(FACTIONS[0]?.id ?? "sm");
	const [q, setQ] = (0, import_react.useState)("");
	const [tab, setTab] = (0, import_react.useState)("sheets");
	const faction = FACTIONS.find((f) => f.id === factionId) ?? FACTIONS[0];
	const units = (0, import_react.useMemo)(() => {
		const query = q.trim().toLowerCase();
		return faction.units.filter((u) => {
			if (!query) return true;
			if (u.name.toLowerCase().includes(query)) return true;
			if (u.keywords.some((k) => k.toLowerCase().includes(query))) return true;
			return u.abilities.some((ab) => ab.name.toLowerCase().includes(query) || ab.text.toLowerCase().includes(query));
		});
	}, [faction, q]);
	const rulesByGroup = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		for (const rule of CORE_RULES) {
			const arr = map.get(rule.group) ?? [];
			arr.push(rule);
			map.set(rule.group, arr);
		}
		return [...map.entries()];
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium tracking-[0.22em] text-muted-foreground uppercase",
					children: "Reference"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display mt-1 text-3xl font-semibold",
					children: "Codex"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Unofficial 11th edition fan reference — datasheets, modular detachments, and the core rules that changed from 10th."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto pb-1",
				children: FACTIONS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setFactionId(f.id),
					className: "h-10 shrink-0 rounded-full border px-3 text-sm",
					style: {
						borderColor: factionId === f.id ? f.accent : void 0,
						background: factionId === f.id ? `${f.accent}22` : void 0
					},
					children: f.name
				}, f.id))
			}),
			faction ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-border bg-card p-4",
					style: {
						borderLeftWidth: 3,
						borderLeftColor: faction.accent
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] tracking-[0.16em] text-muted-foreground uppercase",
						children: faction.allegiance
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-[11px] tracking-[0.14em] text-muted-foreground uppercase",
						children: [
							faction.units.length,
							" datasheets · ",
							faction.detachments.length,
							" detachments",
							faction.updatedAt ? ` · updated ${formatCodexDate(faction.updatedAt)}` : ""
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RuleFold, {
					kicker: "Army rule",
					title: faction.rule.name,
					text: faction.rule.text
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
				value: tab,
				onValueChange: setTab,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
						className: "w-full",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "sheets",
								children: "Datasheets"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "dets",
								children: "Detachments"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "core",
								children: "Core"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
						value: "sheets",
						className: "mt-4 space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute top-3.5 left-3 size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: q,
								onChange: (e) => setQ(e.target.value),
								placeholder: "Search units",
								className: "pl-9"
							})]
						}), units.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Datasheet, {
							unit: u,
							accent: faction.accent
						}, u.id))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "dets",
						className: "mt-4 space-y-2",
						children: faction.detachments.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(RuleFold, {
							kicker: "Detachment",
							title: d.name,
							text: `${d.rule.name}. ${d.rule.text}`,
							badges: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, { children: [d.dp, " DP"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "outline",
								children: d.disposition
							})] }),
							children: [d.stratagems.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-1 text-sm",
								children: d.stratagems.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium text-foreground",
										children: s.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-muted-foreground",
										children: [
											" ",
											"· ",
											s.cp,
											" CP · ",
											s.when
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-muted-foreground",
										children: s.text
									})
								] }, s.id))
							}) : null, d.enhancements.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-1 text-sm",
								children: d.enhancements.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium text-foreground",
										children: e.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-muted-foreground",
										children: [
											" · ",
											e.points,
											" pts"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-muted-foreground",
										children: e.text
									})
								] }, e.id))
							}) : null]
						}, d.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
						value: "core",
						className: "mt-4 space-y-6",
						children: [rulesByGroup.map(([group, rules]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-lg",
								children: group
							}), rules.map((rule) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "rounded-xl border border-border bg-card p-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-medium",
									children: rule.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted-foreground",
									children: rule.text
								})]
							}, rule.id))]
						}, group)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "space-y-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-lg",
									children: "Core stratagems"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted-foreground",
									children: "Ten shared Stratagems. Play as many as you need in a phase; a given unit can only be affected by one."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "space-y-2",
									children: CORE_STRATAGEMS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "rounded-xl border border-border bg-card p-4",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex justify-between gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "font-medium",
													children: s.name
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, { children: [s.cp, " CP"] })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground",
												children: s.when
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-2 text-sm text-muted-foreground",
												children: s.text
											})
										]
									}, s.id))
								})
							]
						})]
					})
				]
			})] }) : null
		]
	});
}
//#endregion
export { CodexPage as component };
