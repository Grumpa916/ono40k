import { i as __toESM } from "../_runtime.mjs";
import { c as getUnit, f as uid, i as cn, o as getDetachment, p as unitCopyMarks, r as battleElapsedMs, s as getFaction } from "./utils-hP9YwH9-.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { I as redirect, _ as createRootRoute, b as useRouter, d as useRouterState, g as createFileRoute, h as lazyRouteComponent, l as Scripts, m as Outlet, p as createRouter, u as HeadContent, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as Swords, g as List, l as ScrollText, r as TriangleAlert, v as Crosshair, w as BookOpen } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-cdYjUO9_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function Toaster$1() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		theme: "dark",
		toastOptions: { classNames: { toast: "bg-card text-foreground border-border" } }
	});
}
var SEED_LISTS = [
	{
		id: "seed-um-blade",
		name: "II Company — Courage and Honour",
		factionId: "um",
		battleSize: "strike",
		pointsLimit: 2e3,
		detachmentIds: ["um-blade"],
		disposition: "Priority Assets",
		favorite: true,
		saved: true,
		savedAt: 1,
		notes: "Blade of Ultramar. Guilliman is Warlord. Unofficial 11th edition Codex sample.",
		createdAt: 1,
		updatedAt: 1,
		units: [
			{
				id: "u1",
				unitId: "um-guilliman",
				models: 1,
				points: 415,
				warlord: true
			},
			{
				id: "u2",
				unitId: "um-tigurius",
				models: 1,
				points: 115
			},
			{
				id: "u3",
				unitId: "um-titus",
				models: 1,
				points: 90
			},
			{
				id: "u4",
				unitId: "um-intercessors",
				models: 10,
				points: 170
			},
			{
				id: "u5",
				unitId: "um-intercessors",
				models: 5,
				points: 85
			},
			{
				id: "u6",
				unitId: "um-assault-intercessors",
				models: 5,
				points: 80
			},
			{
				id: "u7",
				unitId: "um-infiltrators",
				models: 5,
				points: 100
			},
			{
				id: "u8",
				unitId: "um-hellblasters",
				models: 5,
				points: 115
			},
			{
				id: "u9",
				unitId: "um-terminators",
				models: 5,
				points: 190
			},
			{
				id: "u10",
				unitId: "um-bladeguard",
				models: 3,
				points: 90
			},
			{
				id: "u11",
				unitId: "um-company-heroes",
				models: 4,
				points: 125
			},
			{
				id: "u12",
				unitId: "um-redemptor",
				models: 1,
				points: 210
			},
			{
				id: "u13",
				unitId: "um-impulsor",
				models: 1,
				points: 80
			},
			{
				id: "u14",
				unitId: "um-scouts",
				models: 5,
				points: 70
			}
		]
	},
	{
		id: "seed-sm-gladius",
		name: "III Company — Strike Force",
		factionId: "sm",
		battleSize: "strike",
		pointsLimit: 2e3,
		detachmentIds: ["sm-gladius"],
		disposition: "Priority Assets",
		favorite: false,
		saved: true,
		savedAt: 2,
		notes: "Gladius Task Force. Captain is Warlord.",
		createdAt: 2,
		updatedAt: 2,
		units: [
			{
				id: "s1",
				unitId: "sm-captain",
				models: 1,
				points: 80,
				warlord: true,
				enhancementId: "sm-gla-relic"
			},
			{
				id: "s2",
				unitId: "sm-lieutenant",
				models: 1,
				points: 55
			},
			{
				id: "s3",
				unitId: "sm-intercessors",
				models: 10,
				points: 170
			},
			{
				id: "s4",
				unitId: "sm-intercessors",
				models: 5,
				points: 85
			},
			{
				id: "s5",
				unitId: "sm-assault-intercessors",
				models: 10,
				points: 160
			},
			{
				id: "s6",
				unitId: "sm-infiltrators",
				models: 5,
				points: 100
			},
			{
				id: "s7",
				unitId: "sm-terminators",
				models: 5,
				points: 190
			},
			{
				id: "s8",
				unitId: "sm-hellblasters",
				models: 5,
				points: 115
			},
			{
				id: "s9",
				unitId: "sm-eradicators",
				models: 3,
				points: 100
			},
			{
				id: "s10",
				unitId: "sm-infernus",
				models: 5,
				points: 90
			},
			{
				id: "s11",
				unitId: "sm-bladeguard",
				models: 3,
				points: 90
			},
			{
				id: "s12",
				unitId: "sm-redemptor",
				models: 1,
				points: 210
			},
			{
				id: "s13",
				unitId: "sm-ballistus",
				models: 1,
				points: 140
			},
			{
				id: "s14",
				unitId: "sm-impulsor",
				models: 1,
				points: 80
			},
			{
				id: "s15",
				unitId: "sm-gladiator-lancer",
				models: 1,
				points: 160
			},
			{
				id: "s16",
				unitId: "sm-outriders",
				models: 3,
				points: 80
			}
		]
	},
	{
		id: "seed-nids-vanguard",
		name: "Hive Fleet Kraken — Vanguard",
		factionId: "nids",
		battleSize: "strike",
		pointsLimit: 2e3,
		detachmentIds: ["nids-vanguard-onslaught", "nids-ambush"],
		disposition: "Reconnaissance",
		favorite: false,
		saved: true,
		savedAt: 3,
		notes: "Vanguard Onslaught 2 DP + Ambush Predators 1 DP. Unofficial 11th edition sample.",
		createdAt: 3,
		updatedAt: 3,
		units: [
			{
				id: "n1",
				unitId: "nids-winged-tyrant",
				models: 1,
				points: 185,
				warlord: true,
				enhancementId: "nids-vo-adrenal"
			},
			{
				id: "n2",
				unitId: "nids-broodlord",
				models: 1,
				points: 80
			},
			{
				id: "n3",
				unitId: "nids-deathleaper",
				models: 1,
				points: 80
			},
			{
				id: "n4",
				unitId: "nids-lictor",
				models: 1,
				points: 60
			},
			{
				id: "n5",
				unitId: "nids-neurolictor",
				models: 1,
				points: 80,
				enhancementId: "nids-ap-encircle"
			},
			{
				id: "n6",
				unitId: "nids-genestealers",
				models: 10,
				points: 140
			},
			{
				id: "n7",
				unitId: "nids-genestealers",
				models: 10,
				points: 140
			},
			{
				id: "n8",
				unitId: "nids-gargoyles",
				models: 10,
				points: 80
			},
			{
				id: "n9",
				unitId: "nids-hormagaunts",
				models: 20,
				points: 120
			},
			{
				id: "n10",
				unitId: "nids-leapers",
				models: 3,
				points: 55
			},
			{
				id: "n11",
				unitId: "nids-raveners",
				models: 5,
				points: 125
			},
			{
				id: "n12",
				unitId: "nids-exocrine",
				models: 1,
				points: 135
			},
			{
				id: "n13",
				unitId: "nids-tyrannofex",
				models: 1,
				points: 170
			},
			{
				id: "n14",
				unitId: "nids-zoanthropes",
				models: 3,
				points: 90
			},
			{
				id: "n15",
				unitId: "nids-trygon",
				models: 1,
				points: 140
			},
			{
				id: "n16",
				unitId: "nids-barbgaunts",
				models: 5,
				points: 55
			}
		]
	}
];
var BATTLE_SIZES = {
	incursion: {
		label: "Incursion",
		points: 1e3,
		dp: 3,
		enhancements: 2,
		copies: 2,
		battlelineCopies: 4
	},
	strike: {
		label: "Strike Force",
		points: 2e3,
		dp: 3,
		enhancements: 4,
		copies: 3,
		battlelineCopies: 6
	}
};
var PHASES = [
	{
		id: "command",
		label: "Command"
	},
	{
		id: "movement",
		label: "Movement"
	},
	{
		id: "shooting",
		label: "Shooting"
	},
	{
		id: "charge",
		label: "Charge"
	},
	{
		id: "fight",
		label: "Fight"
	},
	{
		id: "end",
		label: "End"
	}
];
var DISPOSITIONS = [
	"Take and Hold",
	"Purge the Foe",
	"Disruption",
	"Reconnaissance",
	"Priority Assets"
];
var m = (name, blurb, scoring) => ({
	name,
	blurb,
	scoring
});
var SAME = {
	"Take and Hold": m("Battlefield Dominance", "Mirror Take and Hold. Seize the field and dig in — home still scores. Primary is capped at 15 VP per round, 45 total.", [
		"2 VP if you control more objectives than your opponent. (R1–R2, end of your turn)",
		"3 VP for each objective you control. (R2–R5, Command; R5 end of turn)",
		"2 VP extra for each non-home objective if you also control your home. (R2–R5, Command; R5 end of turn)"
	]),
	"Purge the Foe": m("Meatgrinder", "Mirror Purge. Kill more than you lose and keep a foothold off your home. Primary is capped at 15 VP per round, 45 total.", [
		"3 VP if one or more enemy units were destroyed this turn. (R1–R5, end of your turn)",
		"4 VP if you control one or more objectives excluding your home. (R2–R5, Command; R5 end of turn)",
		"4 VP if more enemy units were destroyed this turn than friendly units in the previous turn. (R2–R5, end of your turn)",
		"5 VP if you control your opponent's home objective. (R2–R5, end of your turn)"
	]),
	Disruption: m("Outmanoeuvre", "Mirror Disruption. Push off home and pile into their territory. Primary is capped at 15 VP per round, 45 total.", [
		"10 VP if you control your opponent's home objective. (R1–R5, end of your turn)",
		"4 VP for each objective you control excluding home. (R1, end of your turn)",
		"5 VP for each objective you control excluding home. (R2–R3, Command)",
		"6 VP for each objective you control excluding home. (R4–R5, end of your turn)"
	]),
	Reconnaissance: m("Gather Intel", "Mirror Recon. Extract intelligence from the centre and plant markers. Primary is capped at 15 VP per round, 45 total.", [
		"6 VP if you control one or more central objectives. (R1, end of your turn)",
		"4 VP if you control one or more objectives excluding your home. (R2–R5, Command; R5 end of turn)",
		"7 VP for each friendly unit that completed Extract Intelligence this turn. (R2–R5, end of your turn)",
		"5 VP if three or more of your operation markers are on the battlefield. (end of battle)",
		"5 VP extra if one of your operation markers is on the opponent's home. (end of battle)"
	]),
	"Priority Assets": m("Sabotage", "Mirror Priority Assets. Sabotage non-home objectives, especially in their territory. Primary is capped at 15 VP per round, 45 total.", [
		"3 VP for each non-home objective you sabotaged this turn. (R1–R5, end of your turn)",
		"2 VP extra for each sabotaged objective in the opponent's territory. (R1–R5, end of your turn)",
		"4 VP if you control one or more objectives excluding your home. (R2–R5, Command; R5 end of turn)"
	])
};
var PAIR = {
	"Take and Hold|Purge the Foe": {
		me: m("Immovable Object", "Take and Hold vs Purge. Hold the centre through their turn — they score by killing and retaking.", [
			"3 VP if you control one or more central objectives. (R1–R5, end of your turn)",
			"5 VP for each objective you control excluding your home. (R2–R4, Command)",
			"5 VP for each objective you control excluding your home. (R5, end of your turn)"
		]),
		them: m("Unstoppable Force", "Purge vs Take and Hold. Kill, hold off home, and retake ground. Centre is an end-of-battle bonus.", [
			"3 VP if one or more enemy units were destroyed this turn. (R1–R5, end of your turn)",
			"4 VP for each objective you control excluding your home. (R2–R5, Command; R5 end of turn)",
			"3 VP if you control one or more objectives you did not control at the start of the turn, excluding home. (R2–R5, end of your turn)",
			"5 VP if you control one or more central objectives. (end of battle)"
		])
	},
	"Take and Hold|Disruption": {
		me: m("Determined Acquisition", "Take and Hold vs Disruption. Flip markers and pile into their territory — the centre is in their territory.", [
			"2 VP for each objective you control that you did not control at the start of the turn, excluding home. (R1–R5, end of your turn)",
			"3 VP for each objective you control. (R2–R5, Command; R5 end of turn)",
			"3 VP extra for each of those in the opponent's territory. (R2–R5, Command; R5 end of turn)"
		]),
		them: m("Death Trap", "Disruption vs Take and Hold. Trap terrain, then kill inside the trap. Home does not score.", [
			"2 VP for each terrain area trapped this turn. (R1–R5, end of your turn)",
			"3 VP extra per trapped terrain area that is also an objective. (R1–R5, end of your turn)",
			"3 VP if one or more enemy units were destroyed in a trapped area this turn. (R1–R5, end of your turn)",
			"4 VP if you control one or more objectives excluding your home. (R2–R5, Command; R5 end of turn)"
		])
	},
	"Take and Hold|Reconnaissance": {
		me: m("Purge and Secure", "Take and Hold vs Recon. Kill on the markers, hold off home, and retake ground.", [
			"3 VP if an enemy unit was destroyed this turn by a unit on an objective, or an enemy that started on an objective was destroyed. (R1–R5, end of your turn)",
			"4 VP for each objective you control excluding your home. (R2–R5, Command; R5 end of turn)",
			"3 VP if you control one or more objectives you did not control at the start of the turn, excluding home. (R2–R5, end of your turn)"
		]),
		them: m("Reconnaissance Sweep", "Recon vs Take and Hold. Spread into table quarters and pick off units.", [
			"3 VP if friendly units occupy 3 different table quarters and are more than 6\" from the centre. (R1–R5, end of your turn)",
			"3 VP extra if they occupy 4 quarters (6 total). (R1–R5, end of your turn)",
			"1 VP for each enemy unit destroyed this turn. (R1–R5, end of your turn)",
			"3 VP if you control one or more objectives excluding your home. (R2–R5, Command; R5 end of turn)"
		])
	},
	"Take and Hold|Priority Assets": {
		me: m("Inescapable Dominion", "Take and Hold vs Priority Assets. Blanket the board. Home still counts toward 2+ / 3+.", [
			"4 VP if you control three or more objectives. (R1–R5, end of your turn)",
			"5 VP if you control two or more objectives. (R2–R5, Command; R5 end of turn)",
			"4 VP if you control more objectives than your opponent. (R2–R5, Command; R5 end of turn)",
			"5 VP if you control the enemy's home objective. (end of battle)"
		]),
		them: m("Secure Asset", "Priority Assets vs Take and Hold. Action on a non-home objective, then hold the board.", [
			"4 VP if you completed the Secure Asset action on a non-home objective. (R1–R5, end of your turn)",
			"2 VP if one or more enemy units on a central objective were destroyed this turn. (R1–R5, end of your turn)",
			"4 VP if you control one or more objectives excluding your home. (R2–R5, Command; R5 end of turn)",
			"4 VP if you control three or more objectives (home counts). (R2–R5, Command; R5 end of turn)"
		])
	},
	"Purge the Foe|Disruption": {
		me: m("Punishment", "Purge vs Disruption. Condemn units that killed you or sit on markers; they score when they leave the table.", [
			"5 VP if one or more Condemned enemy units left the battlefield this turn. (R1–R5, end of turn)",
			"4 VP if you control one or more objectives excluding your home. (R2–R5, Command; R5 end of turn)",
			"5 VP if you control more objectives than your opponent. (R2–R5, Command; R5 end of turn)",
			"8 VP if you control your opponent's home objective. (end of battle)"
		]),
		them: m("Delaying Action", "Disruption vs Purge. Kill for VP each, then hold a centre and an expansion.", [
			"2 VP for each enemy unit destroyed this turn. (R1–R5, end of your turn)",
			"4 VP if you control one or more objectives excluding your home. (R2–R5, Command; R5 end of turn)",
			"3 VP if you control one or more central and one or more expansion objectives. (R2–R5, end of your turn)"
		])
	},
	"Purge the Foe|Reconnaissance": {
		me: m("Consecrate", "Purge vs Recon. Units that destroy the foe become Consecration units; they consecrate non-home objectives they end on.", [
			"3 VP if 1–2 objectives are consecrated. (R1–R5, end of your turn)",
			"3 VP extra if 3 or more are consecrated (6 total). (R1–R5, end of your turn)",
			"4 VP if you control one or more objectives excluding your home. (R2–R5, Command; R5 end of turn)",
			"4 VP if you control more objectives than your opponent. (R2–R5, Command; R5 end of turn)",
			"5 VP if you consecrated the opponent's home objective. (end of battle)"
		]),
		them: m("Triangulation", "Recon vs Purge. Action to triangulate non-home objectives — it sticks. Deny a second and third action.", [
			"3 VP if 1 objective is triangulated. (R2–R5, end of your turn)",
			"3 VP extra if 2 are triangulated (6 total). (R2–R5, end of your turn)",
			"4 VP extra if 3 or more are triangulated (10 total). (R2–R5, end of your turn)",
			"4 VP if you control one or more objectives excluding your home. (R2–R5, Command; R5 end of turn)",
			"10 VP if you control four or more objectives. (end of battle)"
		])
	},
	"Purge the Foe|Priority Assets": {
		me: m("Destroyer's Wrath", "Purge vs Priority Assets. Kill, hold off home, and out-kill them. Their chaff is your fuel.", [
			"3 VP if one or more enemy units were destroyed this turn. (R1–R5, end of your turn)",
			"4 VP if you control one or more objectives excluding your home. (R2–R5, Command; R5 end of turn)",
			"4 VP if you control more objectives than your opponent. (R2–R5, Command; R5 end of turn)",
			"5 VP if more enemy units were destroyed this turn than they destroyed in their previous turn. (R2–R5, end of your turn)"
		]),
		them: m("Vital Link", "Priority Assets vs Purge. Action to plant operation markers on central objectives, then sit on them.", [
			"2 VP if you control one or more central objectives. (R1–R5, end of your turn)",
			"1 VP for each operation marker on a central objective you control. (R1–R5, end of your turn)",
			"4 VP if you control one or more objectives excluding your home. (R2–R5, Command; R5 end of turn)",
			"4 VP if you control a central objective. (R2–R5, Command; R5 end of turn)",
			"10 VP if you control the opponent's home objective. (end of battle)"
		])
	},
	"Disruption|Reconnaissance": {
		me: m("Smoke and Mirrors", "Disruption vs Recon. Decoy objectives, especially in their territory.", [
			"2 VP for each decoyed objective. (R1–R5, end of your turn)",
			"2 VP extra for each decoyed objective in the opponent's territory. (R1–R5, end of your turn)",
			"4 VP if you control one or more objectives excluding your home. (R2–R5, Command; R5 end of turn)",
			"10 VP if four or more objectives are decoyed. (end of battle)"
		]),
		them: m("Surveil the Foe", "Recon vs Disruption. Surveil enemy units that are not sitting on a decoyed marker.", [
			"4 VP if one or more enemy units were surveilled this turn and are not on a decoyed objective. (R1–R5, end of your turn)",
			"4 VP if you control one or more objectives excluding your home. (R2–R5, Command; R5 end of turn)",
			"5 VP if none of the opponent's operation markers are on the battlefield. (R1–R5, end of your turn)"
		])
	},
	"Disruption|Priority Assets": {
		me: m("Locate and Deny", "Disruption vs Priority Assets. Kill on the markers and contest the last relic.", [
			"4 VP if one or more enemy units that started the turn on an objective were destroyed. (R1–R5, end of your turn)",
			"4 VP if only one operation marker remains and you contest that terrain with no enemy in it. (R1–R5, end of your turn)",
			"4 VP if you control one or more objectives excluding your home. (R2–R5, Command; R5 end of turn)",
			"5 VP if you control the relic and no enemy units are within it. (end of battle)"
		]),
		them: m("Extract Relic", "Priority Assets vs Disruption. Sensor Sweep to strip their markers, then sit on the last one.", [
			"4 VP if you completed a Sensor Sweep this turn. (R1–R5, end of your turn)",
			"3 VP if an enemy unit that started the turn on an objective was destroyed. (R1–R5, end of your turn)",
			"4 VP if only one opponent marker remains and you contest that terrain with no enemy in it. (R1–R5, end of your turn)",
			"4 VP if you control one or more objectives excluding your home. (R2–R5, Command; R5 end of turn)",
			"5 VP if only one opponent marker remains and you contest that terrain with no enemy in it. (end of battle)"
		])
	},
	"Reconnaissance|Priority Assets": {
		me: m("Search and Scour", "Recon vs Priority Assets. Hold the centre, clear terrain, and keep them out of your zone.", [
			"3 VP if you control one or more central objectives. (R1–R5, end of your turn)",
			"2 VP if one or more enemy units that started the turn in a terrain area were destroyed. (R1–R5, end of your turn)",
			"4 VP for each objective you control excluding your home. (R2–R5, Command; R5 end of turn)",
			"5 VP if no enemy units are wholly within your deployment zone. (end of battle)"
		]),
		them: m("Vanguard Operation", "Priority Assets vs Recon. Action in their territory, pick off units, then steal home.", [
			"4 VP if you completed the Vanguard Operation action this turn. (R1–R5, end of your turn)",
			"2 VP if one or more enemy units were destroyed this turn. (R1–R5, end of your turn)",
			"4 VP if you control one or more objectives excluding your home. (R2–R5, Command; R5 end of turn)",
			"10 VP if you control the opponent's home objective. (end of battle)"
		])
	}
};
function missionFor(me, them) {
	if (me === them) {
		const info = SAME[me];
		return {
			me: info,
			them: info
		};
	}
	const forward = PAIR[`${me}|${them}`];
	if (forward) return forward;
	const reverse = PAIR[`${them}|${me}`];
	if (reverse) return {
		me: reverse.them,
		them: reverse.me
	};
	return {
		me: SAME[me],
		them: SAME[them]
	};
}
function totalScore(primaryByRound, tactical, painted) {
	return primaryByRound.reduce((a, b) => a + b, 0) + tactical + painted;
}
function parseObjective(line) {
	const m = line.match(/(\d+)\s*VP/i);
	const once = /end of battle/i.test(line);
	return {
		text: line,
		vp: m ? Number(m[1]) : 0,
		once,
		each: /for each|per (trapped|decoyed|enemy|friendly)|each (non-home|objective|enemy|terrain|operation)/i.test(line),
		rounds: parseRounds(line, once)
	};
}
function parseRounds(line, once) {
	if (once) return [];
	const range = line.match(/\(R(\d)–R(\d)/);
	if (range) {
		const a = Number(range[1]);
		const b = Number(range[2]);
		return Array.from({ length: b - a + 1 }, (_, i) => a + i);
	}
	const one = line.match(/\(R(\d)[,)]/);
	if (one) return [Number(one[1])];
	return [
		1,
		2,
		3,
		4,
		5
	];
}
function checkCount(row, slot) {
	const v = row?.[slot];
	if (typeof v === "boolean") return v ? 1 : 0;
	return Number(v || 0);
}
function objectiveVp(checks, objectives) {
	const byRound = [
		0,
		0,
		0,
		0,
		0
	];
	let bonus = 0;
	objectives.forEach((obj, i) => {
		const row = checks?.[i] ?? [];
		if (obj.once) {
			bonus += checkCount(row, 0) * obj.vp;
			return;
		}
		for (let r = 0; r < 5; r++) byRound[r] += checkCount(row, r) * obj.vp;
	});
	const capped = byRound.reduce((sum, v) => sum + Math.min(15, v), 0);
	return Math.min(45, capped + bonus);
}
function sideVp(score, objectives) {
	return (objectives && score.primaryChecks ? objectiveVp(score.primaryChecks, objectives) : score.primaryByRound.reduce((a, b) => a + b, 0)) + score.tactical + score.painted;
}
var SECONDARIES = [
	{
		id: "assassination",
		name: "Assassination",
		fixed: true,
		blurb: "Cut down the enemy's champions.",
		fixedScoring: ["3 VP for each enemy Character destroyed this turn. (R1–R5, end of turn)", "1 VP extra for each of those Characters with 4 or more Wounds. (R1–R5, end of turn)"],
		tacticalScoring: ["5 VP if one or more enemy Characters were destroyed this turn, or all have already been destroyed. (R1–R5, end of turn)"]
	},
	{
		id: "bring-it-down",
		name: "Bring it Down",
		fixed: true,
		blurb: "Fell the monsters and engines.",
		fixedScoring: ["4 VP for each enemy model with 10 or more Wounds destroyed this turn. (R1–R5, end of turn)"],
		tacticalScoring: ["5 VP if one or more enemy models with 10 or more Wounds were destroyed this turn. (R1–R5, end of turn)"]
	},
	{
		id: "grievous-blow",
		name: "A Grievous Blow",
		fixed: true,
		blurb: "Cull the horde — starting strength 13+.",
		fixedScoring: ["4 VP for each enemy unit with starting strength 13+ (including attached leaders) destroyed this turn. (R1–R5, end of turn)"],
		tacticalScoring: ["5 VP if one or more enemy units with starting strength 13+ were destroyed this turn. (R1–R5, end of turn)"]
	},
	{
		id: "engage",
		name: "Engage on All Fronts",
		fixed: true,
		blurb: "Presence in table quarters, 6\" from centre, not Aircraft or Battle-shocked.",
		fixedScoring: ["2 VP if you have a presence in 3 table quarters. (R1–R5, end of turn)", "2 VP extra if you have a presence in all 4 (4 total). (R1–R5, end of turn)"],
		tacticalScoring: ["3 VP if you have a presence in 3 table quarters. (R1–R5, end of turn)", "2 VP extra if you have a presence in all 4 (5 total). (R1–R5, end of turn)"]
	},
	{
		id: "no-prisoners",
		name: "No Prisoners",
		fixed: false,
		blurb: "Exterminate. 2 VP per kill, max 5.",
		fixedScoring: [],
		tacticalScoring: ["2 VP for each enemy unit destroyed this turn (max 5). (R1–R5, end of turn)"]
	},
	{
		id: "overwhelming-force",
		name: "Overwhelming Force",
		fixed: false,
		blurb: "Kill units that started on objectives.",
		fixedScoring: [],
		tacticalScoring: ["3 VP for each enemy unit that started the turn on an objective and was destroyed (max 5). (R1–R5, end of turn)"]
	},
	{
		id: "plunder",
		name: "Plunder",
		fixed: false,
		blurb: "Action on terrain not in your territory. Redraw if Cleanse is active.",
		fixedScoring: [],
		tacticalScoring: ["5 VP if a terrain area was plundered this turn. (R1–R5, end of your turn)"]
	},
	{
		id: "display-of-might",
		name: "Display of Might",
		fixed: false,
		blurb: "Outnumber the foe in no man's land.",
		fixedScoring: [],
		tacticalScoring: ["2 VP if you have more units wholly in no man's land (not Aircraft or Battle-shocked). (R1–R5, end of any turn)", "3 VP extra (5 total) if this is still true at the end of the opponent's turn. (R1–R5)"]
	},
	{
		id: "outflank",
		name: "Outflank",
		fixed: false,
		blurb: "Push units to opposite board edges, outside your territory.",
		fixedScoring: [],
		tacticalScoring: ["3 VP if a friendly unit (not Aircraft or Battle-shocked) is within 6\" of a battlefield edge and not in your territory. (R1–R5, end of turn)", "2 VP extra if 2+ such units are on opposite edges (5 total). (R1–R5, end of turn)"]
	},
	{
		id: "beacon",
		name: "Beacon",
		fixed: false,
		blurb: "When drawn, pick a beacon unit on the battlefield or embarked.",
		fixedScoring: [],
		tacticalScoring: ["3 VP if your beacon unit is on the battlefield and not in your deployment zone. (R1–R5, end of turn)", "2 VP extra if it is wholly in the opponent's territory (5 total). (R1–R5, end of turn)"]
	},
	{
		id: "cleanse",
		name: "Cleanse",
		fixed: false,
		blurb: "Action on non-home objectives you control. Redraw if Plunder is active.",
		fixedScoring: [],
		tacticalScoring: ["2 VP if you cleansed one objective this turn. (R1–R5, end of your turn)", "3 VP extra if you cleansed 2 or more (5 total). (R1–R5, end of your turn)"]
	},
	{
		id: "defend-stronghold",
		name: "Defend Stronghold",
		fixed: false,
		blurb: "Hold home. Shuffle back if drawn in round 1.",
		fixedScoring: [],
		tacticalScoring: ["3 VP if you control your home objective. (R2–R5, end of opponent's turn)", "2 VP extra if no enemy units are in your deployment zone (5 total). (R2–R5)"]
	},
	{
		id: "secure-nml",
		name: "Secure No Man's Land",
		fixed: false,
		blurb: "Two or more objectives in no man's land.",
		fixedScoring: [],
		tacticalScoring: ["5 VP if you control two or more objectives in no man's land. (R1–R5, end of turn)"]
	},
	{
		id: "forward-position",
		name: "Forward Position",
		fixed: false,
		blurb: "Opponent's home or both expansion objectives. Shuffle back if drawn in round 1.",
		fixedScoring: [],
		tacticalScoring: ["5 VP if you control the opponent's home objective or both expansion objectives. (R2–R5, end of turn)"]
	},
	{
		id: "centre-ground",
		name: "Centre Ground",
		fixed: false,
		blurb: "Contest the middle of the field.",
		fixedScoring: [],
		tacticalScoring: ["3 VP if a friendly unit (not Aircraft or Battle-shocked) is within 3\" of the centre and no enemy is within 3\". (R1–R5, end of turn)", "2 VP extra if no enemy is within 6\" of the centre (5 total). (R1–R5, end of turn)"]
	},
	{
		id: "tempting-target",
		name: "A Tempting Target",
		fixed: false,
		blurb: "When drawn, opponent picks one no man's land objective.",
		fixedScoring: [],
		tacticalScoring: ["5 VP if you control the Tempting Target objective. (R1–R5, end of your turn)"]
	},
	{
		id: "behind-enemy-lines",
		name: "Behind Enemy Lines",
		fixed: false,
		blurb: "Units wholly in the opponent's deployment zone. Shuffle back if drawn in round 1.",
		fixedScoring: [],
		tacticalScoring: ["3 VP for each friendly unit (not Aircraft or Battle-shocked) wholly in the opponent's deployment zone (max 5). (R2–R5, end of turn)"]
	},
	{
		id: "burden-of-trust",
		name: "Burden of Trust",
		fixed: false,
		blurb: "When drawn, assign a guard unit to objectives. Score at the end of the opponent's turn.",
		fixedScoring: [],
		tacticalScoring: ["2 VP for each guarded objective you still control at the end of the opponent's turn (max 5). (R1–R5)"]
	}
];
var FIXED_SECONDARIES = SECONDARIES.filter((s) => s.fixed);
function secondaryLines(card, mode) {
	return mode === "fixed" ? card.fixedScoring : card.tacticalScoring;
}
function scoreOptions(lines) {
	const parsed = lines.map(parseObjective);
	const vps = /* @__PURE__ */ new Set();
	for (const p of parsed) if (p.each) {
		const capMatch = p.text.match(/max (\d+)/i);
		const cap = capMatch ? Number(capMatch[1]) : p.vp * 3;
		for (let n = 1; n * p.vp <= cap; n++) vps.add(n * p.vp);
		if (cap > p.vp) vps.add(cap);
	} else vps.add(p.vp);
	if (parsed.length >= 2 && parsed.every((p) => !p.each)) vps.add(parsed.reduce((sum, p) => sum + p.vp, 0));
	if (parsed.length >= 2 && parsed.every((p) => p.each)) {
		const base = parsed[0].vp;
		const extra = parsed[1].vp;
		for (let n = 1; n <= 3; n++) {
			vps.add(n * base);
			vps.add(n * (base + extra));
		}
	}
	return [...vps].filter((v) => v > 0).sort((a, b) => a - b);
}
function cardAward(checks) {
	return Number(checks?.[0]?.[0] || 0);
}
function secondaryVp(mode, cardIds, checks) {
	if (!mode || cardIds.length === 0) return 0;
	let sum = 0;
	for (const id of cardIds) {
		const award = cardAward(checks?.[id]);
		sum += mode === "fixed" ? Math.min(20, award) : award;
	}
	return Math.min(45, mode === "fixed" ? Math.min(40, sum) : sum);
}
var GW_LAYOUTS = [
	{
		id: "th-th-a",
		letter: "A",
		a: "Take and Hold",
		b: "Take and Hold",
		label: "Take and Hold (mirror)",
		edge: "Short edge",
		zones: [{
			side: "attacker",
			points: "0.19,43.96 20.03,43.96 20.03,22.02 12.07,22.02 12.07,0.04 0.19,0.04 0.19,22.02 0.19,23.1"
		}, {
			side: "defender",
			points: "59.88,0.04 40.04,0.04 40.04,21.98 48,21.98 48,43.96 59.88,43.96 59.88,21.98 59.88,20.9"
		}],
		terrain: [
			"13.06,11.02 16.46,11.02 17.62,11.48 20.97,11.02 21.62,11.6 24.64,11.02 24.64,3.98 13.06,3.98",
			"16.64,31.93 14.05,31.93 14.05,37.44 14.05,39.09 14.05,41.95 16.64,41.95 16.64,34.53 17.2,33.81",
			"33.1,27.79 32.62,25.44 31.44,24.29 28.67,19.66 27.51,18.59 27.05,16.21 25.01,16.21 25.01,27.79",
			"26.99,16.21 27.48,18.59 28.62,19.66 31.42,24.33 32.58,25.41 33.04,27.78 35.09,27.78 35.09,16.21",
			"19.99,21.54 19.57,22.96 17.58,22.96 17.58,18.94 17.3,18.6 17.58,16.92 19.57,16.92 19.57,20.4",
			"42.47,20.99 45.85,20.99 47.23,21.42 50.36,20.99 50.8,21.5 54.05,20.99 54.05,13.96 42.47,13.96",
			"47.02,32.99 43.64,32.99 42.39,32.53 39.13,32.99 38.5,32.4 35.44,32.99 35.44,40.02 47.02,40.02",
			"29.49,8.38 29.98,10.08 31.96,10.08 31.96,6.07 32.25,5.72 31.96,4.04 29.98,4.04 29.98,7.52",
			"32,12.12 34.02,12.49 35.47,12.12 38.04,12.12 38.59,10.07 38.04,9.15 38.04,8.14 32,8.14",
			"43.48,12.11 46.08,12.11 46.08,6.6 46.08,4.95 46.08,2.09 43.48,2.09 43.48,9.51 42.93,10.14",
			"50.99,32.99 51.36,30.97 50.99,29.52 50.99,26.95 48.89,26.4 48.02,26.95 47.01,26.95 47.01,32.99",
			"40.5,20.98 42.49,20.98 42.49,25 42.78,25.29 42.49,27.03 40.5,27.03 40.5,23.54 40.02,22.75",
			"6.02,22.94 9.39,22.94 10.64,22.48 13.92,22.94 14.58,22.36 17.6,22.94 17.6,29.97 6.02,29.97",
			"30.54,35.61 30.05,33.9 28.06,33.9 28.06,37.92 27.78,38.26 28.06,39.95 30.05,39.95 30.05,36.46",
			"28.02,31.87 25.95,31.49 24.56,31.87 21.99,31.87 21.44,33.88 21.99,34.83 21.99,35.84 28.02,35.84",
			"9.22,10.96 8.84,13.04 9.22,14.43 9.22,17 11.32,17.55 12.18,17 13.19,17 13.19,10.96"
		],
		ruins: [
			"19.59,4.3 13.4,4.2 13.32,7.3 13.76,7.3 13.87,6.56 17.01,5.84 17.15,4.84 19.63,4.61",
			"19.41,10.49 24.18,10.67 23.97,4.6 23.57,4.69 23.48,6.74 21.79,7.58 21.96,8.27 21.49,8.59 21.88,8.69 21.2,10.2 19.37,10.47",
			"15.58,31.81 14.52,31.88 15.24,32.08 15.24,35.32 14.52,35.51 15.76,35.45 15.6,31.85",
			"15.58,38.09 14.52,38.16 15.24,38.37 15.24,41.6 14.52,41.8 15.76,41.73 15.6,38.14",
			"16.59,37.95 15.95,37.65 15.95,36.23 16.55,35.88 15.48,35.83 15.32,35.27 15.15,35.83 14.09,35.88 14.69,36.23 14.69,37.65 14.09,38 15.15,38.08 15.32,38.64 15.49,38.05 16.48,38.02",
			"27.4,16.79 25.86,16.68 25.9,18.14 26.14,17.03 27.43,16.89",
			"25.52,22.53 25.37,27.33 29.7,27.2 28.69,26.84 27.74,24.07 25.64,24.51 25.62,22.59",
			"32.67,27.21 34.13,27.38 34.47,27.02 34.17,25.86 33.93,26.97 32.64,27.1",
			"34.55,21.47 34.7,16.67 30.37,16.79 31.38,17.15 32.33,19.93 34.42,19.48 34.45,21.41",
			"19.09,15.43 19.12,16.75 19.54,17.03 19.12,17.42 19.54,18.97 19.11,19.25 19.51,20.9 19.11,21.08 19.11,22.24 19.52,22.7 18.96,23.39 18.45,22.77 18.16,23.47 17.64,22.74 18.04,22.26 18.02,21.01 17.64,20.91 18.03,20.48 17.64,18.75 18.04,18.6 18.04,17.41 17.64,16.92 18.16,16.19 18.82,16.77 18.86,15.46",
			"53.38,17.33 53.53,14.72 52.06,14.61 52.05,15.06 53.05,14.93 53.22,17.36",
			"45.45,14.32 42.83,14.24 42.89,20.56 43.25,18.47 44.81,18.72 45.85,17.74 45.49,16.72 45.89,16.18 45.17,15.32 45.52,14.43",
			"40.48,33.54 35.62,33.48 35.92,39.43 36.32,39.35 36.41,37.29 38.1,36.46 37.93,35.77 38.4,35.44 38,35.35 38.68,33.84 40.51,33.57",
			"40.32,39.59 46.51,39.68 46.6,36.58 46.16,36.58 46.04,37.32 42.91,38.04 42.76,39.04 40.29,39.28",
			"31.01,4.72 30.39,5.34 30.86,5.75 30.86,6.84 30.12,7.18 30.86,7.38 30.86,8.45 30.12,8.88 30.83,8.88 31.01,9.49 31.69,8.72 31.13,8.46 31.14,7.35 31.69,7.12 31.14,6.87 31.13,5.77 31.69,5.49 31.06,4.82",
			"32.87,9.97 33.53,10.54 36.41,10.54 37.09,9.74 36.82,9.13 35.08,8.87 33.46,9 32.91,9.53",
			"33.63,11.35 34.92,11.78 36.31,11.44 35.19,10.31 33.69,11.28",
			"44.53,12.23 45.59,12.16 44.87,11.96 44.87,8.72 45.55,8.46 44.34,8.59 44.5,12.18",
			"44.53,5.94 45.59,5.88 44.87,5.67 44.87,2.44 45.59,2.24 44.34,2.3 44.5,5.9",
			"43.51,6.08 44.15,6.62 44.15,7.81 43.56,8.16 44.62,8.2 44.79,8.77 44.95,8.2 45.17,8.51 46.08,8.11 45.41,7.8 45.41,6.39 46.01,6.03 44.95,5.96 44.78,5.39 44.61,5.99 43.63,6.02",
			"47.26,30.85 47.31,32.61 50.01,32.63 49.41,32.02 47.64,32.19 47.31,30.81",
			"50.33,28.9 50.46,27.32 47.54,27.52 47.88,27.91 50.15,27.71 50.17,28.98",
			"42.08,28.44 42.09,27.12 42.51,26.84 42.09,26.45 42.51,24.9 42.08,24.62 42.48,22.97 42.08,22.79 42.1,21.63 42.48,21.17 41.94,20.48 41.42,21.1 41.13,20.4 40.61,21.13 41.02,21.61 40.99,22.86 40.61,22.96 41,24.69 40.61,25.12 41.03,25.28 40.61,26.95 41.12,27.68 41.78,27.1 41.82,28.41",
			"6.53,26.57 6.39,29.18 8.03,29.21 7.86,28.84 6.87,28.97 6.69,26.54",
			"14.65,29.37 17.26,29.46 17.19,23.14 16.83,25.24 15.28,24.99 14.28,25.87 14.59,26.99 14.2,27.53 14.92,28.38 14.57,29.28",
			"29,39.26 29.62,38.65 29.15,38.23 29.14,37.14 29.88,36.81 29.14,36.6 29.14,35.53 29.88,35.1 29.18,35.1 29.07,34.49 28.32,35.26 28.88,35.53 28.87,36.64 28.32,36.86 28.87,37.12 28.88,38.22 28.32,38.49 28.95,39.17",
			"27.14,34.01 26.47,33.45 23.6,33.45 22.92,34.24 23.43,34.96 24.93,35.11 26.55,34.99 27.09,34.45",
			"12.81,13.16 12.77,11.41 10.06,11.38 10.66,11.99 12.43,11.82 12.77,13.2",
			"9.74,15.11 9.61,16.69 12.54,16.49 12.2,16.1 9.92,16.3 9.91,15.03"
		],
		markers: [
			{
				kind: "expansion",
				x: 19.01,
				y: 9.39
			},
			{
				kind: "centre",
				x: 28.8,
				y: 22
			},
			{
				kind: "home",
				x: 48.41,
				y: 19.35,
				owner: "defender"
			},
			{
				kind: "expansion",
				x: 41.07,
				y: 34.62
			},
			{
				kind: "home",
				x: 11.97,
				y: 24.57,
				owner: "attacker"
			}
		]
	},
	{
		id: "th-th-b",
		letter: "B",
		a: "Take and Hold",
		b: "Take and Hold",
		label: "Take and Hold (mirror)",
		edge: "Long edge",
		zones: [{
			side: "attacker",
			points: "0.14,43.96 0.14,32 59.86,32 59.86,43.96"
		}, {
			side: "defender",
			points: "0.14,12.01 0.14,0.04 59.86,0.04 59.86,12.01"
		}],
		terrain: [
			"24.42,40.17 27.79,40.17 29.01,40.63 32.3,40.17 32.93,40.76 36,40.17 36,33.14 24.42,33.14",
			"5.17,37.95 6.82,39.06 9.06,35.73 9.71,35.19 10.19,34.06 8.55,32.94 6.6,35.83 5.72,36.27",
			"11.15,31.71 10.14,34.1 15.21,36.25 16.72,36.9 19.35,38.02 20.37,35.63 13.54,32.73 13.13,31.95",
			"53.22,38.99 52.51,37 51.48,35.98 50.2,33.76 48.12,34.32 47.65,35.22 46.76,35.75 49.77,40.98",
			"12.98,27.08 15.1,28.26 17.6,28.17 22.01,28.99 23.59,28.81 25.71,30 27.03,28.45 18.23,20.93",
			"46.81,35.74 45.7,34.1 42.37,36.34 41.95,36.28 40.69,37.47 41.8,39.12 44.69,37.17 45.67,37.1",
			"6.1,13.03 6.1,16.4 5.64,17.62 6.1,20.91 5.51,21.54 6.1,24.61 13.13,24.61 13.13,13.03",
			"26,19.05 25.62,21.1 26,22.52 26,25.09 28.07,25.64 28.93,25.1 29.97,25.09 29.97,19.05",
			"34.06,25.09 34.44,23.05 34.06,21.62 34.06,19.06 31.99,18.5 31.12,19.05 30.09,19.06 30.09,25.09",
			"46.92,16.98 44.81,15.78 42.3,15.84 37.9,14.99 36.33,15.16 34.22,13.95 32.88,15.49 41.61,23.08",
			"35.57,4 32.19,4 30.98,3.54 27.68,4 27.05,3.41 23.99,4 23.99,11.04 35.57,11.04",
			"54.65,6.16 53,5.05 50.76,8.38 50.34,8.48 49.63,10.05 51.27,11.17 53.22,8.28 54.11,7.84",
			"48.66,12.45 49.67,10.06 44.6,7.91 43.09,7.27 40.46,6.15 39.44,8.54 46.27,11.44 46.68,12.22",
			"53.99,30.93 53.99,27.56 54.45,26.34 53.99,23.04 54.58,22.41 53.99,19.35 46.96,19.35 46.96,30.93",
			"6.81,4.99 7.51,6.95 8.55,8 9.83,10.22 11.88,9.67 12.38,8.76 13.27,8.23 10.25,3",
			"13.24,8.24 14.35,9.88 17.68,7.64 18.1,7.7 19.36,6.51 18.25,4.86 15.36,6.81 14.38,6.88"
		],
		ruins: [
			"27.72,33.76 25.11,33.62 24.99,35.07 25.45,35.12 25.32,34.11 27.75,33.93",
			"35.28,36.28 35.36,33.67 29.05,33.73 31.14,34.08 30.89,35.64 31.77,36.62 32.89,36.33 33.43,36.73 34.29,35.99 35.19,36.35",
			"9.02,34.09 8.11,34.32 8.31,34.84 7.69,35.74 6.99,35.44 7.38,36.18 6.76,37.06 5.91,36.99 6.49,37.39 6.23,37.95 7.29,37.76 6.98,37.22 7.62,36.31 8.2,36.44 7.89,35.92 8.52,35.01 9.14,35.11 9.05,34.26",
			"10.76,32.54 10.39,33.53 10.8,32.97 12.33,33.6 13.81,34.27 13.71,35.01 14.16,33.85 10.82,32.52",
			"16.78,34.11 16.24,34.57 14.95,34 14.87,33.31 14.4,34.26 13.82,34.19 14.2,34.52 13.89,35.63 14.44,35.15 15.73,35.72 15.73,36.45 16.31,35.48 16.9,35.55 16.48,35.21 16.8,34.24",
			"16.5,34.99 16.12,35.98 16.61,35.4 19.55,36.71 19.45,37.46 19.89,36.3 16.56,34.97",
			"50.95,35.62 50.03,34.11 47.68,35.45 48.51,35.67 49.96,34.65 50.94,35.67",
			"49.39,39.13 50.09,40.56 52.5,38.88 51.82,38.81 50.15,40.06 49.48,38.98",
			"22.03,24.86 18.42,21.68 15.78,25.08 16.69,24.57 19.43,25.6 20.44,23.68 22.01,24.89",
			"25.35,29.7 26.52,28.55 25.46,27.68 26.08,28.62 25.26,29.64",
			"40.39,39.46 42.05,38.87 42.04,38.37 43.57,37.84 43.56,37.34 44.59,36.66 44.96,36.88 46.05,35.66 46.67,35.72 46.9,34.88 46.11,34.82 46.53,34.19 45.63,34.16 45.44,34.78 44.42,35.45 44.11,35.19 42.91,36.47 42.33,36.39 42.43,36.81 41.44,37.48 40.81,37.42 40.51,38.29 41.34,38.48 40.29,39.22",
			"6.7,19.44 6.57,24.26 12.69,23.89 10.45,23.51 9.6,21.89 6.98,21.22 6.72,19.41",
			"12.69,19.67 12.76,13.41 9.77,13.37 9.7,13.84 10.43,13.95 11.16,17.09 12.13,17.21 12.37,19.7",
			"26.79,20.71 26.42,22.14 26.81,23.39 27.19,22.54 27.98,22.22 26.88,20.77",
			"28.15,19.89 27.62,20.57 27.71,23.42 28.53,24.1 29.15,23.8 29.34,22.12 29.16,20.46 28.6,19.93",
			"31.91,24.14 32.44,23.47 32.35,20.61 31.53,19.94 30.91,20.24 30.72,21.91 30.9,23.57 31.46,24.11",
			"33.26,23.33 33.64,22.03 33.25,20.65 32.87,21.5 32.08,21.81 33.18,23.27",
			"34.42,14.32 33.45,15.63 34.63,16.33 33.87,15.5 34.53,14.36",
			"38.12,18.97 41.67,22.22 44.37,18.86 43.45,19.36 40.73,18.29 39.71,20.18 38.14,18.95",
			"24.59,7.78 24.51,10.4 30.83,10.34 28.74,9.98 28.99,8.43 28.1,7.44 26.99,7.73 26.45,7.33 25.58,8.07 24.68,7.72",
			"32.23,10.21 34.84,10.34 34.87,8.71 34.5,8.85 34.63,9.86 32.19,10.04",
			"50.82,10.02 51.65,9.88 52.15,8.37 52.95,8.52 52.43,8.03 53.15,7 53.92,7.12 53.35,6.72 53.55,6.12 52.55,6.35 52.85,6.89 52.21,7.8 51.63,7.66 51.94,8.19 51.31,9.1 50.69,9 50.78,9.85",
			"43.31,8.96 43.69,7.97 43.01,8.46 40.26,7.23 40.36,6.49 39.92,7.65 43.25,8.98",
			"43.03,9.95 43.57,9.48 44.86,10.06 44.94,10.75 45.41,9.79 46.06,9.83 45.55,9.49 45.92,9.41 45.92,8.42 45.37,8.91 44.08,8.33 44.08,7.6 43.5,8.58 42.91,8.5 43.39,8.9 43.01,9.81",
			"49.05,11.51 49.42,10.52 49.01,11.09 47.18,10.32 46,9.79 46.1,9.04 45.65,10.2 48.99,11.53",
			"47.44,24.34 47.38,30.61 50.44,30.61 50.44,30.17 49.7,30.06 48.98,26.93 48.01,26.8 47.76,24.31",
			"53.46,24.38 53.59,19.56 47.47,19.93 49.71,20.31 50.56,21.93 53.19,22.6 53.44,24.41",
			"10.65,4.85 9.95,3.42 7.54,5.1 8.22,5.17 9.89,3.92 10.56,5",
			"9.09,8.36 10.01,9.87 12.36,8.53 11.53,8.31 10.08,9.33 9.1,8.31",
			"19.66,4.52 18,5.11 18.01,5.61 16.48,6.14 16.49,6.64 15.46,7.32 15.09,7.1 14,8.32 13.38,8.26 13.15,9.1 13.94,9.16 13.52,9.79 14.42,9.82 14.61,9.2 15.63,8.53 15.94,8.79 17.14,7.51 17.72,7.59 17.62,7.17 18.61,6.5 19.24,6.56 19.54,5.69 18.71,5.5 19.76,4.76"
		],
		markers: [
			{
				kind: "home",
				x: 30.36,
				y: 38.54,
				owner: "attacker"
			},
			{
				kind: "expansion",
				x: 7.73,
				y: 18.97
			},
			{
				kind: "centre",
				x: 27.57,
				y: 22.83
			},
			{
				kind: "home",
				x: 29.63,
				y: 5.63,
				owner: "defender"
			},
			{
				kind: "expansion",
				x: 52.36,
				y: 24.99
			}
		]
	},
	{
		id: "th-th-c",
		letter: "C",
		a: "Take and Hold",
		b: "Take and Hold",
		label: "Take and Hold (mirror)",
		edge: "Long edge",
		zones: [{
			side: "attacker",
			points: "30.02,30.98 28.19,30.79 26.51,30.27 24.98,29.44 23.65,28.35 22.56,27.02 21.73,25.5 21.21,23.81 21.03,21.98 0.14,21.98 0.14,43.96 30.02,43.96"
		}, {
			side: "defender",
			points: "59.86,0.04 30,0.04 30,13.02 31.81,13.2 33.49,13.73 35.02,14.56 36.35,15.65 37.44,16.98 38.27,18.51 38.79,20.19 38.97,22 59.86,22"
		}],
		terrain: [
			"5.93,13.01 9.26,13.5 10.4,14.14 13.73,14.17 14.26,14.85 17.38,14.72 18.42,7.76 6.97,6.05",
			"3.84,31.92 6.22,34.31 6.76,35.5 9.42,37.5 9.45,38.36 12.03,40.11 17,35.14 8.81,26.95",
			"25.04,39.04 23.05,39.04 23.05,35.02 22.76,34.7 23.05,32.99 25.04,32.99 25.04,36.48 25.53,37.33",
			"23.14,29.04 21.09,28.67 19.67,29.04 17.1,29.04 16.55,31.12 17.1,31.98 17.1,33.02 23.14,33.02",
			"26.98,16.19 27.47,18.57 29.16,20.41 31.4,24.3 32.56,25.38 33.03,27.77 35.07,27.77 35.07,16.19",
			"33.02,27.77 32.53,25.4 30.84,23.55 28.6,19.67 27.44,18.59 26.97,16.2 24.93,16.2 24.93,27.77",
			"57.05,12.05 54.66,9.66 54.13,8.47 51.47,6.47 51.44,5.61 48.86,3.86 43.89,8.83 52.08,17.02",
			"36.93,14.86 38.98,15.24 40.4,14.86 42.97,14.86 43.52,12.81 42.97,11.9 42.97,10.89 36.93,10.89",
			"54.03,30.99 50.7,30.49 49.56,29.85 46.23,29.82 45.7,29.15 42.58,29.28 41.54,36.23 52.99,37.94",
			"34.98,4.89 36.97,4.89 36.97,8.9 37.26,9.22 36.97,10.93 34.98,10.93 34.98,7.45 34.49,6.59",
			"22.07,11.01 24.06,11.01 24.06,6.99 24.34,6.67 24.06,4.97 22.07,4.97 22.07,8.45 21.58,9.31",
			"24.1,13.05 26.14,13.42 27.56,13.05 30.13,13.05 30.68,10.99 30.13,10.08 30.13,9.07 24.1,9.07",
			"38.03,33.05 36.04,33.05 36.04,37.07 35.76,37.39 36.04,39.1 38.03,39.1 38.03,35.61 38.52,34.76",
			"36,31.02 33.96,30.64 32.54,31.02 29.97,31.02 29.42,33.07 29.96,33.96 29.97,34.99 36,34.99",
			"48.02,27.06 50.08,25.48 46.73,21.11 45.73,19.8 43.99,17.53 41.93,19.11 46.44,25 46.41,25.88",
			"12.01,17.01 9.96,18.59 13.31,22.96 14.31,24.27 16.05,26.53 18.11,24.95 13.59,19.07 13.62,18.19"
		],
		ruins: [
			"13.42,7.42 7.21,6.54 6.8,9.58 7.24,9.64 7.45,8.92 10.65,8.61 10.9,7.66 13.41,7.73",
			"12.42,13.41 17.12,14.3 17.8,8.26 17.44,8.25 17,10.31 15.21,10.88 15.27,11.59 14.76,11.84 15.14,11.99 14.24,13.39 12.39,13.38",
			"10.62,29.87 9.14,27.72 7.92,28.51 8.16,28.9 8.86,28.17 10.51,30",
			"14.67,36.94 16.49,35 12.07,30.71 13.29,32.45 12.02,33.37 11.97,34.8 12.98,35.28 13.05,35.93 14.16,36.02 14.55,36.91",
			"24.65,40.42 24.68,39.09 25.1,38.81 24.68,38.42 25.1,36.88 24.67,36.59 25.07,34.94 24.67,34.76 24.67,33.6 25.07,33.14 24.51,32.46 24.01,33.07 23.72,32.38 23.2,33.1 23.59,33.58 23.58,34.83 23.2,34.93 23.59,36.66 23.2,37.09 23.6,37.25 23.2,38.92 23.72,39.65 24.37,39.07 24.42,40.38",
			"18.82,29.46 17.24,29.33 17.44,32.26 17.84,31.72 17.63,29.64 18.9,29.62",
			"21.04,32.51 22.8,32.47 22.82,29.77 22.21,30.37 22.37,32.14 21,32.48",
			"34.24,21.74 34.39,16.94 30.06,17.06 31.07,17.42 32.02,20.2 34.11,19.75 34.14,21.68",
			"32.75,27.19 34.29,27.3 34.25,25.84 34.02,26.95 32.72,27.08",
			"27.26,16.78 25.72,16.67 25.76,18.05 26,17.02 27.29,16.88",
			"25.7,22.53 25.55,27.33 29.89,27.21 28.88,26.85 27.93,24.07 25.83,24.52 25.81,22.59",
			"46.4,6.95 44.49,8.75 49,13.17 47.78,11.44 49.05,10.52 49.1,9.09 48.13,8.62 48.03,7.96 46.91,7.86 46.53,6.98",
			"50.22,14.28 51.83,16.34 53.09,15.29 52.74,15.1 52.09,15.87 50.33,14.14",
			"39.06,11.4 37.3,11.44 37.28,14.15 37.89,13.55 37.73,11.77 39.1,11.44",
			"41.24,14.4 42.82,14.54 42.62,11.61 42.22,12.15 42.43,14.23 41.16,14.24",
			"47.54,30.58 42.85,29.69 42.16,35.73 42.57,35.7 42.96,33.68 44.77,32.96 45.72,30.61 47.57,30.61",
			"46.55,36.57 52.67,37.48 53.16,34.41 52.73,34.36 52.51,35.07 49.31,35.38 49.06,36.33 46.56,36.26",
			"35.37,3.51 35.34,4.83 34.92,5.11 35.34,5.5 34.92,7.05 35.35,7.33 34.95,8.98 35.35,9.16 35.35,10.32 34.95,10.78 35.51,11.47 36.01,10.85 36.26,11.55 36.82,10.82 36.43,10.34 36.44,9.09 36.82,8.99 36.43,7.26 36.82,6.83 36.42,6.68 36.82,5 36.31,4.27 35.75,4.97 35.6,3.54",
			"23.11,5.65 22.49,6.27 22.96,6.68 22.97,7.77 22.23,8.11 22.97,8.31 22.97,9.38 22.23,9.81 22.93,9.81 23.04,10.42 23.8,9.65 23.24,9.39 23.24,8.27 23.8,8.05 23.24,7.8 23.24,6.7 23.8,6.42 23.24,5.78",
			"25.73,12.28 27.02,12.71 28.41,12.37 27.3,11.24 25.79,12.2",
			"24.97,10.9 25.64,11.47 28.51,11.47 29.19,10.67 28.93,10.06 27.18,9.8 25.56,9.93 25.02,10.46",
			"36.99,38.41 37.61,37.8 37.14,37.38 37.13,36.29 37.87,35.96 37.13,35.75 37.13,34.68 37.87,34.25 37.17,34.25 36.99,33.65 36.31,34.41 36.87,34.68 36.86,35.79 36.31,36.01 36.86,36.27 36.87,37.37 36.31,37.64 36.94,38.32",
			"35.13,33.16 34.46,32.6 31.59,32.6 30.91,33.39 31.42,34.11 32.92,34.26 34.54,34.14 35.08,33.6",
			"34.37,31.78 33.08,31.36 31.69,31.69 32.81,32.82 34.31,31.86",
			"44.91,21.6 45.69,20.94 45.01,21.18 43.04,18.61 43.49,18.02 42.55,18.83 44.86,21.58",
			"47.62,22.32 46.78,22.29 46.06,21.35 46.32,20.71 45.45,21.32 44.97,20.98 45.18,21.53 44.81,21.43 44.35,22.29 45.06,22.12 45.92,23.25 45.66,23.89 46.54,23.31 47.03,23.65 46.83,23.15 47.6,22.42",
			"48.72,26.57 49.5,25.91 48.82,26.15 46.85,23.58 47.3,22.99 46.37,23.72 48.67,26.55",
			"11.32,17.5 10.59,18.29 11.22,17.92 12.39,19.44 13.18,20.48 12.73,21.08 13.67,20.34 11.37,17.51",
			"12.42,21.74 13.12,21.58 13.98,22.71 13.72,23.35 14.59,22.74 15.07,23.09 14.86,22.53 15.23,22.64 15.69,21.77 14.98,21.94 14.12,20.82 14.37,20.17 13.49,20.76 13.01,20.41 13.21,20.91 12.44,21.65",
			"15.13,22.46 14.4,23.26 15.03,22.89 16.2,24.41 16.99,25.45 16.54,26.05 17.48,25.31 15.18,22.48"
		],
		markers: [
			{
				kind: "expansion",
				x: 12.04,
				y: 12.27
			},
			{
				kind: "home",
				x: 9.19,
				y: 34.97,
				owner: "attacker"
			},
			{
				kind: "centre",
				x: 28.66,
				y: 21.89
			},
			{
				kind: "home",
				x: 51.7,
				y: 9,
				owner: "defender"
			},
			{
				kind: "expansion",
				x: 47.92,
				y: 31.72
			}
		]
	},
	{
		id: "th-pf-a",
		letter: "A",
		a: "Take and Hold",
		b: "Purge the Foe",
		label: "Purge the Foe vs Take and Hold",
		edge: "Long edge",
		zones: [{
			side: "attacker",
			points: "30.03,30.01 0.14,30.01 0.14,43.96 14.62,43.96 30.03,43.96 59.88,43.96 59.88,35.99 30.03,35.99"
		}, {
			side: "defender",
			points: "59.88,0.04 33.24,0.04 30.03,0.04 0.13,0.04 0.13,8.02 30.03,8.02 30.03,13.99 59.88,13.99"
		}],
		terrain: [
			"42.48,12.05 45.85,12.05 47.17,12.5 50.37,12.05 50.99,12.64 54.06,12.05 54.06,5.02 42.48,5.02",
			"16.57,9.97 13.2,9.97 11.88,9.52 8.69,9.97 8.06,9.38 5,9.97 5,17 16.57,17",
			"25.07,3.2 23.24,5.03 27.13,8.93 28.3,10.09 30.32,12.11 32.15,10.28 26.91,5.03 26.86,4.19",
			"34.75,13.24 36.55,12.14 37.33,10.92 39.24,9.2 38.28,7.31 37.26,7 36.58,6.25 32.1,10.29",
			"19.04,5.63 18.55,3.93 16.57,3.93 16.57,7.94 16.29,8.17 16.57,9.97 18.55,9.97 18.55,6.49",
			"39.01,21.03 36.62,21.17 34.51,22.6 30.38,24.27 29.15,25.27 26.71,25.41 26.42,27.43 37.88,29.04",
			"21.1,23.06 23.52,22.89 24.73,21.9 29.73,19.72 30.94,18.72 33.36,18.57 33.63,16.55 22.15,15.03",
			"17.63,31.9 14.23,31.9 12.81,31.5 9.73,31.9 9.07,31.32 6.05,31.9 6.05,38.94 17.63,38.94",
			"43.43,34.1 46.8,34.1 48.05,34.56 51.41,34.14 51.99,34.68 55,34.1 55,27.07 43.43,27.07",
			"35.25,40.98 37.09,39.15 33.19,35.25 32.03,34.09 30.01,32.06 28.18,33.9 33.42,39.14 33.37,39.78",
			"25.57,30.93 23.78,32.04 23,33.25 21.09,34.97 22.05,36.87 23.07,37.18 23.75,37.93 28.23,33.89",
			"40.95,38.44 41.45,40.14 43.43,40.14 43.43,36.13 43.72,35.78 43.43,34.1 41.45,34.1 41.45,37.58",
			"48.44,22.51 46.94,23.27 45.57,21.83 48.48,19.06 48.46,18.71 49.95,17.67 51.32,19.11 48.79,21.51",
			"44.17,23 42.51,21.79 41.78,20.48 40.02,18.62 41.22,16.75 42.17,16.58 42.9,15.88 47.05,20.26",
			"11.45,21.54 13.02,20.72 14.39,22.16 11.48,24.93 11.43,25.37 10.01,26.32 8.64,24.88 11.17,22.48",
			"15.79,20.99 17.45,22.2 18.18,23.51 19.95,25.37 18.84,27.19 17.8,27.41 17.06,28.11 12.91,23.73"
		],
		ruins: [
			"50.54,11.37 53.15,11.49 53.18,9.87 52.81,10 52.96,11 50.54,11.25",
			"43.09,9 43.25,11.68 49.31,11.55 47.24,11.22 47.46,9.65 46.59,8.66 45.51,8.97 44.95,8.57 44.08,9.31 43.22,8.94",
			"5.59,11.9 5.4,16.68 11.56,16.34 9.7,16.15 8.49,14.29 7.81,14.45 7.47,13.98 7.38,14.38 5.87,13.7 5.77,11.9",
			"16.08,16.56 16.14,10.32 13.19,10.28 13.1,10.72 13.84,10.84 14.6,13.93 15.53,14.09 15.77,16.59",
			"31.02,11.5 31.71,10.72 31.04,11.08 30.14,10.19 28.77,8.81 29.16,8.16 28.34,9.07 30.89,11.54",
			"26.58,7.05 27.27,6.28 26.6,6.64 25.83,5.88 24.33,4.37 24.71,3.72 23.9,4.63 26.45,7.1",
			"27.4,9.32 28.23,8.58 28.79,8.89 28.47,8.35 29.18,7.59 28.49,7.76 27.55,6.78 27.79,6.1 26.9,6.78 26.37,6.51 26.68,6.99 25.96,7.88 26.64,7.65 27.64,8.65 27.27,9.19",
			"34.26,9.23 32.96,10.4 34.67,12.41 34.77,11.59 33.48,10.39 34.31,9.23",
			"37.46,9.97 38.67,8.98 36.5,7.03 36.45,7.47 38.17,9.03 37.29,9.92",
			"17.05,2.6 17.02,3.9 16.59,4.18 17.02,4.58 16.99,5.82 16.59,6.04 17.02,6.41 17.02,7.59 16.62,7.74 17.02,9.41 16.62,9.91 17.14,10.53 17.73,9.91 17.88,10.59 18.46,9.91 18.07,9.41 18.07,8.24 18.46,8.05 18.07,7.65 18.07,6.35 18.46,6.22 18.07,4.52 18.46,4.09 18.03,3.38 17.48,3.47 17.39,4.09 17.27,2.6",
			"27.26,25.66 26.89,27.18 28.33,27.32 27.29,26.99 27.32,25.67",
			"32.8,27.76 37.49,28.75 38.12,24.47 37.58,25.41 36.67,25.25 35.14,26.11 34.71,25.84 34.77,27.99 32.95,27.64",
			"27.21,16.28 22.52,15.3 21.89,19.58 22.43,18.64 23.34,18.8 24.88,17.94 25.3,18.2 25.24,16.06 27.06,16.41",
			"32.78,18.38 33.14,16.85 31.7,16.72 32.74,17.04 32.72,18.37",
			"9.48,32.44 6.87,32.32 6.84,33.93 7.2,33.81 7.05,32.8 9.48,32.56",
			"17.02,34.85 16.86,32.17 10.8,32.29 12.87,32.63 12.65,34.2 13.52,35.19 14.6,34.88 15.16,35.28 16.02,34.54 16.89,34.91",
			"54.5,32.13 54.68,27.36 48.62,27.58 48.72,27.98 50.79,28.08 51.59,29.75 54.1,30.24 54.31,32.13",
			"43.89,27.48 43.83,33.73 46.87,33.73 46.87,33.33 46.13,33.21 45.37,30.11 44.44,29.96 44.2,27.45",
			"29.31,32.68 28.62,33.46 29.29,33.09 31.56,35.37 31.17,36.01 31.99,35.11 29.44,32.64",
			"33.75,37.12 33.06,37.9 33.73,37.54 34.63,38.43 36,39.81 35.62,40.46 36.43,39.55 33.88,37.08",
			"32.93,34.85 32.1,35.59 31.54,35.29 31.86,35.83 31.15,36.59 31.84,36.42 32.78,37.4 32.54,38.07 33.43,37.4 33.95,37.66 33.65,37.18 34.37,36.29 33.69,36.53 32.69,35.53 33.06,34.98",
			"26.07,34.95 27.37,33.78 25.66,31.77 25.56,32.59 26.84,33.78 26.02,34.95",
			"22.87,34.21 21.66,35.2 23.83,37.14 22.16,35.15 23.04,34.25",
			"42.95,41.46 42.98,40.16 43.41,39.89 42.98,39.48 43.01,38.24 43.41,38.03 42.98,37.66 42.98,36.48 43.38,36.33 42.98,34.65 43.38,34.16 42.86,33.54 42.27,34.16 42.12,33.48 41.54,34.16 41.93,34.65 41.93,35.83 41.54,36.02 41.93,36.42 41.93,37.72 41.54,37.84 41.93,39.54 41.54,39.98 41.97,40.69 42.52,40.6 42.61,39.98 42.73,41.46",
			"46.7,22.03 47.55,22.07 47.52,21.46 48.33,20.69 49.09,21 48.69,20.35 49.5,19.59 50.25,19.89 49.85,19.25 50.19,18.84 49.14,18.81 49.35,19.39 48.52,20.17 47.98,19.92 48.18,20.49 47.35,21.28 46.79,21.05 46.75,21.98",
			"42.47,17.63 42.5,18.46 44.52,20.59 45.47,20.53 45.79,19.89 44.84,18.53 43.58,17.38 42.78,17.34",
			"41.93,19.3 43.76,21.09 43.62,19.56 44.8,18.65 44.4,18.27 42.86,19.52 41.95,19.14",
			"13.26,21.96 12.41,21.92 12.44,22.53 11.63,23.3 10.88,22.99 11.27,23.64 10.47,24.4 9.71,24.1 10.11,24.74 9.77,25.15 10.82,25.18 10.62,24.6 11.44,23.82 11.98,24.07 11.78,23.5 12.61,22.71 13.17,22.94 13.22,22.01",
			"17.49,26.36 17.47,25.54 15.45,23.4 14.33,23.61 14.26,24.32 15.12,25.46 16.38,26.61 17.18,26.66",
			"18.04,24.69 16.2,22.9 16.34,24.43 15.16,25.34 15.56,25.72 17.1,24.47 18.01,24.85"
		],
		markers: [
			{
				kind: "home",
				x: 48.43,
				y: 10.42,
				owner: "defender"
			},
			{
				kind: "expansion",
				x: 10.62,
				y: 11.6
			},
			{
				kind: "centre",
				x: 32.59,
				y: 24.53
			},
			{
				kind: "centre",
				x: 27.39,
				y: 19.55
			},
			{
				kind: "home",
				x: 11.65,
				y: 33.54,
				owner: "attacker"
			},
			{
				kind: "expansion",
				x: 49.39,
				y: 32.48
			}
		]
	},
	{
		id: "th-pf-b",
		letter: "B",
		a: "Take and Hold",
		b: "Purge the Foe",
		label: "Purge the Foe vs Take and Hold",
		edge: "Long edge",
		zones: [{
			side: "attacker",
			points: "21.03,21.98 0.14,21.98 0.14,43.96 30.03,43.96 30.03,30.98 30.03,30.98 30.02,30.98 30.02,30.98 30.01,30.98 26.52,30.27 23.66,28.35 21.74,25.49 21.03,22 21.03,22 21.03,21.99 21.03,21.99"
		}, {
			side: "defender",
			points: "59.88,0.04 30.01,0.04 30.01,13.02 33.5,13.73 36.36,15.65 38.28,18.51 38.99,22 59.88,22"
		}],
		terrain: [
			"45.92,28.37 45.92,31.74 45.46,33 45.92,36.28 45.33,36.89 45.92,39.95 52.95,39.95 52.95,28.37",
			"16.64,31.93 13.27,31.93 12.02,31.47 8.74,31.93 8.13,31.34 5.07,31.93 5.07,38.97 16.64,38.97",
			"24.54,12.69 26.52,11.02 22.98,6.8 21.92,5.54 20.09,3.35 18.1,5.02 22.87,10.7 22.9,11.62",
			"30.01,33.87 30.38,35.88 30.01,37.33 30.01,39.9 28,40.45 27.05,39.9 26.04,39.9 26.04,33.87",
			"22.96,25.75 25.49,24.23 25.89,23.31 29.69,19.46 30.46,18.04 32.64,17 32.13,15.02 20.93,17.92",
			"24.73,31.57 26.08,31.95 26.08,33.94 22.07,33.94 21.72,34.23 20.04,33.94 20.04,31.95 23.52,31.95",
			"37.05,18.21 34.53,19.76 33.55,21.39 30.33,24.64 29.4,26.03 27.44,27.05 27.97,29.02 39.14,26.03",
			"14.07,15.53 14.07,12.16 14.52,10.84 14.07,7.64 14.66,6.97 14.07,3.95 7.04,3.95 7.04,15.53",
			"43.46,12.08 46.83,12.08 48.09,12.54 51.35,12.08 51.97,12.67 55.04,12.08 55.04,5.05 43.46,5.05",
			"46.75,24.49 45.04,24 45.04,22.01 49.06,22.01 49.4,21.73 51.08,22.01 51.08,24 47.6,24",
			"41.09,16.02 40.71,18.1 41.09,19.49 41.09,22.06 43.19,22.61 44.05,22.06 45.06,22.06 45.06,16.02",
			"30.09,10.17 29.71,8.1 30.09,6.7 30.09,4.13 32.19,3.58 33.05,4.13 34.06,4.13 34.06,10.17",
			"35.74,12.61 34.04,12.12 34.04,10.13 38.05,10.13 38.4,9.85 40.08,10.13 40.08,12.12 36.6,12.12",
			"35.59,31.43 33.6,33.1 37.14,37.32 38.2,38.58 40.04,40.77 42.03,39.1 37.26,33.42 37.28,32.57",
			"13.72,19.55 15.07,19.94 15.07,21.92 11.05,21.92 10.71,22.21 9.03,21.92 9.03,19.94 12.51,19.94",
			"19.02,27.91 19.4,25.9 19.02,24.45 19.02,21.88 17.01,21.33 16.06,21.88 15.05,21.88 15.05,27.91"
		],
		ruins: [
			"50.98,28.84 46.21,28.66 46.43,34.72 46.83,34.63 46.92,32.55 48.6,31.75 48.47,30.95 48.91,30.73 48.5,30.64 49.19,29.12 50.98,29.03",
			"46.3,39.44 52.54,39.5 52.54,36.46 52.14,36.46 52.02,37.2 48.77,38.06 48.77,38.89 46.27,39.13",
			"8.46,32.65 5.85,32.53 5.81,34.14 6.18,34.02 6.03,33.02 8.46,32.77",
			"16.08,35.11 15.92,32.43 9.86,32.55 11.93,32.89 11.71,34.46 12.58,35.45 13.66,35.14 14.22,35.54 15.09,34.8 15.95,35.17",
			"25.42,12.09 26.17,11.38 25.47,11.68 24.24,10.22 23.41,9.22 23.85,8.61 22.95,9.44 25.28,12.12",
			"21.38,7.28 22.13,6.57 21.43,6.87 19.51,4.58 19.81,3.8 18.92,4.63 21.25,7.31",
			"22,9.61 22.89,8.95 23.42,9.3 23.15,8.73 23.93,8.04 23.1,8.01 22.37,7.09 22.66,6.44 21.72,7.03 21.22,6.73 21.48,7.23 20.69,8.06 21.38,7.88 22.3,8.96 21.88,9.47",
			"26.36,37.93 26.39,39.69 29.03,39.72 28.48,39.1 26.73,39.29 26.39,37.9",
			"29.62,35.75 29.74,34.19 26.84,34.4 27.11,34.74 29.43,34.58 29.46,35.84",
			"32.21,17 31.97,15.45 30.58,15.88 31.67,15.78 32.15,17.02",
			"26.11,17.11 21.43,18.16 22.63,22.31 22.74,21.24 23.63,21 24.67,19.59 25.17,19.65 24.22,17.73 26.03,17.29",
			"18.6,32.53 19.9,32.5 20.18,32.07 20.58,32.5 21.82,32.47 22.03,32.07 22.4,32.5 23.58,32.5 23.74,32.1 25.41,32.5 25.9,32.1 26.52,32.62 25.9,33.21 26.58,33.36 25.9,33.94 25.41,33.55 24.23,33.55 24.04,33.94 23.64,33.55 22.34,33.55 22.22,33.94 20.52,33.55 20.08,33.94 19.37,33.51 19.47,32.96 20.08,32.87 18.6,32.75",
			"33.86,26.88 38.53,25.79 37.29,21.65 37.2,22.73 36.3,22.97 35.27,24.39 34.78,24.33 35.74,26.25 33.94,26.7",
			"27.97,27.02 28.22,28.56 29.6,28.13 28.51,28.23 28.02,27",
			"8.91,14.95 13.68,15.13 13.46,9.07 13.06,9.16 12.96,11.24 11.29,12.04 10.8,14.55 8.91,14.76",
			"13.7,4.46 7.45,4.4 7.45,7.44 7.86,7.44 7.98,6.71 11.23,5.84 11.23,5.01 13.73,4.77",
			"51.75,11.35 54.36,11.47 54.39,9.85 54.02,9.97 54.17,10.98 51.75,11.22",
			"43.81,8.9 43.97,11.58 50.03,11.46 47.96,11.12 48.21,9.7 47.31,8.56 46.23,8.87 45.67,8.47 44.8,9.21 43.94,8.84",
			"45.59,22.93 46.18,23.55 46.58,23.09 47.69,23.09 48.03,23.83 48.19,23.09 49.3,23.09 49.64,23.83 49.79,23.09 50.32,23.03 49.58,22.28 49.33,22.84 48.19,22.84 47.97,22.28 47.72,22.84 46.58,22.84 46.33,22.28 45.66,22.93",
			"43.39,17.08 42.85,17.69 42.82,18.96 42.88,20.76 43.35,21.26 44.37,20.69 44.37,17.66 43.82,17.08",
			"42.02,17.86 41.61,19.21 41.96,20.52 42.43,19.55 43.05,19.36 42.1,17.91",
			"33.74,6.12 33.71,4.37 31.08,4.34 31.63,4.95 33.38,4.77 33.71,6.15",
			"30.49,8.31 30.37,9.87 33.27,9.65 30.67,9.47 30.64,8.22",
			"41.3,11.54 40,11.57 39.72,12 39.32,11.57 38.08,11.6 37.87,12 37.49,11.57 36.32,11.57 36.16,11.97 34.49,11.57 34,11.97 33.38,11.45 34,10.87 33.32,10.71 34,10.13 34.49,10.53 35.67,10.53 35.85,10.13 36.26,10.53 37.56,10.53 37.68,10.13 39.38,10.53 39.81,10.13 40.53,10.56 39.85,11.27 41.3,11.33",
			"34.71,32.03 33.96,32.74 34.66,32.43 36.72,34.9 36.28,35.51 37.17,34.68 34.84,31.99",
			"38.75,36.84 37.99,37.55 38.69,37.25 39.51,38.22 40.76,39.71 40.32,40.32 41.21,39.49 38.88,36.81",
			"38.13,34.51 37.24,35.17 36.7,34.82 36.98,35.39 36.2,36.08 36.91,35.97 37.76,37.03 37.46,37.68 38.41,37.09 38.91,37.39 38.64,36.89 39.43,36.06 38.74,36.24 37.83,35.16 38.24,34.65",
			"14.52,21 13.93,20.38 13.53,20.85 12.42,20.85 12.08,20.11 11.92,20.85 10.81,20.85 10.47,20.11 10.32,20.85 9.79,20.91 10.53,21.65 10.78,21.1 11.92,21.1 12.14,21.65 12.39,21.1 13.53,21.1 13.78,21.65 14.46,21",
			"16.72,26.86 17.27,26.24 17.27,23.3 16.3,22.65 15.77,23.15 15.6,24.53 16.2,26.8",
			"18.09,26.08 18.51,24.73 18.17,23.46 17.07,24.57 18.02,26.02"
		],
		markers: [
			{
				kind: "expansion",
				x: 47.55,
				y: 34.32
			},
			{
				kind: "home",
				x: 10.7,
				y: 33.56,
				owner: "attacker"
			},
			{
				kind: "centre",
				x: 27.52,
				y: 20.09
			},
			{
				kind: "centre",
				x: 32.43,
				y: 24.02
			},
			{
				kind: "expansion",
				x: 12.44,
				y: 9.57
			},
			{
				kind: "home",
				x: 49.41,
				y: 10.45,
				owner: "defender"
			}
		]
	},
	{
		id: "th-pf-c",
		letter: "C",
		a: "Take and Hold",
		b: "Purge the Foe",
		label: "Purge the Foe vs Take and Hold",
		edge: "Short edge",
		zones: [{
			side: "attacker",
			points: "0.14,43.96 0.14,0.04 18.02,0.04 18.02,43.96"
		}, {
			side: "defender",
			points: "42,43.96 42,0.04 59.88,0.04 59.88,43.96"
		}],
		terrain: [
			"45.92,5.04 45.92,8.41 45.46,9.67 45.92,12.93 45.33,13.56 45.92,16.62 52.95,16.62 52.95,5.04",
			"18.9,2.06 18.9,5.46 18.46,6.75 18.9,9.96 18.32,10.62 18.9,13.64 25.94,13.64 25.94,2.06",
			"49.07,33.91 47.81,33.13 46.33,34.45 48.99,37.45 48.93,37.81 50.33,38.97 51.82,37.65 49.51,35.05",
			"40.92,25.62 41.42,27.05 44.01,27.03 43.96,21.52 43.95,19.87 43.92,17.01 41.33,17.03 41.39,24.45",
			"49.51,26.12 47.74,27.26 46.98,28.49 45.1,30.24 46.13,32.15 47.12,32.41 47.81,33.15 52.22,29.03",
			"35.11,12.09 37.12,12.46 38.57,12.09 41.14,12.09 41.68,10.08 41.14,9.12 41.14,8.11 35.11,8.11",
			"32.59,8.66 33.01,10.08 35,10.08 35,6.06 35.29,5.77 35,4.04 33.01,4.04 33.01,7.52",
			"27.93,16.31 28.78,18.59 30.75,20.16 33.55,23.62 34.88,24.53 35.71,26.8 37.73,26.48 35.92,15.05",
			"18.58,16.96 15.99,16.99 16.04,22.49 16.05,24.14 16.08,27 18.67,26.98 18.6,19.56 19.14,19.03",
			"10.74,9.96 11.63,10.22 12.24,10.91 13.73,9.6 11.07,6.59 9.73,5.07 8.24,6.39 10.55,9",
			"10.52,17.9 12.25,16.8 13.06,15.53 14.93,13.78 13.96,11.94 12.91,11.61 12.22,10.88 7.81,14.99",
			"32.02,27.75 31.19,25.51 29.2,23.91 26.38,20.42 25.07,19.54 24.24,17.27 22.22,17.58 24.03,29.02",
			"13.98,38.99 13.98,35.59 14.44,34.43 13.98,31.08 14.56,30.42 13.98,27.41 6.95,27.41 6.95,38.99",
			"41.06,41.95 41.06,38.57 41.52,37.32 41.06,34.06 41.64,33.38 41.06,30.37 34.03,30.37 34.03,41.95",
			"24.89,32.14 22.81,31.76 21.42,32.14 18.85,32.14 18.3,34.24 18.85,35.1 18.85,36.11 24.89,36.11",
			"27.4,35.34 26.98,33.92 24.99,33.92 24.99,37.94 24.71,38.28 24.99,39.97 26.98,39.97 26.98,36.48"
		],
		ruins: [
			"49.1,5.56 46.49,5.44 46.46,7.05 46.83,6.93 46.68,5.92 49.1,5.68",
			"46.28,13.46 46.44,16.13 52.5,16.01 50.43,15.67 50.64,14.1 49.78,13.12 48.69,13.43 48.14,13.03 47.27,13.77 46.41,13.4",
			"20.76,13.12 25.53,13.3 25.31,7.24 24.91,7.33 24.82,9.41 23.15,10.21 23.27,11.02 22.84,11.23 23.24,11.33 22.56,12.84 20.76,12.93",
			"25.57,2.44 19.33,2.37 19.33,5.42 19.73,5.42 19.85,4.68 23.1,3.82 23.1,2.99 25.6,2.74",
			"52.23,39.03 51.41,38.02 51.56,37.53 50.97,37.51 50.35,36.12 49.79,36.12 49.02,34.61 48.6,34.73 47.84,33.84 47.82,33.2 47.02,33.07 46.98,33.92 46.42,33.5 46.42,34.4 47.81,35.41 47.82,36.04 48.19,35.85 49.03,36.84 48.81,37.2 50.22,38.23 50.2,38.82 50.98,39.08 51.34,38.65 51.01,38.12 52.07,39.17",
			"42.28,26.97 43.31,26.9 42.58,26.69 42.56,25.11 42.55,23.48 43.28,23.28 42.06,23.36 42.15,26.91",
			"42.22,20.91 43.26,20.84 42.53,20.63 42.51,19.36 42.5,17.41 43.23,17.22 42.01,17.29 42.1,20.85",
			"41.33,22.99 42.43,23.04 42.62,23.66 42.77,23.04 43.08,23.35 43.81,23 43.2,22.64 43.22,21.28 43.86,20.97 42.75,20.82 42.56,20.27 42.44,20.82 41.4,20.89 41.96,21.26 41.97,22.68 41.33,22.81",
			"50.62,30.16 51.88,28.94 50.1,26.99 50.03,27.81 51.36,28.97 50.58,30.16",
			"46.79,29.37 45.57,30.34 47.7,32.32 46.07,30.3 46.96,29.42",
			"36.09,9.74 36.71,10.29 39.64,10.29 40.26,9.56 40.02,8.89 38.38,8.64 36.68,8.77 36.09,9.31",
			"36.82,11.14 38.21,11.54 39.48,11.2 38.37,10.1 36.91,11.05",
			"34.16,4.75 33.54,5.33 34,5.73 34,6.85 33.26,7.19 34,7.34 34,8.45 33.26,8.79 34,8.95 34.06,9.47 34.8,8.73 34.25,8.48 34.25,7.34 34.8,7.12 34.25,6.88 34.25,5.73 34.8,5.49 34.16,4.81",
			"35.72,26.25 37.28,26.13 36.97,24.72 36.98,25.81 35.71,26.19",
			"36.28,20.24 35.6,15.49 31.37,16.36 32.44,16.55 32.6,17.46 33.93,18.61 33.83,19.1 35.82,18.31 36.11,20.14",
			"17.72,17.04 16.68,17.11 17.42,17.32 17.45,20.54 16.72,20.73 17.94,20.66 17.84,17.1",
			"17.77,23.11 16.74,23.18 17.47,23.39 17.49,24.96 17.5,26.6 16.77,26.79 17.99,26.72 17.9,23.17",
			"18.67,21.02 17.56,20.97 17.37,20.35 17.23,20.97 16.18,21.01 16.8,21.38 16.78,22.73 16.14,23.05 17.25,23.19 17.43,23.74 17.55,23.19 18.69,23.06 18.04,22.75 18.03,21.34 18.67,21.21",
			"7.8,4.99 8.62,6 8.48,6.49 9.06,6.52 9.68,7.9 10.25,7.91 11.01,8.8 10.81,9.18 12.22,10.21 12.22,10.82 13.02,10.96 13.06,10.11 13.7,10.53 13.62,9.63 13.01,9.53 12.21,7.98 11.85,8.17 11,7.18 11.23,6.83 10.62,6.73 9.84,5.2 9.07,4.96 8.69,5.37 9.02,5.9 7.96,4.85",
			"9.4,13.85 8.15,15.07 9.92,17.02 9.99,16.2 8.67,15.05 9.45,13.86",
			"13.23,14.64 14.46,13.67 12.32,11.69 13.96,13.71 13.06,14.59",
			"23.58,23.89 24.42,28.61 28.62,27.59 27.55,27.44 26.07,24.94 24.11,25.8 23.75,23.98",
			"24.23,17.76 22.66,17.86 22.95,19.28 22.96,18.18 24.24,17.82",
			"10.84,38.33 13.45,38.45 13.48,36.83 13.11,36.95 13.27,37.96 10.84,38.21",
			"13.52,30.36 13.37,27.68 7.31,27.8 9.38,28.14 9.16,29.71 10.03,30.7 11.11,30.39 11.67,30.79 12.53,30.05 13.4,30.42",
			"39.1,30.88 34.33,30.7 34.55,36.76 34.95,36.67 35.04,34.6 36.72,33.79 36.59,32.99 37.03,32.77 36.62,32.68 37.3,31.16 39.1,31.07",
			"34.3,41.32 40.55,41.38 40.55,38.34 40.15,38.34 40.02,39.08 36.93,39.84 36.78,40.77 34.27,41.01",
			"23.9,34.48 23.28,33.93 20.35,33.93 19.73,34.66 19.98,35.34 21.61,35.58 23.31,35.46 23.9,34.91",
			"23.17,33.08 21.78,32.68 20.52,33.02 21.63,34.12 23.08,33.17",
			"25.84,39.26 26.45,38.67 25.99,38.27 25.99,37.16 26.73,36.82 25.99,36.66 25.99,35.55 26.73,35.21 25.99,35.06 25.93,34.53 25.19,35.27 25.74,35.52 25.74,36.66 25.19,36.88 25.74,37.13 25.74,38.27 25.19,38.52 25.84,39.2"
		],
		markers: [
			{
				kind: "home",
				x: 47.55,
				y: 10.99,
				owner: "defender"
			},
			{
				kind: "expansion",
				x: 20.53,
				y: 8.02
			},
			{
				kind: "centre",
				x: 33.16,
				y: 21.44
			},
			{
				kind: "centre",
				x: 26.79,
				y: 22.63
			},
			{
				kind: "home",
				x: 12.35,
				y: 33.04,
				owner: "attacker"
			},
			{
				kind: "expansion",
				x: 39.43,
				y: 36
			}
		]
	},
	{
		id: "th-di-a",
		letter: "A",
		a: "Take and Hold",
		b: "Disruption",
		label: "Disruption vs Take and Hold",
		edge: "Long edge",
		zones: [{
			side: "attacker",
			points: "59.86,35.99 30.02,35.99 30.02,30.01 0.14,30.01 0.14,43.96 59.86,43.96"
		}, {
			side: "defender",
			points: "59.86,0.04 0.13,0.04 0.13,8.02 30.02,8.02 30.02,13.99 59.86,13.99"
		}],
		terrain: [
			"54.97,26.98 51.6,26.98 50.38,26.52 47.08,26.98 46.45,26.39 43.39,26.98 43.39,34.01 54.97,34.01",
			"16.57,32.94 13.2,32.94 11.98,32.48 8.69,32.94 8.06,32.35 5,32.94 5,39.97 16.57,39.97",
			"47.38,35.04 45.32,35.51 44.19,36.39 41.82,37.4 42.12,39.51 42.98,40.13 43.38,41.06 48.93,38.7",
			"35.76,18.95 33.38,19.43 31.53,21.12 27.65,23.36 26.57,24.52 24.18,24.99 24.18,27.04 35.76,27.04",
			"24.18,25 26.55,24.51 28.4,22.82 32.28,20.58 33.36,19.42 35.75,18.95 35.75,16.91 24.18,16.91",
			"5.02,17.1 8.39,17.1 9.61,17.56 12.9,17.1 13.53,17.69 16.6,17.1 16.6,10.07 5.02,10.07",
			"43.37,11.05 46.74,11.05 47.96,11.51 51.26,11.05 51.88,11.63 54.95,11.05 54.95,4.01 43.37,4.01",
			"49.24,21.7 47.99,20.15 51.11,17.63 51.6,16.94 52.68,16.35 53.93,17.9 51.23,20.09 50.87,21.01",
			"31.67,13.64 33.38,11.7 29.26,8.05 28.03,6.95 25.89,5.06 24.17,7 29.72,11.92 29.86,12.79",
			"45.63,22.12 44.04,20.75 43.45,19.43 41.84,17.43 43.08,15.71 44.12,15.58 44.92,14.93 48.72,19.62",
			"38.66,8.21 37.1,6.97 34.6,10.12 34.18,10.19 33.34,11.7 34.9,12.94 37.06,10.21 37.98,9.85",
			"28.46,30.44 26.74,32.38 30.87,36.03 32.1,37.12 34.24,39.02 35.96,37.08 30.41,32.16 30.27,31.29",
			"21.47,35.87 23.03,37.11 25.53,33.96 25.95,33.89 26.79,32.38 25.23,31.14 23.07,33.87 22.15,34.23",
			"12.61,9.1 14.67,8.64 15.8,7.75 18.17,6.74 17.88,4.64 17.03,4.04 16.62,3.09 11.06,5.45",
			"10.76,22.41 12.01,23.95 8.88,26.48 8.82,26.9 7.31,27.75 6.06,26.21 8.77,24.02 9.12,23.09",
			"14.39,21.88 15.99,23.25 16.57,24.57 18.19,26.57 16.94,28.29 15.91,28.43 15.1,29.07 11.3,24.38"
		],
		ruins: [
			"48.72,27.66 43.94,27.48 44.15,33.55 44.56,33.46 44.65,31.41 46.33,30.58 46.17,29.89 46.64,29.56 46.24,29.47 46.92,27.96 48.75,27.69",
			"48.16,33.35 54.35,33.45 54.43,30.35 53.99,30.35 53.88,31.09 50.74,31.81 50.6,32.81 48.13,33.04",
			"8.23,33.56 5.62,33.42 5.59,35.06 5.96,34.92 5.83,33.91 8.27,33.73",
			"15.88,36.01 15.96,33.39 9.65,33.45 11.74,33.81 11.49,35.36 12.37,36.34 13.49,36.05 14.03,36.45 14.89,35.71 15.79,36.07",
			"42.9,39.05 43.62,40.64 46.08,39.64 45.32,39.28 43.76,40.12 42.91,38.99",
			"47.57,36.86 47.07,35.36 44.46,36.69 45.12,36.85 46.94,35.84 47.46,37",
			"24.89,24.96 24.71,26.42 25.08,26.76 26.16,26.46 25.14,26.24 25,24.93",
			"30.36,26.45 35.17,26.6 35.04,22.27 34.67,23.28 33.74,23.29 32.37,24.39 31.96,24.19 32.34,26.35 30.49,26.29",
			"29.58,17.49 24.77,17.34 24.9,21.67 25.27,20.66 26.19,20.65 27.57,19.55 27.98,19.75 27.6,17.59 29.44,17.65",
			"35.04,18.98 35.22,17.52 34.85,17.18 33.69,17.48 34.79,17.7 34.93,19.01",
			"11.83,10.73 5.64,10.63 5.55,13.73 5.99,13.73 6.11,13 9.25,12.28 9.39,11.27 11.86,11.04",
			"11.38,16.42 16.16,16.6 15.94,10.53 15.54,10.62 15.45,12.67 13.76,13.51 13.93,14.19 13.46,14.52 13.86,14.61 13.18,16.12 11.35,16.4",
			"44.06,7.98 43.98,10.59 50.29,10.53 48.21,10.18 48.45,8.62 47.57,7.64 46.46,7.93 45.92,7.53 45.05,8.27 44.15,7.92",
			"51.74,10.47 54.35,10.6 54.38,8.96 54.01,9.1 54.14,10.12 51.7,10.29",
			"52.68,17.45 52.52,18.38 51.97,18.23 51.14,18.91 51.5,19.58 50.83,19.22 49.9,19.93 50.04,20.78 49.5,20.26 49.05,20.53 49.17,19.47 49.73,19.73 50.58,19.02 50.4,18.45 50.95,18.72 51.5,18.28 51.66,17.41 52.58,17.47",
			"27.65,8.82 28.22,7.91 27.62,8.35 25.26,6.24 25.51,5.56 24.81,6.47 27.6,8.81",
			"27.09,9.69 27.92,9.55 28.8,10.34 28.67,11.02 29.43,10.28 29.94,10.5 29.63,10 30.01,10.03 30.3,9.09 29.64,9.39 28.58,8.45 28.71,7.77 27.95,8.51 27.41,8.26 27.7,8.72 27.08,9.59",
			"32.36,12.99 32.92,12.07 32.33,12.51 31.17,11.49 29.96,10.4 30.29,9.74 29.51,10.63 32.3,12.98",
			"43.4,18.25 45.07,20.26 45.09,18.7 46.37,17.87 46.03,17.44 44.37,18.59 43.44,18.13",
			"44.07,16.65 44.05,17.51 45.82,19.75 46.88,19.81 47.2,19.19 46.35,17.73 45.22,16.51 44.46,16.41",
			"33.65,13.76 34.51,12.73 34.99,12.78 34.91,12.22 35.65,11.29 36.14,11.34 36.02,10.84 36.77,9.86 37.24,9.92 37.92,8.43 38.52,8.3 38.49,7.43 37.66,7.59 37.93,6.89 37.07,7.13 37.1,7.71 36.35,8.67 35.92,8.57 35.16,10.15 34.79,9.99 34.06,11.55 33.44,11.68 33.42,12.6 34.27,12.54 33.49,13.56",
			"27.77,31.09 27.21,32.01 27.8,31.57 29.24,32.84 30.17,33.67 29.84,34.34 30.62,33.37 27.83,31.1",
			"33.04,34.39 32.21,34.53 31.33,33.74 31.54,33.06 30.7,33.79 30.19,33.58 30.5,34.08 30.12,34.05 29.83,34.99 30.49,34.69 31.55,35.63 31.42,36.31 32.18,35.57 32.72,35.81 32.42,35.36 33.05,34.49",
			"32.48,35.26 31.91,36.17 32.51,35.73 34.87,37.84 34.62,38.51 35.32,37.53 32.53,35.26",
			"26.48,30.32 25.62,31.35 25.13,31.3 25.22,31.85 24.48,32.79 23.99,32.73 24.11,33.23 23.36,34.21 22.89,34.16 22.21,35.65 21.61,35.78 21.64,36.64 22.41,36.47 22.2,37.19 23.06,36.95 23.78,35.4 24.21,35.51 24.97,33.93 25.54,33.83 25.33,33.46 26.69,32.39 26.71,31.47 25.86,31.54 26.64,30.52",
			"12.43,7.29 12.93,8.79 15.54,7.45 14.87,7.3 13.06,8.3 12.54,7.14",
			"17.1,5.09 16.37,3.5 13.92,4.5 14.67,4.87 16.24,4.02 17.08,5.15",
			"7.28,26.6 7.44,25.67 7.99,25.82 8.82,25.14 8.68,24.29 9.23,24.8 10.06,24.12 9.69,23.46 10.91,23.52 10.79,24.59 10.22,24.32 9.7,24.75 9.56,25.6 9.01,25.34 8.16,26.03 8.3,26.65 7.37,26.58",
			"15.95,27.35 15.98,26.5 14.21,24.26 13.15,24.2 12.82,24.81 13.67,26.27 14.8,27.5 15.57,27.6",
			"16.62,25.75 14.95,23.74 14.94,25.3 13.66,26.13 14,26.56 15.66,25.41 16.58,25.87"
		],
		markers: [
			{
				kind: "expansion",
				x: 49.03,
				y: 28.61
			},
			{
				kind: "home",
				x: 10.63,
				y: 34.57,
				owner: "attacker"
			},
			{
				kind: "centre",
				x: 30.06,
				y: 20.64
			},
			{
				kind: "expansion",
				x: 10.96,
				y: 15.47
			},
			{
				kind: "home",
				x: 49.31,
				y: 9.42,
				owner: "defender"
			}
		]
	},
	{
		id: "th-di-b",
		letter: "B",
		a: "Take and Hold",
		b: "Disruption",
		label: "Disruption vs Take and Hold",
		edge: "Short edge",
		zones: [{
			side: "attacker",
			points: "30.02,43.96 0.13,0.04 0.14,43.96"
		}, {
			side: "defender",
			points: "59.75,44.07 59.75,0.15 29.87,0.15"
		}],
		terrain: [
			"39.8,13.99 42.02,12.66 39.18,7.93 38.34,6.52 36.86,4.07 34.64,5.41 38.46,11.77 38.33,12.64",
			"20.06,29.96 17.84,31.3 20.68,36.02 21.52,37.43 23,39.88 25.22,38.55 21.4,32.19 21.53,31.32",
			"47.81,22.08 46.18,23.22 48.48,26.51 48.43,26.93 49.64,28.17 51.27,27.03 49.27,24.17 49.19,23.19",
			"49.42,20.8 48.53,18.9 47.41,17.98 45.92,15.89 43.91,16.64 43.51,17.61 42.69,18.2 46.19,23.11",
			"44.4,12.09 47.77,12.09 48.99,12.55 52.29,12.09 52.91,12.68 55.98,12.09 55.98,5.06 44.4,5.06",
			"24.27,24.99 26.65,24.51 28.5,22.82 32.38,20.58 33.46,19.42 35.85,18.95 35.85,16.9 24.27,16.9",
			"35.84,18.92 33.46,19.41 31.62,21.1 27.73,23.34 26.66,24.5 24.27,24.97 24.27,27.01 35.84,27.01",
			"15.63,31.95 12.26,31.95 11.04,31.49 7.75,31.95 7.12,31.36 4.05,31.95 4.05,38.98 15.63,38.98",
			"24.01,10.04 26,10.05 26.03,6.04 26.27,5.22 26.05,4.01 24.06,3.99 24.03,7.48 23.54,8.33",
			"25.93,12.98 27.97,13.36 29.39,12.98 31.96,12.98 32.52,10.91 31.96,10.02 31.96,9.01 25.93,9.01",
			"36.07,33.93 34.09,33.91 34.05,37.92 33.76,38.24 34.03,39.95 36.02,39.97 36.05,36.48 36.55,35.63",
			"34.14,31.09 32.09,30.71 30.67,31.09 28.1,31.09 27.55,33.14 28.1,34.05 28.1,35.06 34.14,35.06",
			"12.22,21.86 13.85,20.72 11.55,17.43 11.6,17.01 10.39,15.77 8.76,16.91 10.76,19.77 10.84,20.75",
			"10.6,23.13 11.49,25.02 12.62,25.96 14.11,28.05 16.1,27.31 16.5,26.35 17.34,25.74 13.84,20.83",
			"52.96,36.07 51.03,33.3 50.71,32.04 48.44,29.61 48.56,28.75 46.32,26.58 40.56,30.62 47.2,40.1",
			"7.17,8.03 9.1,10.8 9.42,12.06 11.69,14.5 11.57,15.35 13.81,17.52 19.57,13.49 12.93,4"
		],
		ruins: [
			"37.58,8.33 38.43,7.76 37.73,7.92 36.18,5.34 36.58,4.61 35.57,5.24 37.54,8.31",
			"37.06,8.73 37.77,8.65 38.5,9.87 38.17,10.48 39.1,9.97 39.61,10.37 39.39,9.79 39.74,9.94 40.3,9.13 39.58,9.22 38.85,8 39.18,7.39 38.24,7.87 37.79,7.47 37.96,8.07 37.08,8.64",
			"40.73,13.36 41.58,12.79 40.88,12.95 39.21,10.18 39.73,9.64 38.72,10.26 40.68,13.33",
			"19.39,30.54 18.57,31.25 19.24,30.95 20.9,33.72 20.39,34.26 21.4,33.64 19.43,30.57",
			"22.91,35.34 22.2,35.41 21.47,34.2 21.8,33.59 20.87,34.1 20.43,33.7 20.58,34.27 20.22,34.13 19.67,34.93 20.39,34.85 21.12,36.07 20.7,36.66 21.73,36.19 22.18,36.59 22.03,36.07 22.89,35.43",
			"22.5,35.62 21.65,36.19 22.35,36.03 24.01,38.8 23.5,39.34 24.51,38.72 22.54,35.65",
			"51.68,28.4 51.07,26.74 50.57,26.76 50.02,25.24 49.56,25.31 48.84,24.3 49.03,23.87 47.79,22.8 47.84,22.18 47,21.96 46.95,22.75 46.31,22.35 46.3,23.24 46.87,23.38 47.58,24.37 47.36,24.75 48.66,25.93 48.59,26.51 49,26.41 49.69,27.38 49.64,28.01 50.51,28.3 50.69,27.46 51.45,28.5",
			"46.89,17.74 45.83,16.33 43.65,17.84 44.46,18.03 45.81,16.87 46.88,17.79",
			"45.53,21.42 46.34,22.79 48.61,20.92 48.12,20.8 46.36,22.28 45.62,21.26",
			"44.95,9.02 44.87,11.63 51.18,11.57 49.09,11.22 49.34,9.66 48.46,8.68 47.34,8.97 46.8,8.57 45.94,9.31 45.04,8.96",
			"55.39,8.31 55.53,5.7 54.07,5.59 54.06,6.04 55.05,5.9 55.23,8.34",
			"26.4,17.3 25.06,17.02 24.6,17.49 24.9,18.57 25.13,17.54 26.43,17.4",
			"25.03,21.85 24.87,26.65 29.21,26.53 28.2,26.16 27.25,23.39 25.15,23.83 25.13,21.91",
			"35.35,22.25 35.5,17.44 31.16,17.57 32.17,17.93 33.12,20.71 35.22,20.26 35.24,22.18",
			"33.96,26.45 35.5,26.56 35.46,25.18 35.23,26.21 33.93,26.34",
			"4.64,35.73 4.5,38.34 6.14,38.37 5.97,38 4.98,38.13 4.8,35.7",
			"15.09,35.02 15.16,32.41 8.85,32.47 10.94,32.82 10.69,34.38 11.57,35.36 12.69,35.07 13.23,35.47 14.1,34.73 14.99,35.08",
			"25.22,4.62 24.6,5.24 25.07,5.65 25.08,6.74 24.34,7.08 25.08,7.28 25.08,8.35 24.34,8.78 25.04,8.78 25.22,9.39 25.9,8.62 25.34,8.36 25.35,7.25 25.9,7.02 25.35,6.77 25.34,5.67 25.9,5.39 25.27,4.72",
			"31.19,11.31 30.53,10.74 27.65,10.74 26.97,11.54 27.48,12.25 29.08,12.41 30.61,12.28 31.15,11.75",
			"30.44,9.93 29.14,9.5 27.68,9.83 28.87,10.97 30.37,10.01",
			"34.87,39.34 35.48,38.72 35.01,37.22 35.75,36.88 35.01,36.68 35.01,35.61 35.75,35.18 35.05,35.18 34.87,34.57 34.18,35.34 34.74,35.6 34.74,36.72 34.18,36.94 34.74,37.19 34.74,38.29 34.18,38.57 34.74,39.21",
			"29.7,34.15 30.93,34.57 32.38,34.24 31.2,33.1 29.7,34.06",
			"28.88,32.76 29.55,33.33 32.42,33.33 33.1,32.53 32.84,31.92 31,31.66 29.47,31.79 28.93,32.32",
			"8.28,15.54 9.02,16.65 8.83,17.1 9.39,17.18 10.07,18.15 9.88,18.61 10.4,18.63 10.94,20.07 12.17,21.14 12.13,21.76 12.96,21.97 13.01,21.19 13.65,21.59 13.66,20.69 12.38,19.57 12.61,19.19 11.3,18.01 11.38,17.43 10.96,17.53 10.32,15.93 9.45,15.64 9.27,16.47 8.51,15.44",
			"14.43,22.52 13.62,21.15 11.35,23.02 12.03,23.03 13.6,21.65 14.35,22.68",
			"13.08,26.19 14.14,27.61 16.31,26.1 15.51,25.9 14.16,27.06 13.09,26.14",
			"45.04,28.07 41.02,30.66 44.67,35.51 44.95,35.26 43.85,33.46 44.66,31.7 43.73,29.34 45.07,28.07",
			"47.49,39.59 52.66,36.05 50.91,33.53 50.55,33.79 50.88,34.46 48.74,36.83 49.18,37.72 47.29,39.32",
			"12.82,4.58 7.69,8.05 9.37,10.59 9.76,10.38 9.43,9.71 11.57,7.34 11.13,6.45 13.02,4.85",
			"15.1,15.96 19.13,13.37 15.48,8.51 15.19,8.76 16.3,10.56 15.48,12.32 16.41,14.69 15.07,15.95"
		],
		markers: [
			{
				kind: "home",
				x: 50.34,
				y: 10.46,
				owner: "defender"
			},
			{
				kind: "centre",
				x: 30.15,
				y: 20.63
			},
			{
				kind: "home",
				x: 9.69,
				y: 33.58,
				owner: "attacker"
			},
			{
				kind: "expansion",
				x: 48.22,
				y: 32.13
			},
			{
				kind: "expansion",
				x: 11.91,
				y: 11.97
			}
		]
	},
	{
		id: "th-di-c",
		letter: "C",
		a: "Take and Hold",
		b: "Disruption",
		label: "Disruption vs Take and Hold",
		edge: "Short edge",
		zones: [{
			side: "attacker",
			points: "0.14,43.96 0.14,0.04 18.01,0.04 18.01,43.96"
		}, {
			side: "defender",
			points: "41.99,43.96 41.99,0.04 59.86,0.04 59.86,43.96"
		}],
		terrain: [
			"50.02,27.59 50.02,24.22 50.48,23 50.02,19.7 50.61,19.07 50.02,16.01 42.99,16.01 42.99,27.59",
			"34.02,30.34 34.02,33.71 33.56,34.93 34.02,38.22 33.44,38.85 34.02,41.92 41.06,41.92 41.06,30.34",
			"48.98,9.94 48.98,11.92 52.99,11.92 53.31,12.21 55.02,11.92 55.02,9.94 51.54,9.94 50.68,9.45",
			"46.29,39.98 48.88,39.98 48.88,34.47 48.88,32.83 48.88,29.97 46.29,29.97 46.29,37.39 45.73,38.07",
			"35.02,13.1 35.02,11.11 39.03,11.11 39.35,10.83 41.06,11.11 41.06,13.1 37.58,13.1 36.72,13.59",
			"32,11.23 31.62,9.19 32,7.76 32,5.2 34.08,4.64 34.94,5.19 35.97,5.2 35.97,11.23",
			"45.05,3.9 44.67,5.97 45.05,7.37 45.05,9.94 47.1,10.49 48.01,9.94 49.02,9.94 49.02,3.9",
			"25.09,30.97 25.09,32.96 21.07,32.96 20.75,33.25 19.05,32.96 19.05,30.97 22.53,30.97 23.38,30.48",
			"27.88,32.93 28.26,34.98 27.88,36.4 27.88,38.97 25.83,39.52 24.92,38.97 23.91,38.97 23.91,32.93",
			"9.97,16.36 9.97,19.73 9.51,20.95 9.97,24.25 9.38,24.88 9.97,27.94 17,27.94 17,16.36",
			"13.66,4.01 11.07,4.01 11.07,9.52 11.07,11.17 11.07,14.02 13.66,14.02 13.66,6.61 14.11,5.32",
			"26.13,13.62 26.13,10.25 26.59,9.03 26.13,5.74 26.71,5.11 26.13,2.04 19.1,2.04 19.1,13.62",
			"35.75,18.95 33.37,19.44 31.53,21.13 27.64,23.37 26.57,24.53 24.18,25 24.18,27.04 35.75,27.04",
			"24.16,25.01 26.53,24.53 27.61,23.39 32.26,20.59 33.34,19.43 35.73,18.96 35.73,16.92 24.16,16.92",
			"11.02,33.94 11.02,31.95 7.01,31.95 6.69,31.66 4.98,31.95 4.98,33.94 8.46,33.94 9.32,34.43",
			"14.93,39.97 15.31,37.93 14.93,36.5 14.93,33.94 12.86,33.38 12,33.93 10.96,33.94 10.96,39.97"
		],
		ruins: [
			"43.57,24.42 43.43,27.03 44.72,27.21 45.16,27 44.91,26.69 43.91,26.83 43.74,24.39",
			"45.93,16.55 43.31,16.48 43.37,22.8 43.74,20.71 45.29,20.95 46.33,19.97 45.98,18.95 46.37,18.41 45.65,17.56 46,16.66",
			"39.23,30.96 34.45,30.78 34.66,36.85 35.06,36.77 35.16,34.71 36.84,33.88 36.67,33.19 37.14,32.86 36.75,32.77 37.43,31.26 39.26,30.99",
			"34.16,41.47 40.35,41.57 40.44,38.47 40,38.47 39.88,39.2 36.74,39.92 36.6,40.93 34.13,41.16",
			"48.35,11.29 49.06,11.81 49.52,11.41 50.76,11.41 50.91,11.81 51.35,11.41 52.58,11.41 52.74,11.81 54.41,11.41 54.87,11.81 55.59,11.41 55.18,11.11 55.46,10.83 54.9,10.74 56.36,10.4 54.97,10.34 54.84,9.94 54.16,10.37 53.14,10.34 53.02,9.94 52.55,10.37 51.38,10.37 51.19,9.94 49.55,10.37 49.09,9.94 48.44,10.49 49,10.71 48.47,10.95 49.06,11.05 48.56,11.14",
			"46.2,33.96 46.84,34.27 46.84,35.69 46.25,36.04 47.31,36.08 47.47,36.64 47.64,36.08 47.86,36.39 48.76,35.98 48.1,35.68 48.1,34.27 48.7,33.91 47.64,33.84 47.47,33.27 47.3,33.87 46.31,33.89",
			"47.02,39.99 48.09,39.93 47.37,39.72 47.37,36.49 48.09,36.29 46.84,36.35 47,39.95",
			"47.02,33.82 48.09,33.75 47.37,33.55 47.37,30.32 48.09,30.12 46.84,30.18 47,33.78",
			"35.64,12.02 36.26,12.64 36.68,12.16 37.77,12.16 37.85,12.9 38.28,12.16 39.44,12.19 39.8,12.9 39.8,12.2 40.4,12.08 39.64,11.34 39.38,11.9 38.27,11.9 38.05,11.34 37.79,11.9 36.66,11.9 36.4,11.34 35.77,11.9",
			"32.89,6.89 32.47,8.06 32.81,9.56 33.93,7.92 33.22,7.75 33.01,6.92",
			"34.27,6.12 33.72,6.77 33.71,9.52 33.98,10.19 34.51,10.23 35.14,10.06 35.38,8.39 35.26,6.61 34.73,6.06",
			"45.46,8.01 45.33,9.59 48.26,9.39 47.92,9 45.64,9.2 45.71,7.93",
			"48.62,5.92 48.58,4.17 45.88,4.15 46.48,4.75 48.25,4.59 48.58,5.96",
			"24.46,32.05 23.85,31.44 23.43,31.92 22.33,31.92 22.26,31.17 21.82,31.92 20.66,31.88 20.31,31.17 20.31,31.87 19.71,31.99 20.46,32.73 20.73,32.18 21.84,32.18 22.05,32.73 22.32,32.18 23.44,32.18 23.71,32.73 24.34,32.18",
			"25.61,38.07 26.17,37.42 26.17,34.56 25.38,33.86 24.65,34.36 24.5,35.81 24.62,37.44 25.16,38.02",
			"26.99,37.31 27.41,36.02 27.08,34.6 25.95,36.16 26.67,36.41 26.87,37.16",
			"14.06,27.4 16.68,27.47 16.62,21.15 16.26,23.24 14.71,22.99 13.67,23.97 14.02,24.99 13.62,25.53 14.34,26.39 13.99,27.28",
			"16.53,19.51 16.68,16.9 15.38,16.72 14.95,16.93 15.2,17.24 16.2,17.1 16.37,19.54",
			"12.82,10.17 11.76,10.24 12.48,10.44 12.48,13.67 11.76,13.87 13,13.81 12.84,10.21",
			"12.82,3.89 11.76,3.96 12.48,4.16 12.48,7.39 11.76,7.59 13,7.53 12.84,3.93",
			"13.75,10.03 13.11,9.72 13.11,8.3 13.71,7.95 12.64,7.91 12.48,7.35 12.31,7.91 12.09,7.6 11.19,8.01 11.85,8.31 11.85,9.72 11.26,10.08 12.31,10.15 12.48,10.72 12.65,10.12 13.64,10.1",
			"25.86,2.45 19.67,2.35 19.58,5.45 20.02,5.45 20.14,4.71 23.27,3.99 23.42,2.99 25.89,2.76",
			"20.79,13 25.65,13.06 25.35,7.11 24.95,7.19 24.86,9.25 23.17,10.08 23.34,10.77 22.87,11.1 23.27,11.19 22.59,12.7 20.76,12.97",
			"35.18,22.08 35.33,17.28 31,17.4 32.01,17.76 32.95,20.54 35.05,20.09 35.08,22.02",
			"33.69,26.53 35.23,26.64 35.19,25.18 34.96,26.29 33.66,26.43",
			"26.29,17.41 24.83,17.23 24.49,17.59 24.79,18.76 25.03,17.65 26.33,17.51",
			"24.64,21.89 24.49,26.69 28.83,26.57 27.81,26.21 26.87,23.43 24.77,23.88 24.74,21.95",
			"11.66,32.58 10.94,32.06 10.48,32.46 9.24,32.46 9.09,32.06 8.65,32.46 7.42,32.46 7.26,32.06 5.59,32.46 5.13,32.06 4.42,32.46 4.82,32.76 4.54,33.04 5.1,33.13 3.64,33.47 5.03,33.53 5.16,33.93 5.84,33.5 6.86,33.53 6.98,33.93 7.45,33.5 8.62,33.5 8.81,33.93 10.45,33.5 10.91,33.93 11.56,33.38 11.01,33.16 11.53,32.92 10.94,32.82 11.44,32.73",
			"11.37,37.95 11.41,39.7 14.12,39.72 13.51,39.12 11.74,39.28 11.41,37.91",
			"14.53,35.86 14.66,34.28 11.73,34.48 12.07,34.87 14.35,34.68 14.36,35.94"
		],
		markers: [
			{
				kind: "home",
				x: 48.39,
				y: 21.65,
				owner: "defender"
			},
			{
				kind: "expansion",
				x: 35.65,
				y: 36.28
			},
			{
				kind: "home",
				x: 11.6,
				y: 22.3,
				owner: "attacker"
			},
			{
				kind: "expansion",
				x: 24.5,
				y: 7.68
			},
			{
				kind: "centre",
				x: 29.87,
				y: 23.31
			}
		]
	},
	{
		id: "th-re-a",
		letter: "A",
		a: "Take and Hold",
		b: "Reconnaissance",
		label: "Reconnaissance vs Take and Hold",
		edge: "Short edge",
		zones: [{
			side: "attacker",
			points: "0.19,43.96 20.02,43.96 20.02,22.02 12.06,22.02 12.06,0.04 0.19,0.04"
		}, {
			side: "defender",
			points: "59.86,0.04 40.03,0.04 40.03,21.98 47.98,21.98 47.98,43.96 59.86,43.96"
		}],
		terrain: [
			"25.99,11.01 27.98,11.01 27.98,6.99 28.26,6.67 27.98,4.97 25.99,4.97 25.99,8.45 25.5,9.3",
			"28.03,12.03 28.03,10.04 32.05,10.04 32.36,9.76 34.07,10.04 34.07,12.03 30.59,12.03 29.73,12.52",
			"38.36,14.02 40.95,14.02 40.95,8.51 40.95,6.87 40.95,4.01 38.36,4.01 38.36,11.42 37.91,12.71",
			"46.98,22.42 46.6,24.46 46.98,25.88 46.98,28.45 49.05,29.01 49.92,28.46 50.95,28.45 50.95,22.42",
			"35.74,18.87 33.37,19.35 31.51,21.05 27.64,23.28 26.56,24.44 24.18,24.91 24.18,26.96 35.74,26.96",
			"24.19,25.17 26.57,24.69 27.65,23.55 32.3,20.76 33.38,19.6 35.77,19.13 35.77,17.08 24.19,17.08",
			"34.03,32.96 32.04,32.96 32.04,36.98 31.76,37.3 32.04,39 34.03,39 34.03,35.52 34.52,34.66",
			"31.99,32.05 31.99,34.04 27.97,34.04 27.66,34.32 25.95,34.04 25.95,32.05 29.43,32.05 30.29,31.56",
			"40.93,13.99 40.55,16.04 40.93,17.46 40.93,20.03 42.98,20.58 43.87,20.03 44.9,20.03 44.9,13.99",
			"21.45,29.95 18.86,29.95 18.86,35.46 18.86,37.1 18.86,39.96 21.45,39.96 21.45,32.54 22.02,31.86",
			"18.93,29.97 19.31,27.92 18.93,26.5 18.93,23.93 16.88,23.38 15.97,23.93 14.96,23.93 14.96,29.97",
			"55.02,18.61 55.02,15.24 55.48,14.02 55.02,10.72 55.61,10.09 55.02,7.03 47.99,7.03 47.99,18.61",
			"47.02,39.93 47.02,36.55 47.48,35.34 47.02,32.04 47.61,31.41 47.02,28.35 39.99,28.35 39.99,39.93",
			"12.99,4.09 12.99,7.46 12.53,8.68 12.99,11.98 12.4,12.61 12.99,15.67 20.02,15.67 20.02,4.09",
			"5,25.46 5,28.84 4.54,30.05 5,33.35 4.42,33.98 5,37.04 12.03,37.04 12.03,25.46",
			"13.06,21.61 13.44,19.57 13.06,18.14 13.06,15.57 11.01,15.02 10.12,15.57 9.09,15.57 9.09,21.61"
		],
		ruins: [
			"27.09,5.5 26.47,6.11 26.94,6.53 26.95,7.62 26.21,7.95 26.95,8.16 26.95,9.23 26.21,9.66 26.91,9.66 27.02,10.27 27.78,9.5 27.21,9.23 27.22,8.12 27.78,7.9 27.22,7.65 27.21,6.54 27.78,6.27 27.22,5.62",
			"34.69,10.64 33.98,10.12 33.51,10.51 32.27,10.51 32.12,10.12 31.69,10.51 30.45,10.51 30.29,10.12 28.62,10.51 28.16,10.12 27.45,10.51 27.85,10.82 27.57,11.1 28.13,11.19 26.67,11.53 28.07,11.59 28.19,11.99 28.87,11.56 29.89,11.59 30.02,11.99 30.48,11.56 31.66,11.56 31.84,11.99 33.48,11.56 33.94,11.99 34.59,11.44 33.98,10.88 34.47,10.79",
			"38.39,8.01 39.03,8.54 39.03,9.73 38.44,10.08 39.5,10.13 39.67,10.69 39.83,10.13 40.05,10.44 40.96,10.03 40.29,9.73 40.29,8.32 40.89,7.96 39.83,7.88 39.66,7.32 39.49,7.91 38.51,7.94",
			"39.39,14.09 40.45,14.02 39.73,13.82 39.73,10.58 40.45,10.39 39.2,10.45 39.36,14.05",
			"39.52,7.87 40.58,7.8 39.86,7.6 39.86,4.36 40.54,4.1 39.33,4.23 39.49,7.83",
			"47.3,26.27 47.34,28.03 50.05,28.05 49.44,27.44 47.68,27.61 47.34,26.23",
			"50.52,24.22 50.65,22.64 47.72,22.85 48.06,23.23 50.34,23.04 50.27,24.3",
			"35.05,22.36 35.21,17.56 30.87,17.69 31.88,18.05 32.83,20.83 34.93,20.38 34.95,22.3",
			"33.62,26.38 35.16,26.49 35.12,25.11 34.89,26.14 33.59,26.27",
			"26.23,17.68 24.69,17.57 24.73,19.03 24.97,17.92 26.26,17.78",
			"24.73,21.7 24.57,26.5 28.91,26.38 27.9,26.01 26.95,23.24 24.85,23.68 24.83,21.76",
			"32.93,38.47 33.55,37.86 33.08,37.44 33.07,36.35 33.81,36.02 33.07,35.81 33.07,34.74 33.81,34.31 33.11,34.31 33,33.7 32.24,34.47 32.81,34.74 32.8,35.85 32.24,36.07 32.8,36.32 32.81,37.42 32.24,37.7 32.8,38.35",
			"25.33,33.44 26.04,33.96 26.51,33.56 27.75,33.56 27.9,33.96 28.33,33.56 29.57,33.56 29.73,33.96 31.4,33.56 31.86,33.96 32.57,33.56 32.17,33.26 32.45,32.98 31.89,32.89 33.35,32.55 31.95,32.49 31.83,32.09 31.15,32.52 30.13,32.49 30,32.09 29.54,32.52 28.37,32.52 28.18,32.09 26.54,32.52 26.08,32.09 25.43,32.64 26.04,33.2 25.55,33.29",
			"41.68,15.74 41.29,17.05 41.57,18.38 42.75,16.9 42.01,16.6 41.83,15.9",
			"43.09,14.99 42.53,15.65 42.53,18.5 43.32,19.21 43.95,18.93 44.2,17.12 44.07,15.6 43.54,15.04",
			"20.3,36.1 19.24,36.17 19.95,36.37 19.95,39.61 19.24,39.8 20.48,39.74 20.32,36.14",
			"20.43,29.88 19.36,29.95 20.08,30.15 20.08,33.38 19.36,33.58 20.61,33.52 20.45,29.92",
			"21.42,35.96 20.78,35.65 20.78,34.24 21.37,33.88 20.31,33.84 20.08,33.24 19.98,33.84 19.76,33.53 18.86,33.94 19.52,34.24 19.52,35.65 18.92,36.01 19.98,36.08 20.15,36.65 20.32,36.05 21.31,36.03",
			"16.8,28.99 17.35,28.33 17.36,25.47 16.56,24.77 15.93,25.05 15.69,26.86 15.81,28.38 16.34,28.94",
			"18.18,28.22 18.6,26.93 18.31,25.6 17.14,27.07 17.85,27.35 18.06,28.07",
			"51.15,7.51 48.54,7.37 48.51,9.01 48.88,8.87 48.75,7.86 51.19,7.68",
			"48.36,15.65 48.3,18.26 54.61,18.15 52.52,17.81 52.76,16.26 51.86,15.28 50.75,15.58 50.21,15.19 49.35,15.93 48.45,15.59",
			"45.07,28.91 40.29,28.73 40.5,34.8 40.9,34.72 41,32.66 42.68,31.83 42.52,31.14 42.99,30.81 42.59,30.72 43.27,29.21 45.1,28.94",
			"40.3,39.5 46.49,39.6 46.58,36.5 46.14,36.5 46.02,37.24 42.89,37.96 42.75,38.96 40.27,39.19",
			"19.71,4.51 13.52,4.42 13.43,7.52 13.87,7.52 13.99,6.78 17.12,6.06 17.27,5.06 19.74,4.82",
			"14.94,15.1 19.72,15.28 19.51,9.21 19.11,9.3 19.01,11.35 17.33,12.19 17.5,12.87 17.02,13.2 17.42,13.3 16.74,14.8 14.91,15.08",
			"11.67,28.42 11.72,25.81 5.41,25.93 7.5,26.26 7.27,27.82 8.16,28.79 9.27,28.49 9.82,28.89 10.68,28.14 11.58,28.49",
			"8.87,36.56 11.48,36.7 11.6,35.25 11.14,35.2 11.27,36.22 8.83,36.39",
			"9.42,19.92 9.29,21.5 12.22,21.3 11.88,20.91 9.6,21.11 9.59,19.84",
			"12.75,17.76 12.71,16.01 10,15.99 10.61,16.59 12.37,16.43 12.71,17.8"
		],
		markers: [
			{
				kind: "centre",
				x: 29.87,
				y: 23.23
			},
			{
				kind: "home",
				x: 53.39,
				y: 12.67,
				owner: "defender"
			},
			{
				kind: "expansion",
				x: 45.39,
				y: 33.99
			},
			{
				kind: "expansion",
				x: 14.62,
				y: 10.03
			},
			{
				kind: "home",
				x: 6.63,
				y: 31.4,
				owner: "attacker"
			}
		]
	},
	{
		id: "th-re-b",
		letter: "B",
		a: "Take and Hold",
		b: "Reconnaissance",
		label: "Reconnaissance vs Take and Hold",
		edge: "Long edge",
		zones: [{
			side: "attacker",
			points: "0.14,43.96 0.14,32 59.88,32 59.88,43.96"
		}, {
			side: "defender",
			points: "0.14,12.01 0.14,0.04 59.88,0.04 59.88,12.01"
		}],
		terrain: [
			"55.04,24.08 51.66,24.08 50.41,23.62 47.15,24.08 46.52,23.49 43.46,24.08 43.46,31.11 55.04,31.11",
			"52.95,4.53 49.55,4.53 48.39,4.07 45.04,4.53 44.39,3.95 41.37,4.53 41.37,11.57 52.95,11.57",
			"28.18,30.01 26.35,31.06 25.52,32.24 23.56,33.9 24.49,35.86 25.46,36.17 26.11,36.94 30.74,33.06",
			"24.27,25.07 26.61,24.59 27.72,23.44 32.39,20.64 33.44,19.5 35.84,19.02 35.84,16.97 24.27,16.97",
			"35.87,18.98 33.52,19.45 31.66,21.14 27.74,23.41 26.67,24.56 24.29,25.03 24.29,27.07 35.87,27.07",
			"32.22,31.78 30.7,33.06 33.28,36.13 33.25,36.54 34.58,37.69 36.11,36.41 33.87,33.74 33.73,32.83",
			"16.57,19.97 13.17,19.97 11.75,20.37 8.67,19.97 8.01,20.55 4.99,19.97 4.99,12.93 16.57,12.93",
			"7.09,39.45 10.47,39.45 11.78,39.9 14.98,39.45 15.61,40.04 18.67,39.45 18.67,32.42 7.09,32.42",
			"50.38,34.39 49.08,33.69 47.67,35.09 50.51,37.93 50.55,38.38 51.95,39.37 53.35,37.96 50.89,35.5",
			"43.03,13.99 41.89,16.32 46.84,18.73 48.32,19.45 50.89,20.71 52.03,18.38 45.36,15.12 45.2,14.51",
			"45,32.2 43.29,33.33 42.51,34.61 40.66,36.39 41.67,38.21 42.72,38.52 43.42,39.25 47.76,35.06",
			"17.08,29.9 18.22,27.57 13.27,25.16 11.79,24.44 9.22,23.18 8.08,25.51 14.75,28.76 14.99,29.48",
			"31.79,14.05 33.62,13.01 34.45,11.82 36.42,10.17 35.54,8.28 34.51,7.9 33.86,7.13 29.24,11.01",
			"26.63,11.5 27.79,12.29 29.31,11.01 26.73,7.94 26.73,7.49 25.43,6.38 23.9,7.66 26.14,10.33",
			"9.01,8.89 9.91,9.09 10.56,9.75 11.97,8.34 9.13,5.5 7.7,4.07 6.29,5.48 8.75,7.94",
			"14.66,11.24 16.37,10.11 17.15,8.83 19,7.05 17.94,5.15 16.94,4.91 16.24,4.19 11.9,8.38"
		],
		ruins: [
			"54.33,29.11 54.46,24.29 48.34,24.66 50.58,25.03 51.43,26.73 52.09,26.55 52.3,27 52.44,26.64 54.05,27.32 54.3,29.14",
			"43.71,24.35 43.65,30.61 46.71,30.61 46.71,30.18 45.97,30.07 45.25,26.93 44.28,26.8 44.03,24.32",
			"49.69,10.98 52.3,11.11 52.42,9.66 51.96,9.61 52.09,10.63 49.65,10.8",
			"41.69,8.51 41.62,11.13 47.93,11.06 45.84,10.71 46.09,9.16 45.2,8.17 44.09,8.46 43.55,8.06 42.68,8.8 41.79,8.45",
			"25.63,35.19 25.63,34.5 27.92,32.49 28.96,32.65 29.16,33.32 28.01,34.64 26.68,35.56 25.89,35.5",
			"25.2,33.43 26.05,32.35 27.27,31.8 26.97,33.33 28.07,34.41 27.55,34.71 26.2,33.29 25.28,33.61",
			"29.49,17.46 24.68,17.31 24.81,21.64 25.18,20.63 27.89,19.72 27.51,17.56 29.36,17.62",
			"35.33,18.95 35.51,17.49 35.15,17.15 33.98,17.45 35.08,17.67 35.22,18.98",
			"30.64,26.66 35.45,26.82 35.32,22.48 34.95,23.49 34.02,23.5 32.65,24.6 32.24,24.4 32.62,26.56 30.78,26.5",
			"24.75,25.21 24.57,26.66 24.94,27.01 26.1,26.71 25,26.49 24.86,25.18",
			"34.92,36.6 34.92,35.66 34.35,35.71 33.65,34.9 34.11,34.31 33.4,34.55 32.59,33.69 32.87,32.88 32.38,33.29 31.86,32.96 31.79,34.03 32.4,33.86 33.11,34.7 32.84,35.24 33.43,35.06 34.15,35.89 33.92,36.47 34.76,36.59",
			"5.4,14.75 5.27,19.57 11.39,19.2 9.15,18.83 8.3,17.13 5.81,16.64 5.42,14.72",
			"16.12,19.46 16.18,13.2 13.2,13.17 13.13,13.63 13.86,13.74 14.59,16.88 15.55,17 15.8,19.49",
			"10.25,32.93 7.64,32.8 7.61,34.43 7.98,34.29 7.85,33.28 10.29,33.1",
			"18.02,35.42 18.1,32.81 11.79,32.87 13.87,33.22 13.63,34.77 14.51,35.76 15.62,35.47 16.16,35.87 17.03,35.13 17.93,35.48",
			"54,39.29 53.08,38.32 53.18,37.84 52.62,37.87 51.81,36.47 51.32,36.58 50.6,35.29 49.19,34.45 49.13,33.83 48.27,33.76 48.33,34.6 47.66,34.26 47.81,35.15 49.26,36.03 49.1,36.44 49.73,36.5 50.62,37.96 51.02,37.79 51.92,39.26 52.83,39.39 52.86,38.54 53.79,39.43",
			"51.31,19.93 51.74,18.96 51.22,19.51 48.35,18.04 48.5,17.31 47.99,18.44 51.25,19.94",
			"45.71,17.07 46.14,16.1 45.55,16.62 42.76,15.19 42.9,14.45 42.39,15.59 45.65,17.09",
			"45.38,18.04 46.15,17.71 47.21,18.25 47.25,18.94 47.77,18.02 48.35,18.12 47.98,17.77 48.34,16.67 47.77,17.13 46.52,16.49 46.47,15.79 45.92,16.7 45.34,16.6 45.8,17.02 45.37,17.91",
			"46.03,36.15 47.29,34.92 45.51,32.95 45.42,33.78 46.75,34.97 45.97,36.15",
			"42.26,35.44 40.99,36.4 43.1,38.44 43.17,37.94 41.49,36.36 42.42,35.5",
			"8.77,23.96 8.35,24.93 8.93,24.42 11.55,25.75 11.59,26.58 12.1,25.45 8.84,23.95",
			"14.37,26.81 13.95,27.78 14.46,27.23 17.33,28.7 17.26,29.43 17.69,28.3 14.44,26.8",
			"14.71,25.84 14.14,26.28 12.88,25.64 12.84,24.94 12.31,25.87 11.67,25.8 12.16,26.17 11.79,26.22 11.74,27.21 12.31,26.76 13.57,27.4 13.53,28.13 14.16,27.19 14.75,27.29 14.29,26.87 14.72,25.98",
			"34.32,8.88 34.34,9.57 32.04,11.58 31.01,11.42 30.81,10.75 31.94,9.43 33.29,8.51 34.08,8.57",
			"34.77,10.64 32.74,12.27 33.02,10.86 31.88,9.66 32.36,9.36 33.77,10.77 34.69,10.46",
			"25.07,7.47 25.07,8.41 25.64,8.35 26.34,9.16 25.88,9.76 26.69,9.57 27.42,10.47 26.93,10.97 28.13,11.11 28.2,10.04 27.6,10.21 26.88,9.37 27.15,8.83 26.56,9.01 25.84,8.18 26.07,7.6 25.23,7.48",
			"5.62,4.15 6.51,5.67 7,5.57 7.81,6.97 8.3,6.86 9.13,7.69 9.02,8.15 10.43,8.99 10.49,9.6 11.35,9.67 11.26,8.89 11.96,9.17 11.81,8.29 10.36,7.4 10.28,6.76 9.9,6.94 9,5.47 8.61,5.65 7.7,4.18 6.79,4.05 6.76,4.9 5.83,4.01",
			"13.61,7.28 12.35,8.52 14.12,10.48 14.21,9.65 12.89,8.47 13.66,7.29",
			"17.38,8 18.64,7.04 16.53,5 16.6,5.67 18.14,7.08 17.21,7.93"
		],
		markers: [
			{
				kind: "expansion",
				x: 49.09,
				y: 25.71
			},
			{
				kind: "home",
				x: 47,
				y: 6.16,
				owner: "defender"
			},
			{
				kind: "centre",
				x: 29.99,
				y: 23.34
			},
			{
				kind: "expansion",
				x: 10.59,
				y: 18.33
			},
			{
				kind: "home",
				x: 13.05,
				y: 37.82,
				owner: "attacker"
			}
		]
	},
	{
		id: "th-re-c",
		letter: "C",
		a: "Take and Hold",
		b: "Reconnaissance",
		label: "Reconnaissance vs Take and Hold",
		edge: "Long edge",
		zones: [{
			side: "attacker",
			points: "30.02,30.98 28.19,30.79 26.51,30.27 24.98,29.44 23.65,28.35 22.56,27.02 21.73,25.5 21.21,23.81 21.03,21.98 0.14,21.98 0.14,43.96 30.02,43.96"
		}, {
			side: "defender",
			points: "59.86,0.04 30,0.04 30,13.02 31.81,13.2 33.49,13.73 35.02,14.56 36.35,15.65 37.44,16.98 38.27,18.51 38.79,20.19 38.97,22 59.86,22"
		}],
		terrain: [
			"42.4,12.06 45.77,12.06 46.99,12.52 50.29,12.06 50.92,12.64 53.98,12.06 53.98,5.02 42.4,5.02",
			"10.64,15.84 13.39,13.89 14.65,13.57 17.08,11.29 17.95,11.39 20.09,9.16 16.04,3.41 6.58,10.1",
			"42.98,22.02 44.97,22.02 44.97,18.01 45.25,17.69 44.97,15.98 42.98,15.98 42.98,19.46 42.49,20.32",
			"32.99,6.37 35.11,4.88 38.27,9.39 39.22,10.74 40.85,13.08 38.73,14.57 34.48,8.49 33.63,8.26",
			"24.09,13.1 26.16,13.48 27.55,13.1 30.12,13.1 30.67,11.02 30.13,10.16 30.12,9.12 24.09,9.12",
			"22.06,11.09 24.05,11.09 24.05,7.08 24.34,6.76 24.05,5.05 22.06,5.05 22.06,8.53 21.57,9.39",
			"24.21,25.09 26.59,24.61 27.67,23.47 32.32,20.68 33.4,19.51 35.79,19.04 35.79,17 24.21,17",
			"35.78,18.9 33.41,19.38 32.33,20.52 27.68,23.32 26.6,24.48 24.21,24.95 24.21,26.99 35.78,26.99",
			"27.18,37.53 25.06,39.02 21.9,34.51 20.95,33.16 19.31,30.82 21.44,29.33 25.69,35.41 26.54,35.64",
			"17.56,31.93 14.19,31.93 12.97,31.47 9.68,31.93 9.05,31.35 5.99,31.93 5.99,38.97 17.56,38.97",
			"49.53,28.36 46.78,30.3 45.52,30.63 43.09,32.91 42.24,32.79 40.08,35.04 44.13,40.78 53.59,34.1",
			"44.96,25.83 47,26.2 48.43,25.83 51,25.83 51.55,23.75 51,22.89 51,21.85 44.96,21.85",
			"35.89,30.98 33.84,30.61 32.42,30.98 29.85,30.98 29.3,33.04 29.85,33.92 29.85,34.96 35.89,34.96",
			"37.9,32.99 35.91,32.99 35.91,37 35.62,37.32 35.91,39.03 37.9,39.03 37.9,35.55 38.39,34.69",
			"17.15,21.88 15.16,21.88 15.16,25.89 14.88,26.21 15.16,27.92 17.15,27.92 17.15,24.44 17.64,23.58",
			"15.17,18.07 13.13,17.7 11.7,18.07 9.14,18.07 8.58,20.13 9.14,21.04 9.14,22.05 15.17,22.05"
		],
		ruins: [
			"42.85,6.93 42.72,11.74 48.84,11.37 46.6,11 45.75,9.3 43.26,8.81 42.87,6.9",
			"50.53,11.5 53.14,11.63 53.17,10 52.8,10.14 52.93,11.15 50.49,11.33",
			"12.33,6.67 7.18,10.24 8.94,12.75 9.3,12.5 8.97,11.83 11.09,9.44 10.65,8.56 12.53,6.95",
			"17.49,10.54 19.67,9.09 15.98,3.97 16.89,5.88 15.48,6.58 15.19,7.98 16.07,8.61 16.06,9.27 17.14,9.56 17.37,10.49",
			"43.53,14.65 43.5,15.98 43.08,16.26 43.5,16.65 43.08,18.2 43.5,18.48 43.11,20.13 43.5,20.31 43.5,21.47 43.1,21.93 43.66,22.62 44.17,22 44.41,22.7 44.98,21.97 44.58,21.49 44.6,20.24 44.98,20.14 44.59,19.71 44.98,17.98 44.58,17.82 44.58,16.64 44.98,16.15 44.46,15.42 43.8,16 43.76,14.69",
			"36.13,8.87 36.9,8.11 36.26,8.45 34.4,5.8 34.88,5.22 33.91,5.92 36.09,8.84",
			"35.38,9.57 36.08,9.44 36.9,10.61 36.61,11.24 37.5,10.66 37.97,11.03 37.78,10.47 38.15,10.59 38.64,9.75 37.93,9.88 37.12,8.72 37.4,8.09 36.49,8.63 36.03,8.27 36.23,8.85 35.4,9.48",
			"39.59,13.94 40.4,13.31 39.71,13.52 37.86,10.88 38.34,10.3 37.35,11.07 39.55,13.92",
			"25.78,12.12 27.07,12.54 28.46,12.2 26.92,11.07 26.66,11.78 25.84,12.04",
			"25.02,10.73 25.69,11.3 28.56,11.3 29.24,10.51 28.73,9.79 27.23,9.64 25.61,9.76 25.07,10.29",
			"23.21,5.79 22.6,6.41 23.07,7.91 22.33,8.25 23.07,8.45 23.07,9.52 22.33,9.95 23.03,9.95 23.21,10.56 23.9,9.79 23.34,9.53 23.34,8.41 23.9,8.19 23.34,7.94 23.34,6.84 23.9,6.56 23.34,5.92",
			"26.3,17.61 24.84,17.43 24.5,17.79 24.8,18.96 25.04,17.85 26.33,17.71",
			"24.65,21.67 24.5,26.47 28.83,26.35 27.82,25.98 26.88,23.21 24.78,23.66 24.75,21.73",
			"35.2,22.25 35.35,17.45 31.02,17.57 32.03,17.93 32.98,20.71 35.07,20.26 35.1,22.19",
			"33.66,26.49 35.21,26.6 35.1,25.14 34.93,26.25 33.63,26.39",
			"20.58,29.96 19.77,30.58 20.45,30.38 22.31,33.02 21.83,33.6 22.81,32.83 20.62,29.98",
			"24.79,34.32 24.09,34.45 23.27,33.29 23.56,32.66 22.67,33.24 22.2,32.87 22.39,33.43 22.02,33.31 21.53,34.15 22.24,34.02 23.05,35.18 22.77,35.81 23.67,35.26 24.14,35.63 23.96,35.12 24.77,34.42",
			"24.04,35.03 23.22,35.66 23.91,35.45 25.77,38.1 25.29,38.67 26.26,37.98 24.08,35.05",
			"9.44,32.6 6.83,32.47 6.71,33.91 7.17,33.96 7.04,32.95 9.48,32.77",
			"16.99,37.18 17.12,32.36 11,32.73 13.24,33.1 14.09,34.8 14.75,34.62 14.96,35.07 15.1,34.71 16.71,35.39 16.97,37.21",
			"42.68,33.65 40.5,35.11 44.19,40.23 43.28,38.31 44.69,37.62 44.98,36.22 44.07,35.57 44.11,34.92 43.03,34.64 42.8,33.7",
			"47.84,37.52 52.95,34.03 51.23,31.45 50.87,31.7 51.2,32.37 49.08,34.75 49.52,35.64 47.64,37.25",
			"46.9,22.19 45.13,22.23 45.11,24.93 45.72,24.33 45.56,22.56 46.93,22.22",
			"49.35,25.35 50.94,25.49 50.74,22.55 50.33,23.1 50.54,25.18 49.27,25.19",
			"34.95,33.35 34.29,32.78 31.41,32.78 30.73,33.58 30.99,34.19 32.74,34.44 34.36,34.32 34.9,33.79",
			"34.19,31.97 32.9,31.54 31.51,31.88 32.63,33.01 34.13,32.04",
			"36.74,38.29 37.36,37.67 36.89,37.26 36.89,36.17 37.63,35.83 36.89,35.63 36.89,34.56 37.63,34.13 36.92,34.13 36.81,33.52 36.06,34.29 36.62,34.55 36.62,35.67 36.06,35.89 36.62,36.14 36.62,37.24 36.06,37.52 36.62,38.16",
			"16.6,29.25 16.63,27.92 17.05,27.64 16.63,27.25 17.05,25.71 16.63,25.42 16.65,24.19 17.02,24.1 16.63,22.43 17.03,21.97 16.47,21.29 15.97,21.91 15.72,21.21 15.16,21.93 15.55,22.41 15.54,23.66 15.16,23.76 15.54,24.19 15.16,25.92 15.55,26.08 15.55,27.26 15.16,27.76 15.67,28.49 16.33,27.9 16.37,29.21",
			"10.78,18.55 9.19,18.42 9.39,21.35 9.8,20.81 9.59,18.73 10.86,18.71",
			"13.24,21.72 15,21.67 15.02,18.97 14.41,19.57 14.57,21.34 13.2,21.68"
		],
		markers: [
			{
				kind: "home",
				x: 48.34,
				y: 10.43,
				owner: "defender"
			},
			{
				kind: "expansion",
				x: 14.55,
				y: 11.08
			},
			{
				kind: "centre",
				x: 30,
				y: 20.8
			},
			{
				kind: "home",
				x: 11.62,
				y: 33.56,
				owner: "attacker"
			},
			{
				kind: "expansion",
				x: 45.62,
				y: 33.11
			}
		]
	},
	{
		id: "th-pa-a",
		letter: "A",
		a: "Take and Hold",
		b: "Priority Assets",
		label: "Priority Assets vs Take and Hold",
		edge: "Short edge",
		zones: [{
			side: "attacker",
			points: "30.03,43.96 0.13,0.04 0.14,0.04 0.14,43.96"
		}, {
			side: "defender",
			points: "59.88,43.96 59.88,0.04 29.99,0.04 59.86,43.96"
		}],
		terrain: [
			"51.19,37.04 49.3,34.25 48.94,32.9 46.78,30.5 46.91,29.65 44.71,27.44 38.88,31.37 45.36,40.97",
			"48.04,5.03 48.04,8.4 47.59,9.52 48.04,12.92 47.45,13.55 48.04,16.61 55.07,16.61 55.07,5.03",
			"49.85,27.72 50.95,28.5 53.05,26.97 49.81,22.52 48.84,21.18 47.16,18.87 45.06,20.39 49.42,26.4",
			"41.05,26.08 40.21,23.24 38.89,21.87 36.62,17.95 35.47,16.88 35,14.5 32.96,14.5 32.96,26.08",
			"23.51,8.37 24,10.07 25.99,10.07 25.99,6.06 26.27,5.71 25.99,4.03 24,4.03 24,7.51",
			"26.1,11.95 28.18,12.33 29.57,11.95 32.14,11.95 32.67,9.8 32.14,8.99 32.14,7.98 26.1,7.98",
			"9.16,7.09 11.05,9.89 11.37,11.18 13.57,13.63 13.44,14.48 15.64,16.69 21.47,12.76 14.99,3.16",
			"12.09,38.99 12.09,35.62 12.55,34.36 12.11,31.04 12.68,30.47 12.09,27.41 5.06,27.41 5.06,38.99",
			"40.76,15.15 42.18,16.21 43.76,15.01 41.35,11.81 41.37,11.36 40.13,10.19 38.54,11.39 40.64,14.17",
			"41.63,8.86 40.67,6.98 39.52,6.11 37.95,4.07 35.95,4.91 35.6,5.87 34.8,6.49 38.48,11.28",
			"18.97,17.95 19.47,20.35 21.13,22.15 23.38,26.04 24.55,27.15 25.02,29.52 27.06,29.52 27.06,17.95",
			"10.19,16.21 9.09,15.43 6.99,16.96 10.23,21.41 11.2,22.75 12.88,25.06 14.98,23.53 10.61,17.53",
			"19.28,28.96 17.87,27.89 16.28,29.09 18.7,32.3 18.64,32.7 19.91,33.92 21.5,32.72 19.41,29.94",
			"18.41,35.25 19.42,37.16 20.52,38 22.09,40.04 24.05,39.23 24.44,38.23 25.24,37.62 21.57,32.83",
			"36.34,35.25 35.96,33.9 33.97,33.9 33.97,37.91 33.68,38.26 33.97,39.94 35.96,39.94 35.96,36.46",
			"33.85,32.02 31.78,31.64 30.38,32.02 27.81,32.02 27.26,34.12 27.81,34.98 27.81,35.99 33.85,35.99"
		],
		ruins: [
			"45.31,40.26 50.5,36.87 48.84,34.26 48.47,34.5 48.79,35.18 46.61,37.52 47.03,38.41 45.12,39.98",
			"41.68,30.07 39.47,31.47 43.05,36.68 42.18,34.74 43.61,34.08 43.92,32.68 43.03,32.01 43.09,31.37 42.01,31.06 41.8,30.12",
			"51.17,5.52 48.56,5.39 48.53,7.02 48.9,6.88 48.77,5.87 51.21,5.69",
			"48.62,11.41 48.49,16.23 54.61,15.86 52.37,15.49 51.52,13.79 50.85,13.97 50.65,13.52 50.51,13.88 48.9,13.19 48.64,11.38",
			"51.56,28.01 52.36,27.37 51.68,27.59 49.78,24.98 50.25,24.39 49.29,25.1 51.52,27.99",
			"47.98,23.03 48.78,22.39 48.1,22.61 46.2,20 46.66,19.41 45.69,20.2 47.94,23.01",
			"47.35,23.64 48.05,23.5 48.88,24.65 48.61,25.29 49.49,24.7 49.96,25.05 49.77,24.5 50.62,23.76 49.91,23.91 49.07,22.76 49.34,22.12 48.45,22.69 47.97,22.33 48.19,22.91 47.37,23.55",
			"34.96,15.09 33.49,14.92 33.46,16.44 33.69,15.33 34.99,15.2",
			"33.74,20.8 33.59,25.61 37.92,25.48 36.91,25.12 35.96,22.34 33.86,22.79 33.84,20.87",
			"25.07,9.48 24.45,8.86 24.92,8.45 24.93,7.36 24.19,7.02 24.93,6.82 24.93,5.75 24.19,5.32 24.89,5.32 25,4.71 25.76,5.48 25.19,5.74 25.2,6.86 25.76,7.08 25.2,7.33 25.19,8.43 25.76,8.71 25.2,9.35",
			"26.98,9.65 27.64,10.22 30.52,10.22 31.2,9.43 30.69,8.71 29.19,8.56 27.56,8.68 27.02,9.21",
			"27.73,11.04 29.03,11.46 30.42,11.12 29.3,9.99 27.8,10.96",
			"14.99,3.71 9.8,7.09 11.46,9.71 11.83,9.47 11.51,8.79 13.69,6.45 13.27,5.56 15.18,3.99",
			"18.76,14.06 20.97,12.66 17.39,7.45 18.26,9.39 16.83,10.05 16.5,11.35 17.41,12.12 17.35,12.76 18.43,13.07 18.64,14.01",
			"11.49,32.5 11.62,27.68 5.5,28.05 7.74,28.42 8.59,30.12 9.26,29.94 9.46,30.39 9.6,30.04 11.21,30.72 11.47,32.53",
			"8.73,38.42 11.34,38.51 11.35,36.87 10.98,37.02 11.13,38.03 8.69,38.25",
			"44.2,16.46 43.41,15.37 43.59,14.91 43.03,14.86 42.42,13.36 41.97,13.44 41.21,12.46 41.38,12.02 40.11,11 40.13,10.38 39.29,10.19 39.23,11.03 38.62,10.6 38.64,11.49 39.21,11.61 39.95,12.58 39.74,12.96 41.09,14.09 41.04,14.68 41.45,14.56 42.14,16.14 43.02,16.39 43.17,15.56 43.97,16.56",
			"37.42,9.4 38.5,10.79 40.65,9.25 39.84,9.07 38.51,10.25 37.43,9.35",
			"38.69,5.8 37.85,4.45 35.62,6.36 36.3,6.36 37.84,4.95 38.6,5.96",
			"25.15,28.93 26.7,29.04 26.65,27.58 26.42,28.69 25.12,28.82",
			"26.26,23.22 26.41,18.41 22.08,18.54 23.09,18.9 24.04,21.68 26.14,21.23 26.16,23.16",
			"8.45,15.92 7.65,16.56 8.34,16.34 10.24,18.95 9.77,19.54 10.74,18.75 8.5,15.94",
			"12.04,20.89 11.24,21.54 11.92,21.31 13.82,23.93 13.35,24.51 14.31,23.8 12.08,20.91",
			"12.67,20.28 11.97,20.42 11.13,19.28 11.41,18.64 10.52,19.23 9.98,18.88 10.25,19.43 9.88,19.32 9.4,20.17 10.11,20.02 10.94,21.17 10.67,21.8 11.57,21.24 12.04,21.6 11.83,21.02 12.65,20.38",
			"15.83,27.68 16.61,28.76 16.43,29.22 16.99,29.28 17.6,30.77 18.05,30.7 18.81,31.68 18.64,32.11 19.91,33.14 19.89,33.76 20.73,33.95 20.79,33.11 21.41,33.54 21.38,32.64 20.07,31.56 20.28,31.18 19.72,31.08 18.99,29.46 18.58,29.58 17.86,28.63 17.88,28 17,27.74 16.97,28.66 16.06,27.57",
			"22.6,34.48 21.52,33.09 19.37,34.64 20.18,34.82 21.51,33.63 22.59,34.54",
			"21.33,38.3 22.17,39.66 24.4,37.75 23.91,37.63 22.18,39.15 21.42,38.14",
			"34.86,34.49 35.48,35.11 35.01,35.52 35.01,36.61 35.74,36.95 35.01,37.15 35.01,38.22 35.74,38.65 35.04,38.65 34.86,39.26 34.18,38.49 34.74,38.23 34.73,37.11 34.18,36.89 34.73,36.64 34.74,35.54 34.18,35.26 34.81,34.59",
			"32.96,34.32 32.29,33.75 29.42,33.75 28.74,34.54 29.25,35.26 30.75,35.41 32.37,35.29 32.91,34.76",
			"32.2,32.93 30.91,32.51 29.52,32.85 30.64,33.98 32.14,33.01"
		],
		markers: [
			{
				kind: "expansion",
				x: 46.51,
				y: 33.02
			},
			{
				kind: "home",
				x: 49.67,
				y: 10.96,
				owner: "defender"
			},
			{
				kind: "centre",
				x: 36.64,
				y: 20.14
			},
			{
				kind: "expansion",
				x: 13.84,
				y: 11.11
			},
			{
				kind: "home",
				x: 10.47,
				y: 33.04,
				owner: "attacker"
			},
			{
				kind: "centre",
				x: 23.33,
				y: 23.83
			}
		]
	},
	{
		id: "th-pa-b",
		letter: "B",
		a: "Take and Hold",
		b: "Priority Assets",
		label: "Priority Assets vs Take and Hold",
		edge: "Short edge",
		zones: [{
			side: "attacker",
			points: "0.14,43.96 0.14,0.04 18.01,0.04 18.01,43.96"
		}, {
			side: "defender",
			points: "41.99,43.96 41.99,0.04 59.86,0.04 59.86,43.96"
		}],
		terrain: [
			"45.9,6.03 45.9,9.41 45.44,10.62 45.9,13.92 45.32,14.55 45.9,17.61 52.93,17.61 52.93,6.03",
			"41.11,34.04 37.74,34.04 36.52,33.58 33.23,34.04 32.6,33.45 29.54,34.04 29.54,41.07 41.11,41.07",
			"43.15,10.11 43.15,8.12 39.13,8.12 38.32,7.89 37.11,8.12 37.11,10.11 40.59,10.11 41.44,10.6",
			"35,10.09 36.99,10.09 36.99,6.07 37.28,5.76 36.99,4.05 35,4.05 35,7.53 34.51,8.39",
			"45.01,31.96 47.6,31.96 47.6,26.45 47.6,24.8 47.6,21.94 45.01,21.94 45.01,29.36 44.45,30.04",
			"39.99,32.1 40.37,30.06 39.99,28.64 39.99,26.07 37.94,25.51 37.03,26.07 36.02,26.07 36.02,32.1",
			"47.57,31.94 47.2,33.98 47.57,35.41 47.57,37.98 49.62,38.53 50.53,37.98 51.54,37.98 51.54,31.94",
			"33.06,12.1 32.25,14.39 32.75,16.84 32.67,21.33 33.11,22.85 32.28,25.14 34.03,26.19 39.99,16.27",
			"16.88,33.93 16.88,35.92 20.9,35.92 21.21,36.21 22.92,35.92 22.92,33.93 19.44,33.93 18.58,33.44",
			"25.02,33.84 23.04,33.84 23.04,37.86 22.75,38.18 23.04,39.88 25.02,39.88 25.02,36.4 25.52,35.55",
			"16.05,12.09 13.46,12.09 13.46,17.6 13.46,19.25 13.46,22.1 16.05,22.1 16.05,14.69 16.5,14.32",
			"13.51,6.09 13.89,8.13 13.51,9.55 13.51,12.12 11.44,12.68 10.57,12.13 9.54,12.12 9.54,6.09",
			"13.98,37.97 13.98,34.6 14.44,33.38 13.98,30.09 14.56,29.46 13.98,26.39 6.95,26.39 6.95,37.97",
			"19.04,10.04 22.41,10.04 23.63,10.5 26.92,10.04 27.55,10.62 30.61,10.04 30.61,3 19.04,3",
			"19.07,12.09 18.7,14.14 19.07,15.56 19.07,18.13 21.12,18.68 22.04,18.13 23.05,18.13 23.05,12.09",
			"27.02,32 27.79,29.7 27.34,28.2 27.25,22.77 26.78,21.25 27.57,18.95 25.8,17.93 20.01,27.95"
		],
		ruins: [
			"49.06,6.46 46.45,6.33 46.33,7.77 46.79,7.82 46.66,6.81 49.09,6.63",
			"46.44,12.39 46.3,17.21 52.43,16.84 50.18,16.47 49.33,14.77 48.67,14.95 48.46,14.5 48.32,14.86 46.71,14.17 46.46,12.36",
			"32.5,34.5 29.88,34.43 29.94,40.75 30.3,38.66 31.85,38.9 32.89,37.93 32.54,36.9 32.94,36.37 32.22,35.51 32.57,34.61",
			"34.49,40.63 40.69,40.72 40.77,37.62 40.33,37.62 40.22,38.36 37.08,39.08 36.94,40.08 34.46,40.32",
			"36.48,9.44 37.19,9.96 37.66,9.56 38.9,9.56 39.05,9.96 39.48,9.56 40.72,9.56 40.88,9.96 42.55,9.56 43.01,9.96 43.72,9.56 43.32,9.26 43.6,8.98 43.04,8.89 44.5,8.55 43.1,8.49 42.98,8.09 42.3,8.52 41.28,8.49 41.15,8.09 40.69,8.52 39.51,8.52 39.33,8.09 37.69,8.52 37.22,8.09 36.57,8.64 37.13,8.86 36.6,9.1 37.19,9.2 36.7,9.29",
			"36,4.69 35.38,5.3 35.85,5.72 35.85,6.81 35.11,7.15 35.85,7.35 35.85,8.42 35.11,8.85 35.82,8.85 35.93,9.46 36.68,8.69 36.12,8.43 36.13,7.31 36.68,7.09 36.13,6.84 36.12,5.74 36.68,5.46 36.05,4.78",
			"45.01,25.87 45.65,26.41 45.65,27.6 45.06,27.95 46.12,27.99 46.29,28.55 46.45,27.99 46.67,28.3 47.58,27.89 46.91,27.59 46.91,26.18 47.51,25.82 46.45,25.75 46.28,25.18 46.11,25.78 45.13,25.8",
			"45.92,31.9 46.98,31.84 46.26,31.63 46.26,28.4 46.98,28.2 45.73,28.26 45.89,31.86",
			"46.03,25.73 47.09,25.66 46.37,25.46 46.37,22.23 47.09,22.03 45.84,22.09 46,25.69",
			"36.49,30.2 36.35,31.78 39.28,31.58 38.94,31.19 36.66,31.39 36.73,30.12",
			"39.68,28.11 39.64,26.35 36.93,26.33 37.53,26.94 39.3,26.77 39.64,28.15",
			"48.7,33.69 48.31,34.98 48.6,36.31 49.77,34.84 49.03,34.55 48.85,33.84",
			"50.13,32.92 49.58,33.57 49.6,36.44 50.39,37.15 51.03,36.87 51.27,35.2 51.15,33.54 50.61,32.98",
			"32.53,24.77 33.92,25.62 34.51,24.38 33.75,25.21 32.56,24.66",
			"36.77,20.47 39.38,16.42 35.62,14.32 36.27,15.14 35.66,18 37.7,18.72 36.74,20.45",
			"23.55,34.49 22.84,33.97 22.37,34.37 21.13,34.37 20.98,33.97 20.55,34.37 19.31,34.37 19.15,33.97 17.48,34.37 17.02,33.97 16.31,34.37 16.71,34.68 16.43,34.95 16.99,35.04 15.53,35.38 16.93,35.44 17.05,35.84 17.73,35.41 18.75,35.44 18.88,35.84 19.34,35.41 20.52,35.41 20.7,35.84 22.34,35.41 22.8,35.84 23.45,35.29 22.9,35.07 23.42,34.83 22.84,34.74 23.33,34.64",
			"24.03,39.24 24.65,38.63 24.18,38.21 24.17,37.12 24.91,36.79 24.17,36.58 24.17,35.51 24.91,35.08 24.21,35.08 24.1,34.47 23.35,35.24 23.91,35.51 23.9,36.62 23.35,36.84 23.9,37.1 23.91,38.2 23.35,38.47 23.98,39.15",
			"15.04,18.31 13.98,18.38 14.7,18.59 14.7,21.82 13.98,22.02 15.22,21.96 15.06,18.36",
			"15.15,12.14 14.09,12.21 14.81,12.41 14.81,15.65 14.09,15.84 15.33,15.78 15.17,12.18",
			"16.06,18.18 15.41,17.87 15.41,16.45 16.01,16.1 14.94,16.05 14.78,15.49 14.61,16.05 13.55,16.1 14.15,16.46 14.15,17.87 13.49,18.16 14.61,18.3 14.79,18.87 14.95,18.27 15.94,18.24",
			"10.82,11.19 11.37,10.53 11.34,7.68 10.55,6.97 9.91,7.25 9.67,8.92 9.79,10.58 10.33,11.14",
			"12.17,10.46 12.53,9.9 12.26,7.84 11.09,9.32 11.85,9.59 12.01,10.31",
			"13.36,31.59 13.49,26.77 7.37,27.14 9.61,27.51 10.46,29.21 11.13,29.03 11.34,29.48 11.48,29.12 13.08,29.81 13.34,31.62",
			"10.68,37.24 13.29,37.37 13.41,35.93 12.95,35.88 13.08,36.89 10.64,37.07",
			"25.69,3.44 19.5,3.34 19.41,6.44 19.85,6.44 19.97,5.7 23.1,4.98 23.24,3.98 25.72,3.75",
			"27.47,9.47 30.1,9.55 30.03,3.23 29.67,5.32 28.12,5.07 27.08,6.05 27.43,7.07 27.04,7.61 27.76,8.47 27.41,9.36",
			"19.33,16.21 19.37,17.97 22.08,17.99 21.47,17.38 19.7,17.55 19.37,16.17",
			"22.67,13.88 22.81,12.3 19.88,12.5 20.22,12.89 22.5,12.69 22.51,13.96",
			"23.11,23.75 20.57,27.83 24.36,29.87 23.7,29.06 24.26,26.19 22.22,25.53 23.14,23.76",
			"27.16,19.53 25.76,18.7 25.19,19.95 25.94,19.11 27.14,19.64"
		],
		markers: [
			{
				kind: "home",
				x: 47.53,
				y: 11.97,
				owner: "defender"
			},
			{
				kind: "expansion",
				x: 35.17,
				y: 35.67
			},
			{
				kind: "centre",
				x: 33.77,
				y: 19.39
			},
			{
				kind: "home",
				x: 12.35,
				y: 32.03,
				owner: "attacker"
			},
			{
				kind: "expansion",
				x: 24.98,
				y: 8.41
			},
			{
				kind: "centre",
				x: 26.2,
				y: 24.84
			}
		]
	},
	{
		id: "th-pa-c",
		letter: "C",
		a: "Take and Hold",
		b: "Priority Assets",
		label: "Priority Assets vs Take and Hold",
		edge: "Long edge",
		zones: [{
			side: "attacker",
			points: "0.14,43.96 0.14,32 59.88,32 59.88,43.96"
		}, {
			side: "defender",
			points: "0.14,12.01 0.14,0.04 59.88,0.04 59.88,12.01"
		}],
		terrain: [
			"44.09,3.03 40.69,3.03 39.53,2.57 36.19,3.03 35.53,2.45 32.51,3.03 32.51,10.07 44.09,10.07",
			"15.57,13.94 12.2,13.94 10.94,13.48 7.68,13.94 7.01,13.36 3.99,13.94 3.99,20.97 15.57,20.97",
			"17.07,7.81 18.5,6.77 17.82,4.9 14.05,6.27 13.68,6.1 12.15,6.96 12.83,8.83 16.1,7.64",
			"5.01,6.01 6.29,7.61 7.63,8.28 9.57,9.97 11.33,8.78 11.51,7.73 12.17,6.97 7.62,3.01",
			"16.05,41.08 19.42,41.08 20.68,41.54 23.94,41.08 24.57,41.67 27.63,41.08 27.63,34.05 16.05,34.05",
			"44.41,30.11 47.78,30.11 49.03,30.57 52.31,30.11 52.92,30.7 55.99,30.11 55.99,23.07 44.41,23.07",
			"41.53,37.15 42.21,39.01 45.98,37.64 46.4,37.79 47.89,36.95 47.2,35.08 43.93,36.27 43.03,36.09",
			"28.44,31.65 27.61,34.11 32.84,35.85 34.4,36.38 37.11,37.28 37.93,34.83 30.9,32.47 30.39,31.71",
			"55.02,37.89 53.7,36.24 52.4,35.61 50.47,33.93 48.67,35.15 48.52,36.17 47.86,36.93 52.41,40.89",
			"31.85,28.87 31.41,26.48 32.28,24.16 32.91,19.68 33.58,18.25 33.12,15.87 35.02,15.11 39.35,25.84",
			"46.8,18.26 45.23,16.94 44.6,15.58 42.96,13.6 44.2,11.86 45.25,11.71 46.03,11.07 49.87,15.73",
			"51.87,13.57 53.23,13 54.5,14.53 51.4,17.09 51.31,17.52 49.83,18.37 48.57,16.84 51.26,14.62",
			"31.74,12.52 32.57,10.06 27.34,8.31 25.78,7.79 23.07,6.88 22.25,9.34 29.28,11.69 29.61,12.37",
			"13.23,25.91 14.84,27.27 15.44,28.59 17.07,30.57 15.87,32.27 14.78,32.46 14,33.1 10.16,28.44",
			"8.43,30.47 6.8,31.17 5.54,29.64 8.64,27.08 8.72,26.65 10.2,25.79 11.47,27.33 8.78,29.54",
			"28.16,15.1 28.6,17.49 27.94,18.91 27.09,24.29 26.43,25.72 26.88,28.1 24.99,28.86 20.65,18.13"
		],
		ruins: [
			"40.89,9.58 43.5,9.72 43.62,8.27 43.16,8.22 43.29,9.23 40.85,9.41",
			"33.01,5.06 32.88,9.87 39,9.5 36.76,9.13 35.91,7.51 33.29,6.84 33.03,5.03",
			"4.41,17.96 4.33,20.57 10.65,20.51 8.56,20.16 8.8,18.6 7.92,17.62 6.81,17.91 6.27,17.51 5.4,18.25 4.5,17.9",
			"15.13,20.51 15.2,14.25 12.21,14.22 12.14,14.68 12.87,14.79 13.6,17.93 14.57,18.05 14.81,20.54",
			"19.33,4.9 18.08,5.32 17.67,5.02 17.45,5.55 15.84,5.69 15.74,6.17 14.56,6.59 14.35,6.27 12.88,7.2 12.32,7 11.88,7.73 12.63,8 12.07,8.5 12.95,8.76 13.26,8.2 14.98,8.02 14.98,7.59 16.16,7.17 16.39,7.51 17.82,6.56 18.43,6.76 18.93,6.14 18.41,5.86 18.67,5.66 18.06,5.74 19.37,5.12",
			"8.76,4.79 7.4,3.66 5.64,5.64 6.47,5.64 7.51,4.19 8.76,4.84",
			"8.43,8.21 9.54,9.35 11.31,7.01 10.8,7 9.44,8.86 8.48,8.04",
			"19.43,34.54 16.82,34.41 16.7,35.85 17.16,35.9 17.03,34.89 19.47,34.71",
			"27.08,39.17 27.21,34.35 21.09,34.72 23.33,35.09 24.18,36.79 24.85,36.61 25.05,37.06 25.19,36.7 26.8,37.39 27.06,39.2",
			"55.44,26.06 55.52,23.45 49.21,23.51 51.3,23.86 51.05,25.42 51.93,26.4 53.04,26.11 53.58,26.51 54.45,25.77 55.35,26.12",
			"44.74,23.42 44.68,29.68 47.74,29.68 47.74,29.25 47,29.14 46.28,26 45.31,25.88 45.06,23.39",
			"40.68,39 41.93,38.58 42.34,38.88 42.56,38.35 43.72,37.95 44.06,38.25 44.27,37.73 45.45,37.31 45.66,37.64 47.13,36.72 47.69,36.9 48.13,36.19 47.38,35.9 47.9,35.47 47.06,35.14 46.75,35.71 45.56,36.09 45.34,35.77 45.03,36.31 43.31,36.51 43.3,36.94 42.21,37.36 41.59,37.14 41.08,37.84 41.86,38.32 40.64,38.78",
			"28.14,32.38 27.85,33.39 28.36,32.81 31.13,33.79 31.28,34.61 31.63,33.42 28.21,32.36",
			"34.06,34.48 33.77,35.49 34.21,34.88 36.02,35.52 37.24,35.96 37.2,36.71 37.55,35.52 34.13,34.45",
			"34.27,33.47 33.77,33.98 32.41,33.55 32.39,32.79 31.9,33.81 31.32,33.78 31.79,34.12 31.43,34.23 31.49,35.26 32.02,34.69 33.33,35.21 33.4,35.89 33.91,34.87 34.5,34.9 33.99,34.54 34.3,33.55",
			"51.25,39.11 52.61,40.23 54.37,38.26 53.54,38.26 52.5,39.7 51.25,39.05",
			"51.58,35.68 50.47,34.54 48.7,36.89 49.21,36.89 50.57,35.03 51.54,35.86",
			"35.36,17.45 34.98,16.03 34.51,15.85 33.62,16.53 34.65,16.36 35.27,17.52",
			"34.13,27.39 38.65,25.73 36.92,21.79 36.94,22.83 34.73,24.75 35.93,26.55 34.12,27.36",
			"45.17,12.8 45.15,13.66 46.97,15.87 48.03,15.9 48.34,15.29 47.46,13.84 46.31,12.64 45.55,12.55",
			"44.52,14.41 46.23,16.39 46.22,14.83 47.49,13.98 47.15,13.56 45.41,14.74 44.56,14.29",
			"49.63,17.22 50.57,17.24 50.53,16.67 51.36,15.99 52.09,16.35 51.77,15.65 52.6,14.96 53.18,15.45 53.35,14.25 52.28,14.15 52.43,14.76 51.57,15.46 51.05,15.17 51.2,15.76 50.67,16.22 49.78,16.21 49.67,17.13",
			"31.98,11.75 32.27,10.73 31.91,11.32 30.02,10.7 28.8,10.26 28.84,9.51 28.49,10.71 31.91,11.77",
			"26.06,9.65 26.35,8.63 25.91,9.24 24.68,8.81 22.88,8.17 22.92,7.42 22.57,8.61 25.99,9.67",
			"25.85,10.65 26.35,10.15 27.69,10.62 27.88,11.29 28.22,10.32 28.8,10.35 28.33,10 28.75,9.73 28.67,8.9 27.88,9.36 26.75,8.88 26.72,8.24 26.21,9.25 25.62,9.23 26.13,9.58 25.82,10.58",
			"14.85,31.37 14.86,30.51 13.05,28.3 11.99,28.26 11.68,28.88 12.55,30.32 13.7,31.53 14.47,31.62",
			"15.49,29.75 13.79,27.77 13.8,29.34 12.53,30.19 12.87,30.61 14.52,29.43 15.45,29.88",
			"10.38,26.95 9.44,26.92 9.49,27.5 8.66,28.18 8.07,27.7 8.29,28.42 7.42,29.2 6.62,28.9 7.02,29.53 6.67,29.92 7.73,30.01 7.58,29.41 8.44,28.71 8.97,29 8.81,28.4 9.65,27.7 10.23,27.95 10.35,27.04",
			"24.63,26.52 25.01,27.94 25.47,28.12 26.44,27.4 25.33,27.61 24.71,26.45",
			"25.85,16.58 21.34,18.24 23.07,22.18 23.04,21.14 25.26,19.22 24.06,17.42 25.86,16.61"
		],
		markers: [
			{
				kind: "home",
				x: 38.14,
				y: 4.66,
				owner: "defender"
			},
			{
				kind: "expansion",
				x: 9.62,
				y: 15.57
			},
			{
				kind: "home",
				x: 22,
				y: 39.45,
				owner: "attacker"
			},
			{
				kind: "expansion",
				x: 50.36,
				y: 28.48
			},
			{
				kind: "centre",
				x: 33.69,
				y: 21.78
			},
			{
				kind: "centre",
				x: 26.34,
				y: 22.07
			}
		]
	},
	{
		id: "pf-pf-a",
		letter: "A",
		a: "Purge the Foe",
		b: "Purge the Foe",
		label: "Purge the Foe (mirror)",
		edge: "Long edge",
		zones: [{
			side: "attacker",
			points: "30.02,30.98 28.19,30.79 26.51,30.27 24.98,29.44 23.65,28.35 22.56,27.02 21.73,25.5 21.21,23.81 21.03,21.98 0.14,21.98 0.14,43.96 30.02,43.96"
		}, {
			side: "defender",
			points: "59.86,0.04 30,0.04 30,13.02 31.81,13.2 33.49,13.73 35.02,14.56 36.35,15.65 37.44,16.98 38.27,18.51 38.79,20.19 38.97,22 59.86,22"
		}],
		terrain: [
			"44.49,12.05 47.86,12.05 49.08,12.51 52.37,12.05 53,12.64 56.07,12.05 56.07,5.02 44.49,5.02",
			"41.16,15.84 42.26,13.49 37.27,11.16 35.78,10.46 33.19,9.26 32.09,11.61 38.81,14.74 39.19,15.54",
			"5.07,7.03 4.69,9.07 5.07,10.49 5.07,13.07 7.12,13.62 8.03,13.07 9.04,13.07 9.04,7.03",
			"55.94,22.96 54.31,21.15 52.79,20.81 48.02,18.22 46.48,17.88 44.86,16.06 43.1,17.09 48.98,27.07",
			"31.39,8.49 33.19,9.33 34.89,5.69 35.28,5.52 35.74,3.85 33.94,3.01 32.47,6.17 31.67,6.73",
			"18.89,28.19 17.8,30.54 22.78,32.87 24.28,33.56 26.87,34.77 27.96,32.42 21.24,29.29 20.86,28.49",
			"28.66,35.52 26.86,34.68 25.16,38.32 24.77,38.49 24.31,40.16 26.11,41 27.58,37.84 28.39,37.27",
			"3.96,21.07 5.58,22.88 7.98,23.61 11.88,25.82 13.43,26.16 15.04,27.98 16.8,26.94 10.93,16.97",
			"16.58,31.96 13.21,31.96 11.99,31.5 8.7,31.96 8.07,31.37 5,31.96 5,38.99 16.58,38.99",
			"28.96,14.01 25.59,14.01 24.37,13.55 21.08,14.01 20.45,13.42 17.38,14.01 17.38,21.04 28.96,21.04",
			"41.05,33.92 41.05,35.91 37.04,35.91 36.72,36.2 35.01,35.91 35.01,33.92 38.49,33.92 39.35,33.43",
			"45.06,33.86 45.44,35.94 45.06,37.33 45.06,39.9 43.01,40.45 42.1,39.9 41.09,39.9 41.09,33.86",
			"54.93,36.94 55.3,34.9 54.93,33.47 54.93,30.91 52.87,30.35 51.99,30.9 50.95,30.91 50.95,36.94",
			"31.12,30.08 34.49,30.08 35.71,30.54 39,30.08 39.63,30.67 42.69,30.08 42.69,23.05 31.12,23.05",
			"19.01,10.16 19.01,8.17 23.02,8.17 23.34,7.88 25.05,8.17 25.05,10.16 21.57,10.16 20.71,10.65",
			"15,10.11 14.62,8.03 15,6.64 15,4.07 17.07,3.52 17.94,4.06 18.97,4.07 18.97,10.11"
		],
		ruins: [
			"45.06,6.78 44.93,11.6 51.05,11.23 48.81,10.85 47.96,9.16 47.29,9.34 47.08,8.89 46.95,9.24 45.34,8.56 45.08,6.75",
			"52.73,11.31 55.34,11.44 55.37,9.81 55,9.95 55.13,10.96 52.69,11.14",
			"35.97,12.38 36.36,11.39 35.79,11.93 32.95,10.6 33.06,9.86 32.6,11.01 35.91,12.39",
			"35.67,13.36 36.22,12.9 37.53,13.45 37.47,14.21 38.06,13.25 38.63,13.33 38.26,13 38.64,11.92 37.81,12.26 36.75,11.76 36.68,11.07 36.16,12 35.58,11.92 36.05,12.32 35.65,13.22",
			"41.53,15.11 41.92,14.13 41.36,14.66 38.51,13.33 38.55,12.6 38.16,13.74 41.47,15.12",
			"6.62,12.18 7.18,11.52 7.18,8.66 6.39,7.96 5.76,8.24 5.51,9.91 5.63,11.57 6.17,12.13",
			"8,11.41 8.42,10.12 8.14,8.79 6.96,10.27 7.68,10.54 7.88,11.26",
			"45.08,16.56 43.79,16.99 43.62,17.63 44.47,18.48 44.11,17.42 45.16,16.63",
			"46.99,21.98 49.3,26.2 52.94,23.91 51.91,24.08 49.69,22.18 48.1,23.63 47.02,21.96",
			"34.57,4.01 33.78,4.3 33.55,5.88 32.69,5.95 33.32,6.36 32.87,7.33 32.02,7.41 32.65,7.71 32.56,8.33 33.5,7.93 33.11,7.45 33.58,6.44 34.18,6.48 33.78,6.01 34.24,5.01 34.87,5 34.58,4.12",
			"18.52,28.91 18.13,29.89 18.63,29.33 21.36,30.6 21.43,31.43 21.9,30.28 18.59,28.89",
			"24.39,30.66 23.63,31.02 22.55,30.51 22.49,29.83 22,30.77 21.42,30.68 21.86,31.07 21.49,31.14 21.44,32.19 22.03,31.66 23.28,32.31 23.38,32.95 23.89,32.02 24.48,32.1 24.01,31.7 24.4,30.79",
			"24.09,31.64 23.7,32.62 24.19,32.06 25.19,32.52 27.11,33.42 26.99,34.16 27.46,33.01 24.15,31.63",
			"25.48,39.99 26.28,39.71 26.51,38.13 27.24,38.31 26.73,37.65 27.26,36.62 28.04,36.6 27.4,36.3 27.56,35.7 26.55,36.08 26.95,36.56 26.47,37.56 25.88,37.53 26.27,38 25.81,39 25.19,39.01 25.42,39.83",
			"13.11,21.85 10.8,17.62 7.16,19.92 8.19,19.74 10.41,21.65 12.02,20.19 13.08,21.86",
			"14.82,27.59 16.24,26.77 15.43,25.66 15.8,26.73 14.74,27.51",
			"8.3,32.57 5.69,32.44 5.66,34.07 6.03,33.93 5.9,32.92 8.34,32.74",
			"16.01,37.12 16.14,32.3 10.02,32.67 12.26,33.04 13.11,34.74 13.78,34.56 13.99,35.01 14.12,34.66 15.73,35.34 15.99,37.15",
			"17.98,14.35 17.92,20.62 20.98,20.62 20.98,20.18 20.24,20.07 19.52,16.94 18.55,16.81 18.3,14.32",
			"28.48,16.91 28.55,14.29 22.24,14.36 24.33,14.71 24.08,16.26 24.97,17.25 26.08,16.96 26.62,17.36 27.49,16.62 28.38,16.97",
			"34.37,35.33 35.08,35.85 35.55,35.45 36.78,35.45 36.94,35.85 37.37,35.45 38.61,35.45 38.76,35.85 40.44,35.45 40.9,35.85 41.61,35.45 41.21,35.14 41.49,34.87 40.93,34.77 42.38,34.44 40.99,34.38 40.87,33.98 40.19,34.41 39.17,34.38 39.04,33.98 38.58,34.41 37.4,34.41 37.22,33.98 35.58,34.41 35.11,33.98 34.46,34.53 35.02,34.74 34.49,34.99 35.08,35.08 34.59,35.18",
			"41.66,38.03 41.52,39.62 44.45,39.41 44.11,39.03 41.83,39.22 41.82,37.95",
			"44.7,35.82 44.66,34.07 41.95,34.05 42.56,34.65 44.32,34.49 44.66,35.86",
			"51.99,32.56 51.57,33.85 51.86,35.18 53.03,33.7 52.32,33.43 52.11,32.71",
			"53.37,31.79 52.82,32.45 52.81,35.31 53.6,36.01 54.24,35.73 54.48,34.06 54.36,32.4 53.82,31.84",
			"31.6,27.07 31.52,29.68 37.84,29.62 35.75,29.27 35.99,27.71 35.11,26.73 34,27.02 33.46,26.62 32.59,27.36 31.69,27",
			"42.1,29.62 42.16,23.36 39.1,23.36 39.1,23.8 39.84,23.9 40.56,27.04 41.53,27.17 41.78,29.66",
			"25.69,8.75 24.98,8.23 24.52,8.63 23.28,8.63 23.12,8.23 22.69,8.63 21.45,8.63 21.3,8.23 19.63,8.63 19.16,8.23 18.45,8.63 18.86,8.94 18.58,9.21 19.13,9.3 17.68,9.64 19.07,9.7 19.2,10.1 19.88,9.67 20.9,9.7 21.02,10.1 21.48,9.67 22.66,9.67 22.85,10.1 24.49,9.67 24.95,10.1 25.6,9.55 25.04,9.34 25.57,9.09 24.98,9 25.48,8.91",
			"15.36,8.15 15.4,9.9 18.11,9.92 17.51,9.32 15.74,9.48 15.4,8.11",
			"18.41,5.93 18.54,4.35 15.61,4.56 15.95,4.95 18.23,4.75 18.16,6.02"
		],
		markers: [
			{
				kind: "home",
				x: 50.43,
				y: 10.42,
				owner: "defender"
			},
			{
				kind: "expansion",
				x: 6.64,
				y: 10.81
			},
			{
				kind: "home",
				x: 10.64,
				y: 33.59,
				owner: "attacker"
			},
			{
				kind: "centre",
				x: 23.02,
				y: 15.64
			},
			{
				kind: "expansion",
				x: 53.36,
				y: 33.16
			},
			{
				kind: "centre",
				x: 37.06,
				y: 28.45
			}
		]
	},
	{
		id: "pf-pf-b",
		letter: "B",
		a: "Purge the Foe",
		b: "Purge the Foe",
		label: "Purge the Foe (mirror)",
		edge: "Short edge",
		zones: [{
			side: "attacker",
			points: "0.19,43.96 20.02,43.96 20.02,22.02 12.06,22.02 12.06,0.04 0.19,0.04"
		}, {
			side: "defender",
			points: "59.86,0.04 40.03,0.04 40.03,21.98 47.98,21.98 47.98,43.96 59.86,43.96"
		}],
		terrain: [
			"33.97,37.95 33.97,34.58 34.43,33.36 33.97,30.07 34.56,29.44 33.97,26.37 26.94,26.37 26.94,37.95",
			"14.04,1.98 14.04,5.35 13.58,6.58 14.04,9.87 13.45,10.5 14.04,13.56 21.07,13.56 21.07,1.98",
			"25.95,6.03 25.95,9.4 25.49,10.62 25.95,13.91 25.37,14.54 25.95,17.61 32.98,17.61 32.98,6.03",
			"49.89,31.02 51.88,31.02 51.88,35.03 52.16,35.35 51.88,37.06 49.89,37.06 49.89,33.58 49.4,32.72",
			"49.92,30.98 52.51,30.98 52.51,25.47 52.51,23.82 52.51,20.96 49.92,20.96 49.92,28.38 49.36,29.06",
			"37.05,3.97 36.68,6.02 37.05,7.44 37.05,10.01 39.11,10.56 39.99,10.02 41.03,10.01 41.03,3.97",
			"34.74,24.44 36.35,25.8 37.74,26.17 39.97,27.45 41.48,25.93 41.44,24.91 41.95,24.01 36.73,20.99",
			"51.93,17.82 52.03,15.4 50.84,13.2 49.6,8.89 48.74,7.56 48.86,5.13 46.88,4.63 44.08,15.87",
			"34.96,20.21 36.68,21.2 38.69,17.72 39.09,17.59 39.7,15.97 37.98,14.97 36.24,17.99 35.38,18.48",
			"46.01,41.97 46.01,38.59 46.48,37.38 46.01,34.08 46.6,33.45 46.01,30.39 38.98,30.39 38.98,41.97",
			"23.04,39.93 23.41,37.88 23.04,36.46 23.04,33.89 20.99,33.34 20.08,33.89 19.07,33.89 19.07,39.93",
			"10.08,13.02 8.09,13.02 8.09,9.01 7.8,8.69 8.09,6.98 10.08,6.98 10.08,10.47 10.57,11.32",
			"10.05,13.06 7.46,13.06 7.46,18.57 7.46,20.22 7.46,23.08 10.05,23.08 10.05,15.66 10.61,14.98",
			"25.24,19.52 23.64,18.15 22.24,17.78 20.02,16.5 18.51,18 18.54,19.07 18.03,19.94 23.26,22.96",
			"24.98,23.89 23.26,22.9 21.25,26.38 20.84,26.51 20.24,28.13 21.96,29.13 23.7,26.11 24.55,25.62",
			"8.13,26.14 8.03,28.57 9.22,30.77 10.45,35.08 11.32,36.41 11.2,38.84 13.18,39.33 15.98,28.1"
		],
		ruins: [
			"29.77,26.78 27.15,26.68 27.15,33 27.53,30.91 29.08,31.17 30.09,30.3 29.79,29.18 30.19,28.64 29.47,27.78 29.83,26.89",
			"27.44,37.53 33.63,37.63 33.72,34.53 33.28,34.53 33.16,35.27 30.03,35.98 29.88,36.99 27.41,37.22",
			"17.31,2.54 14.7,2.4 14.66,4.04 15.03,3.9 14.9,2.89 17.34,2.71",
			"15.91,12.94 20.69,13.12 20.48,7.05 20.08,7.14 19.98,9.19 18.3,10.03 18.47,10.72 17.99,11.04 18.39,11.14 17.71,12.65 15.88,12.92",
			"32.55,6.33 26.36,6.23 26.27,9.33 26.71,9.33 26.83,8.59 29.97,7.87 30.11,6.87 32.58,6.64",
			"29.97,17.27 32.59,17.34 32.53,11.02 32.17,13.12 30.62,12.87 29.62,13.75 29.93,14.87 29.54,15.41 30.25,16.26 29.9,17.16",
			"51.04,36.41 50.42,35.8 50.89,35.39 50.89,34.29 50.15,33.96 50.89,33.76 50.89,32.69 50.15,32.25 50.86,32.25 51.04,31.65 51.72,32.42 51.16,32.68 51.17,33.79 51.72,34.02 51.17,34.27 51.16,35.37 51.72,35.65 51.09,36.32",
			"49.94,24.89 50.58,25.42 50.58,26.61 49.99,26.96 51.05,27.01 51.22,27.57 51.38,27.01 51.6,27.32 52.51,26.91 51.84,26.61 51.84,25.19 52.44,24.84 51.38,24.76 51.21,24.2 51.04,24.79 50.06,24.82",
			"50.96,31.03 52.02,30.96 51.3,30.76 51.3,27.53 52.02,27.33 50.77,27.39 50.93,30.99",
			"50.96,24.75 52.02,24.68 51.3,24.48 51.3,21.24 52.02,21.04 50.77,21.11 50.93,24.7",
			"37.97,8.43 37.55,7.15 37.84,5.82 39.01,7.29 38.3,7.57 38.1,8.29",
			"39.35,9.2 38.8,8.54 38.79,5.69 39.59,4.98 40.22,5.26 40.46,7.07 40.34,8.59 39.81,9.15",
			"36.52,25 35.08,24.32 36.72,21.88 36.8,22.56 35.58,24.25 36.67,24.9",
			"39.99,23.35 41.5,24.27 40.21,26.59 39.94,25.8 40.96,24.35 39.94,23.37",
			"45.78,10.91 44.45,15.47 48.7,16.46 47.8,15.86 47.58,13.01 45.39,12.85 45.9,11.08",
			"48.65,5.46 47.18,4.98 46.86,6.41 47.34,5.4 48.65,5.57",
			"39.89,14.52 39.42,16.23 38.92,16.26 38.51,17.81 38.04,17.8 37.52,19.47 37.09,19.43 36.5,20.44 36.62,21.03 35.79,21.35 35.67,20.56 35.07,21.02 34.98,20.13 35.52,19.95 36.06,18.25 36.44,18.37 37.09,17.25 36.97,16.68 37.35,16.79 37.99,15.72 37.89,15.09 38.7,14.72 38.98,15.55 39.67,14.44",
			"44.07,30.97 39.29,30.79 39.5,36.86 39.91,36.77 40,34.72 41.68,33.88 41.52,33.19 41.99,32.87 41.59,32.77 42.27,31.26 44.1,30.99",
			"42.75,41.41 45.36,41.54 45.39,39.91 45.02,40.05 45.15,41.06 42.71,41.24",
			"20.66,39.16 21.22,38.5 21.23,35.65 20.43,34.94 19.8,35.22 19.55,36.89 19.68,38.55 20.21,39.11",
			"22.05,38.39 22.47,37.1 22.18,35.77 21,37.25 21.72,37.53 21.92,38.25",
			"8.93,7.63 9.55,8.24 9.08,8.65 9.07,9.75 9.81,10.08 9.07,10.28 9.07,11.35 9.81,11.79 9.11,11.79 8.93,12.39 8.25,11.63 8.81,11.36 8.8,10.25 8.25,10.03 8.8,9.77 8.81,8.67 8.25,8.39 8.88,7.72",
			"9.01,19.3 7.95,19.36 8.67,19.57 8.67,22.8 7.95,23 9.19,22.94 9.04,19.34",
			"9.01,13.01 7.95,13.08 8.67,13.28 8.67,16.52 7.99,16.78 9.19,16.65 9.04,13.06",
			"10.03,19.16 9.38,18.85 9.38,17.43 9.98,17.08 8.92,17.03 8.75,16.47 8.59,17.03 7.52,17.08 8.12,17.44 8.12,18.85 7.46,19.14 8.59,19.28 8.76,19.85 8.92,19.25 9.91,19.22",
			"20.04,20.63 18.54,19.71 19.83,17.39 20.1,18.18 19.07,19.63 20.09,20.61",
			"23.51,18.98 24.96,19.66 23.31,22.1 23.14,21.62 24.46,19.73 23.37,19.08",
			"20.07,29.59 20.53,27.88 21.04,27.85 21.45,26.3 21.92,26.31 22.44,24.64 22.87,24.68 23.43,23.66 23.33,23.08 24.14,22.75 24.29,23.55 24.87,23.08 24.98,23.98 24.43,24.16 23.89,25.86 23.51,25.74 22.86,26.86 23.15,27.15 21.95,28.38 22.05,29.01 21.26,29.39 20.98,28.56 20.29,29.67",
			"11.41,38.5 12.88,38.99 13.2,37.56 12.72,38.56 11.41,38.4",
			"14.29,33.06 15.61,28.49 11.36,27.5 12.26,28.11 12.48,30.96 14.67,31.11 14.16,32.89"
		],
		markers: [
			{
				kind: "centre",
				x: 32.34,
				y: 32.01
			},
			{
				kind: "expansion",
				x: 15.67,
				y: 7.92
			},
			{
				kind: "centre",
				x: 27.58,
				y: 11.97
			},
			{
				kind: "home",
				x: 49.12,
				y: 11.06,
				owner: "defender"
			},
			{
				kind: "expansion",
				x: 44.39,
				y: 36.03
			},
			{
				kind: "home",
				x: 10.94,
				y: 32.91,
				owner: "attacker"
			}
		]
	},
	{
		id: "pf-pf-c",
		letter: "C",
		a: "Purge the Foe",
		b: "Purge the Foe",
		label: "Purge the Foe (mirror)",
		edge: "Long edge",
		zones: [{
			side: "attacker",
			points: "59.86,35.99 30.02,35.99 30.02,30.01 0.14,30.01 0.14,43.96 59.86,43.96"
		}, {
			side: "defender",
			points: "59.86,0.04 0.13,0.04 0.13,8.02 30.02,8.02 30.02,13.99 59.86,13.99"
		}],
		terrain: [
			"15.69,31.98 12.32,31.98 11.1,31.52 7.8,31.98 7.18,31.39 4.11,31.98 4.11,39.01 15.69,39.01",
			"25.99,31.03 24.43,33.11 28.83,36.42 30.15,37.41 32.43,39.13 33.99,37.06 28.06,32.6 27.86,31.74",
			"38.95,38.96 41.24,39.77 42.75,39.35 48.18,39.35 49.7,38.91 51.99,39.74 53.04,37.99 43.12,32.03",
			"21.16,5.11 18.87,4.3 16.42,4.8 11.94,4.72 10.41,5.16 8.12,4.33 7.07,6.08 16.99,12.05",
			"19.99,14.49 19.99,17.86 19.53,19.08 19.99,22.38 19.4,23.01 19.99,26.07 27.02,26.07 27.02,14.49",
			"44.44,12.09 47.81,12.09 49.03,12.55 52.32,12.09 52.95,12.68 56.01,12.09 56.01,5.06 44.44,5.06",
			"49.71,22.44 48.43,20.91 51.51,18.33 51.57,17.91 53.06,17.03 54.33,18.55 51.67,20.79 51.33,21.72",
			"46.89,22.08 45.29,20.75 44.66,19.42 43.01,17.46 44.23,15.71 45.28,15.55 46.05,14.9 49.93,19.52",
			"55.93,31.99 53.89,32.37 52.47,31.99 49.9,31.99 49.35,29.94 49.9,29.03 49.9,28.02 55.93,28.02",
			"24.5,33.09 22.89,31.92 20.53,35.17 20.11,35.26 19.34,36.81 20.95,37.97 22.99,35.16 23.89,34.75",
			"10.4,21.61 11.68,23.14 8.6,25.72 8.54,26.14 7.05,27.02 5.77,25.5 8.44,23.26 8.78,22.33",
			"13.22,21.97 14.82,23.3 15.45,24.63 17.1,26.59 15.86,28.35 14.83,28.5 14.05,29.15 10.17,24.52",
			"3.98,12 6.02,11.62 7.44,12 10.01,12 10.57,14.08 10.02,14.94 10.01,15.98 3.98,15.98",
			"40.01,29.55 40.01,26.18 40.48,24.96 40.01,21.66 40.6,21.04 40.01,17.97 32.98,17.97 32.98,29.55",
			"34.13,13.05 35.69,10.98 31.3,7.66 29.98,6.67 27.7,4.95 26.14,7.02 32.06,11.49 32.27,12.34",
			"35.61,10.98 37.22,12.15 39.58,8.9 39.99,8.81 40.77,7.26 39.16,6.09 37.11,8.91 36.21,9.31"
		],
		ruins: [
			"7.29,32.53 4.68,32.39 4.64,34.03 5.01,33.89 4.88,32.87 7.32,32.7",
			"15.19,37.16 15.32,32.35 9.2,32.72 11.44,33.09 12.29,34.71 14.91,35.38 15.16,37.2",
			"25.37,31.84 24.78,32.72 25.44,32.31 27.96,34.23 27.69,34.91 28.39,33.88 25.43,31.84",
			"30.89,34.72 30.2,35.08 29.07,34.14 29.14,33.53 28.53,34.34 27.98,34.13 28.33,34.61 27.84,34.76 27.73,35.56 28.36,35.21 29.44,36.09 29.42,36.75 30.11,35.95 30.67,36.16 30.35,35.73 30.84,34.83",
			"30.39,35.62 29.8,36.51 30.46,36.09 32.98,38.01 32.7,38.7 33.4,37.67 30.44,35.63",
			"47.32,35.18 43.28,32.57 41.17,36.32 42,35.67 44.86,36.29 45.55,34.25 47.31,35.2",
			"51.66,39.36 52.51,37.97 51.27,37.38 52.1,38.14 51.55,39.34",
			"8.45,4.71 7.6,6.1 8.84,6.69 8.01,5.93 8.56,4.74",
			"12.87,8.8 16.91,11.41 19.02,7.66 18.2,8.31 15.34,7.69 14.64,9.73 12.89,8.78",
			"20.39,25.56 26.58,25.66 26.67,22.56 26.23,22.56 26.11,23.3 22.98,24.02 22.83,25.02 20.36,25.25",
			"26.64,17.58 26.72,14.97 20.41,15.03 22.5,15.38 22.25,16.94 23.13,17.92 24.24,17.63 24.79,18.03 25.65,17.29 26.55,17.65",
			"44.94,7.01 44.81,11.83 50.93,11.46 48.69,11.09 47.84,9.47 45.22,8.79 44.96,6.98",
			"52.63,11.5 55.24,11.63 55.36,10.18 54.9,10.13 55.03,11.15 52.59,11.33",
			"48.3,22.98 49.34,22.15 49.81,22.3 49.83,21.73 51.3,21.05 51.23,20.55 52.58,19.94 53.54,18.62 54.16,18.61 54.3,17.75 53.51,17.78 53.86,17.11 52.96,17.17 52.84,17.8 51.3,18.57 51.45,18.97 49.91,19.73 50.05,20.14 49.14,20.91 48.51,20.91 48.3,21.81 49.22,21.79 48.18,22.76",
			"46.92,16.55 46.01,15.25 43.89,17.29 44.57,17.25 46.02,15.75 46.85,16.71",
			"45.83,20.34 46.99,21.67 49.05,19.99 48.22,19.86 46.97,21.12 45.83,20.29",
			"54.15,29.05 52.88,28.65 51.47,29.01 52.61,30.17 54.1,29.12",
			"54.93,30.42 54.26,29.87 51.38,29.92 50.72,30.72 50.99,31.33 52.74,31.56 54.36,31.41 54.89,30.86",
			"23.22,33.01 22.39,33.15 21.89,34.67 21.09,34.51 21.58,35.11 20.88,36.03 20.11,35.91 20.69,36.31 20.49,36.91 21.49,36.68 21.18,36.14 21.83,35.23 22.41,35.37 22.1,34.84 22.72,33.94 23.34,34.03 23.22,33.12",
			"11.74,21.11 10.7,21.94 10.23,21.8 9.29,23.12 8.82,22.97 8.81,23.54 7.85,24.33 7.46,24.15 6.5,25.48 5.88,25.49 5.74,26.34 6.58,26.35 6.18,26.99 7.08,26.92 7.2,26.29 8.15,25.52 8.48,25.74 9.54,24.34 9.88,24.57 10.9,23.19 11.53,23.18 11.74,22.28 10.82,22.3 11.86,21.33",
			"14.28,23.71 13.11,22.38 11.06,24.06 11.88,24.19 13.14,22.92 14.28,23.76",
			"13.19,27.5 14.1,28.8 16.22,26.76 15.54,26.8 14.08,28.3 13.26,27.34",
			"4.98,13.57 5.65,14.12 8.53,14.07 9.19,13.27 8.92,12.66 7.17,12.43 5.55,12.58 5.02,13.12",
			"5.76,14.94 7.03,15.34 8.44,14.98 7.3,13.82 5.81,14.87",
			"33.36,26.46 33.28,29.07 39.6,29.01 37.51,28.66 37.76,27.1 36.87,26.12 35.76,26.41 35.22,26.01 34.35,26.75 33.45,26.4",
			"39.61,18.42 33.42,18.32 33.33,21.42 33.77,21.42 33.89,20.68 37.02,19.96 37.16,18.96 39.64,18.73",
			"29.73,8.44 30.32,7.56 29.66,7.97 28.13,6.82 27.14,6.06 27.41,5.37 26.71,6.32 29.67,8.44",
			"29.23,9.35 29.86,9.01 31.06,9.86 30.92,10.55 31.59,9.73 32.14,9.93 31.79,9.46 32.28,9.32 32.46,8.5 31.75,8.85 30.62,7.92 30.69,7.31 30,8.11 29.44,7.9 29.82,8.4 29.22,9.25",
			"34.74,12.22 35.33,11.34 34.67,11.75 32.15,9.84 32.35,9.14 31.73,10.18 34.69,12.22",
			"36.8,11.02 37.64,10.88 38.14,9.36 38.83,9.67 38.45,8.92 39.14,8 39.91,8.12 39.34,7.72 39.54,7.12 38.54,7.35 38.84,7.89 38.2,8.8 37.62,8.66 37.69,9.54 37.3,10.09 36.68,10 36.81,10.91"
		],
		markers: [
			{
				kind: "home",
				x: 9.75,
				y: 33.61,
				owner: "attacker"
			},
			{
				kind: "centre",
				x: 21.62,
				y: 20.43
			},
			{
				kind: "home",
				x: 50.38,
				y: 10.46,
				owner: "defender"
			},
			{
				kind: "expansion",
				x: 52.16,
				y: 30.42
			},
			{
				kind: "expansion",
				x: 7.75,
				y: 13.57
			},
			{
				kind: "centre",
				x: 38.38,
				y: 23.61
			}
		]
	},
	{
		id: "pf-di-a",
		letter: "A",
		a: "Purge the Foe",
		b: "Disruption",
		label: "Disruption vs Purge the Foe",
		edge: "Long edge",
		zones: [{
			side: "attacker",
			points: "30.02,30.98 28.19,30.79 26.51,30.27 24.98,29.44 23.65,28.35 22.56,27.02 21.73,25.5 21.21,23.81 21.03,21.98 0.14,21.98 0.14,43.96 30.02,43.96"
		}, {
			side: "defender",
			points: "59.86,0.04 30,0.04 30,13.02 31.81,13.2 33.49,13.73 35.02,14.56 36.35,15.65 37.44,16.98 38.27,18.51 38.79,20.19 38.97,22 59.86,22"
		}],
		terrain: [
			"43.39,13.05 46.76,13.05 47.98,13.51 51.28,13.05 51.91,13.63 54.97,13.05 54.97,6.01 43.39,6.01",
			"44.05,24.53 44.05,21.94 49.56,21.94 51.2,21.94 54.06,21.94 54.06,24.53 46.65,24.53 45.96,25.09",
			"37.11,2.96 36.73,5.03 37.11,6.42 37.11,8.99 39.16,9.55 40.07,8.99 41.08,8.99 41.08,2.96",
			"42.07,21.98 44.05,21.98 44.05,17.97 44.34,17.65 44.05,15.94 42.07,15.94 42.07,19.43 41.58,20.28",
			"23.94,27.09 22.43,25.2 22.11,22.71 20.57,18.5 20.49,16.91 18.97,15.02 20.28,13.46 29.14,20.9",
			"35.96,16.89 37.47,18.79 37.56,20.35 39.33,25.48 39.41,27.07 40.94,28.96 39.62,30.53 30.76,23.09",
			"16.68,30.95 13.31,30.95 12.09,30.48 8.8,30.95 8.17,30.36 5.11,30.95 5.11,37.98 16.68,37.98",
			"50.94,29.39 47.74,30.46 46.44,30.41 43.46,31.9 42.68,31.54 39.96,33.07 42.19,39.74 53.17,36.07",
			"16.14,19.46 16.14,22.05 10.64,22.05 8.99,22.05 6.13,22.05 6.13,19.46 13.55,19.46 14.23,18.9",
			"18.13,22.01 16.14,22.01 16.14,26.02 15.86,26.34 16.14,28.05 18.13,28.05 18.13,24.57 18.62,23.71",
			"22.16,40.98 22.54,38.94 22.16,37.51 22.16,34.95 20.11,34.39 19.2,34.95 18.19,34.95 18.19,40.98",
			"26.93,3.98 24.94,3.98 24.94,7.99 24.71,8.81 24.94,10.02 26.93,10.02 26.93,6.53 27.42,5.68",
			"26.94,13 28.99,13.38 30.41,13 32.98,13 33.53,10.92 32.98,10.06 32.98,9.02 26.94,9.02",
			"33.02,39.99 35.01,39.99 35.01,35.97 35.3,35.65 35.01,33.95 33.02,33.95 33.02,37.43 32.53,38.28",
			"33.01,31.07 30.97,30.7 29.54,31.07 26.98,31.07 26.42,33.13 26.98,34.04 26.98,35.05 33.01,35.05",
			"9.28,14.64 12.48,13.57 13.78,13.62 16.76,12.14 17.54,12.5 20.26,10.97 18.03,4.3 7.05,7.98"
		],
		ruins: [
			"46.49,6.4 43.87,6.32 43.93,12.64 44.29,10.55 45.84,10.8 46.88,9.82 46.53,8.8 46.93,8.26 46.21,7.4 46.56,6.51",
			"51.52,12.38 54.13,12.51 54.16,10.88 53.79,11.02 53.92,12.03 51.48,12.21",
			"47.9,23.5 47.84,22.45 47.7,23.12 46.31,23.16 44.4,23.16 44.15,22.49 44.27,23.68 47.73,23.64",
			"48.04,24.51 48.36,23.87 49.76,23.87 50.06,24.52 50.17,23.4 50.72,23.24 50.24,23.09 50.07,21.95 49.76,22.61 48.35,22.61 47.99,22.02 47.92,23.07 47.35,23.25 47.95,23.41 47.98,24.41",
			"54.18,23.5 54.12,22.45 53.98,23.12 52.59,23.16 50.68,23.16 50.43,22.49 50.55,23.68 54.01,23.64",
			"37.52,7.19 37.39,8.77 40.32,8.57 39.98,8.18 37.7,8.37 37.69,7.11",
			"40.76,4.99 40.72,3.23 38.01,3.21 38.61,3.82 40.38,3.65 40.72,5.03",
			"43.22,16.68 42.6,17.3 43.07,17.71 43.08,18.8 42.33,19.14 43.08,19.34 43.08,20.41 42.33,20.84 43.04,20.84 43.22,21.45 43.9,20.68 43.34,20.42 43.35,19.3 43.9,19.08 43.35,18.83 43.34,17.73 43.9,17.45 43.27,16.78",
			"21.53,15.26 20.35,14.14 19.56,15.27 20.43,14.57 21.48,15.36",
			"25.41,24.52 28.62,20.94 25.24,18.27 25.75,19.18 24.7,21.91 26.6,22.92 25.38,24.5",
			"34.5,19.3 31.29,22.89 34.67,25.55 34.16,24.64 35.21,21.91 33.31,20.88 34.53,19.32",
			"38.53,28.82 39.53,29.9 40.02,29.84 40.49,28.82 39.66,29.46 38.57,28.72",
			"8.56,31.61 5.95,31.48 5.83,32.92 6.29,32.97 6.16,31.96 8.6,31.78",
			"13.58,37.47 16.24,37.36 16.09,31.2 15.74,33.29 14.19,33.06 13.2,33.95 13.52,35.06 13.13,35.61 13.86,36.45 13.51,37.35",
			"44.95,32.03 40.36,33.37 42.48,39.06 42.82,38.9 42.27,36.86 43.61,35.54 43.23,34.94 43.57,34.49 43.17,34.52 43.33,32.87 44.98,32.04",
			"46.84,37.83 52.81,35.9 51.84,32.99 51.43,33.13 51.55,33.87 48.8,35.55 49,36.51 46.73,37.51",
			"6.12,20.49 6.18,21.54 6.32,20.87 7.71,20.83 9.63,20.83 9.88,21.5 9.75,20.31 6.29,20.35",
			"12.16,19.48 11.84,20.12 10.43,20.12 10.14,19.47 10.03,20.59 9.48,20.75 10.03,20.92 9.73,21.16 10.13,22.04 10.43,21.38 11.85,21.38 12.2,21.97 12.27,20.92 12.84,20.74 12.25,20.58 12.22,19.58",
			"12.29,20.49 12.36,21.54 12.49,20.87 13.88,20.83 15.8,20.83 16.05,21.5 15.92,20.31 12.46,20.35",
			"16.98,27.31 17.6,26.69 17.13,26.28 17.12,25.19 17.86,24.85 17.12,24.65 17.12,23.58 17.86,23.15 17.16,23.15 16.98,22.54 16.29,23.31 16.86,23.57 16.85,24.68 16.29,24.91 16.85,25.16 16.86,26.26 16.29,26.54 16.85,27.18",
			"18.51,38.95 18.55,40.7 21.26,40.72 20.66,40.12 18.89,40.28 18.55,38.91",
			"21.75,36.75 21.88,35.17 18.95,35.37 19.29,35.76 21.57,35.57 21.5,36.83",
			"26.38,11.34 26.41,10.02 26.83,9.74 26.41,9.35 26.83,7.8 26.41,7.52 26.8,5.87 26.41,5.69 26.41,4.53 26.81,4.07 26.25,3.38 25.74,4 25.5,3.3 24.93,4.03 25.33,4.51 25.31,5.76 24.93,5.86 25.32,6.29 24.93,8.02 25.33,8.17 25.33,9.36 24.93,9.85 25.45,10.58 26.11,10 26.15,11.31",
			"28.64,12.02 29.93,12.44 31.32,12.1 30.2,10.97 28.7,11.94",
			"27.88,10.63 28.54,11.2 31.42,11.2 32.1,10.41 31.59,9.69 30.09,9.54 28.47,9.66 27.93,10.19",
			"33.57,32.62 33.54,33.94 33.12,34.22 33.54,34.61 33.12,36.16 33.55,36.44 33.15,38.09 33.55,38.27 33.55,39.43 33.15,39.89 33.71,40.58 34.21,39.96 34.5,40.66 35.02,39.93 34.63,39.45 34.64,38.2 35.02,38.1 34.63,36.38 35.02,35.94 34.62,35.79 35.02,34.11 34.5,33.38 33.95,34.08 33.8,32.66",
			"32.07,33.44 31.41,32.87 28.53,32.87 27.85,33.67 28.12,34.28 29.86,34.53 31.49,34.41 32.03,33.88",
			"31.32,32.05 30.02,31.63 28.63,31.97 29.75,33.1 31.25,32.13",
			"13.38,6.21 7.41,8.14 8.38,11.05 8.8,10.91 8.67,10.17 11.42,8.49 11.22,7.53 13.49,6.53",
			"15.27,12.01 19.86,10.67 17.74,4.98 17.4,5.14 17.95,7.18 16.61,8.5 16.89,11.17 15.24,12"
		],
		markers: [
			{
				kind: "home",
				x: 49.33,
				y: 11.42,
				owner: "defender"
			},
			{
				kind: "centre",
				x: 22.24,
				y: 19.97
			},
			{
				kind: "centre",
				x: 37.63,
				y: 23.9
			},
			{
				kind: "home",
				x: 10.74,
				y: 32.58,
				owner: "attacker"
			},
			{
				kind: "expansion",
				x: 45.82,
				y: 32.82
			},
			{
				kind: "expansion",
				x: 14.4,
				y: 11.22
			}
		]
	},
	{
		id: "pf-di-b",
		letter: "B",
		a: "Purge the Foe",
		b: "Disruption",
		label: "Disruption vs Purge the Foe",
		edge: "Short edge",
		zones: [{
			side: "attacker",
			points: "0.19,43.96 20.02,43.96 20.02,22.02 12.06,22.02 12.06,0.04 0.19,0.04"
		}, {
			side: "defender",
			points: "59.86,0.04 40.03,0.04 40.03,21.98 47.98,21.98 47.98,43.96 59.86,43.96"
		}],
		terrain: [
			"21.06,15.53 21.06,12.16 21.52,10.94 21.06,7.64 21.65,7.01 21.06,3.95 14.03,3.95 14.03,15.53",
			"17.49,29.95 14.12,29.95 12.9,30.41 9.61,29.95 8.98,30.54 5.91,29.95 5.91,22.92 17.49,22.92",
			"14.15,32.98 14.15,34.97 10.14,34.97 9.82,35.26 8.11,34.97 8.11,32.98 11.59,32.98 12.45,32.49",
			"10.71,9.09 8.11,9.09 8.11,14.6 8.11,16.25 8.11,19.11 10.71,19.11 10.71,11.69 11.27,11.01",
			"14.14,40.94 13.77,38.89 14.14,37.47 14.14,34.9 16.19,34.35 17.11,34.9 18.12,34.9 18.12,40.94",
			"32.07,32.98 30.08,32.98 30.08,36.99 29.79,37.31 30.08,39.02 32.07,39.02 32.07,35.54 32.56,34.68",
			"29.98,30.93 27.93,30.56 26.51,30.93 23.94,30.93 23.39,33.01 23.93,33.87 23.94,34.91 29.98,34.91",
			"27.97,11.06 29.96,11.06 29.96,7.04 30.24,6.72 29.96,5.01 27.97,5.01 27.97,8.5 27.48,9.35",
			"30.06,12.99 32.11,13.37 33.53,12.99 36.1,12.99 36.65,10.94 36.1,10.05 36.1,9.02 30.06,9.02",
			"33.03,29.01 31.95,26.84 32.14,24.35 31.52,19.91 31.77,18.34 30.67,16.17 32.28,14.91 39.4,24.03",
			"26.96,15 28.04,17.17 27.8,18.72 28.47,24.1 28.22,25.67 29.32,27.84 27.71,29.1 20.59,19.98",
			"42.43,14.04 45.8,14.04 47.02,13.58 50.32,14.04 50.95,13.45 54.01,14.04 54.01,21.07 42.43,21.07",
			"38.93,28.37 38.93,31.74 38.47,32.96 38.93,36.25 38.34,36.88 38.93,39.95 45.96,39.95 45.96,28.37",
			"46.07,11.15 46.07,9.16 50.08,9.16 50.4,8.88 52.11,9.16 52.11,11.15 48.63,11.15 47.77,11.64",
			"49.4,35.03 52,35.03 52,29.52 52,27.87 52,25.01 49.4,25.01 49.4,32.43 48.84,33.11",
			"46.1,3.17 46.47,5.21 46.1,6.63 46.1,9.2 44.04,9.76 43.13,9.2 42.12,9.2 42.12,3.17"
		],
		ruins: [
			"20.64,4.36 14.45,4.26 14.36,7.36 14.8,7.36 14.92,6.63 18.06,5.91 18.2,4.9 20.67,4.67",
			"18.17,15 20.79,15.07 20.73,8.75 20.37,10.84 18.82,10.6 17.82,11.48 18.13,12.6 17.73,13.13 18.45,13.99 18.1,14.89",
			"6.4,26.65 6.26,29.26 7.9,29.29 7.73,28.92 6.74,29.06 6.56,26.62",
			"16.84,28.17 16.97,23.35 10.85,23.73 13.09,24.1 13.94,25.72 16.56,26.39 16.81,28.2",
			"14.78,33.49 14.07,32.97 13.61,33.37 12.37,33.37 12.22,32.97 11.78,33.37 10.55,33.37 10.39,32.97 8.72,33.37 8.26,32.97 7.54,33.37 7.95,33.67 7.67,33.95 8.23,34.04 6.77,34.38 8.16,34.44 8.29,34.84 8.97,34.41 9.99,34.44 10.11,34.84 10.58,34.41 11.75,34.41 11.94,34.84 13.58,34.41 14.04,34.84 14.69,34.29 14.13,34.07 14.66,33.83 14.07,33.74 14.57,33.64",
			"9.65,15.33 8.59,15.4 9.31,15.6 9.31,18.83 8.59,19.03 9.83,18.97 9.67,15.37",
			"9.65,9.04 8.59,9.11 9.31,9.32 9.31,12.55 8.59,12.75 9.83,12.68 9.67,9.09",
			"10.67,15.19 10.02,14.88 10.02,13.46 10.62,13.11 9.56,13.07 9.39,12.51 9.22,13.07 9,12.76 8.1,13.17 8.76,13.47 8.76,14.88 8.17,15.24 9.22,15.31 9.4,15.88 9.56,15.28 10.55,15.26",
			"15.98,35.43 14.4,35.29 14.6,38.22 15,37.68 14.79,35.6 16.06,35.59",
			"16.11,40.55 17.87,40.51 17.89,37.8 17.28,38.4 17.44,40.17 16.07,40.51",
			"30.85,38.44 31.47,37.83 31,37.42 30.99,36.32 31.73,35.99 30.99,35.79 30.99,34.72 31.73,34.28 31.03,34.28 30.85,33.68 30.17,34.45 30.73,34.71 30.72,35.82 30.17,36.05 30.72,36.3 30.73,37.4 30.17,37.68 30.8,38.35",
			"28.77,33.24 28.1,32.68 25.23,32.68 24.55,33.47 25.06,34.19 26.56,34.34 28.18,34.22 28.72,33.68",
			"28.01,31.86 26.72,31.44 25.33,31.77 26.45,32.9 27.95,31.94",
			"29.19,5.59 28.57,6.2 29.04,6.61 29.05,7.71 28.3,8.04 29.05,8.25 29.05,9.32 28.3,9.75 29.01,9.75 29.19,10.35 29.87,9.59 29.31,9.32 29.32,8.21 29.87,7.99 29.32,7.73 29.31,6.63 29.87,6.36 29.24,5.68",
			"32.03,12.06 33.32,12.49 34.71,12.15 33.17,11.02 32.91,11.73 32.09,11.98",
			"31.27,10.68 31.94,11.25 34.81,11.25 35.49,10.45 35.23,9.84 33.48,9.58 31.86,9.71 31.32,10.24",
			"32.99,16.88 32.14,15.48 31.05,16.32 32.11,15.93 32.92,16.96",
			"35.04,26.9 38.92,24.06 36.17,20.75 36.48,21.75 34.88,24.2 36.53,25.6 35.02,26.88",
			"25.03,17.2 21.15,20.04 23.9,23.35 23.59,22.35 25.19,19.9 23.54,18.5 25.05,17.22",
			"26.96,27.27 27.76,28.51 28.26,28.53 28.96,27.55 27.97,28.09 27.02,27.18",
			"42.94,15.95 42.81,20.77 48.93,20.4 46.69,20.03 45.84,18.33 45.18,18.51 44.97,18.06 44.83,18.42 43.22,17.74 42.97,15.92",
			"53.52,17.34 53.66,14.73 52.2,14.62 52.19,15.07 53.19,14.94 53.36,17.37",
			"41.89,28.8 39.27,28.72 39.33,35.04 39.69,32.95 41.24,33.2 42.28,32.22 41.93,31.2 42.33,30.66 41.61,29.8 41.96,28.91",
			"39.42,39.53 45.61,39.63 45.7,36.53 45.26,36.53 45.14,37.27 42,37.99 41.86,38.99 39.39,39.23",
			"45.44,10.53 46.15,11.06 46.61,10.66 47.85,10.66 48,11.06 48.44,10.66 49.67,10.66 49.83,11.06 51.5,10.66 51.96,11.06 52.67,10.66 52.27,10.35 52.55,10.07 51.99,9.98 53.45,9.64 52.06,9.58 51.93,9.18 51.25,9.61 50.23,9.58 50.11,9.18 49.64,9.61 48.47,9.61 48.28,9.18 46.64,9.61 46.18,9.18 45.53,9.74 46.08,9.95 45.56,10.2 46.15,10.29 45.65,10.38",
			"49.44,28.93 50.09,29.24 50.09,30.66 49.49,31.01 50.55,31.06 50.72,31.62 50.89,31.06 51.95,31.01 51.35,30.65 51.35,29.24 52.01,28.95 50.89,28.81 50.71,28.24 50.55,28.84 49.56,28.87",
			"50.46,35.08 51.52,35.01 50.8,34.81 50.8,31.57 51.48,31.31 50.28,31.44 50.44,35.03",
			"50.46,28.79 51.52,28.73 50.8,28.52 50.8,25.29 51.52,25.09 50.28,25.15 50.44,28.75",
			"44.12,3.52 42.36,3.56 42.34,6.26 42.95,5.66 42.79,3.89 44.16,3.55",
			"44.25,8.64 45.83,8.77 45.63,5.84 45.23,6.39 45.44,8.47 44.17,8.48"
		],
		markers: [
			{
				kind: "expansion",
				x: 19.43,
				y: 9.59
			},
			{
				kind: "home",
				x: 11.55,
				y: 28.32,
				owner: "attacker"
			},
			{
				kind: "centre",
				x: 32.85,
				y: 21.7
			},
			{
				kind: "centre",
				x: 27.14,
				y: 22.2
			},
			{
				kind: "home",
				x: 48.37,
				y: 15.67,
				owner: "defender"
			},
			{
				kind: "expansion",
				x: 40.56,
				y: 34.31
			}
		]
	},
	{
		id: "pf-di-c",
		letter: "C",
		a: "Purge the Foe",
		b: "Disruption",
		label: "Disruption vs Purge the Foe",
		edge: "Long edge",
		zones: [{
			side: "attacker",
			points: "30.03,30.01 0.14,30.01 0.14,43.96 14.62,43.96 30.03,43.96 59.88,43.96 59.88,35.99 30.03,35.99"
		}, {
			side: "defender",
			points: "59.88,0.04 33.24,0.04 30.03,0.04 0.13,0.04 0.13,8.02 30.03,8.02 30.03,13.99 59.88,13.99"
		}],
		terrain: [
			"56,21.96 54.32,24.88 54.09,26.2 52.06,28.79 52.26,29.63 50.22,31.99 44.13,28.47 49.92,18.44",
			"16.58,31.97 13.18,31.97 12.02,31.51 8.68,31.97 8.02,31.39 5,31.97 5,39.01 16.58,39.01",
			"42.85,19.39 44.65,19.97 46.14,17.85 41.63,14.69 40.28,13.74 37.94,12.1 36.45,14.23 42.53,18.48",
			"38.77,20.94 36.36,21.21 35.19,22.26 30.29,24.64 29.65,25.36 26.71,25.95 26.54,27.99 38.06,29",
			"21.39,23.08 23.8,22.79 24.96,21.73 29.84,19.3 31.21,18.27 33.4,17.96 33.56,15.93 22.03,15.02",
			"43.37,12.07 46.74,12.07 47.99,12.53 51.26,12.07 51.88,12.66 54.95,12.07 54.95,5.04 43.37,5.04",
			"4.06,22.02 5.74,19.1 5.97,17.78 8,15.19 7.83,14.31 9.85,11.99 15.93,15.51 10.15,25.53",
			"17.48,11.48 18.98,9.8 19.38,8.33 20.8,5.99 19.15,4.41 17.97,4.44 17.01,3.91 13.69,9.4",
			"9.59,6.52 8.01,6.13 6.89,7.92 10.67,10.09 10.79,10.51 12.58,11.19 13.71,9.4 10.42,7.52",
			"15.11,24.09 13.62,26.22 18.13,29.38 19.48,30.32 21.82,31.96 23.31,29.84 17.23,25.58 17.03,24.76",
			"42.71,32.57 41.25,34.2 40.81,35.72 39.39,38.06 41.04,39.64 42.22,39.61 43.18,40.14 46.5,34.65",
			"50.28,37.53 52.08,37.97 53.2,36.18 49.42,34.01 49.3,33.59 47.51,32.91 46.38,34.7 49.67,36.59",
			"36.64,6.93 37.12,5.23 35.44,4.18 33.31,7.58 32.91,7.68 32.24,9.3 33.92,10.35 35.77,7.4",
			"25.04,9.43 26.6,10.85 27.98,11.27 30.16,12.63 31.69,11.21 31.73,10.12 32.27,9.26 27.15,6.06",
			"23.5,37.09 23.02,38.8 24.7,39.85 26.83,36.45 27.23,36.35 27.9,34.73 26.22,33.67 24.37,36.63",
			"35.08,34.61 33.57,33.23 32.14,32.78 29.96,31.42 28.4,32.86 28.39,33.93 27.86,34.79 32.97,37.99"
		],
		ruins: [
			"46.02,28.67 49.92,31.43 52.99,26.08 51.45,27.77 49.61,27.53 47.83,29.37 46.12,28.52",
			"55.47,22.07 50.09,18.89 48.57,21.53 48.92,21.73 49.39,21.15 52.63,22.03 53.05,21.31 55.34,22.35",
			"8.31,32.51 5.7,32.39 5.67,34.01 6.04,33.88 5.89,32.88 8.31,32.63",
			"16.04,35.11 15.89,32.43 9.82,32.55 11.9,32.89 11.68,34.46 12.55,35.45 13.63,35.14 14.19,35.54 15.05,34.8 15.92,35.17",
			"45.24,19.17 45.78,18.29 45.18,18.77 42.55,16.92 42.82,16.22 42.17,17.25 45.11,19.24",
			"40.09,15.57 40.63,14.69 40.04,15.16 37.58,13.44 37.67,12.61 37.02,13.65 39.97,15.64",
			"41.29,17.66 41.98,16.79 42.59,17 42.17,16.52 42.75,15.64 41.94,15.83 41,15.13 41.11,14.43 40.35,15.24 39.79,15.08 40.18,15.5 39.63,16.5 40.25,16.15 41.41,16.96 41.14,17.56",
			"32.92,28.05 37.68,28.62 37.93,24.3 37.48,25.28 36.55,25.2 35.1,26.19 34.65,25.97 34.9,28.09 33.06,27.9",
			"27.23,26.07 26.99,27.68 28.38,27.68 27.33,27.4 27.29,26.08",
			"32.95,17.93 33.21,16.38 31.76,16.34 32.82,16.6 32.88,17.92",
			"27.1,15.81 22.33,15.28 22.11,19.6 22.56,18.62 25.38,17.91 25.11,15.78 26.96,15.96",
			"51.75,11.53 54.36,11.65 54.39,10.04 54.02,10.16 54.17,11.17 51.75,11.41",
			"43.91,8.83 44.06,11.5 50.12,11.38 48.05,11.04 48.27,9.47 47.4,8.49 46.32,8.79 45.76,8.4 44.9,9.13 44.03,8.76",
			"14.04,15.3 10.14,12.55 7.07,17.9 8.24,16.44 10.46,16.44 12.23,14.61 13.94,15.46",
			"4.59,21.91 9.97,25.09 11.5,22.45 11.15,22.25 10.67,22.83 7.43,21.95 7.01,22.67 4.72,21.63",
			"15.11,7.83 14.22,9.43 16.7,10.84 16.52,10.01 14.75,9.21 15.2,7.81",
			"20.27,6.72 20.37,5.97 17.6,4.72 17.87,5.33 19.99,6.25 19.22,7.34 20.16,6.73",
			"5.92,6.77 7.17,7.56 7.16,8.04 7.68,7.85 8.92,8.56 8.98,9.09 9.49,8.85 10.82,10.11 11.21,9.84 12.34,10.48 12.56,11.11 13.45,10.98 13,10.41 13.68,10.55 13.18,10.12 13.98,10.3 13.61,9.45 12.92,9.55 11.8,8.9 11.87,8.45 10.08,7.92 9.86,7.29 9.47,7.57 8.34,6.92 8.11,6.3 7.2,6.3 7,6.85 7.51,7.26 6.03,6.59",
			"14.52,24.89 13.98,25.77 14.58,25.3 17.21,27.14 16.94,27.85 17.59,26.81 14.65,24.82",
			"19.67,28.49 19.13,29.38 19.72,28.9 20.61,29.52 22.35,30.75 22.09,31.45 22.74,30.42 19.79,28.43",
			"18.47,26.4 17.78,27.27 17.17,27.07 17.59,27.55 17.01,28.42 17.67,28.13 18.76,28.93 18.65,29.64 19.41,28.82 19.97,28.99 19.58,28.57 20.13,27.57 19.51,27.92 18.35,27.11 18.62,26.51",
			"45.03,36.19 45.93,34.59 43.44,33.18 43.62,34.01 45.39,34.82 44.94,36.21",
			"39.87,37.3 39.77,38.05 42.55,39.3 42.27,38.69 40.15,37.77 40.92,36.68 39.98,37.29",
			"54.17,37.33 52.92,36.54 52.93,36.06 52.41,36.25 51.17,35.54 51.11,35.01 50.6,35.25 49.27,33.99 48.88,34.26 47.75,33.62 47.53,32.99 46.64,33.12 47.09,33.69 46.41,33.55 46.91,33.98 46.11,33.8 46.48,34.65 47.17,34.55 48.29,35.2 48.22,35.65 50.01,36.18 50.23,36.81 50.62,36.53 51.75,37.18 51.98,37.8 52.89,37.8 53.09,37.24 52.58,36.84 54.06,37.51",
			"33.4,9.21 34.23,9.04 34.05,8.46 34.64,7.51 35.45,7.62 34.9,7.09 35.49,6.15 36.3,6.25 35.76,5.73 35.98,5.25 34.96,5.49 35.06,6.39 34.7,6.96 34.11,6.85 34.45,7.36 33.84,8.32 33.24,8.24 33.43,9.16",
			"26.87,7.93 27.11,8.72 29.6,10.28 30.51,9.99 30.66,9.28 29.4,8.21 27.89,7.41 27.1,7.57",
			"26.76,9.64 28.99,10.96 28.47,9.51 29.34,8.47 28.91,8.12 28.3,9.37 26.78,9.54",
			"26.73,34.82 25.9,34.99 26.08,35.58 25.49,36.52 24.68,36.42 25.23,36.94 24.64,37.89 23.83,37.78 24.38,38.31 24.15,38.78 25.17,38.55 24.83,38.04 25.44,37.07 26.06,37.06 25.68,36.68 26.29,35.71 26.89,35.8 26.7,34.88",
			"33.25,36.12 33.01,35.32 30.52,33.77 29.61,34.06 29.47,34.76 30.8,35.89 32.23,36.63 33.02,36.48",
			"33.37,34.41 31.13,33.08 31.65,34.53 30.78,35.58 31.22,35.93 31.82,34.67 33.34,34.5"
		],
		markers: [
			{
				kind: "expansion",
				x: 51.63,
				y: 26.3
			},
			{
				kind: "home",
				x: 10.63,
				y: 33.6,
				owner: "attacker"
			},
			{
				kind: "centre",
				x: 32.7,
				y: 24.67
			},
			{
				kind: "centre",
				x: 27.52,
				y: 19.26
			},
			{
				kind: "home",
				x: 49.31,
				y: 10.44,
				owner: "defender"
			},
			{
				kind: "expansion",
				x: 8.44,
				y: 17.68
			}
		]
	},
	{
		id: "pf-re-a",
		letter: "A",
		a: "Purge the Foe",
		b: "Reconnaissance",
		label: "Purge the Foe vs Reconnaissance",
		edge: "Short edge",
		zones: [{
			side: "attacker",
			points: "0.14,43.96 0.14,0.04 18.01,0.04 18.01,43.96"
		}, {
			side: "defender",
			points: "41.99,43.96 41.99,0.04 59.86,0.04 59.86,43.96"
		}],
		terrain: [
			"45,13.13 45,16.5 44.54,17.72 45,21.02 44.41,21.64 45,24.71 52.03,24.71 52.03,13.13",
			"41,32.94 37.63,32.94 36.41,32.48 33.12,32.94 32.49,32.35 29.43,32.94 29.43,39.97 41,39.97",
			"52.99,9.15 52.99,7.16 48.97,7.16 48.65,6.88 46.95,7.16 46.95,9.15 50.43,9.15 51.28,9.64",
			"42.96,3.13 42.58,5.18 42.96,6.6 42.96,9.17 45.03,9.72 45.9,9.18 46.93,9.17 46.93,3.13",
			"37.05,14.37 39.55,13.7 38.13,8.38 37.7,6.78 36.96,4.02 34.46,4.69 36.38,11.86 36.01,12.66",
			"31.07,18.04 31.55,20.41 32.69,21.49 35.48,26.14 36.65,27.22 37.12,29.61 39.16,29.61 39.16,18.04",
			"47.84,39.02 49.83,39.02 49.83,35 50.11,34.68 49.83,32.98 47.84,32.98 47.84,36.46 47.35,37.32",
			"22.96,29.58 20.45,30.25 21.88,35.57 22.3,37.17 23.05,39.93 25.55,39.26 23.63,32.09 23.99,31.29",
			"6.99,34.97 6.99,36.96 11.01,36.96 11.82,37.19 13.03,36.96 13.03,34.97 9.55,34.97 8.7,34.48",
			"17.02,40.99 17.4,38.95 17.02,37.52 17.02,34.95 14.97,34.4 14.08,34.95 13.05,34.95 13.05,40.99",
			"11.99,5 10,5 10,9.01 9.71,9.33 10,11.04 11.99,11.04 11.99,7.56 12.48,6.7",
			"11.94,17.04 11.56,15 11.94,13.57 11.94,11.01 13.99,10.45 14.88,11 15.91,11.01 15.91,17.04",
			"14.96,30.95 14.96,27.57 15.43,26.35 14.96,23.06 15.55,22.43 14.96,19.36 7.93,19.36 7.93,30.95",
			"19.04,11.02 22.41,11.02 23.63,11.48 26.92,11.02 27.55,11.61 30.61,11.02 30.61,3.99 19.04,3.99",
			"47.88,26.98 48.26,29.05 47.88,30.44 47.88,33.01 45.83,33.56 44.94,33.02 43.91,33.01 43.91,26.98",
			"28.83,26.04 28.34,23.66 27.2,22.58 24.41,17.93 23.25,16.85 22.78,14.46 20.74,14.46 20.74,26.04"
		],
		ruins: [
			"48.3,13.58 45.69,13.45 45.65,15.08 46.02,14.94 45.89,13.93 48.33,13.75",
			"45.58,19.49 45.45,24.31 51.57,23.93 49.33,23.56 48.48,21.94 45.86,21.27 45.61,19.46",
			"32.43,33.32 29.81,33.25 29.87,39.57 30.24,37.48 31.79,37.73 32.83,36.75 32.48,35.73 32.87,35.19 32.15,34.33 32.5,33.44",
			"34.42,39.58 40.61,39.67 40.7,36.57 40.26,36.57 40.14,37.31 37.01,38.03 36.87,39.03 34.39,39.27",
			"46.32,8.48 47.03,9.01 47.5,8.61 48.74,8.61 48.89,9.01 49.32,8.61 50.56,8.61 50.72,9.01 52.39,8.61 52.85,9.01 53.56,8.61 53.16,8.3 53.44,8.02 52.88,7.93 54.34,7.59 52.94,7.53 52.82,7.13 52.14,7.56 51.12,7.53 50.99,7.13 50.53,7.56 49.35,7.56 49.17,7.13 47.53,7.56 47.06,7.13 46.41,7.68 46.97,7.9 46.45,8.15 47.03,8.24 46.54,8.33",
			"43.4,7.31 43.27,8.89 46.19,8.69 45.85,8.3 43.58,8.5 43.65,7.23",
			"46.64,5.05 46.59,3.3 43.89,3.28 44.49,3.88 46.26,3.72 46.59,5.09",
			"36.42,8.09 37.39,7.78 36.68,7.74 35.84,4.62 36.48,4.24 35.34,4.56 36.38,8.05",
			"35.47,8.49 36.17,8.62 36.54,9.99 36.06,10.48 37.09,10.25 37.4,10.75 37.41,10.16 37.71,10.4 38.47,9.78 37.75,9.66 37.39,8.29 37.87,7.79 36.83,7.99 36.52,7.49 36.51,8.11 35.52,8.42",
			"38.04,14.16 39.02,13.85 38.3,13.81 37.52,10.9 38.11,10.31 36.96,10.63 38.01,14.12",
			"38.45,23.3 38.6,18.49 34.27,18.62 35.28,18.98 36.22,21.76 38.32,21.31 38.35,23.23",
			"37.18,29.02 38.72,29.13 38.68,27.75 38.44,28.78 37.15,28.91",
			"48.83,33.62 48.21,34.23 48.68,34.65 48.69,35.74 47.95,36.07 48.69,36.28 48.69,37.35 47.95,37.78 48.65,37.78 48.76,38.39 49.52,37.62 48.96,37.35 48.96,36.24 49.52,36.02 48.96,35.77 48.96,34.67 49.52,34.39 48.96,33.74",
			"21.96,29.79 20.99,30.1 21.71,30.14 22.49,33.05 21.9,33.64 23.04,33.32 22,29.83",
			"24.54,35.46 23.83,35.33 23.47,33.96 23.95,33.47 22.91,33.7 22.61,33.2 22.59,33.79 22.3,33.55 21.53,34.17 22.25,34.29 22.62,35.66 22.14,36.16 23.17,35.95 23.49,36.46 23.49,35.84 24.49,35.53",
			"23.59,35.86 22.61,36.17 23.33,36.21 24.17,39.33 23.52,39.71 24.67,39.39 23.62,35.9",
			"13.66,35.64 12.95,35.12 12.48,35.52 11.25,35.52 11.09,35.12 10.66,35.52 9.42,35.52 9.27,35.12 7.6,35.52 7.13,35.12 6.42,35.52 6.82,35.82 6.54,36.1 7.1,36.19 5.65,36.53 7.04,36.59 7.16,36.99 7.84,36.56 8.86,36.59 8.99,36.99 9.45,36.56 10.63,36.56 10.81,36.99 12.45,36.56 12.92,36.99 13.57,36.44 13.01,36.22 13.54,35.98 12.95,35.88 13.44,35.79",
			"13.78,38.96 13.83,40.71 16.53,40.73 15.93,40.13 14.16,40.29 13.83,38.92",
			"16.36,36.92 16.49,35.34 13.57,35.54 13.91,35.93 16.18,35.74 16.2,37",
			"10.99,10.4 11.61,9.78 11.14,9.37 11.14,8.27 11.88,7.94 11.14,7.74 11.14,6.67 11.88,6.24 11.17,6.24 10.99,5.63 10.31,6.4 10.87,6.66 10.86,7.77 10.31,8 10.86,8.25 10.87,9.35 10.31,9.63 10.94,10.3",
			"13.51,16.12 14.06,15.46 14.07,12.61 13.27,11.9 12.64,12.18 12.4,13.99 12.52,15.51 13.06,16.07",
			"14.89,15.35 15.31,14.06 15.02,12.73 13.85,14.21 14.56,14.49 14.77,15.21",
			"14.38,24.58 14.51,19.77 8.39,20.14 10.63,20.51 11.48,22.21 13.97,22.7 14.36,24.62",
			"11.78,30.32 14.39,30.45 14.51,29.01 14.05,28.96 14.18,29.97 11.74,30.15",
			"25.58,4.33 19.39,4.23 19.3,7.33 19.74,7.33 19.86,6.59 22.99,5.87 23.14,4.87 25.61,4.63",
			"27.67,10.56 30.29,10.63 30.23,4.31 29.86,6.4 28.31,6.16 27.27,7.14 27.62,8.16 27.23,8.69 27.95,9.55 27.6,10.45",
			"44.94,28.66 44.52,29.95 44.8,31.28 45.98,29.81 45.26,29.53 45.06,28.81",
			"46.32,27.9 45.76,28.55 45.76,31.41 46.55,32.11 47.18,31.84 47.43,30.17 47.31,28.5 46.77,27.95",
			"22.61,14.84 21.15,14.66 20.81,15.02 21.11,16.1 21.35,15.08 22.64,14.94",
			"21.23,20.67 21.08,25.47 25.41,25.35 24.4,24.98 23.45,22.21 21.36,22.65 21.33,20.73"
		],
		markers: [
			{
				kind: "home",
				x: 46.63,
				y: 19.07,
				owner: "defender"
			},
			{
				kind: "expansion",
				x: 35.06,
				y: 34.57
			},
			{
				kind: "centre",
				x: 35.36,
				y: 23.82
			},
			{
				kind: "home",
				x: 13.34,
				y: 25,
				owner: "attacker"
			},
			{
				kind: "expansion",
				x: 24.98,
				y: 9.39
			},
			{
				kind: "centre",
				x: 24.54,
				y: 20.25
			}
		]
	},
	{
		id: "pf-re-b",
		letter: "B",
		a: "Purge the Foe",
		b: "Reconnaissance",
		label: "Purge the Foe vs Reconnaissance",
		edge: "Long edge",
		zones: [{
			side: "attacker",
			points: "0.14,43.96 0.14,32 59.88,32 59.88,43.96"
		}, {
			side: "defender",
			points: "0.14,12.01 0.14,0.04 59.88,0.04 59.88,12.01"
		}],
		terrain: [
			"45.08,3.03 41.68,3.03 40.52,2.57 37.17,3.03 36.52,2.45 33.5,3.03 33.5,10.07 45.08,10.07",
			"15.57,14.05 12.2,14.05 10.94,13.59 7.66,14.05 7.05,13.46 3.99,14.05 3.99,21.08 15.57,21.08",
			"32.78,12.45 33.54,9.97 28.28,8.36 26.7,7.88 23.97,7.05 23.21,9.53 30.3,11.69 30.74,12.41",
			"23.44,29.72 22.1,27.7 21.97,25.14 20.83,20.88 20.88,19.27 19.53,17.26 20.97,15.81 29.16,24",
			"55.27,11.92 56.02,10.31 54.52,9.01 51.88,12.04 51.44,12.11 50.55,13.57 52.05,14.87 54.34,12.24",
			"44.88,14.06 46.24,15.73 47.5,16.33 49.44,18.02 51.17,16.86 51.38,15.78 52.04,15.02 47.49,11.06",
			"15.06,40.86 18.43,40.86 19.69,41.32 22.95,40.86 23.58,41.45 26.64,40.86 26.64,33.83 15.06,33.83",
			"44.41,30.11 47.78,30.11 49.03,30.57 52.31,30.11 52.92,30.7 55.99,30.11 55.99,23.07 44.41,23.07",
			"27.42,31.37 26.62,33.83 31.86,35.53 33.43,36.04 36.15,36.93 36.95,34.46 29.89,32.17 29.38,31.41",
			"15.66,11.23 17.11,9.7 17.55,8.33 18.95,6.17 17.49,4.57 16.46,4.56 15.62,4.01 12.33,9.07",
			"10.55,8.55 12.25,9.07 13.33,7.4 9.96,5.22 9.92,4.86 8.26,4.11 7.18,5.78 10.1,7.68",
			"44.47,32.73 43.01,34.25 42.56,35.62 41.14,37.76 42.58,39.38 43.61,39.4 44.45,39.95 47.78,34.92",
			"49.56,35.45 47.87,34.92 46.77,36.58 50.12,38.8 50.16,39.15 51.81,39.91 52.9,38.26 50,36.33",
			"4.05,33.77 5.55,35.08 8.18,32.04 8.62,31.97 9.51,30.52 8.01,29.21 5.72,31.84 4.84,32.12",
			"15.18,30.03 13.91,28.42 12.56,27.75 10.63,26.06 8.83,27.29 8.68,28.3 8.02,29.06 12.58,33.02",
			"36.76,14.31 38.1,16.33 38.2,18.77 39.37,23.15 39.32,24.76 40.67,26.77 39.23,28.21 31.04,20.03"
		],
		ruins: [
			"34.04,6.61 33.9,9.23 35.54,9.26 35.37,8.89 34.38,9.02 34.2,6.58",
			"38.37,9.43 44.56,9.53 44.65,6.43 44.21,6.43 44.09,7.17 40.96,7.89 40.82,8.89 38.34,9.13",
			"14.94,19.15 15.07,14.33 8.95,14.7 11.19,15.08 12.04,16.69 14.66,17.37 14.92,19.18",
			"4.44,18.01 4.36,20.63 10.67,20.57 8.58,20.21 8.83,18.66 7.95,17.67 6.83,17.97 6.29,17.57 5.43,18.3 4.53,17.95",
			"33.02,11.66 33.29,10.64 32.67,11.2 29.81,10.27 29.76,9.54 29.51,10.72 32.96,11.69",
			"27.05,9.72 27.32,8.7 26.69,9.26 23.84,8.33 23.86,7.58 23.54,8.77 26.99,9.75",
			"26.87,10.73 27.36,10.22 28.71,10.65 28.89,11.33 29.23,10.33 29.81,10.35 29.33,10.02 29.62,8.99 29.09,9.45 27.78,9.02 27.67,8.3 27.2,9.32 26.61,9.31 27.12,9.65 26.84,10.66",
			"22.21,17.83 21.47,16.7 20.81,16.69 20.25,17.67 21.14,17.11 22.16,17.93",
			"24.73,27.23 28.24,23.93 25.11,20.98 25.54,21.94 24.25,24.56 26.06,25.75 24.71,27.2",
			"55.66,8.14 54.23,9.18 54.38,9.65 53.06,10.59 53.25,11.01 52.47,11.98 52,11.92 51.3,13.39 50.7,13.51 50.71,14.38 51.46,14.24 51.27,14.94 52.13,14.71 52.11,14.13 53.51,13.04 53.27,12.73 54.09,11.72 54.46,11.88 55.21,10.34 55.83,10.22 55.87,9.3 55.02,9.35 55.82,8.34",
			"48.62,12.84 47.26,11.71 45.49,13.69 46.32,13.69 47.36,12.25 48.62,12.89",
			"48.29,16.26 49.39,17.4 51.16,15.06 50.5,15.2 49.3,16.91 48.33,16.09",
			"26.04,37.18 26.18,34.57 24.89,34.39 24.45,34.72 25.7,34.77 25.85,35.18 25.88,37.21",
			"21.75,34.46 15.56,34.36 15.47,37.46 15.91,37.46 16.02,36.73 19.16,36.01 19.3,35 21.78,34.77",
			"44.8,25.12 44.67,29.94 50.79,29.56 48.92,29.36 47.7,27.57 45.21,27 44.82,25.09",
			"55.52,26.04 55.6,23.42 49.28,23.48 51.37,23.84 51.13,25.39 52.01,26.37 53.12,26.08 53.66,26.48 54.53,25.74 55.43,26.1",
			"27.14,32.15 26.85,33.17 27.49,32.62 30.33,33.6 30.29,34.35 30.64,33.16 27.2,32.13",
			"33.08,34.19 32.79,35.21 33.15,34.62 34.46,35.02 36.27,35.65 36.23,36.4 36.57,35.2 33.14,34.17",
			"33.28,33.19 32.76,33.7 31.44,33.23 31.28,32.56 30.91,33.55 30.33,33.52 30.8,33.86 30.44,33.97 30.53,34.96 31.25,34.5 32.35,34.89 32.43,35.61 32.92,34.59 33.51,34.61 33,34.26 33.29,33.26",
			"14.33,9.15 15.15,8.92 16.75,6.55 16.49,5.52 15.81,5.4 14.67,6.65 13.84,8.09 13.98,8.86",
			"16.06,9.3 17.47,7.11 15.98,7.56 14.87,6.61 14.56,7.07 16.09,8.28 15.93,9.3",
			"8.32,5.32 8.5,6.15 10.04,6.57 9.77,7.28 10.49,6.85 11.4,7.42 11.37,8.28 11.73,7.74 12.32,7.9 12.07,6.86 11.54,7.2 10.61,6.61 10.71,6.02 10.2,6.35 9.27,5.78 9.32,5.15 8.48,5.28",
			"45.77,34.82 44.94,35.05 43.32,37.4 43.57,38.43 44.25,38.56 45.4,37.32 46.24,35.88 46.11,35.12",
			"44.04,34.65 42.61,36.84 44.1,36.4 45.21,37.36 45.52,36.9 44,35.68 44.17,34.65",
			"51.74,38.7 51.47,37.8 50.94,38.02 50.03,37.44 50.07,36.58 49.58,37.15 48.68,36.58 48.72,35.72 48.24,36.3 47.76,36.09 48.01,37.13 48.54,36.8 49.47,37.4 49.36,37.99 49.87,37.66 50.8,38.24 50.74,38.87 51.58,38.74",
			"4.38,35.94 5.25,34.93 5.74,34.99 5.66,34.43 6.98,33.49 6.8,33.07 7.57,32.1 8.04,32.17 8.74,30.69 9.34,30.57 9.33,29.7 8.5,29.84 8.78,29.14 7.91,29.37 7.17,30.91 6.74,30.79 6.77,31.36 5.38,32.45 5.59,32.82 4.21,33.86 4.17,34.78 5.02,34.73 4.22,35.74",
			"11.42,31.24 12.78,32.37 14.55,30.39 13.72,30.39 12.68,31.84 11.42,31.19",
			"11.76,27.82 10.65,26.68 8.88,29.02 9.54,28.88 10.75,27.17 11.71,27.99",
			"37.97,26.19 39.11,27.36 39.98,26.3 39.04,26.92 38.02,26.1",
			"35.45,16.8 31.94,20.09 35.07,23.04 34.64,22.09 35.93,19.46 34.12,18.29 35.47,16.82"
		],
		markers: [
			{
				kind: "home",
				x: 39.13,
				y: 4.66,
				owner: "defender"
			},
			{
				kind: "expansion",
				x: 9.62,
				y: 15.68
			},
			{
				kind: "centre",
				x: 22.36,
				y: 22.47
			},
			{
				kind: "home",
				x: 21.01,
				y: 39.23,
				owner: "attacker"
			},
			{
				kind: "expansion",
				x: 50.36,
				y: 28.48
			},
			{
				kind: "centre",
				x: 37.84,
				y: 21.54
			}
		]
	},
	{
		id: "pf-re-c",
		letter: "C",
		a: "Purge the Foe",
		b: "Reconnaissance",
		label: "Purge the Foe vs Reconnaissance",
		edge: "Short edge",
		zones: [{
			side: "attacker",
			points: "30.02,43.96 0.13,0.04 0.14,43.96"
		}, {
			side: "defender",
			points: "59.86,43.96 59.86,0.04 29.98,0.04"
		}],
		terrain: [
			"50.95,36.05 49.07,33.26 48.77,31.99 46.54,29.51 46.68,28.66 44.48,26.45 38.65,30.38 45.12,39.99",
			"48.02,7.01 48.02,10.38 47.56,11.6 48.02,14.89 47.44,15.52 48.02,18.59 55.05,18.59 55.05,7.01",
			"42.52,17.17 44.67,15.72 41.59,11.16 40.67,9.79 39.07,7.42 36.92,8.87 41.07,15.02 40.99,15.9",
			"39.08,7.43 40.19,9.08 43.51,6.83 43.94,6.89 45.19,5.7 44.08,4.05 41.2,6 40.21,6.07",
			"23.98,5.99 23.6,8.04 23.98,9.46 23.98,12.03 26.06,12.58 26.92,12.04 27.95,12.03 27.95,5.99",
			"34.06,11.94 34.06,9.95 30.05,9.95 29.73,9.66 28.03,9.95 28.03,11.94 31.51,11.94 32.36,12.43",
			"36.01,15.94 34.28,17.64 33.66,20.06 31.62,24.06 31.35,25.62 29.6,27.32 30.71,29.03 40.42,22.73",
			"36,38.04 36.38,35.99 36,34.57 36,32 33.95,31.45 33.04,32 32.03,32 32.03,38.04",
			"25.91,32.01 25.91,34 29.93,34 30.24,34.29 31.95,34 31.95,32.01 28.47,32.01 27.61,31.52",
			"17.55,26.89 15.4,28.34 18.48,32.91 19.4,34.27 21,36.64 23.15,35.19 19,29.04 19.09,28.16",
			"21,36.63 19.89,34.99 16.56,37.23 16.13,37.17 14.88,38.36 15.99,40.01 18.88,38.06 19.86,37.99",
			"9.16,7.97 11.04,10.77 11.34,12.03 13.57,14.51 13.43,15.36 15.63,17.57 21.46,13.64 14.99,4.04",
			"11.98,37.01 11.98,33.64 12.44,32.42 11.98,29.13 12.56,28.5 11.98,25.43 4.95,25.43 4.95,37.01",
			"48.02,23.03 47.65,25.08 48.02,26.5 48.02,29.07 50.08,29.62 50.99,29.07 52,29.07 52,23.03",
			"23.98,28.1 25.71,26.4 26.33,24 28.38,19.98 28.65,18.42 30.39,16.73 29.28,15.01 19.58,21.32",
			"12.01,21.04 12.39,18.99 12.01,17.57 12.01,15 9.96,14.45 9.07,14.99 8.04,15 8.04,21.04"
		],
		ruins: [
			"41.35,29.08 39.14,30.48 42.72,35.69 41.86,33.75 43.28,33.09 43.61,31.8 42.73,31.05 42.76,30.38 41.68,30.07 41.47,29.13",
			"45.35,39.52 50.52,35.97 48.8,33.51 48.41,33.71 48.73,34.38 46.6,36.76 47.04,37.65 45.15,39.25",
			"51.21,7.43 48.6,7.29 48.48,8.74 48.94,8.79 48.81,7.78 51.25,7.6",
			"48.51,13.28 48.38,18.1 54.5,17.73 52.26,17.35 51.41,15.73 48.79,15.06 48.53,13.25",
			"39.81,11.49 40.63,10.87 39.94,11.07 38.86,9.48 38.13,8.39 38.55,7.79 37.64,8.5 39.76,11.47",
			"39.04,12.18 39.74,12.06 40.54,13.24 40.24,13.87 41.15,13.31 41.6,13.68 41.43,13.12 41.79,13.25 42.3,12.41 41.45,12.33 40.79,11.36 41.09,10.73 40.17,11.26 39.71,10.89 39.88,11.4 39.06,12.09",
			"43.32,16.7 44.1,15.95 43.45,16.28 41.76,13.78 42.13,13.03 41.15,13.71 43.27,16.67",
			"44.16,5.33 43.23,5.21 43.21,5.79 42.32,6.39 41.79,5.85 41.88,6.69 40.99,7.29 40.46,6.75 40.18,7.93 41.23,8.12 41.14,7.5 42.06,6.89 42.56,7.23 42.46,6.62 43.36,6.01 43.91,6.31 44.12,5.41",
			"24.49,10.09 24.36,11.67 27.28,11.47 26.94,11.08 24.67,11.27 24.74,10.01",
			"27.49,8.23 27.45,6.47 24.74,6.45 25.34,7.06 27.11,6.89 27.45,8.27",
			"27.43,11.46 28.14,11.98 28.6,11.58 29.84,11.58 29.99,11.98 30.43,11.58 31.66,11.58 31.82,11.98 33.49,11.58 33.95,11.98 34.67,11.58 33.98,10.88 35.16,10.54 34.05,10.51 33.92,10.11 33.24,10.54 32.22,10.51 32.1,10.11 31.63,10.54 30.46,10.54 30.27,10.11 28.63,10.54 28.17,10.11 27.52,10.66 28.08,10.88 27.55,11.12 28.14,11.22 27.64,11.31",
			"30.14,27.11 30.63,28.38 31.27,28.52 32.02,27.68 31.04,28.05 30.21,27.03",
			"35.5,25.24 39.62,22.74 37.17,19.21 37.39,20.23 35.59,22.53 37.11,24.07 35.49,25.21",
			"32.27,35.91 32.31,37.67 35.02,37.69 34.42,37.08 32.65,37.25 32.31,35.87",
			"35.49,33.83 35.63,32.25 32.7,32.45 33.04,32.84 35.32,32.65 35.33,33.91",
			"32.55,32.6 31.84,32.08 31.37,32.48 30.14,32.48 29.98,32.08 29.55,32.48 28.31,32.48 28.16,32.08 26.49,32.48 26.02,32.08 25.31,32.48 25.99,33.18 24.82,33.52 25.93,33.55 26.05,33.95 26.73,33.52 27.76,33.55 27.88,33.95 28.34,33.52 29.52,33.52 29.7,33.95 31.34,33.52 31.81,33.95 32.46,33.4 31.9,33.18 32.43,32.94 31.84,32.84 32.33,32.75",
			"16.75,27.36 15.93,27.98 16.62,27.78 18.43,30.46 17.94,31.03 18.92,30.35 16.8,27.39",
			"21.03,31.88 20.33,32 19.53,30.82 19.83,30.19 18.93,30.75 18.47,30.38 18.65,30.94 18.28,30.81 17.77,31.65 18.49,31.53 19.28,32.7 18.99,33.33 19.9,32.8 20.36,33.17 20.19,32.66 21.01,31.97",
			"20.27,32.57 19.44,33.19 20.13,32.99 21.94,35.67 21.46,36.24 22.43,35.56 20.31,32.6",
			"15.91,38.73 16.85,38.85 16.86,38.27 17.75,37.67 18.28,38.21 18.19,37.37 19.08,36.77 19.85,37.15 19.51,36.48 19.9,36.13 18.84,35.94 18.93,36.56 18.01,37.17 17.52,36.83 17.62,37.44 17.04,37.84 16.16,37.75 15.96,38.65",
			"14.9,4.54 9.73,8.08 11.48,10.6 11.84,10.34 11.52,9.67 13.65,7.3 13.21,6.41 15.1,4.81",
			"18.65,15.05 20.86,13.65 17.28,8.44 18.15,10.38 16.72,11.04 16.39,12.33 17.27,13.08 17.24,13.75 18.32,14.06 18.53,15",
			"11.38,30.63 11.51,25.82 5.39,26.19 7.63,26.56 8.48,28.18 11.1,28.85 11.36,30.66",
			"8.72,36.51 11.33,36.64 11.37,35.01 11,35.15 11.13,36.16 8.69,36.34",
			"48.93,24.67 48.52,25.96 48.8,27.29 49.98,25.81 49.26,25.53 49.06,24.81",
			"50.32,23.9 49.76,24.56 49.76,27.41 50.55,28.12 51.18,27.84 51.43,26.17 51.3,24.51 50.77,23.95",
			"24.49,18.81 20.38,21.3 22.83,24.83 22.61,23.81 24.41,21.51 22.89,19.97 24.51,18.83",
			"29.88,16.95 29.39,15.68 28.75,15.54 28,16.38 28.98,16.02 29.81,17.04",
			"9.72,20.16 10.27,19.51 10.28,16.65 9.49,15.95 8.85,16.23 8.61,17.9 8.73,19.56 9.27,20.12",
			"11.1,19.4 11.52,18.11 11.23,16.78 10.06,18.25 10.77,18.53 10.98,19.25"
		],
		markers: [
			{
				kind: "expansion",
				x: 46.28,
				y: 32.04
			},
			{
				kind: "home",
				x: 49.65,
				y: 12.95,
				owner: "defender"
			},
			{
				kind: "centre",
				x: 33.46,
				y: 22.8
			},
			{
				kind: "expansion",
				x: 13.83,
				y: 11.99
			},
			{
				kind: "home",
				x: 10.35,
				y: 31.07,
				owner: "attacker"
			},
			{
				kind: "centre",
				x: 26.54,
				y: 21.24
			}
		]
	},
	{
		id: "pf-pa-a",
		letter: "A",
		a: "Purge the Foe",
		b: "Priority Assets",
		label: "Priority Assets vs Purge the Foe",
		edge: "Long edge",
		zones: [{
			side: "attacker",
			points: "0.14,43.96 0.14,32 59.88,32 59.88,43.96"
		}, {
			side: "defender",
			points: "0.14,12.01 0.14,0.04 59.88,0.04 59.88,12.01"
		}],
		terrain: [
			"56.01,23.91 52.64,23.91 51.38,23.45 48.1,23.91 47.49,23.32 44.43,23.91 44.43,30.95 56.01,30.95",
			"22.64,39.52 19.26,39.52 17.88,39.95 14.75,39.52 14.07,40.11 11.06,39.52 11.06,32.49 22.64,32.49",
			"12.96,23.43 11.6,24.95 14.58,27.63 14.56,28 16.08,28.99 17.45,27.48 14.86,25.15 14.6,24.25",
			"10.11,23.84 8.45,25.13 7.74,26.48 5.98,28.43 7.12,30.23 8.18,30.42 8.93,31.09 13.07,26.5",
			"44.03,35.4 44.03,37.99 49.53,37.99 51.18,37.99 54.04,37.99 54.04,35.4 46.62,35.4 45.99,34.84",
			"33.24,34.37 34.25,36.22 35.42,37.06 37.03,39.06 38.94,38.22 39.34,37.19 40.12,36.56 36.32,31.87",
			"34.21,17.58 32.63,19.43 32.21,21.92 30.53,26.08 30.4,27.65 28.81,29.48 30.07,31.09 39.19,23.96",
			"28.31,35.18 27.3,36.63 28.55,38.18 31.67,35.65 32.08,35.69 33.25,34.37 31.99,32.83 29.29,35.02",
			"4.13,20.07 7.5,20.07 8.75,20.53 12.01,20.07 12.64,20.66 15.71,20.07 15.71,13.04 4.13,13.04",
			"37.39,4.46 40.76,4.46 42.02,4 45.34,4.44 45.69,3.97 48.97,4.46 48.97,11.49 37.39,11.49",
			"16,8.59 16,6 10.49,6 8.84,6 5.99,6 5.99,8.59 13.4,8.59 14.04,9.15",
			"25.96,26.38 27.52,24.57 27.96,22.05 29.63,17.92 29.76,16.35 31.36,14.49 30.1,12.88 20.98,20.01",
			"26.3,9.68 25.29,7.83 24.12,6.99 22.5,4.99 20.49,5.94 20.2,6.86 19.41,7.49 23.21,12.18",
			"32.24,7.42 30.99,5.88 27.87,8.4 27.42,8.4 26.29,9.68 27.54,11.22 30.25,9.03 31.17,8.91",
			"45.27,19.79 46.85,20.59 48.24,19.1 45.31,16.36 45.25,15.91 43.82,14.98 42.44,16.47 44.98,18.84",
			"49.7,20.23 51.43,18.93 52.13,17.63 53.92,15.71 52.77,13.87 51.75,13.69 51.01,13 46.8,17.52"
		],
		ruins: [
			"55.46,29 55.59,24.18 49.47,24.55 51.71,24.92 52.56,26.62 53.23,26.44 53.44,26.89 53.58,26.53 55.18,27.21 55.44,29.03",
			"44.82,24.27 44.76,30.54 47.74,30.57 47.81,30.1 47.08,29.99 46.35,26.86 45.39,26.73 45.14,24.24",
			"14.24,32.93 11.63,32.8 11.51,34.24 11.97,34.29 11.84,33.28 14.28,33.1",
			"22.11,35.65 22.19,33.04 15.88,33.1 17.97,33.45 17.72,35.01 18.6,35.99 19.71,35.7 20.26,36.1 21.12,35.36 22.02,35.72",
			"16.13,28.04 16.1,27.2 14.65,26.52 14.9,25.74 14.26,26.16 13.43,25.35 13.85,24.8 12.64,24.8 12.71,25.87 13.29,25.64 14.1,26.38 13.9,26.94 14.46,26.7 15.28,27.43 15.11,28.04 16.03,28.02",
			"11.14,25.91 10.29,26.03 8.37,28.14 8.49,29.2 9.15,29.42 10.45,28.34 11.47,27.02 11.44,26.25",
			"9.14,25.63 7.74,27.49 9.28,27.25 10.39,28.38 10.64,27.93 9.49,27.09 9.3,25.64",
			"54.11,36.45 54.05,37.5 53.91,36.83 52.52,36.79 50.6,36.79 50.36,37.46 50.48,36.27 53.94,36.32",
			"47.83,36.45 47.77,37.5 47.63,36.83 46.24,36.79 44.32,36.79 44.08,37.46 44.2,36.27 47.66,36.32",
			"47.97,35.44 48.28,36.08 49.69,36.08 50.05,35.48 50.09,36.55 50.65,36.71 50.09,36.88 50.39,37.13 49.99,38 49.69,37.34 48.27,37.34 47.92,37.93 47.85,36.88 47.28,36.7 47.8,36.56 47.9,35.54",
			"36.08,37.29 37.23,38.63 39.31,36.99 38.49,36.85 37.21,38.09 36.09,37.24",
			"37.1,33.73 36.21,32.41 34.06,34.42 34.74,34.39 36.22,32.92 37.03,33.89",
			"29.28,29.2 30.04,30.47 30.54,30.51 31.27,29.56 30.26,30.06 29.35,29.11",
			"34.66,26.76 38.55,23.92 35.8,20.61 36.11,21.6 34.51,24.06 36.16,25.44 34.64,26.73",
			"33.33,32.34 31.72,33.07 31.77,33.56 30.85,34.31 30.38,34.15 30.35,34.72 29.38,35.49 28.99,35.31 28.01,36.61 27.39,36.61 27.24,37.46 28.03,37.45 27.67,38.12 28.56,38.07 28.7,37.44 29.66,36.68 29.99,36.91 31.07,35.53 31.66,35.56 31.53,35.15 32.45,34.4 33.08,34.4 33.31,33.51 32.46,33.39 33.44,32.56",
			"4.64,14.79 4.51,19.61 10.63,19.24 8.39,18.87 7.54,17.25 5.05,16.67 4.66,14.76",
			"15.36,19.63 15.42,13.36 12.36,13.36 12.36,13.79 13.1,13.9 13.82,17.04 14.79,17.17 15.04,19.66",
			"45.67,10.89 48.28,11.02 48.4,9.58 47.94,9.53 48.07,10.54 45.63,10.72",
			"37.89,8.33 37.82,10.94 44.13,10.88 42.04,10.53 42.29,8.97 41.4,7.99 40.29,8.28 39.75,7.88 38.88,8.62 37.99,8.27",
			"5.89,7.53 5.96,6.48 6.1,7.15 7.49,7.19 9.4,7.19 9.65,6.52 9.52,7.71 6.06,7.67",
			"12.18,7.53 12.24,6.48 12.38,7.15 13.77,7.19 15.68,7.19 15.93,6.52 15.81,7.71 12.35,7.67",
			"12.04,8.55 11.72,7.9 10.31,7.9 10.02,8.55 9.91,7.43 9.36,7.27 9.84,7.13 10.01,5.98 10.31,6.64 11.73,6.64 12.09,6.05 12.15,7.1 12.72,7.28 12.13,7.44 12.1,8.44",
			"30.83,14.78 30.23,13.56 29.58,13.47 28.91,14.38 29.85,13.92 30.77,14.87",
			"25.38,17.21 21.5,20.05 24.24,23.36 23.93,22.36 25.53,19.91 23.88,18.53 25.4,17.23",
			"23.43,6.76 22.29,5.42 20.21,7.06 21.03,7.2 22.3,5.96 23.43,6.81",
			"22.41,10.32 23.3,11.64 25.46,9.63 24.78,9.66 23.29,11.13 22.49,10.16",
			"26.19,11.71 27.8,10.98 27.74,10.49 28.67,9.74 29.14,9.9 29.16,9.33 30.52,8.74 31.5,7.44 32.12,7.44 32.28,6.59 31.44,6.56 31.85,5.93 30.95,5.98 30.81,6.61 29.27,7.35 29.41,7.75 27.86,8.49 27.99,8.9 27.06,9.65 26.43,9.65 26.21,10.54 27.13,10.54 26.07,11.49",
			"43.74,15.93 43.84,16.86 44.4,16.74 45.19,17.48 44.79,18.12 45.58,17.84 46.39,18.66 45.96,19.21 47.17,19.22 47.13,18.15 46.54,18.38 45.74,17.62 45.96,17.06 45.08,17.02 44.58,16.55 44.76,15.94 43.84,15.95",
			"48.69,18.14 49.54,18.04 51.5,15.96 51.4,14.9 50.74,14.67 49.43,15.73 48.38,17.03 48.4,17.8",
			"50.68,18.46 52.12,16.62 50.57,16.83 49.48,15.68 49.22,16.13 50.36,16.99 50.52,18.44"
		],
		markers: [
			{
				kind: "expansion",
				x: 50.06,
				y: 25.54
			},
			{
				kind: "home",
				x: 16.67,
				y: 37.89,
				owner: "attacker"
			},
			{
				kind: "centre",
				x: 32.26,
				y: 24.65
			},
			{
				kind: "expansion",
				x: 10.07,
				y: 18.44
			},
			{
				kind: "home",
				x: 43.32,
				y: 6.1,
				owner: "defender"
			},
			{
				kind: "centre",
				x: 27.91,
				y: 19.33
			}
		]
	},
	{
		id: "pf-pa-b",
		letter: "B",
		a: "Purge the Foe",
		b: "Priority Assets",
		label: "Priority Assets vs Purge the Foe",
		edge: "Long edge",
		zones: [{
			side: "attacker",
			points: "30.02,30.98 28.19,30.79 26.51,30.27 24.98,29.44 23.65,28.35 22.56,27.02 21.73,25.5 21.21,23.81 21.03,21.98 0.14,21.98 0.14,43.96 30.02,43.96"
		}, {
			side: "defender",
			points: "59.86,0.04 30,0.04 30,13.02 31.81,13.2 33.49,13.73 35.02,14.56 36.35,15.65 37.44,16.98 38.27,18.51 38.79,20.19 38.97,22 59.86,22"
		}],
		terrain: [
			"21.06,15.61 21.06,12.24 21.52,11.02 21.06,7.72 21.65,7.09 21.06,4.03 14.03,4.03 14.03,15.61",
			"15.59,31.96 12.22,31.96 11,31.5 7.71,31.96 7.08,31.38 4.01,31.96 4.01,39 15.59,39",
			"18.96,22.95 16.98,22.95 16.98,26.97 16.69,27.29 16.98,28.99 18.96,28.99 18.96,25.51 19.46,24.66",
			"7,20.39 7,22.99 12.5,22.99 14.15,22.99 17.01,22.99 17.01,20.39 9.59,20.39 8.91,19.83",
			"9.99,16.01 10.37,13.96 9.99,12.54 9.99,9.97 7.94,9.42 7.05,9.96 6.02,9.97 6.02,16.01",
			"24.78,25.93 26.65,24.39 29.12,24.02 33.31,22.41 34.89,22.3 36.76,20.74 38.34,22.03 31.06,31.02",
			"39,28.39 39,31.76 38.54,32.98 39,36.28 38.41,36.91 39,39.97 46.03,39.97 46.03,28.39",
			"44.43,12.03 47.8,12.03 49.02,12.49 52.31,12.03 52.94,12.62 56,12.03 56,5 44.43,5",
			"41.11,21.14 43.09,21.14 43.09,17.13 43.38,16.81 43.09,15.1 41.11,15.1 41.11,18.58 40.62,19.44",
			"53.1,23.71 53.1,21.12 47.59,21.12 45.95,21.12 43.09,21.12 43.09,23.71 50.5,23.71 51.19,24.27",
			"49.98,28.08 49.61,30.13 49.98,31.55 49.98,34.12 52.03,34.67 52.95,34.12 53.95,34.12 53.95,28.08",
			"35.27,18.03 33.4,19.58 30.93,19.95 26.74,21.55 25.16,21.66 23.29,23.22 21.7,21.94 28.99,12.94",
			"31.94,11.99 31.94,10 35.96,10 36.28,9.72 37.98,10 37.98,11.99 34.5,11.99 33.65,12.48",
			"27.99,4.03 27.61,6.08 27.99,7.5 27.99,10.07 30.04,10.62 30.95,10.07 31.96,10.07 31.96,4.03",
			"28.09,31.92 28.09,33.91 24.08,33.91 23.76,34.2 22.05,33.91 22.05,31.92 25.53,31.92 26.39,31.43",
			"32.05,39.88 32.42,37.84 32.05,36.42 32.05,33.85 29.99,33.29 29.11,33.84 28.07,33.85 28.07,39.88"
		],
		ruins: [
			"20.62,4.4 14.43,4.3 14.34,7.4 14.78,7.4 14.9,6.67 18.04,5.95 18.18,4.94 20.65,4.71",
			"16.01,15.02 20.78,15.2 20.57,9.14 20.17,9.22 20.08,11.28 18.39,12.11 18.56,12.8 18.09,13.13 18.49,13.22 17.8,14.73 15.98,15",
			"7.28,32.52 4.67,32.39 4.55,33.84 5.01,33.88 4.88,32.87 7.32,32.69",
			"15.1,35.04 15.17,32.42 8.86,32.48 10.95,32.84 10.7,34.39 11.59,35.38 13.13,35.11 13.24,35.48 14.11,34.75 15,35.1",
			"17.88,28.38 18.5,27.77 18.03,27.35 18.02,26.26 18.77,25.93 18.02,25.72 18.02,24.65 18.77,24.22 18.06,24.22 17.95,23.61 17.2,24.38 17.76,24.65 17.75,25.76 17.2,25.98 17.75,26.24 17.76,27.34 17.2,27.61 17.83,28.29",
			"6.94,21.41 7,22.46 7.14,21.79 8.53,21.74 10.45,21.74 10.69,22.41 10.57,21.23 7.11,21.27",
			"13.09,20.39 12.77,21.04 11.36,21.04 11.01,20.44 10.96,21.51 10.41,21.67 10.96,21.84 10.66,22.08 11.06,22.96 11.36,22.3 12.78,22.3 13.13,22.89 13.2,21.84 13.77,21.66 13.18,21.5 13.15,20.5",
			"13.22,21.41 13.28,22.46 13.42,21.79 14.81,21.74 16.73,21.74 16.98,22.41 16.85,21.23 13.39,21.27",
			"7.54,15.19 8.1,14.53 8.1,11.68 7.31,10.97 6.68,11.25 6.43,12.92 6.56,14.58 7.09,15.14",
			"8.93,14.42 9.34,13.13 9.01,11.74 7.88,12.87 8.8,14.28",
			"27.36,27.28 31,30.43 33.6,27.01 32.7,27.53 29.95,26.53 28.96,28.45 27.37,27.26",
			"36.64,23.36 37.7,22.34 37.63,21.84 36.54,21.34 37.26,22.21 36.54,23.32",
			"44.11,28.96 39.33,28.78 39.54,34.85 39.95,34.76 40.04,32.71 41.73,31.88 41.56,31.19 42.03,30.86 41.63,30.77 42.31,29.26 44.14,28.99",
			"39.37,39.54 45.56,39.64 45.64,36.54 45.2,36.54 45.09,37.28 41.95,38 41.81,39 39.34,39.24",
			"44.81,8.96 44.73,11.58 51.04,11.51 48.96,11.16 49.2,9.61 48.32,8.62 47.21,8.91 46.67,8.51 45.8,9.25 44.9,8.9",
			"52.59,11.31 55.2,11.44 55.23,9.8 54.86,9.94 54.99,10.96 52.55,11.13",
			"42.22,15.72 41.6,16.34 42.07,16.75 42.08,17.84 41.34,18.18 42.08,18.38 42.08,19.45 41.34,19.88 42.04,19.88 42.22,20.49 42.9,19.72 42.34,19.46 42.35,18.35 42.9,18.12 42.35,17.87 42.34,16.77 42.9,16.49 42.27,15.82",
			"46.87,22.7 46.81,21.65 46.67,22.32 45.28,22.36 43.37,22.36 43.12,21.69 43.24,22.88 46.7,22.84",
			"47.01,23.71 47.32,23.07 48.73,23.07 49.03,23.72 49.13,22.6 49.69,22.44 49.13,22.27 49.44,22.03 49.03,21.15 48.73,21.81 47.32,21.81 46.96,21.22 46.89,22.27 46.32,22.45 46.92,22.61 46.95,23.61",
			"53.15,22.7 53.09,21.65 52.95,22.32 51.56,22.36 49.65,22.36 49.4,21.69 49.52,22.88 52.98,22.84",
			"51.05,29.66 50.63,30.95 50.97,32.34 52.09,30.81 51.37,30.53 51.17,29.81",
			"52.43,28.9 51.87,29.55 51.87,32.41 52.66,33.11 53.3,32.83 53.54,31.16 53.42,29.5 52.88,28.94",
			"23.41,20.71 22.35,21.57 22.42,22.23 23.45,22.68 22.8,21.86 23.51,20.76",
			"32.7,16.79 29.06,13.64 26.45,17.07 27.35,16.54 30.1,17.55 31.18,15.69 32.68,16.82",
			"31.25,11.4 31.97,11.92 32.43,11.52 33.67,11.52 33.82,11.92 34.25,11.52 35.49,11.52 35.65,11.92 37.32,11.52 37.78,11.92 38.49,11.52 38.09,11.22 38.37,10.94 37.81,10.85 39.27,10.51 37.87,10.45 37.75,10.05 37.07,10.48 36.05,10.45 35.92,10.05 35.46,10.48 34.28,10.48 34.1,10.05 32.46,10.48 32,10.05 31.35,10.6 31.9,10.82 31.38,11.06 31.97,11.15 31.47,11.25",
			"28.56,8.18 28.43,9.76 31.36,9.56 31.02,9.17 28.74,9.37 28.81,8.1",
			"31.62,6.08 31.58,4.33 28.87,4.3 29.48,4.91 31.24,4.75 31.58,6.12",
			"28.67,32.51 27.96,31.99 27.5,32.39 26.26,32.39 26.1,31.99 25.67,32.39 24.43,32.39 24.28,31.99 22.61,32.39 22.14,31.99 21.43,32.39 21.83,32.7 21.55,32.97 22.11,33.06 20.66,33.4 22.05,33.46 22.17,33.86 22.85,33.43 23.88,33.46 24,33.86 24.46,33.43 25.64,33.43 25.82,33.86 27.46,33.43 27.93,33.86 28.58,33.31 28.02,33.1 28.55,32.85 27.96,32.76 28.45,32.67",
			"28.41,37.83 28.45,39.59 31.16,39.61 30.56,39 28.79,39.17 28.45,37.79",
			"31.47,35.73 31.61,34.15 28.68,34.35 29.02,34.74 31.3,34.55 31.31,35.81"
		],
		markers: [
			{
				kind: "expansion",
				x: 19.43,
				y: 9.67
			},
			{
				kind: "home",
				x: 9.65,
				y: 33.59,
				owner: "attacker"
			},
			{
				kind: "centre",
				x: 31.86,
				y: 24.11
			},
			{
				kind: "expansion",
				x: 40.63,
				y: 34.33
			},
			{
				kind: "home",
				x: 50.37,
				y: 10.4,
				owner: "defender"
			},
			{
				kind: "centre",
				x: 28.18,
				y: 19.86
			}
		]
	},
	{
		id: "pf-pa-c",
		letter: "C",
		a: "Purge the Foe",
		b: "Priority Assets",
		label: "Priority Assets vs Purge the Foe",
		edge: "Short edge",
		zones: [{
			side: "attacker",
			points: "0.14,43.96 0.14,0.04 18.02,0.04 18.02,43.96"
		}, {
			side: "defender",
			points: "42,43.96 42,0.04 59.88,0.04 59.88,43.96"
		}],
		terrain: [
			"26.06,13.66 26.06,10.29 26.52,9.03 26.06,5.77 26.55,5.36 26.06,2.08 19.03,2.08 19.03,13.66",
			"8.86,15.39 8.86,18.76 8.4,20.02 8.84,23.34 8.27,23.91 8.86,26.97 15.89,26.97 15.89,15.39",
			"13.72,4.02 11.13,4.02 11.13,9.53 11.13,11.18 11.13,14.04 13.72,14.04 13.72,6.62 14.28,5.89",
			"21.74,24.13 24.01,23.28 26.45,23.73 30.98,23.58 32.5,23.99 34.76,23.12 35.84,24.85 26.03,30.99",
			"15.42,33.59 15.03,34.94 13.05,34.94 13.05,30.92 12.76,30.58 13.05,28.89 15.03,28.89 15.03,32.38",
			"13.11,34.88 13.49,36.9 13.11,38.35 13.11,40.92 11.06,41.47 10.15,40.92 9.14,40.92 9.14,34.88",
			"34.04,30.43 34.04,33.81 33.58,35.06 34,38.42 33.45,38.95 34.04,42.01 41.07,42.01 41.07,30.43",
			"51.03,28.89 51.03,25.52 51.49,24.26 51.05,20.94 51.62,20.37 51.03,17.31 44,17.31 44,28.89",
			"44.5,10.58 44.92,9.16 46.91,9.16 46.91,13.18 47.19,13.52 46.91,15.2 44.92,15.2 44.92,11.72",
			"46.29,39.95 48.88,39.95 48.88,34.44 48.88,32.79 48.88,29.93 46.29,29.93 46.29,37.35 45.8,37.77",
			"35.09,12.12 37.16,12.5 38.55,12.12 41.12,12.12 41.67,10.11 41.12,9.16 41.12,8.15 35.09,8.15",
			"32.56,8.34 33.05,10.04 35.04,10.04 35.04,6.03 35.32,5.68 35.04,4 33.05,4 33.05,7.48",
			"46.86,9.2 46.48,7.12 46.86,5.73 46.86,3.16 48.91,2.61 49.82,3.16 50.83,3.16 50.83,9.2",
			"38.24,19.78 35.97,20.63 33.49,20.17 28.95,20.31 27.48,19.92 25.22,20.78 24.14,19.05 33.95,12.92",
			"24.94,31.94 22.92,31.56 21.47,31.94 18.9,31.94 18.35,34.04 18.9,34.9 18.9,35.91 24.94,35.91",
			"26.98,34.02 24.99,34.02 24.99,38.03 24.71,38.38 24.99,40.06 26.98,40.06 26.98,36.58 27.46,35.78"
		],
		ruins: [
			"20.92,12.98 25.7,13.16 25.49,7.1 25.08,7.18 24.99,9.24 23.31,10.07 23.47,10.76 23,11.09 23.4,11.18 22.72,12.69 20.89,12.96",
			"25.66,2.44 19.47,2.34 19.38,5.44 19.82,5.44 19.94,4.71 23.07,3.99 23.22,2.98 25.69,2.75",
			"15.46,18.52 15.6,15.91 14.13,15.8 14.12,16.25 15.12,16.12 15.29,18.56",
			"12.91,26.49 15.53,26.57 15.47,20.25 15.11,22.34 13.55,22.09 12.51,23.07 12.87,24.09 12.47,24.63 13.19,25.48 12.84,26.38",
			"12.68,3.99 11.62,4.06 12.34,4.26 12.34,7.5 11.66,7.76 12.87,7.63 12.71,4.04",
			"12.68,10.28 11.62,10.34 12.34,10.55 12.34,13.78 11.62,13.98 12.87,13.92 12.71,10.32",
			"13.7,10.14 13.06,9.6 13.06,8.41 13.65,8.06 12.59,8.01 12.42,7.45 12.26,8.01 11.13,8.11 11.8,8.42 11.8,9.83 11.2,10.18 12.26,10.26 12.43,10.83 12.6,10.23 13.58,10.2",
			"33.76,25.55 35.15,24.7 34.32,23.61 34.71,24.67 33.68,25.48",
			"23.72,26.13 26.14,30.29 29.72,27.9 28.69,28.11 26.42,26.26 24.86,27.76 23.75,26.12",
			"13.45,27.52 13.42,28.84 13,29.12 13.42,29.51 13,31.06 13.43,31.34 13.03,32.99 13.43,33.17 13.43,34.33 13.03,34.79 13.59,35.48 14.09,34.86 14.38,35.56 14.9,34.83 14.51,34.35 14.52,33.1 14.9,33 14.51,31.27 14.9,30.84 14.5,30.68 14.9,29.01 14.38,28.28 13.83,28.98 13.68,27.55",
			"9.47,39.05 9.51,40.8 12.22,40.82 11.61,40.22 9.85,40.38 9.51,39.01",
			"12.63,36.91 12.76,35.33 9.84,35.53 10.18,35.92 12.45,35.73 12.46,36.99",
			"39.04,30.95 34.18,30.88 34.48,36.84 34.88,36.75 34.97,34.7 36.66,33.86 36.49,33.17 36.96,32.85 36.56,32.75 37.24,31.24 39.07,30.97",
			"34.33,41.51 40.52,41.61 40.61,38.51 40.17,38.51 40.05,39.24 36.92,39.96 36.78,40.97 34.3,41.2",
			"44.67,25.65 44.53,28.26 46.17,28.29 46,27.92 45.01,28.05 44.83,25.62",
			"47.07,17.77 44.44,17.7 44.51,24.02 44.87,21.92 46.42,22.17 47.42,21.29 47.11,20.17 47.5,19.63 46.78,18.78 47.13,17.88",
			"46.48,16.58 46.51,15.25 46.93,14.98 46.51,14.59 46.93,13.04 46.51,12.75 46.9,11.11 46.51,10.93 46.51,9.76 46.91,9.31 46.35,8.62 45.84,9.24 45.6,8.54 45.03,9.26 45.43,9.74 45.41,11 45.03,11.09 45.42,11.52 45.03,13.25 45.43,13.41 45.43,14.59 45.03,15.09 45.55,15.82 46.21,15.24 46.25,16.54",
			"47.3,39.98 48.36,39.91 47.64,39.7 47.64,36.47 48.36,36.27 47.12,36.34 47.28,39.93",
			"47.3,33.69 48.36,33.62 47.64,33.42 47.64,30.19 48.36,29.99 47.12,30.05 47.28,33.65",
			"46.28,33.83 46.93,34.14 46.93,35.56 46.33,35.91 47.39,35.95 47.56,36.51 47.73,35.95 47.95,36.26 48.85,35.85 48.19,35.55 48.19,34.14 48.78,33.78 47.73,33.71 47.55,33.14 47.39,33.74 46.4,33.76",
			"40.25,9.74 39.59,10.3 36.71,10.3 36.03,9.51 36.54,8.79 38.04,8.64 39.66,8.76 40.2,9.29",
			"39.49,11.12 38.2,11.54 36.81,11.2 37.93,10.08 39.43,11.04",
			"34.16,4.59 33.54,5.21 34.01,5.62 34.02,6.71 33.28,7.05 34.02,7.25 34.02,8.32 33.28,8.75 33.98,8.75 34.09,9.36 34.85,8.59 34.28,8.33 34.29,7.21 34.85,6.99 34.29,6.74 34.28,5.64 34.85,5.36 34.29,4.72",
			"50.47,5.03 50.43,3.28 47.73,3.26 48.33,3.87 50.1,3.7 50.43,5.07",
			"47.31,7.17 47.18,8.76 50.11,8.55 49.77,8.16 47.49,8.36 47.48,7.09",
			"26.2,18.35 24.81,19.2 25.64,20.29 25.25,19.24 26.28,18.43",
			"36.24,17.66 33.82,13.5 30.24,15.89 31.27,15.69 33.53,17.53 35.1,16.04 36.21,17.68",
			"19.76,34.32 20.42,33.76 23.29,33.76 23.97,34.55 23.46,35.27 21.97,35.42 20.34,35.3 19.8,34.76",
			"20.51,32.94 21.8,32.52 23.19,32.85 22.08,33.98 20.58,33.02",
			"25.84,39.46 26.46,38.85 25.99,38.44 25.99,37.34 26.73,37.01 25.99,36.81 25.99,35.74 26.73,35.31 26.02,35.31 25.91,34.7 25.16,35.47 25.72,35.73 25.72,36.84 25.16,37.07 25.72,37.32 25.72,38.42 25.16,38.7 25.72,39.34"
		],
		markers: [
			{
				kind: "expansion",
				x: 24.42,
				y: 7.74
			},
			{
				kind: "home",
				x: 10.48,
				y: 21.34,
				owner: "attacker"
			},
			{
				kind: "centre",
				x: 29.04,
				y: 24.71
			},
			{
				kind: "expansion",
				x: 35.66,
				y: 36.39
			},
			{
				kind: "home",
				x: 49.41,
				y: 22.94,
				owner: "defender"
			},
			{
				kind: "centre",
				x: 30.93,
				y: 19.2
			}
		]
	},
	{
		id: "di-di-a",
		letter: "A",
		a: "Disruption",
		b: "Disruption",
		label: "Disruption (mirror)",
		edge: "Short edge",
		zones: [{
			side: "attacker",
			points: "30.03,43.96 0.13,0.04 0.14,0.04 0.14,43.96"
		}, {
			side: "defender",
			points: "59.88,43.96 59.88,0.04 29.99,0.04 59.86,43.96"
		}],
		terrain: [
			"15.87,35.01 13.93,32.25 13.66,31.08 11.34,28.55 11.43,27.66 9.22,25.53 3.46,29.56 10.1,39.04",
			"6.91,8.02 8.84,10.78 9.23,12.12 11.43,14.48 11.34,15.37 13.55,17.51 19.31,13.47 12.67,3.99",
			"22.56,9.34 23.05,11.04 25.04,11.04 25.04,7.03 25.32,6.68 25.04,5 23.05,5 23.05,8.48",
			"25.06,13.03 27.08,13.41 28.53,13.03 31.1,13.03 31.65,10.93 31.1,10.07 31.1,9.06 25.06,9.06",
			"37.44,14.04 40.03,14.04 40.03,8.53 40.03,6.88 40.03,4.02 37.44,4.02 37.44,11.44 36.9,11.97",
			"39.08,16.58 37.38,16.08 37.38,14.1 41.4,14.1 41.74,13.81 43.42,14.1 43.42,16.08 39.94,16.08",
			"26.9,27.85 28.61,26.18 28.94,24.56 31.29,19.75 31.58,18.16 33.32,16.47 32.2,14.76 22.5,21.07",
			"33.29,16.44 31.37,18.68 30.94,20.54 28.9,24.54 28.61,26.13 26.88,27.81 27.99,29.52 37.69,23.22",
			"53.13,35.95 51.2,33.19 50.86,31.9 48.61,29.49 48.7,28.6 46.49,26.46 40.73,30.5 47.37,39.98",
			"44.1,9.04 46.03,11.81 46.42,13.14 48.62,15.51 48.5,16.36 50.74,18.53 56.5,14.5 49.86,5.01",
			"37.44,34.73 36.95,33.02 34.96,33.02 34.96,37.04 34.68,37.38 34.96,39.06 36.95,39.06 36.95,35.58",
			"34.94,31.14 32.86,30.76 31.47,31.14 28.9,31.14 28.35,33.19 28.9,34.11 28.9,35.12 34.94,35.12",
			"50.47,26.29 50.7,24.25 50.23,22.83 50.05,20.27 47.96,19.86 47.09,20.47 46.08,20.55 46.51,26.57",
			"9.55,17.81 9.39,19.86 9.91,21.26 10.18,23.82 12.23,24.15 13.13,23.51 14.13,23.4 13.5,17.4",
			"22.78,29.99 20.18,29.99 20.18,35.5 20.18,37.15 20.18,40.01 22.78,40.01 22.78,32.59 23.34,31.95",
			"21.21,27.46 22.83,27.94 22.83,29.93 18.82,29.93 18.65,30.18 16.79,29.93 16.79,27.94 20.27,27.94"
		],
		ruins: [
			"11.2,37.38 15.35,35 11.96,29.97 11.66,30.2 12.67,32.05 11.75,33.62 12.57,36.18 11.17,37.38",
			"10.71,28.4 9.32,26.18 8.16,26.78 8,27.31 9.02,26.63 9.4,26.89 10.59,28.53",
			"16.66,14.86 18.82,13.24 15.2,8.25 16.1,10.17 14.69,10.86 14.4,12.25 15.27,12.89 15.26,13.56 16.34,13.84 16.57,14.78",
			"12.52,4.41 7.36,7.91 9.07,10.5 9.46,10.22 9.13,9.55 11.26,7.18 10.79,6.32 12.72,4.69",
			"23.45,3.72 23.42,5.05 23.01,5.33 23.42,5.72 23.01,7.26 23.43,7.55 23.41,8.78 23.04,8.87 23.43,10.54 23.03,11 23.59,11.68 24.09,11.06 24.38,11.76 24.9,11.04 24.51,10.56 24.52,9.31 24.9,9.21 24.52,7.48 24.9,7.05 24.5,6.89 24.9,5.22 24.39,4.48 23.73,5.07 23.69,3.76",
			"27.1,9.39 25.34,9.43 25.32,12.14 25.93,11.53 25.77,9.76 27.14,9.42",
			"29.33,12.48 30.92,12.62 30.71,9.68 30.31,10.23 30.52,12.31 29.25,12.32",
			"38.43,14.17 39.49,14.11 38.77,13.9 38.77,10.67 39.49,10.47 38.25,10.53 38.41,14.13",
			"38.43,7.89 39.49,7.82 38.77,7.62 38.77,4.39 39.49,4.19 38.25,4.25 38.41,7.85",
			"37.41,8.03 38.06,8.34 38.06,9.76 37.46,10.11 38.53,10.15 38.69,10.71 38.86,10.15 39.08,10.46 39.98,10.05 39.32,9.75 39.32,8.34 39.91,7.98 38.86,7.91 38.69,7.34 38.52,7.94 37.53,7.96",
			"37.92,15.1 38.54,15.72 38.96,15.24 40.05,15.24 40.13,15.98 40.56,15.24 41.72,15.27 42.08,15.98 42.08,15.28 42.68,15.16 41.92,14.42 41.66,14.97 40.55,14.97 40.33,14.42 40.07,14.97 38.94,14.97 38.68,14.42 38.05,14.97",
			"25.5,24.79 28.13,28.82 31.58,26.24 30.56,26.5 28.2,24.78 26.72,26.35 25.52,24.77",
			"24.54,20.31 23.19,21.24 24.08,22.28 23.64,21.25 24.63,20.38",
			"35.41,23.81 36.69,23.34 36.84,22.7 35.97,21.87 36.36,22.92 35.33,23.73",
			"34.61,19.59 31.98,15.56 28.53,18.13 29.54,17.87 31.91,19.6 33.37,18.02 34.58,19.61",
			"43.46,29.1 41.29,30.74 44.9,35.73 44,33.81 45.41,33.12 45.7,31.72 44.79,31.07 44.84,30.42 43.76,30.13 43.54,29.2",
			"47.41,39.37 52.58,35.82 50.87,33.27 50.47,33.56 50.79,34.23 48.66,36.61 49.1,37.53 47.21,39.1",
			"49.3,15.51 50.61,17.77 52,16.91 51.68,16.68 50.93,17.34 49.43,15.39",
			"48.54,6.64 44.52,9.23 48.16,14.08 48.45,13.83 47.34,12.04 48.25,10.39 47.23,7.91 48.57,6.64",
			"36.52,40.34 36.55,39.02 36.97,38.74 36.55,38.35 36.97,36.8 36.55,36.51 36.94,34.87 36.55,34.69 36.55,33.53 36.95,33.07 36.39,32.38 35.88,33 35.6,32.3 35.07,33.02 35.47,33.51 35.45,34.76 35.07,34.86 35.46,35.28 35.07,37.02 35.47,37.17 35.47,38.35 35.07,38.85 35.59,39.58 36.25,39 36.29,40.3",
			"32.88,34.68 34.64,34.63 34.66,31.93 34.05,32.53 34.21,34.3 32.84,34.64",
			"30.76,31.58 29.17,31.45 29.37,34.38 29.78,33.84 29.57,31.76 30.84,31.75",
			"48.54,21.24 48.06,21.95 48.35,24.79 49.21,25.41 49.81,25.07 49.88,23.38 49.59,21.74 48.99,21.24",
			"47.24,22.15 46.96,23.44 47.44,24.82 47.83,23.87 48.74,23.56 48.69,23.15 47.67,22.98 47.31,22.18",
			"11.63,22.79 12.09,22.07 11.7,19.24 10.81,18.65 10.22,19.01 10.23,20.84 10.57,22.33 11.18,22.81",
			"12.89,21.84 13.13,20.53 12.6,19.17 12.25,20.14 11.27,20.59 12.44,21.02 12.83,21.81",
			"21.76,29.85 20.7,29.92 21.42,30.13 21.42,33.36 20.7,33.56 21.94,33.49 21.79,29.9",
			"21.76,36.14 20.7,36.2 21.42,36.41 21.42,39.64 20.7,39.84 21.94,39.78 21.79,36.18",
			"22.78,36 22.13,35.69 22.13,34.27 22.73,33.92 21.67,33.88 21.5,33.32 21.34,33.88 21.12,33.57 20.21,33.98 20.88,34.28 20.88,35.69 20.28,36.05 21.34,36.12 21.51,36.69 21.67,36.09 22.66,36.06",
			"22.16,29.04 21.54,28.42 21.13,28.9 20.03,28.9 19.95,28.16 19.52,28.9 18.36,28.87 18.01,28.16 18.01,28.85 17.4,28.98 18.16,29.72 18.42,29.16 19.53,29.16 19.75,29.72 20.01,29.16 21.14,29.16 21.4,29.72 22.04,29.16"
		],
		markers: [
			{
				kind: "home",
				x: 11.13,
				y: 31.09,
				owner: "attacker"
			},
			{
				kind: "expansion",
				x: 11.66,
				y: 11.97
			},
			{
				kind: "centre",
				x: 29.42,
				y: 21.1
			},
			{
				kind: "expansion",
				x: 48.39,
				y: 32.01
			},
			{
				kind: "home",
				x: 48.85,
				y: 12.99,
				owner: "defender"
			}
		]
	},
	{
		id: "di-di-b",
		letter: "B",
		a: "Disruption",
		b: "Disruption",
		label: "Disruption (mirror)",
		edge: "Short edge",
		zones: [{
			side: "attacker",
			points: "0.19,43.96 20.03,43.96 20.03,22.02 12.07,22.02 12.07,0.04 0.19,0.04 0.19,22.02 0.19,23.1"
		}, {
			side: "defender",
			points: "59.88,0.04 40.04,0.04 40.04,21.98 48,21.98 48,43.96 59.88,43.96 59.88,21.98 59.88,20.9"
		}],
		terrain: [
			"5.07,26.38 5.07,29.76 4.61,31.01 5.07,34.27 4.48,34.9 5.07,37.97 12.1,37.97 12.1,26.38",
			"14.04,4.04 14.04,7.41 13.58,8.66 14.04,11.94 13.45,12.55 14.04,15.62 21.07,15.62 21.07,4.04",
			"48.02,24.04 47.64,26.12 48.02,27.51 48.02,30.08 50.12,30.63 50.98,30.08 51.99,30.08 51.99,24.04",
			"29.01,12.95 31.03,13.33 32.48,12.95 35.05,12.95 35.6,10.85 35.05,9.99 35.05,8.98 29.01,8.98",
			"29.45,6.73 28.96,5.02 26.98,5.02 26.98,9.04 26.69,9.38 26.98,11.06 28.96,11.06 28.96,7.58",
			"33.07,27.84 32.59,25.49 30.88,23.59 28.66,19.74 27.49,18.64 27.02,16.26 24.98,16.26 24.98,27.84",
			"27.02,16.25 27.5,18.63 29.2,20.49 31.44,24.38 32.6,25.45 33.06,27.83 35.1,27.83 35.1,16.25",
			"12.05,20.07 12.43,17.99 12.05,16.6 12.05,14.03 10.04,13.49 9.09,14.03 8.08,14.03 8.08,20.07",
			"55,17.63 55,14.26 55.46,13.08 55,9.73 55.59,9.12 55,6.05 47.97,6.05 47.97,17.63",
			"46.06,40.02 46.06,36.65 46.52,35.4 46.06,32.13 46.64,31.54 46.06,28.44 39.03,28.44 39.03,40.02",
			"38.74,16.03 41.09,17.13 43.42,12.14 44.11,10.64 45.32,8.05 42.97,6.96 39.84,13.68 39.06,14.02",
			"43.89,21.45 45.25,21.79 46.25,20.07 42.77,18.06 42.71,17.71 41.02,17.05 40.02,18.77 43.04,20.51",
			"21.44,28 19.09,26.91 16.76,31.9 16.07,33.39 14.86,35.98 17.21,37.08 20.34,30.36 21.12,30.02",
			"16.59,22.62 14.95,22.22 13.95,23.95 17.43,25.95 17.49,26.31 19.18,26.97 20.18,25.25 17.16,23.5",
			"31.07,31.17 29.06,30.8 27.61,31.17 25.04,31.17 24.49,33.18 25.04,34.14 25.04,35.15 31.07,35.15",
			"30.64,37.37 31.12,38.99 33.11,38.99 33.11,34.98 33.4,34.63 33.11,32.95 31.12,32.95 31.12,36.43"
		],
		ruins: [
			"9.02,37.49 11.63,37.63 11.66,35.99 11.29,36.13 11.42,37.14 8.98,37.32",
			"11.51,31.56 11.64,26.74 5.52,27.11 7.76,27.48 8.61,29.18 9.28,29 9.49,29.45 9.63,29.09 11.23,29.77 11.49,31.59",
			"20.52,4.52 14.33,4.42 14.24,7.52 14.68,7.52 14.8,6.78 17.93,6.06 18.07,5.06 20.55,4.83",
			"17.95,15.15 20.57,15.22 20.51,8.91 20.15,11 18.6,10.75 17.6,11.63 17.91,12.75 17.51,13.29 18.23,14.14 17.88,15.04",
			"50.23,24.96 49.68,25.62 49.67,28.48 50.47,29.18 51.1,28.9 51.34,27.09 51.22,25.57 50.69,25.01",
			"48.85,25.73 48.43,27.02 48.72,28.35 49.89,26.88 49.18,26.6 48.98,25.88",
			"30.96,9.3 29.19,9.34 29.17,12.05 29.78,11.45 29.62,9.67 30.99,9.34",
			"33.16,12.28 34.74,12.42 34.54,9.49 34.14,10.03 34.34,12.11 33.08,12.12",
			"27.49,3.66 27.46,4.98 27.04,5.26 27.46,5.65 27.04,7.2 27.46,7.48 27.07,9.13 27.46,9.31 27.46,10.47 27.07,10.93 27.62,11.62 28.13,11 28.37,11.7 28.94,10.97 28.54,10.49 28.56,9.24 28.94,9.14 28.55,8.72 28.94,6.98 28.54,6.83 28.54,5.65 28.94,5.15 28.42,4.42 27.76,5 27.72,3.69",
			"26.88,16.91 25.34,16.8 25.38,18.26 25.62,17.15 26.91,17.01",
			"25.8,22.26 25.65,27.07 29.98,26.94 28.97,26.58 28.02,23.8 25.92,24.25 25.9,22.32",
			"32.94,27.08 34.41,27.25 34.74,26.69 34.38,25.73 34.21,26.84 32.91,26.97",
			"34.48,21.86 34.63,17.05 30.3,17.18 31.31,17.54 32.25,20.32 34.35,19.87 34.38,21.79",
			"9.81,19.14 10.37,18.49 10.38,15.63 9.58,14.92 8.95,15.2 8.7,16.87 8.83,18.54 9.36,19.09",
			"11.2,18.37 11.62,17.09 11.33,15.76 10.15,16.82 11.07,18.23",
			"48.54,12.46 48.4,17.28 54.53,16.91 52.28,16.54 51.43,14.84 50.77,15.02 50.56,14.57 50.42,14.92 48.81,14.24 48.56,12.43",
			"51.07,6.51 48.46,6.37 48.28,7.67 48.62,8.11 48.67,6.85 51.1,6.68",
			"39.55,39.42 45.74,39.51 45.82,36.41 45.38,36.41 45.27,37.15 42.13,37.87 41.99,38.87 39.51,39.11",
			"41.91,28.91 39.25,28.99 39.35,35.15 39.71,33.06 41.26,33.31 42.3,32.33 41.95,31.31 42.35,30.77 41.63,29.92 41.98,29.02",
			"39.68,16.5 40.63,16.89 40.1,16.4 41.47,13.47 42.2,13.59 41.12,13.1 39.67,16.45",
			"42.33,10.8 43.37,11.09 42.76,10.7 44.12,7.77 44.86,7.9 43.7,7.43 42.33,10.76",
			"41.34,10.51 41.81,11.05 41.21,12.34 40.52,12.41 41.46,12.89 41.38,13.47 41.77,13.03 41.85,13.41 42.83,13.42 42.35,12.87 42.95,11.58 43.64,11.51 42.71,11 42.8,10.41 42.4,10.88 41.44,10.47",
			"41.25,18.29 41.56,19.18 42.08,18.94 43.01,19.48 42.77,20.2 43.36,19.74 44.4,20.28 44.4,21.14 44.85,20.54 45.34,20.73 45.05,19.7 44.54,20.06 43.58,19.5 43.67,18.9 43.17,19.26 42.21,18.72 42.25,18.08 41.35,18.3",
			"20.48,27.53 19.53,27.14 20.06,27.64 18.69,30.56 17.95,30.44 19.04,30.93 20.48,27.58",
			"17.83,33.23 16.88,32.84 17.4,33.33 16.94,34.33 16.04,36.26 15.31,36.21 16.38,36.63 17.83,33.28",
			"18.82,33.53 18.35,32.98 18.95,31.7 19.64,31.63 18.7,31.14 18.74,30.49 18.39,31 18.31,30.62 17.33,30.61 17.81,31.16 17.21,32.45 16.52,32.52 17.44,33.03 17.36,33.62 17.71,33.21 18.72,33.56",
			"18.91,25.73 18.61,24.84 18.09,25.08 17.16,24.54 17.24,23.73 16.69,24.28 15.76,23.74 15.77,22.88 15.32,23.48 14.83,23.29 15.12,24.32 15.63,23.97 16.59,24.52 16.5,25.12 17.37,24.97 17.95,25.31 17.92,25.94 18.82,25.73",
			"29.11,34.82 30.87,34.78 30.89,32.08 30.28,32.68 30.44,34.45 29.07,34.79",
			"26.91,31.73 25.32,31.6 25.53,34.53 25.93,33.98 25.72,31.91 26.99,31.89",
			"32.58,40.36 32.61,39.03 33.02,38.75 32.61,38.36 33.02,36.82 32.6,36.53 32.62,35.3 32.99,35.21 32.6,33.54 33,33.08 32.44,32.4 31.94,33.02 31.65,32.32 31.13,33.04 31.52,33.52 31.51,34.77 31.13,34.87 31.51,36.6 31.13,37.03 31.53,37.19 31.13,38.86 31.64,39.6 32.3,39.01 32.34,40.32"
		],
		markers: [
			{
				kind: "home",
				x: 6.7,
				y: 32.33,
				owner: "attacker"
			},
			{
				kind: "expansion",
				x: 15.67,
				y: 9.98
			},
			{
				kind: "centre",
				x: 31.38,
				y: 22.14
			},
			{
				kind: "home",
				x: 53.37,
				y: 11.69,
				owner: "defender"
			},
			{
				kind: "expansion",
				x: 44.43,
				y: 34.08
			}
		]
	},
	{
		id: "di-di-c",
		letter: "C",
		a: "Disruption",
		b: "Disruption",
		label: "Disruption (mirror)",
		edge: "Long edge",
		zones: [{
			side: "attacker",
			points: "30.03,30.01 0.14,30.01 0.14,43.96 14.62,43.96 30.03,43.96 59.88,43.96 59.88,35.99 30.03,35.99"
		}, {
			side: "defender",
			points: "59.88,0.04 33.24,0.04 30.03,0.04 0.13,0.04 0.13,8.02 30.03,8.02 30.03,13.99 59.88,13.99"
		}],
		terrain: [
			"47.98,22.03 47.98,25.4 47.52,26.65 47.98,29.92 47.49,30.33 47.98,33.61 55.01,33.61 55.01,22.03",
			"16.59,31.95 13.22,31.95 11.96,31.49 8.7,31.95 8.07,31.36 5.01,31.95 5.01,38.98 16.59,38.98",
			"30.48,37.77 32.04,39 34.54,35.86 34.97,35.77 35.8,34.28 34.24,33.04 32.07,35.76 31.2,36.08",
			"17.6,29.62 16.55,31.99 21.58,34.23 23.09,34.9 25.7,36.06 26.75,33.69 19.98,30.67 19.54,29.87",
			"52.09,35.99 50.02,35.61 48.62,35.99 46.05,35.99 45.5,38.09 46.05,38.95 46.05,39.96 52.09,39.96",
			"35.76,18.86 33.38,19.35 31.52,21.05 27.67,23.27 26.56,24.45 24.18,24.91 24.18,26.96 35.76,26.96",
			"24.2,24.94 26.58,24.45 27.65,23.31 32.32,20.51 33.4,19.35 35.77,18.89 35.77,16.85 24.2,16.85",
			"38.59,33.43 36.95,32.75 35.71,34.31 38.85,36.81 38.95,37.24 40.44,38.07 41.68,36.51 38.95,34.35",
			"14.17,8.04 12.1,8.42 10.71,8.04 8.14,8.04 7.59,5.99 8.14,5.08 8.14,4.07 14.17,4.07",
			"28.94,7.8 29.57,6.23 28.01,4.99 25.51,8.14 25.08,8.23 24.25,9.72 25.81,10.96 27.98,8.23",
			"21.73,10.69 23.1,11.24 24.34,9.69 21.19,7.19 21.14,6.78 19.61,5.93 18.37,7.48 21.1,9.65",
			"11.98,21.96 11.98,18.56 12.44,17.4 11.98,14.05 12.56,13.4 11.98,10.38 4.94,10.38 4.94,21.96",
			"43.5,12.04 46.87,12.04 48.05,12.5 51.4,12.04 52.02,12.63 55.08,12.04 55.08,5 43.5,5",
			"11.98,25.92 14.05,26.3 15.44,25.92 18.01,25.92 18.56,23.91 18.01,22.96 18.01,21.95 11.98,21.95",
			"42.52,14.31 43.64,11.97 38.67,9.6 37.18,8.89 34.6,7.66 33.49,10 40.18,13.19 40.35,13.81",
			"47.99,18.12 45.98,17.75 44.53,18.12 41.96,18.12 41.41,20.14 41.96,21.09 41.96,22.1 47.99,22.1"
		],
		ruins: [
			"54.38,27.21 54.52,22.39 48.39,22.76 50.64,23.13 51.49,24.75 53.97,25.32 54.36,27.24",
			"48.28,26.99 48.22,33.26 51.28,33.26 51.28,32.82 50.54,32.71 49.82,29.57 48.85,29.45 48.6,26.96",
			"8.09,32.38 5.48,32.25 5.45,33.88 5.82,33.74 5.69,32.73 8.13,32.55",
			"15.98,35.15 16.05,32.53 9.74,32.59 11.83,32.95 11.58,34.5 12.46,35.48 13.58,35.19 14.12,35.59 14.99,34.85 15.88,35.21",
			"30.8,39.77 35.62,34.29 35.64,33.45 34.76,33.58 35.02,32.87 34.16,33.12 34.21,33.79 32.81,34.81 33.06,35.12 31.68,36.24 31.9,36.61 31.21,37.57 30.54,37.67 30.52,38.59 31.41,38.56 30.59,39.55",
			"17.2,30.49 16.83,31.48 17.24,30.92 18.77,31.55 20.25,32.22 20.15,32.96 20.6,31.8 17.27,30.47",
			"22.94,33.04 22.57,34.04 23.12,33.49 25.99,34.77 25.89,35.51 26.33,34.36 23,33.03",
			"23.19,32.1 22.64,32.56 21.39,31.94 21.31,31.26 20.84,32.21 20.19,32.17 20.64,32.46 20.34,33.58 21.1,33.19 22.13,33.71 22.17,34.4 22.75,33.43 23.34,33.5 22.92,33.16 23.24,32.19",
			"50.01,39.51 51.77,39.46 51.79,36.76 51.18,37.36 51.34,39.13 49.97,39.47",
			"47.99,36.57 46.41,36.44 46.61,39.37 47.01,38.83 46.81,36.75 48.07,36.74",
			"24.67,25.03 24.49,26.49 25.06,26.83 26.02,26.47 24.92,26.31 24.78,25",
			"30.53,26.28 35.34,26.43 35.21,22.1 34.84,23.11 33.91,23.12 32.54,24.22 32.13,24.02 32.51,26.18 30.66,26.12",
			"35.26,18.88 35.54,17.54 35.08,17.08 34.13,17.29 35.02,17.6 35.15,18.91",
			"29.41,17.3 24.6,17.15 24.73,21.48 25.1,20.47 27.81,19.56 27.43,17.4 29.27,17.46",
			"40.47,36.97 40.3,36.05 39.74,36.21 38.9,35.54 39.03,34.69 38.49,35.21 37.61,34.45 38,33.87 36.79,33.96 36.92,35.02 37.48,34.74 38.34,35.44 38.17,36.01 38.72,35.74 39.58,36.41 39.45,37.03 40.37,36.96",
			"12.11,7.74 13.87,7.7 13.89,4.99 13.28,5.59 13.44,7.37 12.07,7.7",
			"9.98,4.59 8.4,4.45 8.6,7.39 9.01,6.84 8.8,4.76 10.06,4.75",
			"29.23,4.22 27.82,5.28 27.97,5.75 27.23,6.68 26.74,6.63 26.86,7.13 26.11,8.11 25.64,8.06 24.97,9.55 24.36,9.68 24.39,10.54 25.14,10.39 24.95,11.09 25.82,10.85 26.53,9.3 26.96,9.41 26.92,8.84 28.3,7.73 28.08,7.36 28.82,6.42 29.44,6.29 29.46,5.37 28.61,5.44 29.39,4.42",
			"19.51,6.99 19.68,7.92 20.23,7.76 21.07,8.43 20.73,9.1 21.49,8.76 22.37,9.51 21.98,10.09 23.19,10.01 23.06,8.95 22.49,9.22 21.96,8.8 21.81,7.95 21.26,8.23 20.4,7.55 20.52,6.93 19.6,7.01",
			"5.57,16.75 5.44,21.57 11.56,21.19 9.32,20.82 8.47,19.2 5.85,18.53 5.6,16.72",
			"11.58,16.98 11.64,10.71 8.58,10.71 8.58,11.15 9.32,11.25 10.04,14.39 11.01,14.52 11.25,17.01",
			"51.7,11.38 54.31,11.52 54.43,10.07 53.98,10.02 54.1,11.04 51.67,11.21",
			"44.09,8.84 44.02,11.46 50.33,11.4 48.24,11.04 48.49,9.49 47.61,8.5 46.49,8.8 45.95,8.4 45.08,9.13 44.19,8.78",
			"17.23,24.37 16.57,23.8 13.69,23.8 13.01,24.6 13.28,25.21 15.02,25.47 16.65,25.34 17.19,24.81",
			"16.48,22.99 15.18,22.56 13.79,22.9 14.91,24.03 16.41,23.07",
			"42.92,13.51 43.32,12.53 42.82,13.09 41.38,12.41 39.92,11.7 40.04,10.96 39.56,12.11 42.86,13.53",
			"37.25,10.81 37.65,9.82 36.96,10.3 34.25,9 34.37,8.26 33.89,9.41 37.19,10.82",
			"36.94,11.78 37.47,11.27 38.83,11.85 38.83,12.63 39.33,11.69 39.91,11.79 39.47,11.39 39.85,11.33 39.87,10.34 39.31,10.81 38.04,10.2 37.97,9.51 37.45,10.43 36.86,10.34 37.33,10.75 36.92,11.71",
			"42.72,19.62 43.38,20.18 44.76,20.3 46.78,19.97 46.94,19.39 46.43,18.67 44.83,18.52 44.11,18.9 43.3,18.64 42.76,19.17",
			"43.47,21 44.04,21.42 46.16,21.03 44.62,19.96 44.35,20.73 43.54,20.92"
		],
		markers: [
			{
				kind: "expansion",
				x: 49.62,
				y: 27.95
			},
			{
				kind: "home",
				x: 10.64,
				y: 33.58,
				owner: "attacker"
			},
			{
				kind: "centre",
				x: 29.88,
				y: 23.23
			},
			{
				kind: "expansion",
				x: 10.35,
				y: 16.01
			},
			{
				kind: "home",
				x: 49.44,
				y: 10.41,
				owner: "defender"
			}
		]
	},
	{
		id: "di-re-a",
		letter: "A",
		a: "Disruption",
		b: "Reconnaissance",
		label: "Disruption vs Reconnaissance",
		edge: "Short edge",
		zones: [{
			side: "attacker",
			points: "0.19,43.96 20.02,43.96 20.02,22.02 12.06,22.02 12.06,0.04 0.19,0.04"
		}, {
			side: "defender",
			points: "59.86,0.04 40.03,0.04 40.03,21.98 47.98,21.98 47.98,43.96 59.86,43.96"
		}],
		terrain: [
			"12.94,11.09 16.31,11.09 17.53,11.55 20.83,11.09 21.46,11.67 24.52,11.09 24.52,4.05 12.94,4.05",
			"5.96,29.92 9.33,29.92 10.55,30.38 13.84,29.92 14.47,30.51 17.53,29.92 17.53,22.89 5.96,22.89",
			"10.36,21.1 12.96,21.1 12.96,15.59 12.96,13.94 12.96,11.08 10.36,11.08 10.36,18.5 9.8,19.18",
			"18.08,40.94 18.46,38.87 18.08,37.47 18.08,34.9 16.01,34.35 15.14,34.9 14.11,34.9 14.11,40.94",
			"32,5.26 30.04,4.98 29.48,8.96 29.15,9.24 29.2,10.97 31.16,11.24 31.65,7.8 32.25,7.02",
			"30.91,13.19 32.91,13.85 34.34,13.67 36.88,14.03 37.72,12.05 37.3,11.09 37.44,10.09 31.46,9.25",
			"47.05,32.94 43.68,32.94 42.46,32.48 39.17,32.94 38.54,32.35 35.48,32.94 35.48,39.97 47.05,39.97",
			"53.96,14.11 50.59,14.11 49.37,13.65 46.07,14.11 45.44,13.52 42.38,14.11 42.38,21.14 53.96,21.14",
			"49.59,22.95 47,22.95 47,28.46 47,30.11 47,32.96 49.59,32.96 49.59,25.55 50.04,24.26",
			"42.12,3.14 41.74,5.18 42.12,6.6 42.12,9.17 44.17,9.72 45.08,9.17 46.09,9.17 46.09,3.14",
			"52.09,11.12 52.09,9.14 48.07,9.14 47.75,8.85 46.05,9.14 46.05,11.12 49.53,11.12 50.38,11.62",
			"25.43,26.59 23.76,24.84 23.54,23.28 21.33,18.33 21.11,16.76 19.42,15 20.59,13.33 30.07,19.97",
			"34.66,17.46 36.32,19.22 36.55,20.78 38.76,25.73 38.98,27.3 40.66,29.06 39.49,30.73 30.02,24.09",
			"28.1,38.81 30.07,39.05 30.56,35.07 30.88,34.79 30.8,33.06 28.83,32.82 28.41,36.27 27.82,37.06",
			"29.05,30.87 27.07,30.25 25.61,30.45 23.06,30.13 22.26,32.13 22.7,33.05 22.58,34.08 28.57,34.81",
			"8.11,32.95 8.11,34.94 12.12,34.94 12.44,35.23 14.15,34.94 14.15,32.95 10.67,32.95 9.81,32.46"
		],
		ruins: [
			"19.53,4.44 13.32,4.34 13.23,7.36 13.69,7.44 13.81,6.7 16.95,5.98 17.07,4.98 19.56,4.75",
			"21.39,10.65 24.03,10.72 23.97,4.4 23.61,6.5 22.06,6.25 21.06,7.13 21.37,8.25 20.98,8.79 21.7,9.64 21.34,10.54",
			"6.39,26.83 6.25,29.45 7.89,29.48 7.72,29.11 6.73,29.24 6.55,26.8",
			"16.96,28.06 17.09,23.24 10.97,23.61 13.21,23.98 14.06,25.6 16.68,26.28 16.94,28.09",
			"11.91,17.34 10.85,17.4 11.57,17.61 11.57,20.84 10.85,21.04 12.09,20.98 11.93,17.38",
			"11.91,11.05 10.85,11.12 11.57,11.32 11.57,14.56 10.89,14.82 12.09,14.69 11.93,11.1",
			"12.93,17.2 12.28,16.89 12.28,15.47 12.88,15.12 11.82,15.07 11.65,14.51 11.48,15.07 10.42,15.12 11.02,15.48 11.02,16.89 10.36,17.18 11.48,17.32 11.66,17.89 11.82,17.29 12.81,17.26",
			"14.74,39.2 14.6,40.78 17.53,40.58 17.19,40.19 14.91,40.39 14.9,39.12",
			"17.78,37.02 17.74,35.26 15.03,35.24 15.64,35.85 17.4,35.68 17.74,37.06",
			"30.41,10.49 29.9,9.82 30.57,8.37 29.89,7.84 30.59,7.93 30.76,6.69 30.08,6.53 31.08,5.77 31.65,6.62 31.05,6.81 30.91,7.91 31.42,8.21 30.84,8.38 30.68,9.47 31.2,9.82 30.48,10.4",
			"35.29,13 33.98,13.24 32.62,12.71 33.58,12.36 34.03,11.38 34.47,12.55 35.25,12.92",
			"36.23,11.74 35.48,12.2 32.66,11.8 32.09,10.92 32.46,10.33 34.14,10.33 35.78,10.68 36.25,11.28",
			"38.38,33.3 35.68,33.38 35.78,39.55 36.14,37.45 37.7,37.7 38.74,36.72 38.39,35.7 38.78,35.16 38.06,34.31 38.41,33.41",
			"40.48,39.53 46.78,39.61 46.8,36.53 46.32,36.53 46.21,37.27 43.07,37.99 42.97,38.99 40.45,39.22",
			"42.95,15.97 42.82,20.78 48.94,20.41 46.7,20.04 45.85,18.34 45.19,18.52 44.98,18.07 44.84,18.43 43.23,17.75 42.98,15.94",
			"53.52,17.19 53.66,14.58 52.2,14.47 52.19,14.92 53.19,14.78 53.36,17.22",
			"47.03,26.85 47.68,27.16 47.68,28.58 47.08,28.93 48.14,28.97 48.31,29.53 48.47,28.97 48.7,29.28 49.6,28.87 48.93,28.57 48.93,27.16 49.53,26.8 48.47,26.73 48.3,26.16 48.14,26.76 47.15,26.78",
			"48.05,33 49.11,32.93 48.39,32.72 48.39,29.49 49.11,29.29 47.87,29.35 48.02,32.95",
			"48.05,26.71 49.11,26.64 48.39,26.44 48.39,23.21 49.11,23.01 47.87,23.07 48.02,26.67",
			"42.55,7.06 42.6,8.81 45.3,8.83 44.7,8.23 42.93,8.39 42.6,7.02",
			"45.6,4.87 45.74,3.29 42.81,3.5 43.15,3.88 45.43,3.69 45.44,4.95",
			"52.71,9.75 52,9.23 51.54,9.63 50.3,9.63 50.14,9.23 49.71,9.63 48.47,9.63 48.32,9.23 46.65,9.63 46.18,9.23 45.47,9.63 45.87,9.94 45.6,10.21 46.15,10.3 44.7,10.64 46.09,10.7 46.21,11.1 46.89,10.67 47.92,10.7 48.04,11.1 48.5,10.67 49.68,10.67 49.87,11.1 51.5,10.67 51.97,11.1 52.62,10.55 52.06,10.33 52.59,10.09 52,10 52.49,9.9",
			"21.95,14.93 20.8,14 20.32,14.13 19.96,15.28 20.73,14.46 21.91,15.04",
			"25.4,17.46 29.52,19.95 27.07,23.49 27.29,22.47 25.48,20.16 27.01,18.62 25.39,17.49",
			"34.69,26.6 30.57,24.11 33.02,20.57 32.8,21.59 34.6,23.9 33.08,25.43 34.7,26.57",
			"38.14,29.13 39.52,30.01 40.13,28.78 39.35,29.6 38.17,29.02",
			"29.6,33.56 30.12,34.35 29.62,34.6 29.48,35.68 30.16,36.2 29.41,36.21 29.28,37.27 29.96,37.72 29.23,37.77 29.08,38.3 28.43,37.44 29.02,37.25 29.15,36.14 28.62,35.85 29.21,35.67 29.35,34.58 28.82,34.24 29.53,33.64",
			"23.76,32.42 24.49,31.94 27.34,32.29 27.92,33.16 27.32,33.81 25.82,33.77 24.22,33.46 23.75,32.86",
			"24.68,31.14 26.01,30.87 27.35,31.38 25.69,32.65 25.51,31.57 24.73,31.22",
			"7.48,34.33 8.2,34.85 8.66,34.45 9.9,34.45 10.05,34.85 10.48,34.45 11.72,34.45 11.88,34.85 13.55,34.45 14.01,34.85 14.72,34.45 14.32,34.14 14.6,33.87 14.04,33.77 15.5,33.44 14.1,33.37 13.98,32.98 13.3,33.41 12.28,33.37 12.16,32.98 11.69,33.41 10.52,33.41 10.33,32.98 8.69,33.41 8.23,32.98 7.58,33.53 8.13,33.74 7.61,33.99 8.2,34.08 7.7,34.17"
		],
		markers: [
			{
				kind: "expansion",
				x: 18.88,
				y: 9.46
			},
			{
				kind: "home",
				x: 11.9,
				y: 28.29,
				owner: "attacker"
			},
			{
				kind: "expansion",
				x: 41.11,
				y: 34.57
			},
			{
				kind: "home",
				x: 48.02,
				y: 15.74,
				owner: "defender"
			},
			{
				kind: "centre",
				x: 23.16,
				y: 19.76
			},
			{
				kind: "centre",
				x: 36.93,
				y: 24.3
			}
		]
	},
	{
		id: "di-re-b",
		letter: "B",
		a: "Disruption",
		b: "Reconnaissance",
		label: "Disruption vs Reconnaissance",
		edge: "Long edge",
		zones: [{
			side: "attacker",
			points: "0.14,43.96 0.14,32 59.86,32 59.86,43.96"
		}, {
			side: "defender",
			points: "0.14,12.01 0.14,0.04 59.86,0.04 59.86,12.01"
		}],
		terrain: [
			"17.6,39.96 14.23,39.96 13.01,40.42 9.72,39.96 9.09,40.54 6.02,39.96 6.02,32.92 17.6,32.92",
			"39.01,22.85 36.63,23.34 35.55,24.48 30.9,27.27 29.82,28.43 27.44,28.9 27.44,30.94 39.01,30.94",
			"22.77,36.28 23.86,37.95 27.22,35.76 27.65,35.83 28.92,34.66 27.84,32.99 24.92,34.89 23.93,34.94",
			"48.04,31.05 50.64,28.91 51.87,28.49 54.12,26.04 54.98,26.09 56.97,23.69 52.5,18.26 43.56,25.62",
			"53.98,4.03 50.61,4.03 49.39,3.57 46.1,4.03 45.47,3.45 42.41,4.03 42.41,11.06 53.98,11.06",
			"21.11,21.15 23.49,20.66 25.33,18.97 29.22,16.73 30.29,15.57 32.68,15.1 32.68,13.06 21.11,13.06",
			"37.08,7.62 35.99,5.96 32.63,8.15 32.2,8.08 30.93,9.25 32.01,10.92 34.93,9.02 35.92,8.97",
			"40.33,37.05 41.55,38.62 44.72,36.14 45.15,36.17 46.31,34.9 45.09,33.33 42.35,35.48 41.37,35.62",
			"35.89,36.21 34.73,34.45 33.49,33.71 31.7,31.86 29.84,32.89 29.58,33.9 28.85,34.63 33.04,38.97",
			"11.97,12.94 9.37,15.08 8.13,15.5 5.88,17.95 5.03,17.9 3.04,20.3 7.51,25.73 16.44,18.36",
			"23.96,7.7 25.11,9.43 26.36,10.19 28.15,12.04 30.01,11.01 30.27,10 31.01,9.28 26.81,4.94",
			"17.24,22.97 15.95,25.21 20.72,27.97 22.14,28.79 24.62,30.22 25.91,27.98 19.49,24.27 19.18,23.44",
			"19.7,6.97 18.51,5.38 15.3,7.8 14.87,7.76 13.68,9.02 14.88,10.61 17.66,8.51 18.64,8.39",
			"7.03,6.42 7.92,8.32 9.04,9.24 10.53,11.33 12.52,10.59 12.93,9.63 13.77,9.02 10.26,4.11",
			"52.91,37.5 52.03,35.61 50.9,34.67 49.41,32.58 47.4,33.34 47,34.3 46.17,34.89 49.68,39.81",
			"42.7,20.98 44,18.73 39.23,15.98 37.8,15.15 35.33,13.72 34.03,15.97 40.45,19.68 40.76,20.5"
		],
		ruins: [
			"9.22,33.41 6.61,33.28 6.49,34.72 6.95,34.77 6.82,33.76 9.26,33.58",
			"16.9,35.81 16.97,33.19 10.66,33.25 12.75,33.61 12.5,35.16 13.39,36.15 14.5,35.85 15.04,36.25 15.91,35.52 16.8,35.87",
			"28.02,28.98 27.74,30.31 28.2,30.78 29.28,30.48 28.26,30.26 28.13,28.95",
			"33.6,30.17 38.42,30.33 38.29,25.99 37.92,27.01 36.99,27.01 35.54,28.14 35.21,27.91 35.58,30.07 33.74,30.01",
			"27.84,34.28 26.91,34.15 26.89,34.73 25.99,35.31 25.46,34.77 25.54,35.61 24.64,36.19 23.88,35.8 24.21,36.47 23.82,36.82 24.87,37.03 24.79,36.41 25.72,35.81 26.21,36.16 26.12,35.55 26.7,35.16 27.58,35.27 27.8,34.37",
			"45.2,26.65 48.09,30.46 52.64,26.44 52.37,26.17 50.67,27.41 48.96,26.64 46.56,27.86 45.2,26.62",
			"56.44,23.67 52.5,18.79 50.18,20.7 50.41,21.07 51.05,20.7 53.59,22.64 54.44,22.13 56.18,23.89",
			"42.89,8.08 42.81,10.7 49.13,10.64 47.04,10.28 47.29,8.73 46.4,7.74 45.29,8.04 44.75,7.63 43.88,8.37 42.98,8.02",
			"50.83,10.56 53.44,10.69 53.47,9.06 53.1,9.2 53.23,10.21 50.79,10.39",
			"26.51,13.83 21.7,13.67 21.83,18.01 22.2,16.99 23.13,16.99 24.58,15.86 24.91,16.09 24.53,13.92 26.38,13.99",
			"31.91,15.2 31.93,13.57 30.56,13.7 31.67,13.92 31.8,15.23",
			"32.01,9.62 32.94,9.75 32.96,9.17 33.86,8.59 34.63,8.98 34.31,8.3 35.31,7.71 35.73,8.26 36.03,7.09 34.99,6.87 35.07,7.49 34.14,8.09 33.65,7.75 33.73,8.35 32.82,8.95 32.27,8.64 32.05,9.53",
			"40.19,39.06 41.81,38.36 41.77,37.86 43.26,37.23 43.21,36.73 44.19,35.98 44.58,36.17 45.58,34.87 46.2,34.89 46.37,34.04 45.58,34.03 45.95,33.38 45.06,33.41 44.91,34.04 43.93,34.78 43.61,34.54 42.5,35.91 41.92,35.87 42.04,36.28 40.47,36.99 40.24,37.88 41.08,38.02 40.08,38.83",
			"33.55,37.08 33.5,36.22 31.57,34.21 31.12,33.95 30.3,34.42 31.4,36.45 32.47,37.38 33.24,37.41",
			"34.07,35.42 32.21,33.58 32.34,35.21 31.14,36.11 31.56,36.49 32.49,35.33 34.09,35.59",
			"3.57,20.32 7.51,25.2 9.83,23.29 9.6,22.91 8.95,23.29 6.42,21.35 5.57,21.86 3.82,20.1",
			"14.81,17.34 11.91,13.53 7.36,17.55 7.64,17.81 9.34,16.57 11.16,17.25 13.44,16.13 14.81,17.37",
			"25.74,8.44 27.59,10.28 27.47,8.84 28.72,7.79 28.29,7.42 27.33,8.61 25.81,8.36",
			"26.25,6.78 26.31,7.63 28.28,9.69 29.34,9.65 29.61,9.01 28.58,7.58 27.38,6.52 26.61,6.5",
			"16.68,23.92 16.21,24.87 16.81,24.38 19.55,25.97 19.36,26.69 19.92,25.58 16.74,23.92",
			"22.51,26.11 21.92,26.52 20.69,25.81 20.69,25.11 20.12,26.01 19.55,25.88 19.95,26.3 19.48,27.32 20.07,26.9 21.29,27.61 21.22,28.33 21.9,27.42 22.47,27.56 22.04,27.11 22.51,26.25",
			"22.12,27.06 21.65,28.01 22.25,27.52 24.99,29.11 24.8,29.83 25.36,28.72 22.18,27.06",
			"19.88,4.97 18.79,5.75 18.33,5.57 18.28,6.13 16.78,6.74 16.82,7.24 15.82,7.98 15.44,7.78 14.42,9.05 13.8,9.03 13.61,9.87 14.45,9.93 14.02,10.55 14.91,10.52 15.08,9.9 16.64,9.22 16.52,8.81 18.1,8.13 17.98,7.72 18.93,7 19.56,7.02 19.81,6.14 18.98,5.99 19.98,5.19",
			"11.17,5.99 10.11,4.57 7.93,6.08 8.74,6.28 10.09,5.12 11.16,6.04",
			"9.93,9.39 10.73,10.76 13,8.89 12.33,8.88 10.76,10.26 10.01,9.23",
			"50.05,34.55 49.24,33.18 46.98,35.05 47.65,35.06 49.22,33.68 49.97,34.71",
			"48.81,37.96 49.87,39.37 52.05,37.86 51.24,37.67 49.89,38.83 48.82,37.9",
			"37.82,16.88 38.3,15.93 37.7,16.42 34.96,14.83 35.15,14.11 34.58,15.22 37.77,16.88",
			"37.43,17.83 38.22,17.54 39.25,18.14 39.26,18.83 39.83,17.93 40.46,18.03 39.99,17.64 40.37,17.61 40.47,16.62 39.67,16.93 38.65,16.34 38.64,15.64 38.05,16.52 37.47,16.39 37.91,16.83 37.43,17.7",
			"43.26,20.02 43.74,19.07 43.14,19.56 41.8,18.79 40.4,17.97 40.59,17.25 40.02,18.36 43.21,20.03"
		],
		markers: [
			{
				kind: "home",
				x: 11.66,
				y: 38.33,
				owner: "attacker"
			},
			{
				kind: "centre",
				x: 33.23,
				y: 27.14
			},
			{
				kind: "expansion",
				x: 51.59,
				y: 26.02
			},
			{
				kind: "home",
				x: 48.04,
				y: 5.66,
				owner: "defender"
			},
			{
				kind: "centre",
				x: 26.99,
				y: 16.79
			},
			{
				kind: "expansion",
				x: 8.42,
				y: 17.97
			}
		]
	},
	{
		id: "di-re-c",
		letter: "C",
		a: "Disruption",
		b: "Reconnaissance",
		label: "Disruption vs Reconnaissance",
		edge: "Long edge",
		zones: [{
			side: "attacker",
			points: "21.03,21.98 0.14,21.98 0.14,43.96 30.03,43.96 30.03,30.98 30.03,30.98 30.02,30.98 30.02,30.98 30.01,30.98 26.52,30.27 23.66,28.35 21.74,25.49 21.03,22 21.03,22 21.03,21.99 21.03,21.99"
		}, {
			side: "defender",
			points: "59.88,0.04 30.01,0.04 30.01,13.02 33.5,13.73 36.36,15.65 38.28,18.51 38.99,22 59.88,22"
		}],
		terrain: [
			"21.65,33.91 18.28,33.91 16.96,33.46 13.77,33.91 13.14,33.32 10.07,33.91 10.07,40.94 21.65,40.94",
			"17.49,25.65 17,23.95 15.02,23.95 15.02,27.96 14.73,28.3 15.02,29.99 17,29.99 17,26.5",
			"6.83,20.8 5.02,21.35 5.02,23.95 10.52,23.95 12.17,23.95 15.03,23.95 15.03,21.35 7.61,21.35",
			"40.54,29.3 39.01,30.67 38.43,32.05 36.86,34.08 38.19,35.8 39.21,35.89 40.01,36.5 43.69,31.72",
			"19.93,18.29 20.41,20.63 22.12,22.53 24.4,26.44 25.5,27.46 25.98,29.86 28.02,29.86 28.02,18.29",
			"57.13,33.15 54.44,31.12 53.65,29.97 50.83,28.4 50.64,27.53 47.88,26.18 43.65,31.79 52.9,38.76",
			"38.33,10.14 41.73,10.14 43.15,10.54 46.24,10.14 46.89,10.72 49.91,10.14 49.91,3.1 38.33,3.1",
			"42.61,18.45 43.09,20.07 45.08,20.07 45.08,16.05 45.36,15.76 45.08,14.03 43.09,14.03 43.09,17.51",
			"55.08,22.66 55.08,20.07 49.57,20.07 47.92,20.07 45.07,20.07 45.07,22.66 52.48,22.66 53.21,23.22",
			"27.02,10.99 29.04,11.37 30.49,10.99 33.06,10.99 33.61,8.89 33.06,8.03 33.06,7.02 27.02,7.02",
			"25.02,9.05 27.01,9.05 27.01,5.03 27.29,4.69 27.01,3.01 25.02,3.01 25.02,6.49 24.54,7.28",
			"40.07,25.74 39.59,23.36 38.45,22.29 35.6,17.59 34.51,16.57 34.02,14.17 31.98,14.17 31.98,25.74",
			"32.99,33.09 30.98,32.71 29.53,33.09 26.96,33.09 26.43,35.24 26.96,36.05 26.96,37.06 32.99,37.06",
			"35.42,36.34 35,34.92 33.01,34.92 33.01,38.94 32.73,39.23 33.01,40.96 35,40.96 35,37.48",
			"2.93,11.13 5.62,13.16 6.4,14.31 9.22,15.88 9.41,16.75 12.17,18.1 16.4,12.49 7.16,5.52",
			"19.48,14.89 21.01,13.52 21.59,12.14 23.16,10.1 21.87,8.41 20.81,8.3 20.01,7.68 16.33,12.47"
		],
		ruins: [
			"13.33,34.39 10.72,34.27 10.69,35.89 11.06,35.77 10.91,34.76 13.33,34.52",
			"21.12,36.98 20.97,34.3 14.9,34.43 16.98,34.76 16.76,36.33 17.63,37.32 18.71,37.01 19.27,37.41 20.13,36.67 21,37.04",
			"16.64,31.3 16.67,30 17.1,29.72 16.67,29.32 16.7,28.08 17.1,27.86 16.67,27.49 17.07,25.85 16.67,25.67 16.66,24.49 17.07,24 16.55,23.38 15.97,24 15.81,23.31 15.23,24 15.63,25.67 15.23,25.85 15.63,26.25 15.63,27.55 15.23,27.68 15.63,29.38 15.23,29.81 15.65,30.53 16.21,30.43 16.3,29.81 16.42,31.3",
			"4.96,22.34 5.02,23.37 5.24,22.64 8.45,22.64 8.64,23.37 8.57,22.15 5.02,22.21",
			"11.24,22.34 11.3,23.37 11.52,22.64 14.73,22.64 14.92,23.37 14.86,22.15 11.3,22.21",
			"9.06,21.31 8.99,22.42 8.38,22.6 8.99,22.76 9.03,23.8 9.4,23.19 10.75,23.22 11.06,23.86 11.21,22.76 11.77,22.57 11.21,22.45 11.09,21.31 10.78,21.96 9.36,21.96 9.24,21.31",
			"38.5,32.5 37.43,33.89 39.48,35.56 39.43,34.73 37.95,33.79 38.54,32.5",
			"42.1,32.82 43.15,31.66 40.71,30.06 42.66,31.79 41.92,32.8",
			"26.01,29.46 27.64,29.56 27.51,28.17 27.33,29.25 26.01,29.4",
			"27.55,23.45 27.71,18.65 23.39,18.78 24.4,19.15 25.33,21.9 27.43,21.47 27.4,23.33",
			"47.41,28.03 44.33,31.68 49.24,35.24 49.41,34.87 47.8,33.58 48.13,33.59 48.23,31.7 47.52,31.31 47.62,30.83 47.3,31.09 46.52,29.62 47.56,28.15",
			"52.8,38.04 56.61,33.25 54.38,31.31 54.04,31.59 54.55,32.15 53.19,35.3 53.84,35.81 52.54,37.87",
			"46.72,9.47 49.33,9.6 49.36,7.98 48.99,8.1 49.14,9.11 46.72,9.35",
			"38.86,7.06 39.02,9.74 45.08,9.61 43.01,9.28 43.26,7.86 42.36,6.72 41.28,7.03 40.72,6.63 39.85,7.37 38.99,7",
			"43.35,12.72 43.32,14.02 42.89,14.29 43.32,14.7 42.89,16.15 43.32,16.52 42.92,18.16 43.32,18.35 43.33,19.52 42.92,20.02 43.44,20.64 44.02,20.02 44.25,20.73 44.76,20.02 44.36,18.35 44.76,18.16 44.36,17.76 44.36,16.46 44.76,16.34 44.36,14.63 44.76,14.2 44.34,13.49 43.78,13.58 43.68,14.2 43.56,12.72",
			"55.14,21.68 55.07,20.64 54.86,21.37 51.64,21.37 51.46,20.64 51.52,21.86 55.07,21.8",
			"48.85,21.68 48.79,20.64 48.58,21.37 45.36,21.37 45.18,20.64 45.24,21.86 48.79,21.8",
			"51.04,22.7 51.1,21.6 51.72,21.41 51.1,21.26 51.07,20.21 50.7,20.83 49.34,20.8 49.04,20.15 48.88,21.26 48.33,21.44 48.88,21.57 48.94,22.61 49.31,22.06 50.73,22.06 50.85,22.7",
			"27.92,8.74 28.54,9.28 31.48,9.28 32.1,8.55 31.85,7.88 30.21,7.64 28.51,7.76 27.92,8.31",
			"28.67,10.13 30.06,10.53 31.32,10.19 30.21,9.08 28.76,10.03",
			"26.25,3.66 25.63,4.25 26.09,4.65 26.09,5.77 25.35,6.11 26.09,6.26 26.09,7.37 25.35,7.71 26.09,7.87 26.15,8.39 26.89,7.65 26.34,7.4 26.34,6.26 26.89,6.04 26.34,5.8 26.34,4.65 26.89,4.41 26.25,3.73",
			"33.96,14.71 32.4,14.56 32.46,16.01 32.64,14.93 33.96,14.77",
			"32.45,20.58 32.3,25.37 36.62,25.25 35.6,24.88 35.6,23.95 34.49,22.59 34.67,22.12 32.58,22.56 32.61,20.7",
			"32.09,35.34 31.47,34.79 28.54,34.79 27.92,35.53 28.17,36.2 29.81,36.44 31.51,36.32 32.09,35.77",
			"31.35,33.95 29.96,33.55 28.69,33.89 29.81,34.99 31.26,34.04",
			"33.77,40.3 34.39,39.72 33.93,39.32 33.93,38.2 34.67,37.86 33.93,37.71 33.93,36.6 34.67,36.26 33.93,36.1 33.86,35.58 33.12,36.32 33.68,36.56 33.68,37.71 33.12,37.92 33.68,38.17 33.68,39.32 33.12,39.56 33.77,40.24",
			"12.68,16.19 15.71,12.42 10.64,9 12.26,10.7 11.89,10.61 11.79,12.5 12.5,12.89 12.41,13.37 12.73,13.11 13.58,14.64 12.47,16.05",
			"7.23,6.16 3.41,10.95 5.8,12.94 5.48,12.05 6.87,8.98 6.14,8.41 7.49,6.33",
			"21.52,11.68 22.59,10.29 20.54,8.63 20.59,9.45 22.07,10.4 21.48,11.69",
			"17.92,11.36 16.87,12.53 19.31,14.13 17.36,12.4 18.1,11.38"
		],
		markers: [
			{
				kind: "home",
				x: 15.7,
				y: 35.54,
				owner: "attacker"
			},
			{
				kind: "centre",
				x: 24.3,
				y: 24.17
			},
			{
				kind: "expansion",
				x: 51.39,
				y: 30.86
			},
			{
				kind: "home",
				x: 44.31,
				y: 8.5,
				owner: "defender"
			},
			{
				kind: "centre",
				x: 35.77,
				y: 19.95
			},
			{
				kind: "expansion",
				x: 8.66,
				y: 13.42
			}
		]
	},
	{
		id: "di-pa-a",
		letter: "A",
		a: "Disruption",
		b: "Priority Assets",
		label: "Disruption vs Priority Assets",
		edge: "Long edge",
		zones: [{
			side: "attacker",
			points: "59.86,35.99 30.02,35.99 30.02,30.01 0.14,30.01 0.14,43.96 59.86,43.96"
		}, {
			side: "defender",
			points: "59.86,0.04 0.13,0.04 0.13,8.02 30.02,8.02 30.02,13.99 59.86,13.99"
		}],
		terrain: [
			"16.57,17.09 13.2,17.09 11.98,17.55 8.68,17.09 8.05,17.68 4.99,17.09 4.99,10.06 16.57,10.06",
			"15.61,32.95 12.24,32.95 11.02,32.49 7.72,32.95 7.09,32.36 4.03,32.95 4.03,39.98 15.61,39.98",
			"39.92,36.45 39.92,39.04 45.43,39.04 47.08,39.04 49.93,39.04 49.93,36.45 42.52,36.45 41.84,35.89",
			"46.14,23 45.02,21.36 48.33,19.09 48.43,18.67 50,17.94 51.12,19.58 48.25,21.55 47.83,22.44",
			"43.59,22.12 42.12,20.61 41.66,19.25 40.22,17.12 41.63,15.5 42.65,15.47 43.51,14.89 46.89,19.9",
			"13.91,21.09 15.04,22.73 11.73,25 11.19,25.65 10.06,26.15 8.94,24.51 11.81,22.54 12.23,21.65",
			"16.46,21.96 17.93,23.47 18.4,24.84 19.84,26.97 18.43,28.59 17.41,28.62 16.55,29.19 13.17,24.19",
			"43.48,26.98 46.85,26.98 48.07,26.52 51.36,26.98 51.99,26.39 55.05,26.98 55.05,34.01 43.48,34.01",
			"44.43,11.03 47.8,11.03 49.02,11.49 52.31,11.03 52.94,11.62 56,11.03 56,3.99 44.43,3.99",
			"30.99,29.97 30.99,31.96 35,31.96 35.32,32.24 37.03,31.96 37.03,29.97 33.55,29.97 32.69,29.48",
			"33.99,24.98 34.37,22.94 33.99,21.52 33.99,18.95 31.94,18.39 31.05,18.94 30.02,18.95 30.02,24.98",
			"25.94,18.92 25.56,20.96 25.94,22.38 25.94,24.95 27.99,25.51 28.88,24.96 29.91,24.95 29.91,18.92",
			"41.01,8.78 39.08,7.31 37.51,7.24 32.36,5.56 30.77,5.51 28.85,4.02 27.31,5.35 34.9,14.09",
			"29.02,14.08 29.02,12.09 25,12.09 24.68,11.8 22.98,12.09 22.98,14.08 26.46,14.08 27.31,14.57",
			"18.87,35.22 20.79,36.7 22.36,36.76 27.52,38.44 29.1,38.49 31.02,39.99 32.56,38.65 24.97,29.91",
			"20.11,7.56 20.11,4.96 14.6,4.96 12.96,4.96 10.1,4.96 10.1,7.56 17.51,7.56 18.2,8.12"
		],
		ruins: [
			"5.63,12 5.49,16.81 11.62,16.44 9.37,16.07 8.52,14.45 5.9,13.78 5.65,11.97",
			"16.07,16.64 16.13,10.38 13.07,10.38 13.07,10.81 13.81,10.92 14.53,14.06 15.5,14.18 15.74,16.67",
			"7.18,33.29 4.57,33.15 4.45,34.6 4.91,34.65 4.78,33.64 7.22,33.46",
			"15.05,35.92 15.13,33.31 8.82,33.37 10.91,33.72 10.66,35.28 11.54,36.26 12.66,35.97 13.2,36.37 14.06,35.63 14.96,35.98",
			"39.85,37.42 39.92,38.47 40.05,37.8 41.44,37.75 43.36,37.75 43.61,38.43 43.48,37.24 40.02,37.28",
			"46,36.4 45.68,37.05 44.27,37.05 43.98,36.4 43.87,37.52 43.32,37.68 43.8,37.82 43.97,38.97 44.27,38.31 45.69,38.31 46.04,38.9 46.11,37.85 46.68,37.67 46.09,37.51 46.06,36.51",
			"46.13,37.42 46.2,38.47 46.34,37.8 47.73,37.75 49.64,37.75 49.89,38.43 49.76,37.24 46.3,37.28",
			"52.03,18.36 50.95,19.16 50.98,19.65 50.43,19.52 49.39,20.76 48.92,20.57 47.98,21.71 46.46,22.3 46.29,22.89 45.43,22.81 45.63,21.99 44.92,22.21 45.21,21.37 45.85,21.41 46.99,20.12 47.34,20.37 48.48,19.08 48.83,19.32 49.81,18.64 49.98,18.03 50.9,18.06 50.78,18.9 51.85,18.19",
			"44.13,16.63 43.36,15.24 41.04,17.05 41.53,17.19 43.32,15.74 44.04,16.79",
			"42.79,20.22 43.82,21.66 46.07,20.16 45.23,19.99 43.85,21.12 42.8,20.17",
			"8.03,25.72 9.11,24.93 9.08,24.44 9.63,24.56 10.67,23.32 11.14,23.52 12.08,22.37 13.6,21.79 13.77,21.19 14.63,21.27 14.41,22.03 15.14,21.87 14.85,22.72 14.21,22.68 13.21,23.39 13.35,23.77 11.71,24.43 11.58,25 11.23,24.76 10.08,26.05 9.16,26.02 9.28,25.18 8.21,25.89",
			"17.26,23.86 16.24,22.42 13.99,23.92 14.83,24.09 16.21,22.97 17.25,23.91",
			"15.93,27.45 16.7,28.84 19.02,27.04 18.34,27 16.74,28.34 16.02,27.3",
			"43.82,27.3 43.76,33.56 46.82,33.56 46.82,33.13 46.08,33.02 45.36,29.88 44.39,29.76 44.14,27.27",
			"54.45,32.13 54.58,27.32 48.46,27.69 50.7,28.06 51.55,29.76 52.22,29.58 52.42,30.03 52.56,29.67 54.17,30.35 54.43,32.16",
			"44.98,8.05 44.9,10.67 51.21,10.61 49.13,10.26 49.37,8.7 48.49,7.72 47.38,8.01 46.84,7.61 45.97,8.35 45.07,7.99",
			"52.82,10.58 55.43,10.71 55.46,9.07 55.09,9.21 55.22,10.23 52.78,10.4",
			"36.28,31.07 35.66,30.46 35.24,30.93 34.15,30.93 34.07,30.19 33.64,30.93 32.48,30.9 32.12,30.19 32.12,30.89 31.52,31.01 32.28,31.75 32.54,31.2 33.65,31.2 33.87,31.75 34.13,31.2 35.26,31.2 35.52,31.75 36.15,31.2",
			"31.55,23.99 32.11,23.33 32.12,20.48 31.32,19.77 30.69,20.05 30.44,21.72 30.57,23.38 31.1,23.94",
			"32.94,23.22 33.35,21.93 33.02,20.54 31.89,22.08 32.61,22.36 32.81,23.08",
			"26.99,20.68 26.57,21.96 26.91,23.36 28.04,21.82 27.32,21.54 27.12,20.82",
			"28.38,19.91 27.82,20.57 27.81,23.42 28.61,24.13 29.24,23.85 29.49,22.18 29.36,20.52 28.83,19.96",
			"29.26,4.48 28.04,5.31 28.03,5.81 29.02,6.49 28.46,5.51 29.36,4.55",
			"31.89,9.59 34.92,13.32 38.09,10.4 37.1,10.76 34.58,9.29 33.26,11.01 31.91,9.57",
			"23.73,12.97 24.34,13.59 24.76,13.11 25.86,13.11 25.94,13.85 26.37,13.11 27.53,13.14 27.88,13.85 27.88,13.16 28.48,13.04 27.73,12.29 27.46,12.85 26.35,12.85 26.14,12.29 25.87,12.85 24.75,12.85 24.48,12.29 23.85,12.85",
			"27.98,34.42 24.95,30.68 21.79,33.6 22.77,33.24 25.3,34.71 26.59,32.99 27.96,34.44",
			"30.5,39.41 31.74,38.35 30.74,37.41 31.3,38.39 30.4,39.35",
			"13.93,6.55 13.87,5.5 13.73,6.17 12.34,6.22 10.43,6.22 10.18,5.54 10.3,6.73 13.76,6.69",
			"14.07,7.57 14.39,6.92 15.8,6.92 16.15,7.52 16.2,6.45 16.75,6.29 16.27,6.15 16.1,5 15.8,5.66 14.38,5.66 14.02,5.07 13.96,6.12 13.39,6.3 13.98,6.46 14.01,7.46",
			"20.22,6.55 20.15,5.5 20.01,6.17 18.62,6.22 16.71,6.22 16.46,5.54 16.59,6.73 20.05,6.69"
		],
		markers: [
			{
				kind: "expansion",
				x: 10.63,
				y: 15.46
			},
			{
				kind: "home",
				x: 9.67,
				y: 34.58,
				owner: "attacker"
			},
			{
				kind: "expansion",
				x: 49.42,
				y: 28.61
			},
			{
				kind: "home",
				x: 50.37,
				y: 9.4,
				owner: "defender"
			},
			{
				kind: "centre",
				x: 32.42,
				y: 21.21
			}
		]
	},
	{
		id: "di-pa-b",
		letter: "B",
		a: "Disruption",
		b: "Priority Assets",
		label: "Disruption vs Priority Assets",
		edge: "Short edge",
		zones: [{
			side: "attacker",
			points: "0.19,43.96 20.02,43.96 20.02,22.02 12.06,22.02 12.06,0.04 0.19,0.04"
		}, {
			side: "defender",
			points: "59.86,0.04 40.03,0.04 40.03,21.98 47.98,21.98 47.98,43.96 59.86,43.96"
		}],
		terrain: [
			"18.2,22.87 14.83,22.87 13.62,22.41 10.32,22.87 9.69,22.29 6.63,22.87 6.63,29.91 18.2,29.91",
			"39.8,12.95 38.68,10.8 36.55,9.49 33.33,6.37 31.91,5.66 30.8,3.49 28.84,4.05 32.03,15.18",
			"45.89,39.93 42.52,39.93 41.3,40.39 38,39.93 37.37,40.52 34.31,39.93 34.31,32.89 45.89,32.89",
			"41.47,21.03 44.84,21.03 46.06,21.49 49.35,21.03 49.98,21.62 53.05,21.03 53.05,14 41.47,14",
			"44.96,3.06 46.95,3.06 46.95,7.08 47.24,7.4 46.95,9.11 44.96,9.11 44.96,5.62 44.47,4.77",
			"48.48,35.04 51.07,35.04 51.07,29.53 51.07,27.88 51.07,25.02 48.48,25.02 48.48,32.44 47.91,33.12",
			"26.89,17.94 28.94,17.57 30.36,17.94 32.93,17.94 33.48,20 32.93,20.88 32.93,21.92 26.89,21.92",
			"32.93,25.99 30.89,26.36 29.47,25.99 26.9,25.99 26.34,23.91 26.89,23.05 26.9,22.01 32.93,22.01",
			"35.24,21.21 35.5,23.3 36.28,24.51 37.05,26.96 39.2,26.87 39.86,26.09 40.84,25.77 39.03,20.01",
			"52.98,11.06 52.98,9.07 48.96,9.07 48.64,8.78 46.94,9.07 46.94,11.06 50.42,11.06 51.28,11.55",
			"13.01,40.9 14.99,40.9 14.99,36.88 15.28,36.57 14.99,34.86 13.01,34.86 13.01,38.34 12.52,39.2",
			"7,32.89 7,34.88 11.01,34.88 11.83,35.11 13.04,34.88 13.04,32.89 9.55,32.89 8.7,32.4",
			"20.23,31.24 21.35,33.39 23.48,34.7 26.7,37.82 28.12,38.54 29.23,40.7 31.19,40.14 28,29.01",
			"25.58,11.03 22.21,11.03 20.99,11.49 17.69,11.03 17.07,11.62 14,11.03 14,4 25.58,4",
			"11.72,9.14 9.13,9.14 9.13,14.64 9.13,16.29 9.13,19.15 11.72,19.15 11.72,11.73 12.28,11.05",
			"24.85,22.75 24.55,20.66 23.75,19.46 22.93,17.03 20.79,17.16 20.12,17.97 19.16,18.29 21.08,24.01"
		],
		ruins: [
			"9.63,23.2 7.02,23.07 6.9,24.51 7.36,24.56 7.23,23.55 9.67,23.37",
			"17.66,27.99 17.8,23.17 11.67,23.54 13.92,23.91 14.77,25.53 17.39,26.21 17.64,28.02",
			"30.89,3.99 29.32,4.42 29.82,5.7 29.73,4.58 30.95,4.08",
			"31.09,9.97 32.23,14.59 36.4,13.32 35.33,13.24 33.71,10.89 31.73,11.85 31.29,10.06",
			"37.38,33.3 34.76,33.22 34.82,39.54 35.19,37.45 36.74,37.7 37.78,36.72 37.43,35.7 37.82,35.16 37.1,34.31 37.45,33.41",
			"39.3,39.49 45.49,39.59 45.58,36.49 45.14,36.49 45.02,37.23 41.89,37.95 41.75,38.95 39.27,39.19",
			"41.95,16 41.82,20.81 47.95,20.44 45.7,20.07 44.85,18.45 42.23,17.78 41.98,15.96",
			"49.93,20.42 52.53,20.6 52.59,18.96 52.22,19.1 52.33,20.11 49.89,20.25",
			"45.91,8.45 45.3,7.83 45.78,7.42 45.8,6.33 45.07,5.88 45.77,5.89 45.83,4.72 45.1,4.28 45.8,4.29 45.99,3.69 46.66,4.47 46.09,4.72 46.08,5.83 46.63,6.07 46.07,6.31 46.05,7.41 46.6,7.7 45.96,8.36",
			"48.41,28.95 49.05,29.26 49.05,30.68 48.46,31.03 49.52,31.07 49.75,31.68 49.85,31.07 50.07,31.38 50.97,30.97 50.31,30.67 50.31,29.26 50.91,28.9 49.85,28.83 49.68,28.26 49.51,28.86 48.52,28.88",
			"49.42,35.1 50.48,35.03 49.77,34.82 49.77,31.59 50.48,31.39 49.24,31.45 49.4,35.05",
			"49.42,28.81 50.48,28.74 49.77,28.54 49.77,25.31 50.48,25.11 49.24,25.17 49.4,28.77",
			"32.07,20.07 31.4,19.51 28.53,19.51 27.85,20.3 28.36,21.02 29.86,21.17 31.48,21.05 32.02,20.51",
			"31.31,18.69 30.02,18.27 28.63,18.6 29.75,19.73 31.25,18.77",
			"28.51,25.24 29.81,25.66 31.2,25.33 30.08,24.2 28.58,25.16",
			"27.76,23.86 28.42,24.42 31.3,24.42 31.98,23.63 31.47,22.91 29.97,22.76 28.34,22.88 27.8,23.42",
			"38.92,21.89 38.53,20.35 35.83,21.48 36.48,21.69 38.37,20.83 38.79,22.03",
			"36.72,24.99 37.32,26.64 39.85,25.84 39.12,25.41 37.49,26.13 36.74,24.94",
			"46.37,10.35 47.09,10.9 47.55,10.47 48.8,10.5 48.95,10.9 49.38,10.5 51.09,10.9 51.21,10.5 52.44,10.47 52.9,10.87 53.62,10.5 53.22,10.19 53.49,9.89 52.94,9.82 54.4,9.49 53,9.42 52.88,9.03 52.2,9.46 51.05,9.03 50.59,9.46 49.41,9.46 49.23,9.03 47.59,9.46 47.13,9.03 46.48,9.58 47.03,9.79 46.51,10.04 47.09,10.13 46.6,10.22",
			"13.92,35.3 14.53,35.91 14.06,36.33 14.06,37.42 14.8,37.75 14.06,37.96 14.06,39.03 14.8,39.46 14.1,39.46 13.98,40.07 13.23,39.3 13.79,39.03 13.79,37.92 13.23,37.7 13.79,37.44 13.79,36.34 13.23,36.07 13.79,35.42",
			"13.6,33.6 12.89,33.08 12.43,33.47 11.19,33.47 11.04,33.08 10.6,33.47 9.36,33.47 9.21,33.08 7.54,33.47 7.07,33.08 6.36,33.47 6.77,33.78 6.49,34.06 7.04,34.15 5.59,34.49 6.98,34.55 7.11,34.95 7.79,34.52 8.81,34.55 8.93,34.95 9.4,34.52 10.57,34.52 10.76,34.95 12.4,34.52 12.86,34.95 13.51,34.4 12.95,34.18 13.48,33.93 12.89,33.84 13.39,33.75",
			"28.94,34.22 27.8,29.6 23.63,30.87 24.7,30.95 24.97,31.84 26.4,32.85 26.32,33.3 28.3,32.34 28.74,34.13",
			"29.14,40.2 30.71,39.77 30.21,38.49 30.29,39.61 29.08,40.11",
			"20.49,4.35 14.3,4.25 14.22,7.35 14.66,7.35 14.77,6.61 17.91,5.89 18.05,4.89 20.53,4.66",
			"22.59,10.51 25.22,10.58 25.15,4.26 24.79,6.36 23.24,6.11 22.24,6.99 22.55,8.11 22.16,8.65 22.88,9.5 22.53,10.4",
			"9.08,13.06 9.72,13.37 9.72,14.79 9.13,15.14 10.19,15.19 10.36,15.75 10.52,15.19 11.58,15.14 10.98,14.78 10.98,13.37 11.58,13.02 10.52,12.94 10.35,12.37 10.18,12.97 9.19,13",
			"10.1,19.21 11.16,19.14 10.44,18.94 10.44,15.7 11.12,15.44 9.91,15.57 10.07,19.16",
			"10.1,12.92 11.16,12.86 10.44,12.65 10.44,9.42 11.16,9.22 9.91,9.28 10.07,12.88",
			"23.3,18.99 22.67,17.35 20.16,18.2 20.89,18.61 22.5,17.87 23.28,19.04",
			"21.16,22.13 21.57,23.66 24.25,22.49 23.6,22.29 21.72,23.18 21.28,21.99"
		],
		markers: [
			{
				kind: "home",
				x: 12.26,
				y: 24.5,
				owner: "attacker"
			},
			{
				kind: "expansion",
				x: 39.95,
				y: 38.3
			},
			{
				kind: "home",
				x: 47.41,
				y: 19.4,
				owner: "defender"
			},
			{
				kind: "centre",
				x: 30.67,
				y: 19.51
			},
			{
				kind: "expansion",
				x: 19.64,
				y: 9.4
			}
		]
	},
	{
		id: "di-pa-c",
		letter: "C",
		a: "Disruption",
		b: "Priority Assets",
		label: "Disruption vs Priority Assets",
		edge: "Long edge",
		zones: [{
			side: "attacker",
			points: "30.02,30.98 28.19,30.79 26.51,30.27 24.98,29.44 23.65,28.35 22.56,27.02 21.73,25.5 21.21,23.81 21.03,21.98 0.14,21.98 0.14,43.96 30.02,43.96"
		}, {
			side: "defender",
			points: "59.86,0.04 30,0.04 30,13.02 31.81,13.2 33.49,13.73 35.02,14.56 36.35,15.65 37.44,16.98 38.27,18.51 38.79,20.19 38.97,22 59.86,22"
		}],
		terrain: [
			"18.92,9.18 15.68,8.25 14.64,7.47 11.35,7.01 10.88,6.26 7.8,5.99 5.86,12.75 16.99,15.94",
			"4.13,38.94 7.5,38.94 8.72,39.4 12.01,38.94 12.64,39.52 15.7,38.94 15.7,31.9 4.13,31.9",
			"44,17.09 45.99,17.09 45.99,21.11 46.28,21.43 45.99,23.13 44,23.13 44,19.65 43.51,18.8",
			"55.98,25.67 55.98,23.07 50.48,23.07 48.83,23.07 45.97,23.07 45.97,25.67 53.38,25.67 54.07,26.23",
			"26.98,25.95 29.03,26.33 30.45,25.95 33.02,25.95 33.57,23.9 33.02,23.01 33.02,21.98 26.98,21.98",
			"33.02,17.96 30.98,17.59 29.56,17.96 26.99,17.96 26.44,20.04 26.98,20.9 26.99,21.94 33.02,21.94",
			"21.02,11.04 23,11.04 23,7.02 23.29,6.7 23,4.99 21.02,4.99 21.02,8.48 20.53,9.33",
			"22.99,13.03 25.03,13.41 26.45,13.03 29.02,13.03 29.57,10.98 29.02,10.06 29.02,9.05 22.99,9.05",
			"39.05,32.87 37.06,32.87 37.06,36.89 36.77,37.21 37.06,38.91 39.05,38.91 39.05,35.43 39.54,34.58",
			"37.01,30.99 34.96,30.61 33.54,30.99 30.97,30.99 30.42,33.04 30.97,33.93 30.97,34.96 37.01,34.96",
			"41.13,34.76 44.37,35.69 45.42,36.47 48.71,36.93 49.15,37.67 52.26,37.95 54.2,31.19 43.07,28",
			"55.88,4.98 52.51,4.98 51.29,4.52 47.99,4.98 47.37,4.4 44.3,4.98 44.3,12.02 55.88,12.02",
			"35.98,4.95 37.68,6.67 38.26,9.11 40.23,13.14 40.47,14.71 42.19,16.43 41.05,18.12 31.46,11.65",
			"24.06,39 22.36,37.27 22.1,35.72 19.81,30.81 19.56,29.24 17.85,27.52 18.99,25.82 28.58,32.29",
			"15.96,27 13.98,27 13.98,22.98 13.69,22.66 13.98,20.96 15.96,20.96 15.96,24.44 16.46,25.29",
			"3.99,18.42 3.99,21.02 9.49,21.02 11.14,21.02 14,21.02 14,18.42 6.58,18.42 5.9,17.86"
		],
		ruins: [
			"14.01,8.15 8,6.36 7.15,9.31 7.58,9.43 7.89,8.75 11.1,8.92 11.49,8.02 13.93,8.48",
			"14.23,14.72 16.73,15.51 18.41,9.42 17.48,11.33 16.06,10.67 14.79,11.32 14.85,12.4 14.32,12.81 14.76,13.8 14.19,14.59",
			"4.61,35.64 4.47,38.26 5.94,38.37 5.95,37.92 4.95,38.05 4.78,35.61",
			"15.08,37 15.21,32.18 9.09,32.55 11.33,32.92 12.18,34.62 12.84,34.44 13.05,34.89 13.19,34.53 14.8,35.22 15.05,37.03",
			"45.2,17.67 44.58,18.29 45.05,18.7 45.06,19.79 44.31,20.13 45.06,20.33 45.06,21.4 44.31,21.83 45.02,21.83 45.2,22.44 45.88,21.67 45.32,21.41 45.33,20.3 45.88,20.07 45.33,19.82 45.32,18.72 45.88,18.44 45.25,17.77",
			"49.76,24.63 49.7,23.57 49.56,24.24 48.17,24.29 46.25,24.29 46.01,23.62 46.13,24.81 49.59,24.76",
			"49.9,25.64 50.21,25 51.62,25 51.98,25.6 52.02,24.53 52.58,24.37 52.02,24.2 52.32,23.95 51.92,23.08 51.62,23.74 50.2,23.74 49.85,23.15 49.78,24.2 49.21,24.37 49.73,24.51 49.83,25.53",
			"56.04,24.63 55.98,23.57 55.84,24.24 54.45,24.29 52.53,24.29 52.29,23.62 52.41,24.81 55.87,24.76",
			"28.55,25.01 29.84,25.43 31.23,25.09 29.69,23.96 29.43,24.68 28.61,24.93",
			"27.79,23.62 28.46,24.19 31.33,24.19 32.01,23.4 31.5,22.68 30,22.53 28.38,22.65 27.84,23.18",
			"32.1,20.29 31.44,19.73 28.56,19.73 27.88,20.52 28.39,21.24 29.89,21.39 31.52,21.27 32.06,20.73",
			"31.35,18.91 30.05,18.49 28.66,18.82 29.78,19.95 31.28,18.99",
			"21.53,3.67 21.5,5 21.08,5.28 21.5,5.67 21.08,7.22 21.5,7.5 21.11,9.15 21.5,9.33 21.5,10.49 21.1,10.95 21.66,11.63 22.17,11.02 22.41,11.72 22.98,10.99 22.58,10.51 22.6,9.26 22.98,9.16 22.59,8.73 22.98,7 22.58,6.84 22.58,5.66 22.98,5.17 22.46,4.44 21.8,5.02 21.76,3.71",
			"25.07,9.55 23.31,9.59 23.29,12.3 23.9,11.7 23.74,9.92 25.11,9.59",
			"27.25,12.55 28.83,12.68 28.63,9.75 28.23,10.3 28.44,12.38 27.17,12.39",
			"38.54,40.23 38.57,38.91 38.99,38.63 38.57,38.24 38.99,36.69 38.56,36.41 38.96,34.76 38.56,34.58 38.56,33.42 38.96,32.96 38.41,32.27 37.9,32.89 37.61,32.19 37.09,32.92 37.48,33.4 37.47,34.65 37.09,34.75 37.48,36.48 37.09,36.91 37.49,37.06 37.09,38.74 37.61,39.47 38.16,38.77 38.31,40.2",
			"32.69,31.48 31.1,31.34 31.31,34.28 31.71,33.73 31.5,31.65 32.77,31.64",
			"34.92,34.47 36.69,34.43 36.7,31.72 36.1,32.32 36.26,34.09 34.89,34.43",
			"45.83,29.22 43.33,28.42 41.65,34.51 42.58,32.6 44,33.27 45.27,32.62 45.21,31.54 45.74,31.13 45.28,30.11 45.87,29.34",
			"46.04,35.78 51.97,37.59 52.91,34.71 52.48,34.51 52.17,35.18 48.95,35.01 48.56,35.92 46.13,35.46",
			"45.08,6.89 44.95,11.71 51.07,11.34 48.83,10.96 47.98,9.34 45.49,8.77 45.1,6.86",
			"55.44,8.17 55.58,5.56 53.94,5.53 54.11,5.9 55.1,5.77 55.27,8.21",
			"34.9,7.61 32.08,11.51 35.72,13.81 35.12,12.95 35.88,10.13 33.89,9.32 34.93,7.62",
			"39.69,16.56 41.04,17.48 41.69,16.28 40.89,17.07 39.73,16.45",
			"20.24,27.39 18.89,26.46 18.24,27.67 19.04,26.88 20.2,27.49",
			"25.14,36.34 27.95,32.44 24.32,30.14 24.92,30.99 24.16,33.82 26.16,34.64 25.11,36.32",
			"14.77,26.41 15.39,25.8 14.92,25.39 14.91,24.29 15.65,23.96 14.91,23.76 14.91,22.69 15.65,22.25 14.95,22.25 14.77,21.65 14.09,22.41 14.65,22.68 14.64,23.79 14.09,24.01 14.64,24.27 14.65,25.37 14.09,25.65 14.72,26.32",
			"3.93,19.46 3.99,20.51 4.13,19.84 5.52,19.8 7.43,19.8 7.68,20.47 7.56,19.28 4.1,19.32",
			"10.07,18.45 9.76,19.09 8.35,19.09 8.05,18.44 7.95,19.56 7.39,19.72 7.95,19.89 7.65,20.14 8.05,21.01 8.35,20.35 9.76,20.35 10.12,20.94 10.19,19.89 10.76,19.71 10.16,19.55 10.13,18.55",
			"10.21,19.46 10.27,20.51 10.41,19.84 11.8,19.8 13.72,19.8 13.96,20.47 13.84,19.28 10.38,19.32"
		],
		markers: [
			{
				kind: "expansion",
				x: 12.76,
				y: 9.11
			},
			{
				kind: "home",
				x: 10.07,
				y: 37.31,
				owner: "attacker"
			},
			{
				kind: "centre",
				x: 30.76,
				y: 24.38
			},
			{
				kind: "expansion",
				x: 47.29,
				y: 34.83
			},
			{
				kind: "home",
				x: 49.94,
				y: 6.61,
				owner: "defender"
			}
		]
	},
	{
		id: "re-re-a",
		letter: "A",
		a: "Reconnaissance",
		b: "Reconnaissance",
		label: "Reconnaissance (mirror)",
		edge: "Long edge",
		zones: [{
			side: "attacker",
			points: "59.86,35.99 30.02,35.99 30.02,30.01 0.14,30.01 0.14,43.96 59.86,43.96"
		}, {
			side: "defender",
			points: "59.86,0.04 0.13,0.04 0.13,8.02 30.02,8.02 30.02,13.99 59.86,13.99"
		}],
		terrain: [
			"47.96,22.03 47.96,25.4 47.5,26.62 47.96,29.92 47.38,30.55 47.96,33.61 54.99,33.61 54.99,22.03",
			"16.58,31.95 13.21,31.95 11.99,31.49 8.7,31.95 8.07,31.36 5.01,31.95 5.01,38.98 16.58,38.98",
			"30.49,37.77 32.05,39 34.54,35.86 35.23,35.36 35.8,34.27 34.25,33.04 32.08,35.76 31.17,36.13",
			"17.58,29.62 16.52,31.99 21.55,34.23 23.06,34.9 25.67,36.06 26.72,33.69 19.95,30.68 19.55,29.88",
			"52.07,35.99 50.03,35.61 48.6,35.99 46.04,35.99 45.48,38.07 46.03,38.93 46.04,39.96 52.07,39.96",
			"36.95,20.84 34.58,21.32 33.5,22.47 28.85,25.26 27.77,26.42 25.38,26.89 25.38,28.93 36.95,28.93",
			"36.94,32.75 35.7,34.31 38.84,36.81 38.91,37.23 40.42,38.07 41.66,36.51 38.94,34.35 38.57,33.43",
			"14.17,8.04 12.13,8.42 10.7,8.04 8.13,8.04 7.58,5.99 8.13,5.1 8.13,4.07 14.17,4.07",
			"29.56,6.23 28,4.99 25.5,8.13 25.08,8.21 24.24,9.72 25.8,10.96 27.97,8.23 28.88,7.87",
			"23.09,11.24 24.33,9.69 21.19,7.19 19.6,5.93 18.37,7.48 21.09,9.65 21.45,10.57 22.37,10.66",
			"11.97,21.96 11.97,18.59 12.43,17.37 11.97,14.07 12.56,13.44 11.97,10.38 4.94,10.38 4.94,21.96",
			"43.48,12.04 46.85,12.04 48.07,12.5 51.37,12.04 52,12.62 55.06,12.04 55.06,5.01 43.48,5.01",
			"11.97,25.92 14.02,26.3 15.44,25.92 18.01,25.92 18.56,23.87 18.01,22.98 18.01,21.95 11.97,21.95",
			"22.43,23.07 24.81,22.59 25.89,21.45 30.54,18.65 31.62,17.49 34.01,17.02 34.01,14.98 22.43,14.98",
			"42.51,14.33 43.63,11.99 38.66,9.62 37.17,8.91 34.59,7.68 33.48,10.02 40.17,13.21 40.54,14.01",
			"47.98,18.12 45.93,17.75 44.51,18.12 41.94,18.12 41.39,20.2 41.94,21.07 41.94,22.1 47.98,22.1"
		],
		ruins: [
			"48.28,26.99 48.22,33.26 51.28,33.26 51.28,32.82 50.54,32.71 49.82,29.57 48.85,29.45 48.6,26.96",
			"54.38,27.21 54.52,22.39 48.39,22.76 50.64,23.13 51.49,24.75 53.97,25.32 54.36,27.24",
			"8.09,32.38 5.48,32.25 5.45,33.88 5.82,33.74 5.69,32.73 8.13,32.55",
			"15.98,35.15 16.05,32.53 9.74,32.59 11.83,32.95 11.58,34.5 12.46,35.48 13.58,35.19 14.12,35.59 14.99,34.85 15.88,35.21",
			"30.82,39.77 35.63,34.29 35.66,33.45 34.77,33.58 35.03,32.87 34.17,33.12 34.23,33.79 32.82,34.81 33.07,35.12 31.69,36.24 31.91,36.61 31.23,37.57 30.55,37.67 30.53,38.59 31.43,38.56 30.6,39.55",
			"17.19,30.49 16.82,31.48 17.23,30.92 18.76,31.55 20.24,32.22 20.14,32.96 20.59,31.8 17.26,30.47",
			"23.17,32.1 22.62,32.56 21.38,31.94 21.3,31.26 20.83,32.21 20.18,32.17 20.63,32.46 20.33,33.58 21.09,33.19 22.18,33.75 22.16,34.4 22.74,33.43 23.33,33.5 22.91,33.16 23.23,32.19",
			"22.93,33.04 22.56,34.04 23.11,33.49 25.98,34.77 25.88,35.51 26.32,34.36 22.99,33.03",
			"47.99,36.57 46.41,36.44 46.61,39.37 47.01,38.83 46.81,36.75 48.07,36.74",
			"50.01,39.51 51.77,39.46 51.79,36.76 51.18,37.36 51.34,39.13 49.97,39.47",
			"25.88,27.01 25.87,28.64 27.23,28.51 26.13,28.29 25.99,26.98",
			"31.52,28.25 36.33,28.41 36.2,24.07 35.83,25.09 34.9,25.09 33.45,26.22 33.12,25.99 33.49,28.16 31.65,28.09",
			"40.47,36.97 40.3,36.05 39.74,36.21 38.9,35.54 39.03,34.69 38.49,35.21 37.61,34.45 38,33.87 36.79,33.96 36.92,35.02 37.48,34.74 38.34,35.44 38.17,36.01 38.72,35.74 39.58,36.41 39.45,37.03 40.37,36.96",
			"9.98,4.59 8.4,4.45 8.6,7.39 9.01,6.84 8.8,4.76 10.06,4.75",
			"12.11,7.74 13.87,7.7 13.89,4.99 13.28,5.59 13.44,7.37 12.07,7.7",
			"29.23,4.22 27.82,5.28 27.97,5.75 27.23,6.68 26.74,6.63 26.86,7.13 26.11,8.11 25.64,8.06 24.97,9.55 24.36,9.68 24.39,10.54 25.14,10.39 24.95,11.09 25.82,10.85 26.53,9.3 26.96,9.41 26.92,8.84 28.3,7.73 28.08,7.36 28.82,6.42 29.44,6.29 29.46,5.37 28.61,5.44 29.39,4.42",
			"19.51,6.99 19.68,7.92 20.23,7.76 21.07,8.43 20.73,9.1 21.49,8.76 22.37,9.51 21.98,10.09 23.19,10.01 23.06,8.95 22.49,9.22 21.96,8.8 21.81,7.95 21.26,8.23 20.4,7.55 20.52,6.93 19.6,7.01",
			"5.57,16.75 5.44,21.57 11.56,21.19 9.32,20.82 8.47,19.2 5.85,18.53 5.6,16.72",
			"11.58,16.98 11.64,10.71 8.58,10.71 8.58,11.15 9.32,11.25 10.04,14.39 11.01,14.52 11.25,17.01",
			"44.09,8.84 44.02,11.46 50.33,11.4 48.24,11.04 48.49,9.49 47.61,8.5 46.49,8.8 45.95,8.4 45.08,9.13 44.19,8.78",
			"51.75,11.4 54.36,11.53 54.39,9.9 54.02,10.04 54.15,11.05 51.71,11.23",
			"17.23,24.37 16.57,23.8 13.69,23.8 13.01,24.6 13.28,25.21 15.02,25.47 16.65,25.34 17.19,24.81",
			"16.48,22.99 15.18,22.56 13.79,22.9 14.91,24.03 16.41,23.07",
			"27.65,15.44 22.84,15.28 22.97,19.62 23.34,18.6 24.27,18.6 25.72,17.47 26.05,17.7 25.67,15.54 27.52,15.6",
			"33.51,17.01 33.52,15.38 32.16,15.51 33.26,15.73 33.4,17.04",
			"37.25,10.82 37.65,9.83 36.96,10.31 34.25,9.01 34.37,8.27 33.89,9.42 37.19,10.83",
			"36.94,11.79 37.47,11.29 38.83,11.87 38.83,12.64 39.33,11.7 39.91,11.8 39.47,11.4 39.85,11.34 39.87,10.35 39.31,10.82 38.04,10.21 37.97,9.52 37.45,10.44 36.86,10.35 37.33,10.76 36.92,11.72",
			"42.92,13.52 43.32,12.54 42.82,13.1 41.38,12.42 39.92,11.71 40.04,10.97 39.56,12.12 42.86,13.54",
			"43.47,21 44.04,21.42 46.16,21.03 44.62,19.96 44.35,20.73 43.54,20.92",
			"42.72,19.62 43.38,20.18 44.76,20.3 46.78,19.97 46.94,19.39 46.43,18.67 44.83,18.52 44.11,18.9 43.3,18.64 42.76,19.17"
		],
		markers: [
			{
				kind: "expansion",
				x: 49.59,
				y: 27.97
			},
			{
				kind: "home",
				x: 10.64,
				y: 33.58,
				owner: "attacker"
			},
			{
				kind: "centre",
				x: 31.17,
				y: 25.13
			},
			{
				kind: "expansion",
				x: 10.34,
				y: 16.02
			},
			{
				kind: "home",
				x: 49.42,
				y: 10.41,
				owner: "defender"
			},
			{
				kind: "centre",
				x: 28.22,
				y: 18.78
			}
		]
	},
	{
		id: "re-re-b",
		letter: "B",
		a: "Reconnaissance",
		b: "Reconnaissance",
		label: "Reconnaissance (mirror)",
		edge: "Short edge",
		zones: [{
			side: "attacker",
			points: "30.02,43.96 0.13,0.04 0.14,43.96"
		}, {
			side: "defender",
			points: "59.86,43.96 59.86,0.04 29.98,0.04"
		}],
		terrain: [
			"15.86,35.01 13.93,32.25 13.6,30.98 11.34,28.55 11.46,27.7 9.22,25.52 3.46,29.56 10.1,39.04",
			"6.9,8.02 8.84,10.78 9.16,12.05 11.42,14.48 11.31,15.33 13.54,17.51 19.3,13.47 12.66,3.99",
			"23.04,11.04 25.03,11.04 25.03,7.02 25.31,6.71 25.03,5 23.04,5 23.04,8.48 22.55,9.34",
			"25.05,13.03 27.1,13.41 28.52,13.03 31.09,13.03 31.64,10.96 31.09,10.09 31.09,9.06 25.05,9.06",
			"37.42,14.04 40.02,14.04 40.02,8.53 40.02,6.88 40.02,4.02 37.42,4.02 37.42,11.44 36.86,12.12",
			"37.37,16.09 37.37,14.1 41.38,14.1 41.7,13.81 43.41,14.1 43.41,16.09 39.92,16.09 39.07,16.58",
			"24.15,27.98 25.93,26.34 26.27,24.81 28.82,20.02 29.15,18.47 30.95,16.83 29.9,15.08 19.98,21.04",
			"53.11,35.95 51.18,33.19 50.86,31.93 48.59,29.49 48.71,28.64 46.47,26.46 40.71,30.5 47.35,39.98",
			"36.02,16.14 34.21,17.74 33.85,19.27 31.21,24.01 30.86,25.56 29.03,27.16 30.05,28.93 40.07,23.14",
			"44.08,9.04 46.02,11.81 46.34,13.07 48.6,15.5 48.49,16.36 50.72,18.53 56.48,14.5 49.84,5.01",
			"36.94,33.02 34.95,33.02 34.95,37.04 34.66,37.36 34.95,39.07 36.94,39.07 36.94,35.58 37.43,34.73",
			"34.92,31.14 32.88,30.77 31.46,31.14 28.89,31.14 28.34,33.19 28.89,34.11 28.89,35.12 34.92,35.12",
			"50.45,26.29 50.68,24.2 50.21,22.83 50.03,20.27 47.92,19.86 47.1,20.47 46.07,20.55 46.49,26.57",
			"9.54,17.81 9.38,19.89 9.9,21.26 10.17,23.82 12.27,24.15 13.12,23.51 14.12,23.4 13.49,17.4",
			"22.77,29.99 20.18,29.99 20.18,35.5 20.18,37.15 20.18,40.01 22.77,40.01 22.77,32.59 23.33,31.91",
			"22.82,27.94 22.82,29.93 18.81,29.93 18.49,30.22 16.79,29.93 16.79,27.94 20.27,27.94 21.12,27.45"
		],
		ruins: [
			"10.71,28.4 9.32,26.18 8.16,26.78 8,27.31 9.02,26.63 9.4,26.89 10.59,28.53",
			"11.2,37.38 15.35,35 11.96,29.97 11.66,30.2 12.67,32.05 11.75,33.62 12.57,36.18 11.17,37.38",
			"12.52,4.41 7.36,7.91 9.07,10.5 9.46,10.22 9.13,9.55 11.26,7.18 10.79,6.32 12.72,4.69",
			"16.66,14.86 18.82,13.24 15.2,8.25 16.1,10.17 14.69,10.86 14.4,12.25 15.27,12.89 15.26,13.56 16.34,13.84 16.57,14.78",
			"23.45,3.72 23.42,5.05 23.01,5.33 23.42,5.72 23.01,7.26 23.43,7.55 23.41,8.78 23.04,8.87 23.43,10.54 23.03,11 23.59,11.68 24.09,11.06 24.38,11.76 24.9,11.04 24.51,10.56 24.52,9.31 24.9,9.21 24.52,7.48 24.9,7.05 24.5,6.89 24.9,5.22 24.39,4.48 23.73,5.07 23.69,3.76",
			"27.1,9.39 25.34,9.43 25.32,12.14 25.93,11.53 25.77,9.76 27.14,9.42",
			"29.33,12.48 30.92,12.62 30.71,9.68 30.31,10.23 30.52,12.31 29.25,12.32",
			"37.41,8.03 38.06,8.34 38.06,9.76 37.46,10.11 38.53,10.15 38.69,10.71 38.86,10.15 39.08,10.46 39.98,10.05 39.32,9.75 39.32,8.34 39.91,7.98 38.86,7.91 38.69,7.34 38.52,7.94 37.53,7.96",
			"38.43,14.17 39.49,14.11 38.77,13.9 38.77,10.67 39.49,10.47 38.25,10.53 38.41,14.13",
			"38.43,7.89 39.49,7.82 38.77,7.62 38.77,4.39 39.49,4.19 38.25,4.25 38.41,7.85",
			"37.92,15.1 38.54,15.72 38.96,15.24 40.05,15.24 40.13,15.98 40.56,15.24 41.72,15.27 42.08,15.98 42.08,15.28 42.68,15.16 41.92,14.42 41.66,14.97 40.55,14.97 40.33,14.42 40.07,14.97 38.94,14.97 38.68,14.42 38.05,14.97",
			"24.76,18.78 20.56,21.13 22.89,24.75 22.7,23.72 24.59,21.48 23.12,19.89 24.78,18.81",
			"30.59,17.14 29.78,15.71 28.67,16.51 29.74,16.15 30.51,17.22",
			"43.46,29.1 41.29,30.74 44.9,35.73 44,33.81 45.41,33.12 45.7,31.72 44.79,31.07 44.84,30.42 43.76,30.13 43.54,29.2",
			"47.41,39.37 52.58,35.82 50.87,33.27 50.47,33.56 50.79,34.23 48.66,36.61 49.1,37.53 47.21,39.1",
			"29.51,26.98 30.39,28.36 31.46,27.5 30.41,27.92 29.59,26.9",
			"35.18,25.22 39.43,22.95 37.17,19.29 37.33,20.32 35.41,22.52 36.85,24.14 35.17,25.19",
			"48.54,6.64 44.52,9.23 48.16,14.08 48.45,13.83 47.34,12.04 48.25,10.39 47.23,7.91 48.57,6.64",
			"49.3,15.51 50.61,17.77 52,16.91 51.68,16.68 50.93,17.34 49.43,15.39",
			"36.52,40.34 36.55,39.02 36.97,38.74 36.55,38.35 36.97,36.8 36.55,36.51 36.94,34.87 36.55,34.69 36.55,33.53 36.95,33.07 36.39,32.38 35.88,33 35.6,32.3 35.07,33.02 35.47,33.51 35.45,34.76 35.07,34.86 35.46,35.28 35.07,37.02 35.47,37.17 35.47,38.35 35.07,38.85 35.59,39.58 36.25,39 36.29,40.3",
			"30.76,31.58 29.17,31.45 29.37,34.38 29.78,33.84 29.57,31.76 30.84,31.75",
			"32.88,34.68 34.64,34.63 34.66,31.93 34.05,32.53 34.21,34.3 32.84,34.64",
			"47.24,22.15 46.96,23.44 47.44,24.82 47.83,23.87 48.74,23.56 47.38,22.27",
			"48.54,21.24 48.06,21.95 48.35,24.79 49.21,25.41 49.81,25.07 49.88,23.38 49.59,21.74 48.99,21.24",
			"11.63,22.79 12.09,22.07 11.7,19.24 10.81,18.65 10.22,19.01 10.23,20.84 10.57,22.33 11.18,22.81",
			"12.89,21.84 13.13,20.53 12.6,19.17 12.25,20.14 11.27,20.59 12.44,21.02 12.83,21.81",
			"21.76,36.14 20.7,36.2 21.42,36.41 21.42,39.64 20.7,39.84 21.94,39.78 21.79,36.18",
			"21.76,29.85 20.7,29.92 21.42,30.13 21.42,33.36 20.7,33.56 21.94,33.49 21.79,29.9",
			"22.78,36 22.13,35.69 22.13,34.27 22.73,33.92 21.67,33.88 21.5,33.32 21.34,33.88 21.12,33.57 20.21,33.98 20.88,34.28 20.88,35.69 20.28,36.05 21.34,36.12 21.51,36.69 21.67,36.09 22.66,36.06",
			"22.16,29.04 21.54,28.42 21.13,28.9 20.03,28.9 19.95,28.16 19.52,28.9 18.36,28.87 18.01,28.16 18.01,28.85 17.4,28.98 18.16,29.72 18.42,29.16 19.53,29.16 19.75,29.72 20.01,29.16 21.14,29.16 21.4,29.72 22.04,29.16"
		],
		markers: [
			{
				kind: "home",
				x: 11.12,
				y: 31.08,
				owner: "attacker"
			},
			{
				kind: "expansion",
				x: 11.64,
				y: 11.95
			},
			{
				kind: "centre",
				x: 26.89,
				y: 21.32
			},
			{
				kind: "expansion",
				x: 48.37,
				y: 32.02
			},
			{
				kind: "centre",
				x: 33.16,
				y: 22.74
			},
			{
				kind: "home",
				x: 48.82,
				y: 12.98,
				owner: "defender"
			}
		]
	},
	{
		id: "re-re-c",
		letter: "C",
		a: "Reconnaissance",
		b: "Reconnaissance",
		label: "Reconnaissance (mirror)",
		edge: "Short edge",
		zones: [{
			side: "attacker",
			points: "0.19,43.96 20.02,43.96 20.02,22.02 12.06,22.02 12.06,0.04 0.19,0.04"
		}, {
			side: "defender",
			points: "59.86,0.04 40.03,0.04 40.03,21.98 47.98,21.98 47.98,43.96 59.86,43.96"
		}],
		terrain: [
			"5.07,26.39 5.07,29.76 4.61,30.98 5.07,34.27 4.48,34.9 5.07,37.97 12.1,37.97 12.1,26.39",
			"14.04,4.04 14.04,7.41 13.58,8.63 14.04,11.92 13.45,12.55 14.04,15.62 21.07,15.62 21.07,4.04",
			"48,24.04 47.63,26.09 48,27.51 48,30.08 50.05,30.63 50.97,30.08 51.98,30.08 51.98,24.04",
			"29,12.95 31.05,13.33 32.47,12.95 35.04,12.95 35.59,10.9 35.04,10.01 35.04,8.98 29,8.98",
			"28.95,5.02 26.96,5.02 26.96,9.04 26.68,9.36 26.96,11.06 28.95,11.06 28.95,7.58 29.44,6.73",
			"29.9,27.92 30.01,25.49 29.16,24.17 27.58,18.98 26.71,17.65 26.83,15.22 24.85,14.73 22.05,25.96",
			"30.24,15.93 30.09,18.35 30.92,19.68 32.41,24.9 33.25,26.24 33.09,28.67 35.06,29.2 38.05,18.02",
			"12.05,20.07 12.42,18.02 12.05,16.6 12.05,14.03 9.99,13.48 9.11,14.02 8.07,14.03 8.07,20.07",
			"54.98,17.63 54.98,14.26 55.44,13.04 54.98,9.75 55.56,9.12 54.98,6.05 47.95,6.05 47.95,17.63",
			"46.04,40.02 46.04,36.65 46.5,35.43 46.04,32.13 46.63,31.51 46.04,28.44 39.01,28.44 39.01,40.02",
			"38.73,16.03 41.08,17.13 43.4,12.14 44.1,10.64 45.31,8.05 42.96,6.95 39.82,13.68 39.03,14.06",
			"45.24,21.79 46.23,20.07 42.75,18.06 42.62,17.65 41,17.05 40.01,18.77 43.02,20.51 43.52,21.36",
			"21.43,28 19.08,26.91 16.76,31.9 16.06,33.39 14.85,35.98 17.2,37.08 20.34,30.36 21.13,29.97",
			"14.9,22.23 13.91,23.95 17.38,25.95 17.52,26.36 19.14,26.97 20.13,25.25 17.12,23.5 16.62,22.65",
			"31.06,31.17 29.02,30.8 27.6,31.17 25.03,31.17 24.47,33.25 25.02,34.11 25.03,35.15 31.06,35.15",
			"31.11,38.99 33.1,38.99 33.1,34.98 33.38,34.66 33.1,32.95 31.11,32.95 31.11,36.43 30.62,37.29"
		],
		ruins: [
			"11.51,31.56 11.64,26.74 5.52,27.11 7.76,27.48 8.61,29.18 9.28,29 9.49,29.45 9.63,29.09 11.23,29.77 11.49,31.59",
			"9.02,37.49 11.63,37.63 11.66,35.99 11.29,36.13 11.42,37.14 8.98,37.32",
			"20.52,4.52 14.33,4.42 14.24,7.52 14.68,7.52 14.8,6.78 17.93,6.06 18.07,5.06 20.55,4.83",
			"17.95,15.15 20.57,15.22 20.51,8.91 20.15,11 18.6,10.75 17.6,11.63 17.91,12.75 17.51,13.29 18.23,14.14 17.88,15.04",
			"48.85,25.73 48.43,27.02 48.72,28.35 49.89,26.88 49.18,26.6 48.98,25.88",
			"50.23,24.96 49.68,25.62 49.67,28.48 50.47,29.18 51.1,28.9 51.34,27.09 51.22,25.57 50.69,25.01",
			"30.96,9.3 29.19,9.34 29.17,12.05 29.78,11.45 29.62,9.67 30.99,9.34",
			"33.16,12.28 34.74,12.42 34.54,9.49 34.14,10.03 34.34,12.11 33.08,12.12",
			"27.49,3.66 27.46,4.98 27.04,5.26 27.46,5.65 27.04,7.2 27.46,7.48 27.07,9.13 27.46,9.31 27.46,10.47 27.07,10.93 27.62,11.62 28.13,11 28.37,11.7 28.94,10.97 28.54,10.49 28.56,9.24 28.94,9.14 28.55,8.72 28.94,6.98 28.54,6.83 28.54,5.65 28.94,5.15 28.42,4.42 27.76,5 27.72,3.69",
			"23.99,20.86 22.68,25.5 26.92,26.42 26.02,25.82 25.8,22.97 23.61,22.81 24.12,21.04",
			"26.56,15.82 25.09,15.34 24.77,16.77 25.25,15.76 26.56,15.93",
			"33.17,27.92 34.54,28.47 35.02,28.01 34.97,27 34.47,28.01 33.17,27.81",
			"36,23.27 37.41,18.73 33.18,17.67 34.06,18.29 34.24,21.14 36.42,21.33 35.88,23.1",
			"9.81,19.14 10.37,18.49 10.38,15.63 9.58,14.92 8.95,15.2 8.7,16.87 8.83,18.54 9.36,19.09",
			"11.2,18.37 11.62,17.09 11.33,15.76 10.15,16.82 11.07,18.23",
			"51.07,6.51 48.46,6.37 48.28,7.67 48.62,8.11 48.67,6.85 51.1,6.68",
			"48.54,12.46 48.4,17.28 54.53,16.91 52.28,16.54 51.43,14.84 50.77,15.02 50.56,14.57 50.42,14.92 48.81,14.24 48.56,12.43",
			"41.91,28.91 39.25,28.99 39.35,35.15 39.71,33.06 41.26,33.31 42.3,32.33 41.95,31.31 42.35,30.77 41.63,29.92 41.98,29.02",
			"39.55,39.42 45.74,39.51 45.82,36.41 45.38,36.41 45.27,37.15 42.13,37.87 41.99,38.87 39.51,39.11",
			"39.68,16.5 40.63,16.89 40.1,16.4 41.47,13.47 42.2,13.59 41.12,13.1 39.67,16.45",
			"41.34,10.51 41.81,11.05 41.21,12.34 40.52,12.41 41.46,12.89 41.38,13.47 41.77,13.03 41.85,13.41 42.83,13.42 42.35,12.87 42.95,11.58 43.64,11.51 42.71,11 42.8,10.41 42.4,10.88 41.44,10.47",
			"42.33,10.8 43.37,11.09 42.76,10.7 44.12,7.77 44.86,7.9 43.7,7.43 42.33,10.76",
			"41.25,18.29 41.56,19.18 42.08,18.94 43.01,19.48 42.77,20.2 43.36,19.74 44.4,20.28 44.4,21.14 44.85,20.54 45.34,20.73 45.05,19.7 44.54,20.06 43.58,19.5 43.67,18.9 43.17,19.26 42.21,18.72 42.25,18.08 41.35,18.3",
			"17.83,33.23 16.88,32.84 17.4,33.33 16.94,34.33 16.04,36.26 15.31,36.21 16.38,36.63 17.83,33.28",
			"18.82,33.53 18.35,32.98 18.95,31.7 19.64,31.63 18.7,31.14 18.74,30.49 18.39,31 18.31,30.62 17.33,30.61 17.81,31.16 17.21,32.45 16.52,32.52 17.44,33.03 17.36,33.62 17.71,33.21 18.72,33.56",
			"20.48,27.53 19.53,27.14 20.06,27.64 18.69,30.56 17.95,30.44 19.04,30.93 20.48,27.58",
			"18.89,25.73 18.59,24.84 18.07,25.08 17.14,24.54 17.22,23.73 16.67,24.28 15.74,23.74 15.75,22.88 15.3,23.48 14.81,23.29 15.1,24.32 15.61,23.97 16.57,24.52 16.48,25.12 17.35,24.97 17.93,25.31 17.9,25.94 18.8,25.73",
			"26.91,31.73 25.32,31.6 25.53,34.53 25.93,33.98 25.72,31.91 26.99,31.89",
			"29.11,34.82 30.87,34.78 30.89,32.08 30.28,32.68 30.44,34.45 29.07,34.79",
			"32.58,40.36 32.61,39.03 33.02,38.75 32.61,38.36 33.02,36.82 32.6,36.53 32.62,35.3 32.99,35.21 32.6,33.54 33,33.08 32.44,32.4 31.94,33.02 31.65,32.32 31.13,33.04 31.52,33.52 31.51,34.77 31.13,34.87 31.51,36.6 31.13,37.03 31.53,37.19 31.13,38.86 31.64,39.6 32.3,39.01 32.34,40.32"
		],
		markers: [
			{
				kind: "home",
				x: 6.7,
				y: 32.33,
				owner: "attacker"
			},
			{
				kind: "expansion",
				x: 15.67,
				y: 9.98
			},
			{
				kind: "centre",
				x: 27.14,
				y: 21.27
			},
			{
				kind: "centre",
				x: 32.89,
				y: 22.62
			},
			{
				kind: "home",
				x: 53.35,
				y: 11.69,
				owner: "defender"
			},
			{
				kind: "expansion",
				x: 44.41,
				y: 34.08
			}
		]
	},
	{
		id: "re-pa-a",
		letter: "A",
		a: "Reconnaissance",
		b: "Priority Assets",
		label: "Priority Assets vs Reconnaissance",
		edge: "Short edge",
		zones: [{
			side: "attacker",
			points: "30.03,43.96 0.13,0.04 0.14,0.04 0.14,43.96"
		}, {
			side: "defender",
			points: "59.88,43.96 59.88,0.04 29.99,0.04 59.86,43.96"
		}],
		terrain: [
			"18.48,13.66 16.59,10.87 16.27,9.57 14.06,7.13 14.17,6.24 12,4.06 6.17,8 12.64,17.6",
			"15.56,29.98 12.16,29.98 10.87,29.54 7.66,29.98 7,29.4 3.98,29.98 3.98,37.02 15.56,37.02",
			"35.81,18.94 33.43,19.42 32.36,20.56 27.69,23.37 26.64,24.5 24.24,24.98 24.24,27.03 35.81,27.03",
			"24.23,25 26.61,24.52 27.73,23.35 32.36,20.58 33.43,19.42 35.81,18.96 35.81,16.92 24.23,16.92",
			"23.92,31.85 21.33,31.85 21.33,37.36 21.33,39.01 21.33,41.86 23.92,41.86 23.92,34.45 24.48,33.72",
			"22.48,29.42 23.9,29.84 23.9,31.83 19.89,31.83 19.59,32.11 17.86,31.83 17.86,29.84 21.34,29.84",
			"41.48,30.36 43.36,33.16 43.68,34.46 45.89,36.9 45.78,37.79 47.95,39.96 53.78,36.03 47.31,26.43",
			"44.34,14.03 47.71,14.03 49.03,14.48 52.23,14.03 52.66,14.54 55.92,14.03 55.92,7 44.34,7",
			"37.47,33.67 36.98,31.97 35,31.97 35,35.99 34.71,36.33 35,38.01 36.98,38.01 36.98,34.53",
			"34.95,30.05 32.87,29.68 31.48,30.05 28.91,30.05 28.36,32.11 28.91,33.02 28.91,34.03 34.95,34.03",
			"25.19,14.09 27.26,14.47 28.65,14.09 31.22,14.09 31.77,12.08 31.22,11.13 31.22,10.12 25.19,10.12",
			"22.61,10.49 23.09,12.11 25.08,12.11 25.08,8.09 25.36,7.75 25.08,6.07 23.09,6.07 23.09,9.55",
			"36.04,11.99 38.64,11.99 38.64,6.48 38.64,4.83 38.64,1.97 36.04,1.97 36.04,9.39 35.56,9.81",
			"37.74,14.57 36.04,14.07 36.04,12.09 40.05,12.09 40.28,11.81 42.08,12.09 42.08,14.07 38.6,14.07",
			"43.74,21.59 44.66,23.49 45.78,24.4 47.29,26.48 49.31,25.69 49.69,24.73 50.51,24.14 46.96,19.26",
			"16.22,22.42 15.34,20.57 14.19,19.62 12.67,17.54 10.65,18.33 10.28,19.28 9.46,19.88 13.01,24.76"
		],
		ruins: [
			"13.85,15.87 17.96,13.42 14.48,8.45 14.19,8.69 15.23,10.52 14.35,12.25 15.2,14.65 13.82,15.87",
			"12.16,4.49 6.94,7.93 8.6,10.55 9,10.24 8.68,9.57 10.86,7.23 10.44,6.31 12.35,4.77",
			"4.49,33.7 4.35,36.31 5.81,36.43 5.82,35.97 4.83,36.11 4.65,33.67",
			"14.94,33.01 15.02,30.39 8.7,30.45 10.79,30.8 10.54,32.36 11.43,33.34 12.54,33.05 13.08,33.45 13.95,32.71 14.84,33.07",
			"33.79,26.5 35.25,26.67 35.59,26.11 35.29,25.15 35.06,26.26 33.76,26.39",
			"35.18,22.14 35.34,17.34 31,17.46 32.01,17.83 32.96,20.6 35.06,20.15 35.08,22.08",
			"24.67,21.77 24.52,26.57 28.86,26.44 27.85,26.08 26.9,23.3 24.8,23.75 24.78,21.83",
			"26.39,17.34 24.85,17.23 24.89,18.69 25.12,17.58 26.42,17.45",
			"22.92,31.8 21.86,31.87 22.58,32.07 22.58,35.31 21.86,35.51 23.1,35.44 22.94,31.85",
			"22.92,38.09 21.86,38.15 22.58,38.36 22.58,41.59 21.86,41.79 23.1,41.73 22.94,38.13",
			"23.94,37.95 23.29,37.64 23.29,36.22 23.89,35.87 22.83,35.82 22.66,35.26 22.49,35.82 21.43,35.87 22.03,36.23 22.03,37.64 21.44,38 22.49,38.07 22.67,38.64 22.83,38.04 23.82,38.01",
			"23.27,30.88 22.65,30.26 22.24,30.74 21.14,30.74 21.06,30 20.63,30.74 19.47,30.71 19.11,30 19.11,30.69 18.51,30.82 19.27,31.56 19.53,31 20.64,31 20.86,31.56 21.12,31 22.25,31 22.51,31.56 23.15,31",
			"46.12,27.98 42.04,30.58 45.61,35.42 45.9,35.18 44.83,33.36 45.68,31.61 44.78,29.23 46.15,27.99",
			"48.02,39.37 53.21,35.99 51.55,33.37 51.18,33.61 51.5,34.29 49.32,36.63 49.74,37.52 47.83,39.09",
			"55.39,10.32 55.53,7.71 53.89,7.67 54.06,8.04 55.05,7.91 55.23,10.35",
			"44.94,11.01 44.87,13.63 51.18,13.57 49.09,13.21 49.34,11.66 48.45,10.67 47.34,10.97 46.8,10.57 45.93,11.3 45.04,10.95",
			"36.5,39.37 36.53,38.04 36.95,37.76 36.53,37.37 36.95,35.83 36.52,35.54 36.92,33.9 36.52,33.72 36.52,32.55 36.92,32.09 36.36,31.41 35.86,32.03 35.57,31.33 35.05,32.05 35.44,32.53 35.43,33.78 35.05,33.88 35.44,35.61 35.05,36.04 35.45,36.2 35.05,37.88 35.57,38.61 36.22,38.02 36.27,39.33",
			"30.99,33.64 29.23,33.6 29.21,30.89 29.82,31.49 29.66,33.27 31.03,33.6",
			"33.13,30.51 34.72,30.37 34.52,33.31 34.11,32.76 34.32,30.68 33.05,30.67",
			"29.12,10.5 30.89,10.55 30.9,13.25 30.3,12.65 30.46,10.88 29.09,10.54",
			"26.98,13.63 25.39,13.77 25.59,10.84 26,11.38 25.79,13.46 27.06,13.39",
			"23.5,4.67 23.47,6 23.05,6.28 23.47,6.67 23.05,8.22 23.48,8.5 23.08,10.15 23.48,10.33 23.48,11.49 23.08,11.95 23.64,12.63 24.14,12.02 24.43,12.71 24.95,11.99 24.56,11.51 24.57,10.26 24.95,10.16 24.56,8.43 24.95,8 24.55,7.84 24.95,6.17 24.43,5.44 23.78,6.02 23.73,4.71",
			"37.02,12.03 38.08,11.97 37.37,11.76 37.37,8.53 38.08,8.33 36.84,8.4 37,11.99",
			"37.02,5.75 38.08,5.68 37.37,5.48 37.37,2.25 38.08,2.05 36.84,2.11 37,5.71",
			"36.01,5.89 36.65,6.2 36.65,7.62 36.06,7.97 37.12,8.01 37.35,8.62 37.45,8.01 37.67,8.32 38.57,7.91 37.91,7.61 37.91,6.2 38.51,5.84 37.45,5.77 37.28,5.2 37.11,5.8 36.12,5.82",
			"36.65,13.03 37.27,13.65 37.68,13.17 38.78,13.17 39.2,13.91 39.29,13.17 40.45,13.2 40.8,13.91 40.8,13.22 41.41,13.1 40.65,12.35 40.39,12.91 39.27,12.91 39.06,12.35 38.79,12.91 37.67,12.91 37.4,12.35 36.77,12.91",
			"46.05,20.97 45.98,21.83 46.75,22.99 47.81,24.22 48.73,24.21 49.02,23.37 48.3,22.12 47.22,20.84 46.46,20.71",
			"45.33,22.51 46.91,24.59 46.97,23.07 48.26,22.33 47.93,21.87 46.16,22.93 45.35,22.43",
			"13.9,23.04 13.96,22.18 12.29,19.87 11.23,19.77 10.89,20.36 11.67,21.86 12.75,23.13 13.51,23.27",
			"14.64,21.47 13.06,19.39 12.98,20.94 11.68,21.69 12.02,22.14 13.69,21.09 14.6,21.59"
		],
		markers: [
			{
				kind: "expansion",
				x: 13.8,
				y: 9.64
			},
			{
				kind: "home",
				x: 9.6,
				y: 31.61,
				owner: "attacker"
			},
			{
				kind: "centre",
				x: 30.03,
				y: 23.23
			},
			{
				kind: "expansion",
				x: 46.15,
				y: 34.39
			},
			{
				kind: "home",
				x: 50.27,
				y: 12.39,
				owner: "defender"
			}
		]
	},
	{
		id: "re-pa-b",
		letter: "B",
		a: "Reconnaissance",
		b: "Priority Assets",
		label: "Priority Assets vs Reconnaissance",
		edge: "Short edge",
		zones: [{
			side: "attacker",
			points: "0.19,43.96 20.02,43.96 20.02,22.02 12.06,22.02 12.06,0.04 0.19,0.04"
		}, {
			side: "defender",
			points: "59.86,0.04 40.03,0.04 40.03,21.98 47.98,21.98 47.98,43.96 59.86,43.96"
		}],
		terrain: [
			"20.17,16.58 20.17,13.21 20.63,11.99 20.17,8.7 20.75,8.07 20.17,5 13.14,5 13.14,16.58",
			"7.01,26.43 7.01,29.8 6.55,31.02 7.01,34.32 6.42,34.95 7.01,38.01 14.04,38.01 14.04,26.43",
			"49.01,25.07 48.63,27.11 49.01,28.53 49.01,31.1 51.06,31.66 51.97,31.1 52.98,31.1 52.98,25.07",
			"33.08,27.76 32.59,25.39 31.45,24.31 28.66,19.66 27.5,18.58 27.03,16.19 24.99,16.19 24.99,27.76",
			"26.95,16.2 27.43,18.58 28.57,19.65 31.37,24.31 32.53,25.39 33,27.77 35.04,27.77 35.04,16.2",
			"10.98,19.08 11.35,17.04 10.98,15.62 10.98,13.05 8.9,12.49 8.04,13.04 7,13.05 7,19.08",
			"39.97,27.41 39.97,30.78 39.51,32 39.97,35.29 39.38,35.92 39.97,38.99 47,38.99 47,27.41",
			"52.99,17.55 52.99,14.18 53.45,12.96 52.99,9.66 53.58,9.03 52.99,5.97 45.96,5.97 45.96,17.55",
			"27.06,10.97 29.04,10.97 29.04,6.95 29.33,6.64 29.04,4.93 27.06,4.93 27.06,8.41 26.57,9.27",
			"29.04,12.99 31.09,13.36 32.51,12.99 35.08,12.99 35.63,10.93 35.08,10.02 35.08,9.01 29.04,9.01",
			"42.53,13.63 40.02,14.28 38.65,8.95 38.23,7.35 37.52,4.58 40.03,3.94 41.88,11.12 42.6,11.64",
			"43.98,17.52 45.97,17.52 45.97,21.54 46.26,21.86 45.97,23.56 43.98,23.56 43.98,20.08 43.49,19.23",
			"33.14,32.96 31.15,32.96 31.15,36.97 30.86,37.29 31.15,39 33.14,39 33.14,35.52 33.63,34.66",
			"31.15,31.05 29.11,30.68 27.68,31.05 25.11,31.05 24.56,33.13 25.11,33.99 25.11,35.03 31.15,35.03",
			"15.99,26.42 14,26.42 14,22.41 13.77,21.59 14,20.38 15.99,20.38 15.99,23.86 16.48,24.72",
			"17.56,30.28 20.07,29.63 21.45,34.97 21.86,36.56 22.57,39.33 20.07,39.98 18.21,32.8 17.5,32.28"
		],
		ruins: [
			"19.78,5.52 13.59,5.42 13.5,8.52 13.94,8.52 14.06,7.78 17.2,7.06 17.34,6.06 19.81,5.82",
			"14.95,15.78 19.72,15.96 19.51,9.89 19.11,9.98 19.02,12.03 17.33,12.86 17.5,13.55 17.03,13.88 17.43,13.97 16.75,15.48 14.92,15.75",
			"13.42,29.34 13.49,26.73 7.18,26.79 9.27,27.14 9.02,28.7 9.9,29.68 11.02,29.39 11.56,29.79 12.43,29.05 13.32,29.41",
			"10.91,37.46 13.52,37.59 13.55,35.96 13.18,36.1 13.31,37.11 10.87,37.29",
			"49.97,26.85 49.56,28.14 49.89,29.53 51.02,28.4 50.1,26.99",
			"51.36,26.08 50.8,26.74 50.8,29.59 51.59,30.3 52.22,30.02 52.47,28.35 52.34,26.69 51.81,26.13",
			"26.94,16.69 25.47,16.52 25.44,17.96 25.67,16.93 26.97,16.8",
			"25.55,22.3 25.4,27.1 29.73,26.98 28.72,26.62 27.77,23.84 25.67,24.29 25.65,22.36",
			"34.53,21.41 34.68,16.6 30.35,16.73 31.36,17.09 32.31,19.87 34.41,19.42 34.43,21.34",
			"32.95,27.1 34.42,27.28 34.75,26.72 34.39,25.76 34.22,26.86 32.92,27",
			"8.63,18.07 9.18,17.41 9.19,14.56 8.4,13.85 7.76,14.13 7.52,15.8 7.64,17.46 8.18,18.02",
			"10.01,17.3 10.43,16.01 10.09,14.62 8.97,16.16 9.68,16.44 9.89,17.16",
			"45.18,28.21 40.41,28.03 40.62,34.1 41.02,34.01 41.12,31.96 42.8,31.12 42.63,30.44 43.1,30.11 42.71,30.02 43.39,28.51 45.22,28.23",
			"40.34,38.46 46.53,38.56 46.61,35.46 46.17,35.46 46.06,36.2 42.92,36.92 42.78,37.92 40.31,38.16",
			"49.28,6.49 46.67,6.36 46.55,7.81 47.01,7.85 46.88,6.84 49.32,6.66",
			"46.49,14.61 46.41,17.23 52.72,17.17 50.63,16.81 50.88,15.26 50,14.28 48.88,14.57 48.34,14.17 47.48,14.91 46.58,14.55",
			"27.55,3.57 27.52,4.9 27.11,5.17 27.52,5.56 27.11,7.11 27.53,7.4 27.51,8.63 27.14,8.71 27.53,10.39 27.13,10.84 27.69,11.53 28.19,10.91 28.48,11.61 29,10.89 28.61,10.4 28.62,9.15 29,9.05 28.62,7.33 29,6.89 28.6,6.74 29,5.06 28.49,4.33 27.93,5.03 27.79,3.61",
			"30.88,9.62 29.29,9.46 29.44,12.39 29.86,11.85 29.69,9.77 30.95,9.78",
			"33.12,12.64 34.89,12.59 34.91,9.89 34.3,10.49 34.46,12.26 33.09,12.6",
			"39.48,7.91 40.47,7.62 39.75,7.57 39.02,4.64 39.62,4.07 38.47,4.37 39.45,7.88",
			"38.53,8.3 39.23,8.44 39.57,9.82 39.08,10.3 40.12,10.09 40.42,10.59 40.44,10.01 40.73,10.25 41.51,9.64 40.79,9.51 40.45,8.13 40.94,7.64 39.9,7.83 39.6,7.32 39.58,7.86 38.58,8.23",
			"41,14.01 41.99,13.57 41.27,13.66 40.78,11.72 40.49,10.53 41.14,10.16 39.99,10.46 40.97,13.98",
			"45.02,18.18 44.4,18.79 44.87,19.2 44.87,20.3 44.13,20.63 44.87,20.83 44.87,21.9 44.13,22.34 44.84,22.34 45.02,22.94 45.7,22.18 45.14,21.91 45.15,20.8 45.7,20.57 45.15,20.32 45.14,19.22 45.7,18.94 45.07,18.27",
			"32.64,40.36 32.67,39.03 33.09,38.76 32.67,38.37 33.09,36.82 32.67,36.53 33.06,34.89 32.67,34.71 32.67,33.54 33.06,33.09 32.51,32.4 32,33.02 31.71,32.32 31.19,33.04 31.58,33.53 31.57,34.78 31.19,34.88 31.58,36.6 31.19,37.04 31.59,37.19 31.19,38.87 31.71,39.6 32.26,38.9 32.41,40.32",
			"27.07,31.4 25.31,31.45 25.29,34.15 25.9,33.55 25.74,31.78 27.11,31.44",
			"29.32,34.42 30.9,34.58 30.75,31.65 30.34,32.19 30.51,34.27 29.24,34.26",
			"14.99,25.81 15.61,25.19 15.14,24.78 15.13,23.69 15.87,23.35 15.13,23.15 15.13,22.08 15.87,21.65 15.17,21.65 15.06,21.04 14.3,21.81 14.87,22.07 14.86,23.19 14.3,23.41 14.86,23.66 14.87,24.76 14.3,25.04 14.86,25.68",
			"19.09,29.9 18.11,30.2 18.82,30.25 19.61,33.38 18.95,33.75 20.11,33.45 19.12,29.94",
			"21.56,35.62 20.86,35.47 20.52,34.1 21.01,33.61 19.97,33.83 19.67,33.32 19.65,33.91 19.36,33.66 18.63,34.21 19.3,34.41 19.64,35.78 19.07,36.23 20.19,36.08 20.5,36.59 20.51,35.97 21.52,35.68",
			"20.61,36 19.62,36.43 20.34,36.34 21.13,39.48 20.47,39.85 21.63,39.55 20.64,36.03"
		],
		markers: [
			{
				kind: "expansion",
				x: 18.54,
				y: 10.64
			},
			{
				kind: "home",
				x: 8.64,
				y: 32.37,
				owner: "attacker"
			},
			{
				kind: "centre",
				x: 28.79,
				y: 21.98
			},
			{
				kind: "expansion",
				x: 41.6,
				y: 33.35
			},
			{
				kind: "home",
				x: 51.36,
				y: 11.61,
				owner: "defender"
			}
		]
	},
	{
		id: "re-pa-c",
		letter: "C",
		a: "Reconnaissance",
		b: "Priority Assets",
		label: "Priority Assets vs Reconnaissance",
		edge: "Long edge",
		zones: [{
			side: "attacker",
			points: "30.03,30.01 0.14,30.01 0.14,43.96 14.62,43.96 30.03,43.96 59.88,43.96 59.88,35.99 30.03,35.99"
		}, {
			side: "defender",
			points: "59.88,0.04 33.24,0.04 30.03,0.04 0.13,0.04 0.13,8.02 30.03,8.02 30.03,13.99 59.88,13.99"
		}],
		terrain: [
			"55.97,27.97 52.6,27.97 51.29,27.52 48.09,27.97 47.46,27.38 44.39,27.97 44.39,35 55.97,35",
			"17.57,31.95 14.19,31.95 12.94,31.49 9.58,31.91 9,31.37 5.98,31.95 5.98,38.98 17.57,38.98",
			"23.52,33.73 25.07,32.87 26.48,34.28 23.64,37.12 23.6,37.56 22.21,38.55 20.8,37.14 23.26,34.68",
			"28.16,31.64 26.95,31.05 25.12,32.88 29.01,36.77 30.18,37.94 32.2,39.96 34.03,38.13 28.79,32.88",
			"45.03,23.75 43.39,22.42 42.78,21.11 41.11,19.16 42.35,17.37 43.36,17.23 44.13,16.58 48.05,21.17",
			"49.39,23.4 47.85,24.1 46.55,22.6 49.58,19.96 49.65,19.52 51.11,18.63 52.41,20.13 49.78,22.42",
			"35.77,18.95 33.39,19.43 32.27,20.6 27.67,23.35 26.6,24.51 24.19,24.99 24.19,27.04 35.77,27.04",
			"24.19,24.99 26.53,24.52 27.64,23.37 32.31,20.57 33.39,19.41 35.76,18.95 35.76,16.9 24.19,16.9",
			"15.52,9.16 17.59,9.54 18.98,9.16 21.55,9.16 22.1,7.15 21.55,6.2 21.55,5.19 15.52,5.19",
			"44.39,34.99 42.31,34.61 40.92,34.99 38.35,34.99 37.8,37.04 38.35,37.95 38.35,38.96 44.39,38.96",
			"36.28,10.51 34.98,11.21 33.57,9.81 36.41,6.97 36.38,6.61 37.85,5.53 39.25,6.94 36.79,9.4",
			"31.82,12.41 33.1,13.04 34.93,11.2 31.04,7.31 29.87,6.14 27.85,4.12 26.02,5.95 31.26,11.2",
			"15.12,20.39 16.76,21.72 17.38,23.03 19.04,24.98 17.87,26.7 16.79,26.91 16.02,27.56 12.1,22.97",
			"10.76,20.74 12.3,20.05 13.6,21.54 10.57,24.18 10.5,24.62 9.04,25.51 7.74,24.01 10.37,21.72",
			"42.51,12.03 45.88,12.03 47.2,12.48 50.4,12.03 51.07,12.62 54.09,12.03 54.09,5 42.51,5",
			"3.99,16.14 7.37,16.14 8.62,16.6 11.9,16.14 12.51,16.73 15.57,16.14 15.57,9.1 3.99,9.1"
		],
		ruins: [
			"55.3,33.1 55.43,28.28 49.31,28.65 51.55,29.03 52.4,30.65 55.03,31.32 55.28,33.13",
			"44.76,28.21 44.7,34.47 47.68,34.51 47.76,34.04 47.02,33.93 46.3,30.79 45.33,30.67 45.08,28.18",
			"9.09,32.36 6.48,32.22 6.45,33.86 6.82,33.72 6.69,32.71 9.13,32.53",
			"16.87,35.02 16.95,32.4 10.64,32.46 12.73,32.82 12.48,34.37 13.36,35.36 14.48,35.06 15.02,35.46 15.88,34.73 16.78,35.08",
			"25.42,34.15 24.48,34.22 24.58,34.79 23.82,35.54 23.19,35.12 23.44,35.92 22.59,36.71 21.92,36.41 22.32,37.05 22,37.47 23.07,37.46 22.87,36.87 23.65,36.09 24.2,36.33 24.28,35.45 24.76,34.97 25.36,35.17 25.39,34.24",
			"32.93,39.34 33.55,38.46 32.93,38.86 30.7,36.62 30.99,35.95 30.23,36.89 32.88,39.33",
			"28.49,34.89 29.11,34.01 28.49,34.42 26.25,32.17 26.62,31.53 25.79,32.45 28.44,34.88",
			"27.87,35.72 28.54,35.47 29.54,36.48 29.37,37.15 30.17,36.46 30.67,36.71 30.39,36.19 30.77,36.24 31.11,35.33 30.44,35.58 29.43,34.58 29.6,33.91 28.81,34.6 28.28,34.32 28.59,34.86 27.87,35.62",
			"42.99,18.26 43.01,19.12 44.9,21.27 45.96,21.27 46.25,20.64 45.27,19.16 44.13,18.06 43.36,18",
			"42.4,19.9 44.18,21.82 44.11,20.27 45.36,19.34 44.94,18.99 43.39,20.19 42.44,19.78",
			"46.44,24.59 47.48,23.75 47.95,23.9 47.98,23.34 48.89,22.57 49.36,22.72 49.38,22.15 50.72,21.54 51.68,20.22 52.3,20.21 52.44,19.36 51.65,19.38 52,18.71 51.11,18.78 50.98,19.41 50.03,20.18 49.7,19.96 48.64,21.36 48.3,21.13 47.28,22.51 46.65,22.52 46.44,23.41 47.29,23.52 46.32,24.36",
			"24.89,24.96 24.71,26.42 25.08,26.76 26.16,26.46 25.14,26.24 25,24.93",
			"30.36,26.45 35.17,26.6 35.04,22.27 34.67,23.28 33.74,23.29 32.37,24.39 31.96,24.19 32.34,26.35 30.49,26.29",
			"35.04,18.98 35.22,17.52 34.85,17.18 33.69,17.48 34.79,17.7 34.93,19.01",
			"29.58,17.49 24.77,17.34 24.9,21.67 25.27,20.66 26.19,20.65 27.57,19.55 27.98,19.75 27.6,17.59 29.44,17.65",
			"19.55,8.75 21.32,8.71 21.33,6 20.73,6.6 20.89,8.37 19.51,8.71",
			"17.38,5.73 15.79,5.6 15.99,8.53 16.4,7.98 16.19,5.9 17.45,5.89",
			"40.34,35.34 38.58,35.38 38.56,38.09 39.17,37.49 39.01,35.71 40.38,35.38",
			"42.52,38.36 44.1,38.49 43.9,35.56 43.5,36.11 43.71,38.19 42.44,38.2",
			"34.61,9.93 35.55,9.86 35.45,9.3 36.21,8.54 36.84,8.96 36.59,8.16 37.44,7.37 37.97,7.83 38.03,6.61 36.96,6.63 37.16,7.22 36.38,7.99 35.83,7.76 36.04,8.33 35.27,9.11 34.67,8.91 34.64,9.84",
			"27.1,4.74 26.48,5.62 27.1,5.22 29.34,7.47 28.97,8.11 29.8,7.19 27.15,4.76",
			"31.54,9.19 30.92,10.07 31.54,9.66 33.78,11.91 33.41,12.55 34.24,11.71 31.59,9.2",
			"32.16,8.36 31.49,8.61 30.49,7.6 30.66,6.93 29.86,7.62 29.36,7.37 29.64,7.89 29.26,7.84 28.92,8.76 29.59,8.5 30.6,9.5 30.34,10.18 31.22,9.48 31.75,9.76 31.44,9.22 32.16,8.46",
			"17.14,25.87 17.12,25.02 15.23,22.87 14.17,22.87 13.88,23.5 14.86,24.98 16,26.08 16.77,26.14",
			"17.73,24.24 15.95,22.32 16.02,23.87 14.78,24.8 15.19,25.15 16.75,23.95 17.69,24.36",
			"13.69,19.55 12.65,20.39 12.18,20.24 12.15,20.8 11.24,21.57 10.77,21.42 10.76,21.99 9.8,22.77 9.41,22.59 8.45,23.92 7.83,23.93 7.69,24.78 8.53,24.8 8.13,25.43 9.02,25.36 9.15,24.73 10.1,23.96 10.43,24.18 11.49,22.78 11.83,23.01 12.85,21.63 13.48,21.62 13.69,20.73 12.77,20.74 13.81,19.77",
			"50.88,11.61 53.49,11.75 53.52,10.11 53.15,10.25 53.28,11.26 50.84,11.44",
			"43.18,8.97 43.1,11.58 49.42,11.52 47.33,11.17 47.57,9.61 46.69,8.63 45.58,8.92 45.04,8.52 44.17,9.26 43.27,8.9",
			"4.64,11.01 4.51,15.82 10.64,15.45 8.39,15.08 7.54,13.38 6.88,13.56 6.67,13.11 6.53,13.47 4.92,12.79 4.67,10.97",
			"15.19,15.89 15.25,9.63 12.19,9.63 12.19,10.06 12.93,10.17 13.65,13.31 14.62,13.44 14.86,15.93"
		],
		markers: [
			{
				kind: "expansion",
				x: 50.02,
				y: 29.6
			},
			{
				kind: "home",
				x: 11.6,
				y: 33.57,
				owner: "attacker"
			},
			{
				kind: "centre",
				x: 29.97,
				y: 20.7
			},
			{
				kind: "home",
				x: 48.47,
				y: 10.4,
				owner: "defender"
			},
			{
				kind: "expansion",
				x: 9.94,
				y: 14.51
			}
		]
	},
	{
		id: "pa-pa-a",
		letter: "A",
		a: "Priority Assets",
		b: "Priority Assets",
		label: "Priority Assets (mirror)",
		edge: "Long edge",
		zones: [{
			side: "attacker",
			points: "30.03,30.01 0.14,30.01 0.14,43.96 14.62,43.96 30.03,43.96 59.88,43.96 59.88,35.99 30.03,35.99"
		}, {
			side: "defender",
			points: "59.88,0.04 33.24,0.04 30.03,0.04 0.13,0.04 0.13,8.02 30.03,8.02 30.03,13.99 59.88,13.99"
		}],
		terrain: [
			"44.36,11.06 47.73,11.06 49.05,11.51 52.25,11.06 52.92,11.65 55.94,11.06 55.94,4.03 44.36,4.03",
			"33.91,25.08 34.29,23.01 33.91,21.62 33.91,19.05 31.9,18.5 30.95,19.05 29.94,19.05 29.94,25.08",
			"25.95,18.99 25.57,21.07 25.95,22.46 25.95,25.03 28.05,25.58 28.91,25.03 29.92,25.03 29.92,18.99",
			"41.05,7.59 38.24,6.67 37.28,6.96 31.88,6.6 30.31,6.94 28.09,5.97 26.92,7.65 36.43,14.24",
			"19.26,36 21.44,37.05 22.99,36.78 28.41,37.35 29.96,37.08 32.14,38.14 33.37,36.51 24.12,29.54",
			"15.55,33 12.18,33 10.99,32.54 7.64,33 6.99,32.42 3.97,33 3.97,40.04 15.55,40.04",
			"44.44,33.2 47.84,33.18 49.07,33.62 52.34,33.14 52.96,33.72 56.02,33.1 55.96,26.07 44.38,26.17",
			"7.02,7.6 7.04,5.01 12.55,5.05 14.2,5.07 17.05,5.09 17.03,7.69 9.61,7.62 9.08,8.16",
			"53.08,36.45 53.06,39.04 47.55,39 45.9,38.98 43.05,38.96 43.07,36.36 50.48,36.43 51.02,35.9",
			"15.6,10.92 12.2,10.95 10.9,10.52 7.69,10.99 7.07,10.41 4.02,11.03 4.08,18.06 15.66,17.96",
			"42.31,16.99 40.9,16.06 39.38,17.34 41.96,20.42 41.96,20.86 43.26,21.97 44.78,20.69 42.54,18.02",
			"47.59,17.4 48.49,17.25 49.18,16.63 50.51,18.1 47.53,20.79 46.02,22.15 44.69,20.67 47.28,18.34",
			"19.02,27.97 20.54,26.69 17.96,23.62 17.96,23.17 16.66,22.07 15.14,23.34 17.38,26.01 17.52,26.93",
			"12.31,26.61 10.72,27.38 9.39,25.9 12.37,23.22 12.39,22.81 13.87,21.86 15.2,23.34 12.62,25.67",
			"41.03,30 39.01,29.64 37.56,30.03 34.99,30.05 34.47,32.06 35.02,33.01 35.03,34.02 41.07,33.97",
			"19.01,14.1 21.02,14.46 22.47,14.07 25.04,14.05 25.58,11.99 25.02,11.09 25.01,10.08 18.97,10.13"
		],
		ruins: [
			"55.48,7.22 55.63,4.61 54.16,4.5 54.15,4.95 55.15,4.81 55.32,7.25",
			"44.85,7.92 44.77,10.53 51.08,10.47 49,10.12 49.24,8.56 48.36,7.58 47.25,7.87 46.71,7.47 45.84,8.21 44.94,7.86",
			"31.65,24.02 32.2,23.37 32.21,20.51 31.41,19.81 30.78,20.08 30.54,21.9 30.66,23.42 31.19,23.98",
			"32.97,23.28 33.39,21.99 33.1,20.66 31.93,22.13 32.64,22.41 32.84,23.13",
			"28.3,19.83 27.75,20.49 27.74,23.34 28.54,24.05 29.17,23.77 29.41,21.96 29.29,20.44 28.76,19.88",
			"26.98,20.58 26.54,21.83 26.85,23.26 28.04,22.16 27.1,20.72",
			"28.43,6.31 27.45,7.41 27.56,7.9 28.69,8.32 27.91,7.5 28.54,6.35",
			"32.49,10.74 36.36,13.61 38.7,10.01 37.84,10.6 35.03,9.8 34.18,11.79 32.51,10.72",
			"31.79,37.78 32.78,36.48 31.61,35.76 32.36,36.61 31.68,37.73",
			"27.9,33.19 24.16,30.17 21.67,33.68 22.56,33.13 25.34,34.04 26.24,32.09 27.88,33.21",
			"4.41,36.85 4.26,39.46 5.73,39.57 5.74,39.12 4.74,39.25 4.57,36.82",
			"14.93,36.04 15.01,33.42 8.7,33.49 10.78,33.84 10.54,35.39 11.42,36.38 12.53,36.09 13.07,36.49 13.94,35.75 14.84,36.1",
			"55.24,31.16 55.37,26.35 49.25,26.72 51.49,27.09 52.34,28.71 54.96,29.38 55.22,31.2",
			"44.76,26.45 44.7,32.71 47.69,32.74 47.76,32.28 47.02,32.17 46.3,29.03 45.33,28.91 45.09,26.42",
			"16.95,6.89 16.9,5.83 16.75,6.5 15.36,6.54 13.45,6.52 13.21,5.85 13.32,7.04 16.78,7.02",
			"10.9,6.83 10.85,5.78 10.7,6.45 9.31,6.48 7.39,6.46 7.15,5.79 7.27,6.98 10.73,6.97",
			"10.94,7.52 11.21,6.94 12.67,6.89 12.96,7.54 13.08,6.42 13.63,6.27 13.08,6.09 12.99,4.97 12.68,5.63 11.27,5.62 10.98,4.95 10.84,6.07 10.27,6.24 10.86,6.41 10.88,7.41",
			"43.13,37.16 43.18,38.22 43.32,37.55 44.72,37.51 46.63,37.53 46.87,38.2 46.76,37.01 43.3,37.03",
			"49.18,37.22 49.23,38.27 49.38,37.6 50.77,37.57 52.68,37.59 52.93,38.26 52.81,37.07 49.35,37.08",
			"49.14,36.53 48.81,37.17 47.4,37.16 47.12,36.51 47,37.63 46.44,37.78 47,37.96 46.69,38.2 47.09,39.08 47.39,38.42 48.81,38.43 49.1,39.1 49.24,37.98 49.81,37.81 49.22,37.64 49.2,36.64",
			"4.55,12.89 4.42,17.7 10.54,17.33 8.3,16.96 7.45,15.34 4.83,14.67 4.57,12.86",
			"15.3,17.54 15.36,11.27 12.3,11.27 12.3,11.71 13.04,11.82 13.76,14.96 14.73,15.08 14.98,17.57",
			"38.86,16.01 39.7,17.05 39.55,17.52 40.87,18.46 40.79,19.01 41.24,18.91 42.05,19.84 41.9,20.29 43.23,21.25 43.23,21.87 44.09,22.01 44.06,21.22 44.74,21.57 44.67,20.67 43.3,19.66 43.49,19.27 42.09,18.21 42.11,17.62 41.7,17.76 40.93,16.22 40.03,16.01 40.05,16.93 39.08,15.89",
			"45.83,20.97 46.77,20.92 46.68,20.35 47.45,19.61 48.07,20.04 47.83,19.24 48.61,18.49 49.43,18.73 48.98,18.13 49.3,17.72 48.23,17.71 48.42,18.3 47.62,19.07 47.08,18.82 47.28,19.4 46.5,20.17 45.9,19.96 45.86,20.88",
			"21.04,28.03 20.21,26.98 20.36,26.51 19.79,26.49 19.03,25.58 19.18,25.11 18.66,25.13 17.85,24.19 18,23.74 16.68,22.78 16.67,22.17 15.82,22.02 15.84,22.81 15.17,22.47 15.23,23.36 16.6,24.37 16.41,24.76 17.82,25.83 17.79,26.41 18.2,26.27 18.97,27.82 19.87,28.02 19.97,27.18 20.82,28.14",
			"14.06,23.03 13.12,23.08 13.21,23.65 12.44,24.4 11.68,24.1 12.05,24.77 11.28,25.52 10.46,25.28 10.91,25.88 10.59,26.29 11.66,26.3 11.46,25.7 12.26,24.94 12.81,25.19 12.61,24.61 13.39,23.84 13.99,24.05 14.06,23.2",
			"39.09,33.63 40.86,33.6 40.9,30.9 40.29,31.5 40.43,33.27 39.06,33.59",
			"36.75,30.41 35.16,30.35 35.49,33.27 35.87,32.7 35.57,30.64 36.84,30.57",
			"20.92,10.46 19.16,10.49 19.11,13.2 19.73,12.6 19.58,10.83 20.96,10.5",
			"23.27,13.68 24.86,13.75 24.53,10.83 24.15,11.39 24.45,13.46 23.18,13.53"
		],
		markers: [
			{
				kind: "home",
				x: 50.32,
				y: 9.43,
				owner: "defender"
			},
			{
				kind: "centre",
				x: 32.34,
				y: 21.3
			},
			{
				kind: "home",
				x: 9.61,
				y: 34.63,
				owner: "attacker"
			},
			{
				kind: "expansion",
				x: 50.38,
				y: 31.52
			},
			{
				kind: "expansion",
				x: 9.65,
				y: 12.61
			}
		]
	},
	{
		id: "pa-pa-b",
		letter: "B",
		a: "Priority Assets",
		b: "Priority Assets",
		label: "Priority Assets (mirror)",
		edge: "Short edge",
		zones: [{
			side: "attacker",
			points: "30.02,43.96 0.13,0.04 0.14,43.96"
		}, {
			side: "defender",
			points: "59.86,43.96 59.86,0.04 29.98,0.04"
		}],
		terrain: [
			"32.98,18.02 30.93,17.64 29.51,18.02 26.95,18.02 26.39,20.1 26.94,20.96 26.95,22 32.98,22",
			"26.88,25.96 28.92,26.34 30.35,25.96 32.91,25.96 33.47,23.91 32.91,23 32.91,21.99 26.88,21.99",
			"41.07,9.06 42.27,11.17 42.11,12.73 43.06,18.07 42.89,19.65 44.1,21.76 42.56,23.1 34.97,14.36",
			"26.86,5.07 24.87,5.07 24.87,9.09 24.59,9.41 24.87,11.12 26.86,11.12 26.86,7.63 27.35,6.78",
			"26.98,13.01 29.02,13.39 30.44,13.01 33.01,13.01 33.57,10.96 33.02,10.07 33.01,9.04 26.98,9.04",
			"13.12,38.89 13.12,35.52 13.58,34.3 13.12,31.01 13.71,30.38 13.12,27.31 6.09,27.31 6.09,38.89",
			"39.46,30.45 41.34,33.25 41.64,34.52 43.87,36.99 43.73,37.84 45.93,40.05 51.76,36.12 45.29,26.52",
			"46.99,5.08 46.99,8.45 46.52,9.67 46.99,12.97 46.4,13.6 46.99,16.66 54.02,16.66 54.02,5.08",
			"38.12,8.08 39.69,6.85 37.21,3.69 37.24,3.26 35.97,2.09 34.4,3.32 36.55,6.06 36.68,7.04",
			"46.85,22.73 48.89,21.14 52.28,25.48 53.3,26.78 55.06,29.03 53.01,30.62 48.45,24.78 47.59,24.59",
			"32.97,38.96 34.96,38.96 34.96,34.94 35.25,34.62 34.96,32.92 32.97,32.92 32.97,36.4 32.48,37.26",
			"32.85,31.19 30.81,30.82 29.39,31.19 26.82,31.19 26.27,33.25 26.82,34.16 26.82,35.17 32.85,35.17",
			"13.15,21.35 11.11,22.95 7.72,18.61 6.71,17.31 4.95,15.06 6.99,13.46 11.56,19.31 12.42,19.5",
			"21.82,35.87 20.25,37.1 22.72,40.26 22.69,40.69 23.97,41.86 25.53,40.63 23.39,37.89 23.25,36.91",
			"18.99,35.02 17.79,32.91 17.86,30.41 17,26 17.17,24.43 15.96,22.32 17.5,20.98 25.09,29.71",
			"20.55,13.67 18.67,10.87 18.37,9.6 16.14,7.13 16.28,6.28 14.08,4.06 8.25,8 14.72,17.6"
		],
		ruins: [
			"32.02,20.31 31.35,19.74 28.48,19.74 27.8,20.54 28.06,21.15 29.81,21.41 31.43,21.28 31.97,20.75",
			"31.26,18.93 29.97,18.5 28.58,18.84 30.12,19.97 30.38,19.26 31.2,19.01",
			"28.6,25.06 29.89,25.48 31.28,25.14 30.16,24.02 28.66,24.98",
			"27.84,23.68 28.51,24.24 31.38,24.24 32.06,23.45 31.55,22.73 30.05,22.58 28.43,22.7 27.89,23.23",
			"39.53,11.38 35.8,14.42 38.72,17.58 38.36,16.6 39.83,14.07 38.11,12.78 39.56,11.41",
			"41.49,20.98 42.55,22.22 43.49,21.22 42.51,21.78 41.55,20.88",
			"25.29,3.68 25.26,5.01 24.84,5.29 25.26,5.68 24.84,7.22 25.27,7.51 24.87,9.15 25.27,9.33 25.27,10.5 24.87,10.96 25.43,11.64 25.93,11.02 26.17,11.72 26.74,11 26.35,10.52 26.36,9.27 26.74,9.17 26.35,7.44 26.74,7.01 26.34,6.85 26.74,5.17 26.22,4.44 25.57,5.03 25.52,3.72",
			"28.99,9.34 27.22,9.38 27.2,12.09 27.81,11.48 27.65,9.71 29.02,9.37",
			"31.18,12.47 32.76,12.6 32.56,9.67 32.16,10.22 32.36,12.29 31.1,12.31",
			"12.75,30.56 12.83,27.94 6.52,28 8.61,28.36 8.36,29.91 9.24,30.9 10.35,30.6 10.9,31 11.76,30.27 12.66,30.62",
			"10.05,38.43 12.66,38.56 12.78,37.12 12.32,37.07 12.45,38.08 10.01,38.26",
			"43.99,28.06 39.92,30.58 43.49,35.5 43.78,35.25 42.7,33.44 43.55,31.69 42.66,29.31 44.02,28.07",
			"45.95,39.36 51.18,35.91 49.47,33.36 49.11,33.61 49.42,34.29 47.25,36.62 47.67,37.52 45.75,39.09",
			"50.06,5.55 47.45,5.41 47.33,6.86 47.79,6.91 47.66,5.89 50.1,5.72",
			"47.36,13.42 47.28,16.03 53.59,15.97 51.5,15.62 51.75,14.06 50.87,13.08 49.76,13.37 49.21,12.97 48.35,13.71 47.45,13.35",
			"35.71,3.17 35.6,4.01 36.9,4.93 36.41,5.51 37.14,5.3 37.89,6.2 37.39,6.77 38.64,6.93 38.71,5.9 38.1,6.04 37.42,5.16 37.72,4.64 37.13,4.78 36.45,3.92 36.72,3.36 35.81,3.21",
			"49.85,25.12 50.63,24.45 49.95,24.7 47.96,22.15 48.41,21.55 47.48,22.3 49.8,25.11",
			"49.13,25.87 49.83,25.7 50.7,26.82 50.45,27.47 51.31,26.85 51.87,27.18 51.58,26.64 51.95,26.74 52.4,25.87 51.55,25.85 50.83,24.93 51.08,24.28 50.2,24.87 49.71,24.53 49.92,25.03 49.15,25.77",
			"53.72,30.08 54.44,29.28 53.82,29.65 51.96,27.27 52.28,26.5 51.35,27.25 53.67,30.06",
			"34.54,40.35 34.57,39.03 34.99,38.75 34.57,38.36 34.99,36.81 34.57,36.52 34.59,35.29 34.96,35.21 34.57,33.53 34.97,33.08 34.41,32.39 33.91,33.01 33.62,32.31 33.1,33.03 33.49,33.52 33.48,34.77 33.1,34.86 33.48,35.29 33.1,37.03 33.49,37.18 33.49,38.36 33.1,38.86 33.61,39.59 34.27,39.01 34.31,40.31",
			"28.65,31.74 27.07,31.6 27.27,34.53 27.68,33.99 27.47,31.91 28.73,31.9",
			"30.85,34.87 32.61,34.82 32.63,32.12 32.02,32.72 32.18,34.49 30.81,34.83",
			"6.29,14.01 5.56,14.81 6.19,14.44 6.99,15.46 8.17,16.98 7.73,17.58 8.66,16.84 6.33,14.03",
			"10.87,18.22 10.17,18.38 9.3,17.26 9.55,16.62 8.69,17.24 8.21,16.9 8.43,17.45 8.05,17.35 7.6,18.21 8.31,18.04 9.18,19.16 8.93,19.81 9.8,19.21 10.29,19.55 10.05,18.98 10.85,18.31",
			"10.15,18.96 9.43,19.76 10.05,19.39 10.73,20.25 12.04,21.93 11.6,22.53 12.53,21.79 10.2,18.98",
			"24.23,40.78 24.27,39.84 23.71,39.88 23.04,39.02 23.53,38.45 22.7,38.6 22.03,37.66 22.36,36.96 21.81,37.39 21.3,37.02 21.23,38.05 21.83,37.91 22.51,38.79 22.21,39.31 23.07,39.49 23.49,40.03 23.22,40.6 24.13,40.74",
			"18.57,23.1 17.51,21.86 16.61,22.9 17.54,22.3 18.51,23.19",
			"20.52,32.69 24.26,29.65 21.34,26.49 21.7,27.48 20.23,30.01 21.95,31.3 20.5,32.67",
			"14.06,4.76 8.83,8.21 10.54,10.76 10.9,10.51 10.59,9.83 12.76,7.49 12.34,6.6 14.26,5.03",
			"16.02,16.05 20.09,13.53 16.52,8.62 16.23,8.86 17.31,10.68 16.44,12.28 17.35,14.81 15.99,16.05"
		],
		markers: [
			{
				kind: "centre",
				x: 29.2,
				y: 19.59
			},
			{
				kind: "home",
				x: 11.49,
				y: 32.95,
				owner: "attacker"
			},
			{
				kind: "expansion",
				x: 44.13,
				y: 34.47
			},
			{
				kind: "home",
				x: 48.61,
				y: 11.02,
				owner: "defender"
			},
			{
				kind: "expansion",
				x: 15.88,
				y: 9.65
			}
		]
	},
	{
		id: "pa-pa-c",
		letter: "C",
		a: "Priority Assets",
		b: "Priority Assets",
		label: "Priority Assets (mirror)",
		edge: "Short edge",
		zones: [{
			side: "attacker",
			points: "0.19,43.96 20.02,43.96 20.02,22.02 12.06,22.02 12.06,0.04 0.19,0.04"
		}, {
			side: "defender",
			points: "59.86,0.04 40.03,0.04 40.03,21.98 47.98,21.98 47.98,43.96 59.86,43.96"
		}],
		terrain: [
			"15.01,11.07 18.38,11.07 19.6,11.53 22.89,11.07 23.52,11.66 26.58,11.07 26.58,4.04 15.01,4.04",
			"7.01,39.96 7.01,36.59 6.55,35.37 7.01,32.07 6.42,31.45 7.01,28.38 14.04,28.38 14.04,39.96",
			"38.81,19.2 39.89,20.87 43.31,18.65 43.74,18.71 45.04,17.52 43.96,15.86 40.99,17.79 39.99,17.85",
			"42,29.02 44.17,27.61 41.17,22.99 40.27,21.61 38.72,19.21 36.54,20.62 40.58,26.84 40.48,27.72",
			"56.04,34.02 55.53,31.65 53.83,29.82 51.55,25.95 50.38,24.89 49.89,22.5 47.85,22.52 47.95,34.09",
			"53.04,4.03 53.04,7.4 53.5,8.62 53.04,11.92 53.62,12.55 53.04,15.61 46.01,15.61 46.01,4.03",
			"27.03,26.03 29.07,26.41 30.49,26.03 33.06,26.03 33.61,23.98 33.06,23.07 33.06,22.06 27.03,22.06",
			"33.09,18.03 31.05,17.66 29.63,18.03 27.06,18.03 26.5,20.09 27.05,20.97 27.06,22.01 33.09,22.01",
			"4.01,10.07 4.5,12.45 6.19,14.29 8.43,18.18 9.59,19.25 10.06,21.64 12.1,21.64 12.1,10.07",
			"33.1,13.14 35.14,13.52 36.56,13.14 39.13,13.14 39.69,11.09 39.14,10.2 39.13,9.17 33.1,9.17",
			"33.05,5.04 31.06,5.04 31.06,9.06 30.77,9.38 31.06,11.08 33.05,11.08 33.05,7.6 33.54,6.74",
			"27.05,30.98 25,30.61 23.58,30.98 21.01,30.98 20.46,33.04 21.01,33.95 21.01,34.96 27.05,34.96",
			"27.1,39.08 29.09,39.08 29.09,35.07 29.37,34.75 29.09,33.04 27.1,33.04 27.1,36.53 26.61,37.38",
			"21.06,24.77 20.01,23.08 16.55,25.25 16.12,25.18 14.8,26.34 15.86,28.02 18.86,26.15 19.86,26.1",
			"18.05,14.89 15.85,16.27 18.77,20.94 19.64,22.34 21.15,24.76 23.35,23.39 19.42,17.1 19.54,16.22",
			"46.03,33.03 42.66,33.03 41.44,32.57 38.15,33.03 37.52,32.45 34.45,33.03 34.45,40.07 46.03,40.07"
		],
		ruins: [
			"21.47,4.44 15.28,4.45 15.25,7.55 15.69,7.54 15.79,6.8 18.91,6.03 19.04,5.02 21.51,4.75",
			"23.63,10.56 26.25,10.63 26.18,4.31 25.82,6.41 24.27,6.16 23.27,7.04 23.58,8.16 23.19,8.7 23.91,9.55 23.56,10.45",
			"13.43,33.66 13.64,28.85 7.51,29.11 9.75,29.53 10.57,31.24 11.24,31.07 11.44,31.52 11.58,31.17 13.18,31.88 13.4,33.7",
			"10.87,39.42 13.48,39.56 13.51,37.92 13.14,38.06 13.27,39.08 10.83,39.25",
			"43.95,17.22 43.02,17.09 43,17.67 42.1,18.25 41.57,17.71 41.65,18.54 40.65,19.14 40.23,18.58 39.92,19.76 40.97,19.97 40.89,19.35 41.82,18.75 42.31,19.1 42.22,18.49 42.81,18.1 43.69,18.21 43.91,17.31",
			"39.31,23.28 40.14,22.68 39.45,22.87 37.69,20.16 38.19,19.6 37.19,20.26 39.27,23.26",
			"38.53,23.96 39.24,23.86 40.01,25.05 39.71,25.67 40.62,25.13 41.07,25.51 40.9,24.94 41.26,25.07 41.79,24.25 41.07,24.36 40.3,23.17 40.69,22.56 39.68,23.06 39.23,22.68 39.41,23.27 38.56,23.87",
			"42.73,28.55 43.56,27.95 42.87,28.14 41.11,25.43 41.61,24.87 40.62,25.53 42.69,28.53",
			"49.81,23.16 48.27,23.07 48.33,24.53 48.55,23.42 49.85,23.27",
			"48.38,28.94 48.27,33.74 52.6,33.58 51.59,33.23 50.62,30.46 48.52,30.93 48.48,29",
			"49.24,4.57 46.63,4.43 46.51,5.88 46.97,5.93 46.84,4.92 49.27,4.74",
			"46.64,10.5 46.51,15.32 52.63,14.94 50.39,14.57 49.54,12.95 46.92,12.28 46.66,10.47",
			"28.76,24.87 30.05,25.29 31.44,24.96 30.32,23.83 28.82,24.79",
			"28,23.49 28.67,24.05 31.54,24.05 32.22,23.26 31.71,22.54 30.21,22.39 28.59,22.51 28.05,23.05",
			"32.23,20.36 31.56,19.79 28.69,19.79 28.01,20.59 28.27,21.2 30.02,21.46 31.64,21.33 32.18,20.8",
			"31.47,18.98 30.18,18.55 28.79,18.89 29.9,20.02 31.41,19.06",
			"11.63,15.22 11.78,10.41 7.44,10.54 8.45,10.9 9.4,13.68 11.5,13.23 11.53,15.16",
			"10.16,21.14 11.63,21.31 11.66,19.79 11.43,20.9 10.13,21.03",
			"35.22,9.44 33.45,9.48 33.43,12.19 34.04,11.59 33.88,9.82 35.25,9.48",
			"37.26,12.6 38.84,12.73 38.64,9.8 38.24,10.35 38.45,12.42 37.18,12.44",
			"31.51,3.65 31.48,4.97 31.06,5.25 31.48,5.64 31.06,7.19 31.49,7.47 31.09,9.12 31.49,9.3 31.49,10.46 31.09,10.92 31.65,11.61 32.15,10.99 32.39,11.69 32.96,10.97 32.57,10.48 32.58,9.23 32.96,9.13 32.57,7.41 32.96,6.97 32.56,6.82 32.96,5.14 32.44,4.41 31.89,5.11 31.74,3.69",
			"22.78,31.53 21.19,31.39 21.39,34.32 21.8,33.78 21.59,31.7 22.86,31.69",
			"24.93,34.68 26.69,34.64 26.71,31.93 26.1,32.54 26.26,34.31 24.89,34.65",
			"28.64,40.48 28.67,39.15 29.08,38.87 28.67,38.48 29.08,36.93 28.66,36.65 28.68,35.42 29.05,35.33 28.66,33.66 29.06,33.2 28.5,32.51 28,33.13 27.71,32.43 27.19,33.16 27.58,33.64 27.57,34.89 27.19,34.99 27.57,36.72 27.19,37.15 27.59,37.31 27.19,38.98 27.7,39.71 28.36,39.13 28.4,40.44",
			"15.89,26.66 16.82,26.8 16.85,26.23 17.76,25.66 18.52,26.06 18.21,25.38 19.12,24.81 19.87,25.21 19.56,24.53 19.96,24.19 18.91,23.96 18.98,24.58 18.04,25.16 17.56,24.81 17.64,25.42 16.71,26.01 16.17,25.68 15.93,26.57",
			"17.3,15.35 16.46,15.94 17.16,15.76 18.18,17.39 18.87,18.51 18.43,19.09 19.37,18.41 17.35,15.38",
			"21.42,20.01 20.59,19.91 19.96,18.9 20.28,18.29 19.36,18.81 18.84,18.42 19.07,18.99 18.71,18.85 18.17,19.67 18.89,19.57 19.64,20.78 19.33,21.39 20.26,20.89 20.71,21.28 20.53,20.69 21.4,20.11",
			"20.63,20.68 19.79,21.27 20.49,21.09 22.2,23.83 21.76,24.42 22.7,23.74 20.68,20.7",
			"37.41,33.54 34.79,33.47 34.85,39.79 35.22,37.7 36.77,37.95 37.81,36.97 37.46,35.95 37.85,35.41 37.13,34.55 37.48,33.66",
			"39.57,39.66 45.76,39.65 45.79,36.55 45.35,36.56 45.25,37.3 42.13,38.07 42,39.08 39.53,39.36"
		],
		markers: [
			{
				kind: "expansion",
				x: 20.95,
				y: 9.44
			},
			{
				kind: "home",
				x: 8.64,
				y: 34.02,
				owner: "attacker"
			},
			{
				kind: "home",
				x: 51.41,
				y: 9.97,
				owner: "defender"
			},
			{
				kind: "centre",
				x: 30.8,
				y: 24.46
			},
			{
				kind: "expansion",
				x: 40.09,
				y: 34.66
			}
		]
	}
];
function orderedPair(a, b) {
	return DISPOSITIONS.indexOf(a) <= DISPOSITIONS.indexOf(b) ? [a, b] : [b, a];
}
var MAPS = GW_LAYOUTS.map((layout) => ({
	id: layout.id,
	letter: layout.letter,
	a: layout.a,
	b: layout.b,
	name: `Layout ${layout.letter} · ${layout.edge}`,
	blurb: `${layout.label}. Games Workshop 11th edition Event Companion layout on a 44×60 board.`,
	board: "44×60",
	zones: layout.zones,
	areas: [],
	terrain: layout.terrain,
	ruins: layout.ruins,
	markers: layout.markers
}));
var MAP_BY_ID = Object.fromEntries(MAPS.map((m) => [m.id, m]));
function layoutsFor(a, b) {
	if (!a || !b) return [];
	const [left, right] = orderedPair(a, b);
	return MAPS.filter((m) => m.a === left && m.b === right);
}
function getMap(id) {
	if (!id) return void 0;
	return MAP_BY_ID[id];
}
function areaLabel(kind) {
	if (kind === "home") return "H";
	if (kind === "expansion") return "E";
	return "C";
}
var GROUP_LABEL = {
	loadout: "Loadout",
	sergeant: "Sergeant",
	special: "Special weapon",
	extra: "Wargear"
};
function o(id, name, points, group, text) {
	return {
		id,
		name,
		points,
		group,
		text
	};
}
var HIDDEN_DEFAULTS = /* @__PURE__ */ new Set([
	"Standard issue",
	"Listed weapons",
	"Standard biomorphs",
	"As written",
	"Sergeant: as written",
	"No special weapon",
	"No extra weapon",
	"None"
]);
function isDefaultWargearName(name) {
	return HIDDEN_DEFAULTS.has(name);
}
function prefix(unit) {
	return unit.id.split("-")[0] ?? "";
}
function inferred(unit) {
	const p = prefix(unit);
	const uid = unit.id;
	const epic = unit.keywords.includes("Epic Hero");
	const opts = [o(`${uid}-std`, "Standard issue", 0, "loadout", "Weapons as printed on the datasheet.")];
	if (epic) return opts;
	if (p === "sm" || p === "um" || p === "csm") {
		if (unit.role === "character") {
			opts.push(o(`${uid}-mc`, "Master-crafted weapon", 10, "loadout"), o(`${uid}-relic-w`, "Relic weapon", 15, "loadout"), o(`${uid}-char-pp`, "Plasma pistol", 5, "extra"), o(`${uid}-char-combi`, "Combi-weapon", 10, "extra"));
			return opts;
		}
		if (unit.role === "battleline" || unit.role === "infantry") {
			const boltLine = /intercessor|infiltrator|scout/.test(uid);
			const sgtLine = /intercessor|legionaries|cultist|sternguard/.test(uid);
			if (boltLine && p !== "csm") opts.push(o(`${uid}-abr`, "Assault bolt rifles", 0, "loadout"), o(`${uid}-hbr`, "Heavy bolt rifles", 5, "loadout"));
			if (p === "csm" && /legionaries|chosen|cultist/.test(uid)) opts.push(o(`${uid}-csm-bolt`, "Boltguns", 0, "loadout"), o(`${uid}-csm-accursed`, "Accursed weapons", 10, "loadout"));
			if (sgtLine) opts.push(o(`${uid}-sgt-std`, "Sergeant: as written", 0, "sergeant"), o(`${uid}-sgt-pw`, "Sergeant: power weapon", 5, "sergeant"), o(`${uid}-sgt-pf`, "Sergeant: power fist", 10, "sergeant"), o(`${uid}-sgt-pp`, "Sergeant: plasma pistol", 5, "sergeant"), o(`${uid}-sp-none`, "No special weapon", 0, "special"), o(`${uid}-sp-plasma`, "Plasma gun", 10, "special"), o(`${uid}-sp-melta`, "Meltagun", 10, "special"), o(`${uid}-sp-flamer`, "Flamer", 5, "special"));
			return opts;
		}
		if (unit.role === "vehicle" || unit.role === "transport") {
			opts.push(o(`${uid}-hk`, "Hunter-killer missile", 5, "extra"), o(`${uid}-pintle`, "Pintle storm bolter", 5, "extra"), o(`${uid}-onslaught`, "Onslaught gatling cannon", 10, "extra"));
			return opts;
		}
		if (unit.role === "mounted") opts.push(o(`${uid}-mt-plasma`, "Plasma talons", 10, "loadout"), o(`${uid}-mt-melta`, "Multi-meltas", 15, "loadout"));
		return opts;
	}
	if (p === "nids") {
		if (unit.role === "character" || unit.role === "monster") {
			if (/tyrant|exocrine|tyrannofex|trygon|carnifex|maleceptor|norn|hierodule|harridan|hierophant/.test(uid)) opts.push(o(`${uid}-hvc`, "Heavy venom cannon", 10, "loadout"), o(`${uid}-stc`, "Stranglethorn cannon", 5, "loadout"), o(`${uid}-bonesword`, "Bonesword and lash whip", 10, "loadout"), o(`${uid}-adrenal`, "Adrenal glands", 10, "extra"), o(`${uid}-toxin`, "Toxin sacs", 10, "extra"), o(`${uid}-regen`, "Regeneration", 15, "extra"));
			else opts.push(o(`${uid}-adrenal`, "Adrenal glands", 10, "extra"), o(`${uid}-toxin`, "Toxin sacs", 10, "extra"));
		} else if (/termagant|hormagaunt|gargoyle|neurogaunt/.test(uid)) opts.push(o(`${uid}-flesh`, "Fleshborers", 0, "loadout"), o(`${uid}-devourer`, "Devourers", 5, "loadout"), o(`${uid}-spine`, "Spinefists", 0, "loadout"), o(`${uid}-adrenal-g`, "Adrenal glands", 10, "extra"), o(`${uid}-toxin-g`, "Toxin sacs", 10, "extra"));
		else if (/warriors-ranged|hive-guard/.test(uid)) opts.push(o(`${uid}-devourer`, "Devourers", 0, "loadout"), o(`${uid}-deathspitter`, "Deathspitters", 5, "loadout"), o(`${uid}-venom`, "Venom cannon", 10, "special"), o(`${uid}-impaler`, "Impaler cannons", 10, "special"));
		else if (/warriors-melee|tyrant-guard|carnifex/.test(uid)) opts.push(o(`${uid}-talons`, "Scything talons", 0, "loadout"), o(`${uid}-cleaver`, "Bone cleaver and lash whip", 5, "loadout"), o(`${uid}-crush`, "Crushing claws", 10, "loadout"));
		return opts;
	}
	if (p === "tau") {
		if (/crisis|coldstar|stealth/.test(uid)) opts.push(o(`${uid}-burst`, "Burst cannon", 0, "loadout"), o(`${uid}-plasma-r`, "Plasma rifle", 10, "loadout"), o(`${uid}-fusion`, "Fusion blaster", 15, "loadout"), o(`${uid}-missile`, "Missile pod", 10, "loadout"), o(`${uid}-shield`, "Shield generator", 10, "extra"), o(`${uid}-sts`, "Support turret", 5, "extra"));
		else if (unit.role === "battleline") opts.push(o(`${uid}-pulse`, "Pulse rifles", 0, "loadout"), o(`${uid}-carbine`, "Pulse carbines", 0, "loadout"), o(`${uid}-marker`, "Markerlight", 5, "extra"));
		return opts;
	}
	if (p === "custodes") {
		if (/guard|wardens|allarus|shield-captain|blade-champion/.test(uid)) opts.push(o(`${uid}-spear`, "Guardian spears", 0, "loadout"), o(`${uid}-sword`, "Sentinel blades", 0, "loadout"), o(`${uid}-axe`, "Castellan axes", 5, "loadout"), o(`${uid}-misericordia`, "Misericordia", 5, "extra"));
		return opts;
	}
	if (unit.role === "vehicle" || unit.role === "transport") opts.push(o(`${uid}-hk`, "Hunter-killer missile", 5, "extra"), o(`${uid}-pintle`, "Pintle weapon", 5, "extra"));
	return opts;
}
function wargearGroups(unit) {
	const all = [...inferred(unit), ...unit.wargear ?? []];
	const map = /* @__PURE__ */ new Map();
	for (const opt of all) {
		const arr = map.get(opt.group) ?? [];
		if (!arr.some((x) => x.id === opt.id)) arr.push(opt);
		map.set(opt.group, arr);
	}
	return [...map.entries()].map(([id, options]) => {
		const list = options.some((opt) => opt.points === 0) ? options : [o(`${unit.id}-${id}-none`, "None", 0, id), ...options];
		return {
			id,
			label: GROUP_LABEL[id] ?? id,
			options: list
		};
	}).filter((g) => g.options.length > 0);
}
function resolvedWargearIds(unit, ids) {
	const set = new Set(ids ?? []);
	return wargearGroups(unit).map((g) => {
		const hit = g.options.find((opt) => set.has(opt.id));
		if (hit) return hit.id;
		return (g.options.find((opt) => opt.points === 0) ?? g.options[0]).id;
	});
}
function selectedWargear(unit, ids) {
	const set = new Set(resolvedWargearIds(unit, ids));
	return wargearGroups(unit).flatMap((g) => g.options.filter((opt) => set.has(opt.id)));
}
function wargearPoints(unit, ids) {
	return selectedWargear(unit, ids).reduce((sum, opt) => sum + opt.points, 0);
}
function wargearSummary(unit, ids) {
	return selectedWargear(unit, ids).filter((opt) => !isDefaultWargearName(opt.name));
}
function rosterLoadout(unit, ids) {
	const weapons = [...unit.ranged, ...unit.melee].map((wpn) => wpn.name);
	const extras = wargearSummary(unit, ids).map((g) => g.points ? `${g.name} +${g.points}` : g.name);
	return [...weapons, ...extras].filter(Boolean).join(" · ");
}
function setWargearGroup(unit, current, groupId, optionId) {
	const group = wargearGroups(unit).find((g) => g.id === groupId);
	const next = resolvedWargearIds(unit, current).filter((id) => !group?.options.some((opt) => opt.id === id));
	next.push(optionId);
	return next;
}
function unitTotalPoints(roster, ru) {
	const faction = getFaction(roster.factionId);
	const def = getUnit(roster.factionId, ru.unitId);
	const enh = ru.enhancementId ? faction?.detachments.flatMap((d) => d.enhancements).find((e) => e.id === ru.enhancementId) : void 0;
	return ru.points + (enh?.points ?? 0) + (def ? wargearPoints(def, ru.wargearIds) : 0);
}
function rosterPoints(roster) {
	return roster.units.reduce((sum, ru) => sum + unitTotalPoints(roster, ru), 0);
}
function rosterDp(roster) {
	return roster.detachmentIds.reduce((sum, id) => {
		return sum + (getDetachment(roster.factionId, id)?.dp ?? 0);
	}, 0);
}
function rosterDisposition(roster) {
	const fromDets = roster.detachmentIds.map((id) => getDetachment(roster.factionId, id)?.disposition).filter(Boolean);
	if (roster.disposition && (fromDets.length === 0 || fromDets.includes(roster.disposition))) return roster.disposition;
	return fromDets[0] ?? roster.disposition ?? null;
}
function primaryForSide(side, other) {
	const a = rosterDisposition(side);
	const b = rosterDisposition(other);
	if (!a || !b) return null;
	return {
		info: missionFor(a, b).me,
		mine: a,
		theirs: b
	};
}
function warlord(roster) {
	return roster.units.find((u) => u.warlord);
}
function validateRoster(roster) {
	const issues = [];
	const size = BATTLE_SIZES[roster.battleSize];
	if (!getFaction(roster.factionId)) {
		issues.push({
			level: "error",
			text: "Unknown faction."
		});
		return issues;
	}
	const pts = rosterPoints(roster);
	if (pts > size.points) issues.push({
		level: "error",
		text: `${pts} pts exceeds ${size.points} pts limit.`
	});
	if (pts === 0) issues.push({
		level: "warn",
		text: "List is empty."
	});
	const dp = rosterDp(roster);
	if (roster.detachmentIds.length === 0) issues.push({
		level: "error",
		text: "Select at least one detachment."
	});
	if (dp > size.dp) issues.push({
		level: "error",
		text: `${dp} DP spent — budget is ${size.dp}.`
	});
	if (dp > 3) issues.push({
		level: "error",
		text: `${dp} DP spent — maximum is 3 DP.`
	});
	const tags = roster.detachmentIds.map((id) => getDetachment(roster.factionId, id)?.uniqueTag).filter(Boolean);
	const dupTag = tags.find((t, i) => tags.indexOf(t) !== i);
	if (dupTag) issues.push({
		level: "error",
		text: `Two detachments share the unique tag “${dupTag}”.`
	});
	const counts = /* @__PURE__ */ new Map();
	for (const ru of roster.units) {
		const def = getUnit(roster.factionId, ru.unitId);
		const cur = counts.get(ru.unitId) ?? {
			n: 0,
			def
		};
		cur.n += 1;
		counts.set(ru.unitId, cur);
	}
	for (const [id, { n, def }] of counts) {
		const cap = def?.role === "battleline" ? size.battlelineCopies : size.copies;
		if (n > cap) issues.push({
			level: "error",
			text: `${def?.name ?? id}: ${n} copies (max ${cap}).`
		});
	}
	const enhCount = roster.units.filter((u) => u.enhancementId).length;
	if (enhCount > size.enhancements) issues.push({
		level: "error",
		text: `${enhCount} enhancements (max ${size.enhancements}).`
	});
	if (!warlord(roster)) issues.push({
		level: "error",
		text: "Assign a Warlord (a Character)."
	});
	const detDisps = roster.detachmentIds.map((id) => getDetachment(roster.factionId, id)?.disposition).filter(Boolean);
	if (!roster.disposition) issues.push({
		level: "warn",
		text: "Pick a Force Disposition from your detachments before you play."
	});
	else if (!detDisps.includes(roster.disposition)) issues.push({
		level: "error",
		text: "Force Disposition must come from a selected detachment."
	});
	return issues;
}
var emptyScore = () => ({
	primaryByRound: [
		0,
		0,
		0,
		0,
		0
	],
	primaryChecks: [],
	secondaryMode: null,
	fixedIds: [],
	tacticalActive: [],
	secondaryChecks: {},
	secondaryMeta: {},
	tactical: 0,
	painted: 10
});
function snapshotRoster(r) {
	const copy = JSON.parse(JSON.stringify(r));
	delete copy.owner;
	copy.disposition = rosterDisposition(copy);
	copy.saved = copy.saved ?? true;
	return copy;
}
var SEED_IDS = new Set(SEED_LISTS.map((l) => l.id));
function knownFaction(factionId) {
	return Boolean(getFaction(factionId));
}
function mergeLists(persisted, current) {
	const known = (l) => knownFaction(l.factionId);
	const currentKnown = current.filter(known);
	if (!persisted?.length) return currentKnown.map((l) => snapshotRoster(l));
	const currentById = new Map(currentKnown.map((l) => [l.id, l]));
	const out = [];
	const seen = /* @__PURE__ */ new Set();
	for (const raw of persisted) {
		if (!known(raw)) continue;
		const live = currentById.get(raw.id);
		const chosen = live && (live.updatedAt ?? 0) > (raw.updatedAt ?? 0) ? live : raw;
		out.push(snapshotRoster(chosen));
		seen.add(raw.id);
	}
	for (const live of currentKnown) {
		if (seen.has(live.id) || SEED_IDS.has(live.id)) continue;
		out.push(snapshotRoster(live));
	}
	return out.length ? out : currentKnown.map((l) => snapshotRoster(l));
}
function gameStamp(g) {
	return g.log?.[0]?.at ?? g.finishedAt ?? g.startedAt ?? 0;
}
function mergeGames(persisted, current) {
	const known = (g) => knownFaction(g.myRoster.factionId) && knownFaction(g.opponentRoster.factionId);
	const map = /* @__PURE__ */ new Map();
	for (const g of current.filter(known)) map.set(g.id, g);
	for (const g of (persisted ?? []).filter(known)) {
		const prev = map.get(g.id);
		map.set(g.id, !prev || gameStamp(g) >= gameStamp(prev) ? g : prev);
	}
	return [...map.values()].map(hydrateGame);
}
function idbStorage() {
	const DB = "ono40k";
	const STORE = "kv";
	let opened = null;
	const withTimeout = (p, ms) => new Promise((resolve, reject) => {
		const t = setTimeout(() => reject(/* @__PURE__ */ new Error("idb-timeout")), ms);
		p.then((v) => {
			clearTimeout(t);
			resolve(v);
		}, (e) => {
			clearTimeout(t);
			reject(e);
		});
	});
	const open = () => {
		if (typeof indexedDB === "undefined") return Promise.reject(/* @__PURE__ */ new Error("no indexedDB"));
		opened ??= new Promise((resolve, reject) => {
			const req = indexedDB.open(DB, 1);
			req.onupgradeneeded = () => {
				if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE);
			};
			req.onsuccess = () => resolve(req.result);
			req.onerror = () => reject(req.error);
		});
		return withTimeout(opened, 800).catch((err) => {
			opened = null;
			throw err;
		});
	};
	let writes = Promise.resolve();
	let pending = null;
	let timer = null;
	const flush = () => {
		if (timer) {
			clearTimeout(timer);
			timer = null;
		}
		const job = pending;
		pending = null;
		if (!job) return writes;
		const write = async () => {
			try {
				const db = await open();
				await new Promise((resolve, reject) => {
					const tx = db.transaction(STORE, "readwrite");
					tx.objectStore(STORE).put(job.value, job.name);
					tx.oncomplete = () => resolve();
					tx.onerror = () => reject(tx.error);
				});
			} catch {
				try {
					localStorage.setItem(job.name, job.value);
				} catch {}
			}
		};
		writes = writes.then(write, write);
		return writes;
	};
	if (typeof window !== "undefined") {
		const hide = () => {
			flush();
		};
		window.addEventListener("pagehide", hide);
		document.addEventListener("visibilitychange", () => {
			if (document.visibilityState === "hidden") hide();
		});
	}
	return {
		getItem: async (name) => {
			try {
				const db = await open();
				const fromIdb = await new Promise((resolve, reject) => {
					const r = db.transaction(STORE, "readonly").objectStore(STORE).get(name);
					r.onsuccess = () => resolve(r.result ?? null);
					r.onerror = () => reject(r.error);
				});
				if (fromIdb != null) return fromIdb;
			} catch {}
			try {
				return localStorage.getItem(name);
			} catch {
				return null;
			}
		},
		setItem: (name, value) => {
			pending = {
				name,
				value
			};
			if (timer) clearTimeout(timer);
			timer = setTimeout(() => {
				flush();
			}, 400);
			return writes;
		},
		removeItem: async (name) => {
			try {
				const db = await open();
				await new Promise((resolve, reject) => {
					const tx = db.transaction(STORE, "readwrite");
					tx.objectStore(STORE).delete(name);
					tx.oncomplete = () => resolve();
					tx.onerror = () => reject(tx.error);
				});
			} catch {
				try {
					localStorage.removeItem(name);
				} catch {}
			}
		}
	};
}
function initUnitState(roster, other) {
	const state = {};
	for (const ru of [...roster.units, ...other.units]) state[ru.id] = {
		modelsRemaining: ru.models,
		woundsOnCurrent: 0,
		battleShocked: false,
		hidden: false,
		destroyed: false
	};
	return state;
}
function clone(v) {
	return JSON.parse(JSON.stringify(v));
}
function patchScore(g, side, patch) {
	const score = {
		...g.scores[side],
		...patch
	};
	const mode = score.secondaryMode ?? null;
	score.tactical = secondaryVp(mode, mode === "fixed" ? score.fixedIds ?? [] : mode === "tactical" ? score.tacticalActive ?? [] : [], score.secondaryChecks);
	return {
		...g,
		scores: {
			...g.scores,
			[side]: score
		}
	};
}
function hydrateGame(g) {
	const complete = g.status === "complete";
	const elapsedMs = g.elapsedMs ?? (complete ? Math.max(0, (g.finishedAt ?? g.startedAt) - g.startedAt) : 0);
	const runningSince = g.runningSince === void 0 ? complete ? null : g.startedAt : g.runningSince;
	return {
		...g,
		log: g.log ?? [],
		activeStrats: g.activeStrats ?? [],
		undoStack: g.undoStack ?? [],
		elapsedMs,
		runningSince,
		turnMs: g.turnMs ?? {
			me: 0,
			opponent: 0
		},
		liveRound: g.liveRound ?? g.round,
		liveSide: g.liveSide ?? g.activeSide,
		livePhase: g.livePhase ?? g.phase
	};
}
function turnRank(round, side) {
	return (round - 1) * 2 + (side === "opponent" ? 1 : 0);
}
function turnFromRank(rank) {
	const clamped = Math.min(9, Math.max(0, rank));
	return {
		round: Math.floor(clamped / 2) + 1,
		side: clamped % 2 === 1 ? "opponent" : "me"
	};
}
function browseTurn(g, round, side, phase) {
	const liveR = g.liveRound ?? g.round;
	const liveS = g.liveSide ?? g.activeSide;
	const leavingLive = g.round === liveR && g.activeSide === liveS && (round !== liveR || side !== liveS);
	return {
		...g,
		round,
		activeSide: side,
		viewing: side,
		phase,
		liveRound: liveR,
		liveSide: liveS,
		livePhase: leavingLive ? g.phase : g.livePhase ?? g.phase
	};
}
function freezeTurns(g, now = Date.now()) {
	const extra = g.runningSince ? now - g.runningSince : 0;
	const turnMs = {
		me: g.turnMs?.me ?? 0,
		opponent: g.turnMs?.opponent ?? 0
	};
	if (extra) turnMs[g.activeSide] += extra;
	return {
		runningSince: null,
		turnMs
	};
}
function stopAllClocks(g, now = Date.now()) {
	return {
		...freezeTurns(g, now),
		elapsedMs: now - g.startedAt,
		finishedAt: now,
		status: "complete"
	};
}
function rollTurnClock(g, next, now = Date.now()) {
	const extra = g.runningSince ? now - g.runningSince : 0;
	const turnMs = {
		me: g.turnMs?.me ?? 0,
		opponent: g.turnMs?.opponent ?? 0
	};
	turnMs[g.activeSide] += extra;
	turnMs[next] = 0;
	return {
		turnMs,
		runningSince: g.runningSince ? now : g.runningSince
	};
}
function snapshotUndo(g) {
	return {
		round: g.round,
		phase: g.phase,
		activeSide: g.activeSide,
		viewing: g.viewing,
		cp: clone(g.cp),
		unitState: clone(g.unitState),
		activeStrats: clone(g.activeStrats ?? []),
		status: g.status,
		finishedAt: g.finishedAt
	};
}
function phaseLabel(id) {
	return PHASES.find((p) => p.id === id)?.label ?? id;
}
function findRosterUnit(game, unitId) {
	const mine = game.myRoster.units.find((u) => u.id === unitId);
	if (mine) return {
		ru: mine,
		factionId: game.myRoster.factionId,
		side: "me"
	};
	const theirs = game.opponentRoster.units.find((u) => u.id === unitId);
	if (theirs) return {
		ru: theirs,
		factionId: game.opponentRoster.factionId,
		side: "opponent"
	};
	return null;
}
function unitLabel(game, unitId) {
	const found = findRosterUnit(game, unitId);
	if (!found) return "Unit";
	const name = getUnit(found.factionId, found.ru.unitId)?.name ?? "Unit";
	const roster = found.side === "me" ? game.myRoster : game.opponentRoster;
	const mark = unitCopyMarks(roster.units)[found.ru.id];
	return mark ? `${name} [${mark}]` : name;
}
function sideName(game, side) {
	return side === "me" ? game.myName : game.opponentName;
}
function applyTracked(get, set, kind, summary, mutator) {
	const id = get().activeGameId;
	const raw = get().games.find((g) => g.id === id);
	if (!id || !raw) return;
	const game = hydrateGame(raw);
	const next = mutator({
		...game,
		undoStack: [snapshotUndo(game), ...game.undoStack].slice(0, 5)
	});
	const stampedAt = Date.now();
	const event = {
		id: uid("ev"),
		at: stampedAt,
		kind,
		summary,
		round: next.round,
		phase: next.phase,
		turn: next.activeSide,
		clockMs: battleElapsedMs(next, stampedAt)
	};
	set({ games: get().games.map((g) => g.id === id ? {
		...next,
		log: [event, ...game.log ?? []].slice(0, 50)
	} : g) });
}
var useWarStore = create()(persist((set, get) => ({
	hydrated: false,
	lists: SEED_LISTS,
	games: [],
	activeGameId: null,
	setHydrated: () => set({ hydrated: true }),
	createList: ({ name, factionId, battleSize }) => {
		const id = uid("list");
		const now = Date.now();
		set({ lists: [{
			id,
			name,
			factionId,
			battleSize,
			pointsLimit: BATTLE_SIZES[battleSize].points,
			detachmentIds: [],
			disposition: null,
			units: [],
			notes: "",
			favorite: false,
			saved: false,
			createdAt: now,
			updatedAt: now
		}, ...get().lists] });
		return id;
	},
	updateList: (id, patch) => set({ lists: get().lists.map((l) => l.id === id ? {
		...l,
		...patch,
		updatedAt: Date.now()
	} : l) }),
	deleteList: (id) => set({ lists: get().lists.filter((l) => l.id !== id) }),
	duplicateList: (id) => {
		const src = get().lists.find((l) => l.id === id);
		if (!src) return null;
		const copy = {
			...snapshotRoster(src),
			id: uid("list"),
			name: `${src.name} (copy)`,
			favorite: false,
			saved: false,
			createdAt: Date.now(),
			updatedAt: Date.now(),
			units: src.units.map((u) => ({
				...u,
				id: uid("u")
			}))
		};
		set({ lists: [copy, ...get().lists] });
		return copy.id;
	},
	toggleFavorite: (id) => set({ lists: get().lists.map((l) => l.id === id ? {
		...l,
		favorite: !l.favorite
	} : l) }),
	saveList: (id) => set({ lists: get().lists.map((l) => l.id === id ? {
		...l,
		saved: true,
		savedAt: Date.now(),
		updatedAt: Date.now()
	} : l) }),
	addUnit: (listId, unit) => {
		const ru = {
			...unit,
			id: uid("u")
		};
		set({ lists: get().lists.map((l) => l.id === listId ? {
			...l,
			units: [...l.units, ru],
			updatedAt: Date.now()
		} : l) });
	},
	updateUnit: (listId, unitId, patch) => set({ lists: get().lists.map((l) => l.id === listId ? {
		...l,
		units: l.units.map((u) => u.id === unitId ? {
			...u,
			...patch
		} : u),
		updatedAt: Date.now()
	} : l) }),
	removeUnit: (listId, unitId) => set({ lists: get().lists.map((l) => l.id === listId ? {
		...l,
		units: l.units.filter((u) => u.id !== unitId),
		updatedAt: Date.now()
	} : l) }),
	importList: (roster) => {
		const id = uid("list");
		const now = Date.now();
		set({ lists: [{
			...roster,
			id,
			favorite: false,
			saved: true,
			savedAt: now,
			createdAt: now,
			updatedAt: now
		}, ...get().lists] });
		return id;
	},
	startGame: ({ myName, opponentName, mine, theirs, briefing, scores }) => {
		if (!mine || !theirs) return null;
		const myRoster = snapshotRoster({
			...mine,
			id: mine.id || uid("tbl")
		});
		const opponentRoster = snapshotRoster({
			...theirs,
			id: theirs.id || uid("tbl")
		});
		const id = uid("game");
		const first = briefing?.firstTurn ?? "me";
		const attacker = briefing?.attacker ?? "me";
		const now = Date.now();
		const mapName = briefing?.mapId ? getMap(briefing.mapId)?.name : void 0;
		set({
			games: [{
				id,
				myName: myName || "You",
				opponentName: opponentName || "Opponent",
				myRoster,
				opponentRoster,
				round: 1,
				phase: "command",
				activeSide: first,
				viewing: first,
				scores: {
					me: scores?.me ?? emptyScore(),
					opponent: scores?.opponent ?? emptyScore()
				},
				cp: {
					me: 1,
					opponent: 1
				},
				unitState: initUnitState(myRoster, opponentRoster),
				activeStrats: [],
				log: briefing ? [{
					id: uid("ev"),
					at: now,
					kind: "prebattle",
					summary: `Attacker ${attacker === "me" ? myName || "You" : opponentName || "Opponent"} · first ${first === "me" ? myName || "You" : opponentName || "Opponent"}${mapName ? ` · ${mapName}` : ""}`,
					round: 1,
					phase: "command",
					turn: first,
					clockMs: 0
				}] : [],
				undoStack: [],
				notes: [briefing?.terrainNote, briefing?.formationNote].filter(Boolean).join(" · "),
				status: "active",
				startedAt: now,
				elapsedMs: 0,
				runningSince: now,
				turnMs: {
					me: 0,
					opponent: 0
				},
				liveRound: 1,
				liveSide: first,
				livePhase: "command",
				preBattle: briefing
			}, ...get().games],
			activeGameId: id
		});
		return id;
	},
	patchGame: (id, patch) => set({ games: get().games.map((g) => g.id === id ? {
		...g,
		...patch
	} : g) }),
	setViewing: (side) => {
		const id = get().activeGameId;
		if (!id) return;
		set({ games: get().games.map((g) => g.id === id ? {
			...g,
			viewing: side
		} : g) });
	},
	setPhase: (phase) => {
		const id = get().activeGameId;
		const raw = get().games.find((g) => g.id === id);
		if (!id || !raw || raw.phase === phase) return;
		applyTracked(get, set, "phase", `Phase → ${phaseLabel(phase)}`, (g) => {
			const liveR = g.liveRound ?? g.round;
			const liveS = g.liveSide ?? g.activeSide;
			const atLive = g.round === liveR && g.activeSide === liveS;
			return {
				...g,
				phase,
				...atLive ? { livePhase: phase } : {}
			};
		});
	},
	prevTurn: () => {
		const id = get().activeGameId;
		const raw = get().games.find((g) => g.id === id);
		if (!id || !raw) return;
		const game = hydrateGame(raw);
		const rank = turnRank(game.round, game.activeSide);
		if (rank <= 0) return;
		const next = turnFromRank(rank - 1);
		set({ games: get().games.map((g) => g.id === id ? browseTurn(hydrateGame(g), next.round, next.side, "command") : g) });
	},
	jumpRound: (round) => {
		const id = get().activeGameId;
		const raw = get().games.find((g) => g.id === id);
		if (!id || !raw) return;
		const game = hydrateGame(raw);
		const liveR = game.liveRound ?? game.round;
		const liveS = game.liveSide ?? game.activeSide;
		if (round > liveR) return;
		const side = round === liveR ? liveS : "me";
		const phase = round === liveR && side === liveS ? game.livePhase ?? "command" : "command";
		set({ games: get().games.map((g) => g.id === id ? browseTurn(hydrateGame(g), round, side, phase) : g) });
	},
	endTurn: () => {
		const id = get().activeGameId;
		const raw = get().games.find((g) => g.id === id);
		if (!id || !raw) return;
		const game = hydrateGame(raw);
		const liveR = game.liveRound ?? game.round;
		const liveS = game.liveSide ?? game.activeSide;
		const cur = turnRank(game.round, game.activeSide);
		const live = turnRank(liveR, liveS);
		if (cur < live) {
			const next = turnFromRank(cur + 1);
			const backToLive = cur + 1 === live;
			set({ games: get().games.map((g) => g.id === id ? browseTurn(hydrateGame(g), next.round, next.side, backToLive ? hydrateGame(g).livePhase ?? "command" : "command") : g) });
			return;
		}
		if (game.status === "complete") return;
		if (game.activeSide === "me") {
			applyTracked(get, set, "turn", `Turn ended · ${game.opponentName}'s turn`, (g) => ({
				...g,
				...rollTurnClock(g, "opponent"),
				activeSide: "opponent",
				phase: "command",
				viewing: "opponent",
				cp: {
					...g.cp,
					opponent: g.cp.opponent + 1
				},
				liveRound: g.round,
				liveSide: "opponent",
				livePhase: "command"
			}));
			return;
		}
		const done = game.round >= 5;
		const nextRound = done ? game.round : Math.min(5, game.round + 1);
		applyTracked(get, set, "turn", done ? `Battle ended · Round ${game.round}` : `Turn ended · Round ${nextRound}, ${game.myName}`, (g) => {
			const clock = done ? stopAllClocks(g) : rollTurnClock(g, "me");
			return {
				...g,
				...clock,
				round: nextRound,
				phase: "command",
				activeSide: "me",
				viewing: "me",
				cp: {
					...g.cp,
					me: g.cp.me + 1
				},
				status: done ? "complete" : "active",
				finishedAt: done ? Date.now() : g.finishedAt,
				liveRound: nextRound,
				liveSide: "me",
				livePhase: "command"
			};
		});
	},
	adjustPrimary: (side, round, delta) => {
		const id = get().activeGameId;
		if (!id) return;
		set({ games: get().games.map((g) => {
			if (g.id !== id) return g;
			const score = { ...g.scores[side] };
			const arr = [...score.primaryByRound];
			const i = round - 1;
			arr[i] = Math.max(0, Math.min(20, arr[i] + delta));
			score.primaryByRound = arr;
			return {
				...g,
				scores: {
					...g.scores,
					[side]: score
				}
			};
		}) });
	},
	setPrimary: (side, round, value) => {
		const id = get().activeGameId;
		if (!id) return;
		set({ games: get().games.map((g) => {
			if (g.id !== id) return g;
			const score = { ...g.scores[side] };
			const arr = [...score.primaryByRound];
			arr[round - 1] = Math.max(0, Math.min(20, value));
			score.primaryByRound = arr;
			return {
				...g,
				scores: {
					...g.scores,
					[side]: score
				}
			};
		}) });
	},
	togglePrimaryCheck: (side, objIndex, slot, max = 1) => {
		const id = get().activeGameId;
		if (!id) return;
		const cap = Math.max(1, max);
		set({ games: get().games.map((g) => {
			if (g.id !== id) return g;
			const score = { ...g.scores[side] };
			const checks = (score.primaryChecks ?? []).map((row) => [...row]);
			while (checks.length <= objIndex) checks.push([]);
			const row = [...checks[objIndex] ?? []];
			while (row.length <= slot) row.push(0);
			row[slot] = (Number(row[slot] || 0) + 1) % (cap + 1);
			checks[objIndex] = row;
			return {
				...g,
				scores: {
					...g.scores,
					[side]: {
						...score,
						primaryChecks: checks
					}
				}
			};
		}) });
	},
	setSecondaryMode: (side, mode) => {
		const id = get().activeGameId;
		if (!id) return;
		set({ games: get().games.map((g) => {
			if (g.id !== id) return g;
			return patchScore(g, side, { secondaryMode: mode });
		}) });
	},
	toggleFixedSecondary: (side, cardId) => {
		const id = get().activeGameId;
		if (!id) return;
		set({ games: get().games.map((g) => {
			if (g.id !== id) return g;
			const cur = g.scores[side].fixedIds ?? [];
			const adding = !cur.includes(cardId);
			const next = adding ? cur.length >= 2 ? cur : [...cur, cardId] : cur.filter((x) => x !== cardId);
			const meta = { ...g.scores[side].secondaryMeta ?? {} };
			if (adding && next.includes(cardId)) meta[cardId] = { selectedRound: g.round };
			return patchScore(g, side, {
				secondaryMode: "fixed",
				fixedIds: next,
				secondaryMeta: meta
			});
		}) });
	},
	toggleTacticalActive: (side, cardId) => {
		const id = get().activeGameId;
		if (!id) return;
		set({ games: get().games.map((g) => {
			if (g.id !== id) return g;
			const cur = g.scores[side].tacticalActive ?? [];
			const adding = !cur.includes(cardId);
			const next = adding ? [...cur, cardId] : cur.filter((x) => x !== cardId);
			const meta = { ...g.scores[side].secondaryMeta ?? {} };
			if (adding) meta[cardId] = { selectedRound: g.round };
			return patchScore(g, side, {
				secondaryMode: "tactical",
				tacticalActive: next,
				secondaryMeta: meta
			});
		}) });
	},
	setSecondaryScore: (side, cardId, vp) => {
		const id = get().activeGameId;
		if (!id) return;
		set({ games: get().games.map((g) => {
			if (g.id !== id) return g;
			const prev = g.scores[side].secondaryChecks ?? {};
			const meta = { ...g.scores[side].secondaryMeta ?? {} };
			const stamp = meta[cardId] ?? { selectedRound: g.round };
			if (vp > 0) meta[cardId] = {
				...stamp,
				selectedRound: stamp.selectedRound ?? g.round,
				completedRound: g.round
			};
			else meta[cardId] = { selectedRound: stamp.selectedRound ?? g.round };
			return patchScore(g, side, {
				secondaryChecks: {
					...prev,
					[cardId]: [[Math.max(0, vp)]]
				},
				secondaryMeta: meta
			});
		}) });
	},
	ensureSecondaryMeta: (side) => {
		const id = get().activeGameId;
		const raw = get().games.find((g) => g.id === id);
		if (!id || !raw) return;
		const g = hydrateGame(raw);
		const score = g.scores[side];
		const ids = score.secondaryMode === "fixed" ? score.fixedIds ?? [] : score.secondaryMode === "tactical" ? score.tacticalActive ?? [] : [];
		const meta = { ...score.secondaryMeta ?? {} };
		let changed = false;
		for (const cardId of ids) if (!meta[cardId]) {
			meta[cardId] = { selectedRound: g.round };
			changed = true;
		}
		if (!changed) return;
		set({ games: get().games.map((game) => game.id === id ? patchScore(hydrateGame(game), side, { secondaryMeta: meta }) : game) });
	},
	adjustTactical: (side, delta) => {
		const id = get().activeGameId;
		if (!id) return;
		set({ games: get().games.map((g) => {
			if (g.id !== id) return g;
			const score = {
				...g.scores[side],
				tactical: Math.max(0, g.scores[side].tactical + delta)
			};
			return {
				...g,
				scores: {
					...g.scores,
					[side]: score
				}
			};
		}) });
	},
	adjustCp: (side, delta) => {
		const id = get().activeGameId;
		if (!id) return;
		set({ games: get().games.map((g) => g.id === id ? {
			...g,
			cp: {
				...g.cp,
				[side]: Math.max(0, g.cp[side] + delta)
			}
		} : g) });
	},
	setUnitState: (unitId, patch) => {
		const id = get().activeGameId;
		const raw = get().games.find((g) => g.id === id);
		if (!id || !raw) return;
		const game = hydrateGame(raw);
		const prev = game.unitState[unitId];
		if (!prev) return;
		const next = {
			...prev,
			...patch
		};
		const found = findRosterUnit(game, unitId);
		const name = unitLabel(game, unitId);
		const who = found ? sideName(game, found.side) : "";
		const apply = (g) => ({
			...g,
			unitState: {
				...g.unitState,
				[unitId]: next
			}
		});
		if (next.destroyed !== prev.destroyed) {
			applyTracked(get, set, "destroyed", `${who} · ${name} ${next.destroyed ? "destroyed" : "restored"}`, apply);
			return;
		}
		if (next.battleShocked !== prev.battleShocked) {
			applyTracked(get, set, "battleShock", `${who} · ${name} ${next.battleShocked ? "Battle-shocked" : "rallied"}`, apply);
			return;
		}
		set({ games: get().games.map((g) => g.id === id ? apply(hydrateGame(g)) : g) });
	},
	playStratagem: (side, strat, source) => {
		get().playStratagems(side, [{
			strat,
			source
		}]);
	},
	playStratagems: (side, items) => {
		const id = get().activeGameId;
		const raw = get().games.find((g) => g.id === id);
		if (!id || !raw || raw.status === "complete" || items.length === 0) return;
		const game = hydrateGame(raw);
		const total = items.reduce((n, i) => n + i.strat.cp, 0);
		if (game.cp[side] < total) return;
		const actives = items.map(({ strat, source }) => ({
			id: uid("as"),
			stratId: strat.id,
			name: strat.name,
			cp: strat.cp,
			when: strat.when,
			text: strat.text,
			source,
			side,
			round: game.round,
			phase: game.phase
		}));
		const names = items.map((i) => i.strat.name);
		const label = names.length === 1 ? names[0] : names.length <= 3 ? names.join(" + ") : `${names[0]} + ${names.length - 1} more`;
		applyTracked(get, set, "stratagem", `${sideName(game, side)} · ${label} (${total} CP)`, (g) => ({
			...g,
			cp: {
				...g.cp,
				[side]: Math.max(0, g.cp[side] - total)
			},
			activeStrats: [...actives, ...g.activeStrats]
		}));
	},
	dismissStrat: (activeId) => {
		const id = get().activeGameId;
		if (!id) return;
		set({ games: get().games.map((g) => g.id === id ? {
			...hydrateGame(g),
			activeStrats: (g.activeStrats ?? []).filter((s) => s.id !== activeId)
		} : g) });
	},
	undoLast: () => {
		const id = get().activeGameId;
		const raw = get().games.find((g) => g.id === id);
		if (!id || !raw) return;
		const game = hydrateGame(raw);
		const slice = game.undoStack[0];
		if (!slice) return;
		set({ games: get().games.map((g) => g.id === id ? {
			...hydrateGame(g),
			round: slice.round,
			phase: slice.phase,
			activeSide: slice.activeSide,
			viewing: slice.viewing ?? g.viewing,
			cp: clone(slice.cp),
			unitState: clone(slice.unitState),
			activeStrats: clone(slice.activeStrats),
			status: slice.status,
			finishedAt: slice.finishedAt,
			log: game.log.slice(1),
			undoStack: game.undoStack.slice(1)
		} : g) });
	},
	pauseClock: () => {
		const id = get().activeGameId;
		if (!id) return;
		set({ games: get().games.map((g) => g.id === id && g.runningSince ? {
			...g,
			...freezeTurns(g)
		} : g) });
	},
	resumeClock: () => {
		const id = get().activeGameId;
		if (!id) return;
		const now = Date.now();
		set({ games: get().games.map((g) => g.id === id && !g.runningSince && g.status === "active" ? {
			...g,
			runningSince: now
		} : g) });
	},
	endGame: () => {
		const id = get().activeGameId;
		if (!id) return;
		const now = Date.now();
		set({ games: get().games.map((g) => g.id === id ? {
			...g,
			...stopAllClocks(g, now)
		} : g) });
	},
	leaveGame: () => set({ activeGameId: null }),
	resumeGame: (id) => set({ activeGameId: id }),
	reopenGame: () => {
		const id = get().activeGameId;
		if (!id) return;
		const now = Date.now();
		set({ games: get().games.map((g) => {
			if (g.id !== id) return g;
			const frozen = g.elapsedMs ?? (g.finishedAt ? g.finishedAt - g.startedAt : 0);
			return {
				...g,
				status: "active",
				finishedAt: void 0,
				startedAt: now - frozen,
				runningSince: now
			};
		}) });
	}
}), {
	name: "war-ledger",
	skipHydration: true,
	storage: createJSONStorage(() => idbStorage()),
	merge: (persistedState, currentState) => {
		const persisted = persistedState ?? {};
		const lists = mergeLists(persisted.lists, currentState.lists);
		const games = mergeGames(persisted.games, currentState.games);
		const currentActive = currentState.activeGameId && games.some((g) => g.id === currentState.activeGameId) ? currentState.activeGameId : null;
		const persistedActive = persisted.activeGameId && games.some((g) => g.id === persisted.activeGameId) ? persisted.activeGameId : null;
		return {
			...currentState,
			lists,
			games,
			activeGameId: currentActive ?? persistedActive
		};
	},
	partialize: (s) => ({
		lists: s.lists,
		games: s.games,
		activeGameId: s.activeGameId
	})
}));
function useActiveGame() {
	return useWarStore((s) => s.games.find((g) => g.id === s.activeGameId));
}
var hydrateOnce = null;
function hydrateWarStore() {
	if (hydrateOnce) return hydrateOnce;
	hydrateOnce = Promise.resolve(useWarStore.persist.rehydrate()).catch(() => void 0).finally(() => {
		useWarStore.getState().setHydrated();
	});
	return hydrateOnce;
}
var NAV = [
	{
		to: "/",
		label: "Lists",
		icon: List,
		match: (p) => p === "/" || p.startsWith("/lists")
	},
	{
		to: "/battle",
		label: "Ledger",
		icon: Swords,
		match: (p) => p.startsWith("/battle")
	},
	{
		to: "/analytics",
		label: "Annals",
		icon: ScrollText,
		match: (p) => p.startsWith("/analytics")
	},
	{
		to: "/codex",
		label: "Codex",
		icon: BookOpen,
		match: (p) => p.startsWith("/codex")
	},
	{
		to: "/lab",
		label: "Lab",
		icon: Crosshair,
		match: (p) => p.startsWith("/lab")
	}
];
function AppShell({ children }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const activeGameId = useWarStore((s) => s.activeGameId);
	(0, import_react.useEffect)(() => {
		hydrateWarStore();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "tactical-grid min-h-dvh",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-30 border-b border-border bg-background",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex h-14 max-w-6xl items-center justify-between px-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "flex items-baseline gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-lg font-semibold tracking-wide",
							children: "Ono40k"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden text-[10px] tracking-[0.2em] text-muted-foreground uppercase sm:inline",
							children: "11th edition"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "hidden items-center gap-1 md:flex",
						children: NAV.map((item) => {
							const active = item.match(pathname);
							const Icon = item.icon;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: item.to,
								className: cn("relative flex h-10 items-center gap-2 rounded-md px-3 text-sm font-medium", active ? "bg-accent text-foreground" : "text-muted-foreground hover:bg-accent/60 hover:text-foreground"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }),
									item.label,
									item.to === "/battle" && activeGameId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-1.5 right-1.5 size-1.5 rounded-full bg-blood" }) : null
								]
							}, item.to);
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "mx-auto w-full min-w-0 max-w-6xl px-4 pt-5 pb-24 md:pb-10",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-30 border-t border-border bg-background pb-[env(safe-area-inset-bottom)] md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-5",
					children: NAV.map((item) => {
						const active = item.match(pathname);
						const Icon = item.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							className: cn("relative flex min-h-14 flex-col items-center justify-center gap-0.5 text-[11px] font-medium tracking-wide uppercase", active ? "text-foreground" : "text-muted-foreground"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }),
								item.label,
								item.to === "/battle" && activeGameId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-2 right-[calc(50%-18px)] size-1.5 rounded-full bg-blood" }) : null
							]
						}, item.to);
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, {})
		]
	});
}
var styles_default = "/assets/styles-x-uquf3Q.css";
var APP_NAME = "Ono40k";
var Route$7 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "theme-color",
				content: "#0B0C0E"
			},
			{
				name: "description",
				content: "Muster armies, track the fight, close the ledger."
			}
		],
		links: [
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Cinzel:wght@500;600;700&family=IBM+Plex+Sans:ital,wght@0,400;0,500;0,600;1,400&family=IBM+Plex+Mono:wght@500;600&display=swap"
			},
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$5 = () => import("./routes-BwBHPLRx.mjs");
var Route$6 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./analytics-DpAkQ-LA.mjs");
var Route$5 = createFileRoute("/analytics")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./battle-ZA6RvmRB.mjs");
var Route$4 = createFileRoute("/battle")({
	validateSearch: (s) => ({ setup: typeof s.setup === "string" ? s.setup : void 0 }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./codex-DO-_-FaE.mjs");
var Route$3 = createFileRoute("/codex")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./lab-G_S4KQIx.mjs");
var Route$2 = createFileRoute("/lab")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var Route$1 = createFileRoute("/lists/")({ beforeLoad: () => {
	throw redirect({ to: "/" });
} });
var $$splitComponentImporter = () => import("./lists._listId-Dq1e9sPZ.mjs");
var Route = createFileRoute("/lists/$listId")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var IndexRoute = Route$6.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$7
});
var AnalyticsRoute = Route$5.update({
	id: "/analytics",
	path: "/analytics",
	getParentRoute: () => Route$7
});
var BattleRoute = Route$4.update({
	id: "/battle",
	path: "/battle",
	getParentRoute: () => Route$7
});
var CodexRoute = Route$3.update({
	id: "/codex",
	path: "/codex",
	getParentRoute: () => Route$7
});
var LabRoute = Route$2.update({
	id: "/lab",
	path: "/lab",
	getParentRoute: () => Route$7
});
var ListsIndexRoute = Route$1.update({
	id: "/lists/",
	path: "/lists/",
	getParentRoute: () => Route$7
});
var rootRouteChildren = {
	IndexRoute,
	AnalyticsRoute,
	BattleRoute,
	CodexRoute,
	LabRoute,
	ListsListIdRoute: Route.update({
		id: "/lists/$listId",
		path: "/lists/$listId",
		getParentRoute: () => Route$7
	}),
	ListsIndexRoute
};
var routeTree = Route$7._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { parseObjective as A, scoreOptions as C, checkCount as D, DISPOSITIONS as E, SEED_LISTS as F, totalScore as M, BATTLE_SIZES as N, missionFor as O, PHASES as P, cardAward as S, secondaryVp as T, areaLabel as _, useWarStore as a, FIXED_SECONDARIES as b, rosterDp as c, validateRoster as d, resolvedWargearIds as f, wargearSummary as g, wargearGroups as h, useActiveGame as i, sideVp as j, objectiveVp as k, rosterPoints as l, setWargearGroup as m, Route as n, primaryForSide as o, rosterLoadout as p, Route$4 as r, rosterDisposition as s, router_exports as t, unitTotalPoints as u, getMap as v, secondaryLines as w, SECONDARIES as x, layoutsFor as y };
