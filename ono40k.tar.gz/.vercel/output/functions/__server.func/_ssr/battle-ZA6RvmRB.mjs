import { i as __toESM } from "../_runtime.mjs";
import { a as formatClock, c as getUnit, d as turnElapsedMs, f as uid, i as cn, l as remainingWounds, m as unitMaxWounds, o as getDetachment, p as unitCopyMarks, r as battleElapsedMs, s as getFaction, t as FACTIONS } from "./utils-hP9YwH9-.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { S as Check, b as ChevronLeft, d as Plus, f as Play, m as Minus, n as Undo2, p as Pause, s as Skull, t as X } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { A as parseObjective, C as scoreOptions, D as checkCount, N as BATTLE_SIZES, P as PHASES, S as cardAward, T as secondaryVp, _ as areaLabel, a as useWarStore, b as FIXED_SECONDARIES, g as wargearSummary, i as useActiveGame, j as sideVp, k as objectiveVp, l as rosterPoints, o as primaryForSide, r as Route$4, s as rosterDisposition, v as getMap, w as secondaryLines, x as SECONDARIES, y as layoutsFor } from "./router-cdYjUO9_.mjs";
import { t as Badge } from "./badge-DTfl_mpk.mjs";
import { n as Card, t as Button } from "./card-6JO_WVWA.mjs";
import { n as RuleFold, t as Datasheet } from "./RuleFold-BYMBt6uO.mjs";
import { n as Textarea, t as Input } from "./input-D-dBVxfd.mjs";
import { t as Label } from "./label-FG9JJXgY.mjs";
import { a as TabsList, i as TabsContent, n as CORE_STRATAGEMS, o as TabsTrigger, r as Tabs, s as stratagemPrimaryPhase } from "./core-cuR8Fl8E.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/battle-ZA6RvmRB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function BattleMap({ layout, className, compact = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 60 44",
		className: cn("w-full overflow-visible", className),
		role: "img",
		"aria-label": `${layout.name} on a ${layout.board} board`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "60",
				height: "44",
				fill: "var(--color-muted)"
			}),
			layout.zones.map((z) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: z.points,
				fill: z.side === "defender" ? "var(--color-steel)" : "var(--color-blood)",
				fillOpacity: "0.22",
				stroke: z.side === "defender" ? "var(--color-steel)" : "var(--color-blood)",
				strokeWidth: compact ? .5 : .32,
				strokeOpacity: "0.9"
			}, z.side)),
			layout.terrain.map((points, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points,
				fill: "var(--color-foreground)",
				fillOpacity: "0.04",
				stroke: "var(--color-foreground)",
				strokeWidth: compact ? .42 : .26,
				strokeOpacity: "0.4",
				strokeDasharray: compact ? void 0 : "1.15 0.7"
			}, `t-${i}`)),
			layout.ruins.map((points, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points,
				fill: "var(--color-background)",
				stroke: "var(--color-foreground)",
				strokeWidth: compact ? .32 : .18,
				strokeOpacity: "0.75"
			}, `r-${i}`)),
			layout.markers.map((m, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: m.x,
				cy: m.y,
				r: compact ? 1.15 : 1.7,
				fill: "var(--color-card)",
				stroke: m.owner === "attacker" ? "var(--color-blood)" : m.owner === "defender" ? "var(--color-steel)" : "var(--color-foreground)",
				strokeWidth: "0.45"
			}), compact ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: m.x,
				y: m.y + .7,
				textAnchor: "middle",
				fill: "var(--color-foreground)",
				fontSize: "2.2",
				fontFamily: "ui-sans-serif, system-ui, sans-serif",
				children: areaLabel(m.kind)
			})] }, `m-${i}`)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "60",
				height: "44",
				fill: "none",
				stroke: "var(--color-border)",
				strokeWidth: "0.5"
			})
		]
	});
}
function defaultPreBattle() {
	return {
		rollOff: null,
		attacker: "me",
		deploysFirst: "opponent",
		firstTurn: "me",
		mapId: null,
		terrainNote: "",
		formationNote: "",
		scoutIds: [],
		infiltrateIds: []
	};
}
function hasScout(def) {
	return def.keywords.some((k) => /scout/i.test(k)) || def.abilities.some((a) => /scout/i.test(a.name));
}
function hasInfiltrate(def) {
	return def.keywords.some((k) => /infiltrate/i.test(k)) || def.abilities.some((a) => /infiltrate/i.test(a.name));
}
function preAbilityUnits(roster) {
	const out = [];
	for (const ru of roster.units) {
		const def = getUnit(roster.factionId, ru.unitId);
		if (!def) continue;
		const scout = hasScout(def);
		const infiltrate = hasInfiltrate(def);
		if (scout || infiltrate) out.push({
			ru,
			def,
			scout,
			infiltrate
		});
	}
	return out;
}
function otherSide(side) {
	return side === "me" ? "opponent" : "me";
}
function pickAttacker(prev, attacker) {
	return {
		...prev,
		attacker,
		deploysFirst: otherSide(attacker)
	};
}
function emptyDraft() {
	return {
		mode: null,
		fixedIds: [],
		painted: true
	};
}
function toScore(draft) {
	const meta = {};
	if (draft.mode === "fixed") for (const id of draft.fixedIds) meta[id] = { selectedRound: 1 };
	return {
		primaryByRound: [
			0,
			0,
			0,
			0,
			0
		],
		primaryChecks: [],
		secondaryMode: draft.mode,
		fixedIds: draft.mode === "fixed" ? draft.fixedIds : [],
		tacticalActive: [],
		secondaryChecks: {},
		secondaryMeta: meta,
		tactical: 0,
		painted: draft.painted ? 10 : 0
	};
}
function PreBattleForm({ myName, oppName, mine, theirs, onBack, onStart }) {
	const [brief, setBrief] = (0, import_react.useState)(defaultPreBattle);
	const [meScore, setMeScore] = (0, import_react.useState)(emptyDraft);
	const [themScore, setThemScore] = (0, import_react.useState)(emptyDraft);
	const myPrimary = primaryForSide(mine, theirs);
	const theirPrimary = primaryForSide(theirs, mine);
	const sizeMismatch = mine.battleSize !== theirs.battleSize;
	const myAbilities = (0, import_react.useMemo)(() => preAbilityUnits(mine), [mine]);
	const theirAbilities = (0, import_react.useMemo)(() => preAbilityUnits(theirs), [theirs]);
	const myCopies = (0, import_react.useMemo)(() => unitCopyMarks(mine.units), [mine.units]);
	const theirCopies = (0, import_react.useMemo)(() => unitCopyMarks(theirs.units), [theirs.units]);
	const maps = layoutsFor(rosterDisposition(mine), rosterDisposition(theirs));
	const selectedMap = getMap(brief.mapId);
	const secondariesReady = (d) => d.mode === "tactical" || d.mode === "fixed" && d.fixedIds.length === 2;
	const ready = secondariesReady(meScore) && secondariesReady(themScore) && Boolean(brief.mapId || maps.length === 0);
	const nameOf = (side) => side === "me" ? myName : oppName;
	const defender = otherSide(brief.attacker);
	const toggleFixed = (which, id) => {
		(which === "me" ? setMeScore : setThemScore)((prev) => {
			const next = prev.fixedIds.includes(id) ? prev.fixedIds.filter((x) => x !== id) : prev.fixedIds.length >= 2 ? prev.fixedIds : [...prev.fixedIds, id];
			return {
				...prev,
				mode: "fixed",
				fixedIds: next
			};
		});
	};
	const toggleAbility = (kind, unitId) => {
		setBrief((prev) => {
			const key = kind === "scout" ? "scoutIds" : "infiltrateIds";
			const other = kind === "scout" ? "infiltrateIds" : "scoutIds";
			const on = prev[key].includes(unitId);
			return {
				...prev,
				[key]: on ? prev[key].filter((id) => id !== unitId) : [...prev[key], unitId],
				[other]: prev[other].filter((id) => id !== unitId)
			};
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-lg space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium tracking-[0.22em] text-muted-foreground uppercase",
					children: "War Journal · Pre-battle"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display mt-1 text-3xl font-semibold",
					children: "11th edition muster"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Mission, secondaries, attacker, and Scout / Infiltrate — then the ledger opens."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase",
						children: "1 · Mission"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-border bg-card p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm",
								children: [
									getFaction(mine.factionId)?.name,
									" · ",
									BATTLE_SIZES[mine.battleSize].label,
									" · ",
									rosterDisposition(mine) ?? "no disposition"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: [
									"vs ",
									getFaction(theirs.factionId)?.name,
									" · ",
									BATTLE_SIZES[theirs.battleSize].label,
									" · ",
									rosterDisposition(theirs) ?? "no disposition"
								]
							}),
							sizeMismatch ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-blood",
								children: "Battle sizes differ. Play to the lower limit, or swap a list."
							}) : null
						]
					}),
					myPrimary ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RuleFold, {
						kicker: `${myName} · primary`,
						title: myPrimary.info.name,
						text: myPrimary.info.blurb,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "list-disc space-y-1 pl-4 text-sm text-muted-foreground",
							children: myPrimary.info.scoring.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: line }, line))
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Set a force disposition on both lists to generate a primary."
					}),
					theirPrimary ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RuleFold, {
						kicker: `${oppName} · primary`,
						title: theirPrimary.info.name,
						text: theirPrimary.info.blurb,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "list-disc space-y-1 pl-4 text-sm text-muted-foreground",
							children: theirPrimary.info.scoring.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: line }, line))
						})
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "11th edition scores terrain areas, not 40mm markers. Place home, expansions, and centre as terrain features."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase",
						children: "2 · Secondaries"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Pick Fixed (two cards) or Tactical for both players."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryDraft, {
						name: myName,
						draft: meScore,
						onChange: setMeScore,
						onToggleFixed: (id) => toggleFixed("me", id)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryDraft, {
						name: oppName,
						draft: themScore,
						onChange: setThemScore,
						onToggleFixed: (id) => toggleFixed("them", id)
					}),
					!secondariesReady(meScore) || !secondariesReady(themScore) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-blood",
						children: !secondariesReady(meScore) && !secondariesReady(themScore) ? "Both players still need a secondary mode." : !secondariesReady(meScore) ? `${myName}: pick Fixed (two cards) or Tactical.` : `${oppName}: pick Fixed (two cards) or Tactical.`
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase",
					children: "3 · Attacker and first turn"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-border bg-card p-4 space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "Roll off. Winner chooses to attack or defend. Defender deploys first; the player who finishes deploying first chooses who takes turn 1."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] tracking-[0.14em] text-muted-foreground uppercase",
							children: "Won the roll-off"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidePair, {
							a: myName,
							b: oppName,
							value: brief.rollOff,
							onChange: (side) => setBrief((p) => ({
								...p,
								rollOff: side
							}))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] tracking-[0.14em] text-muted-foreground uppercase",
							children: "Attacker"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidePair, {
							a: myName,
							b: oppName,
							value: brief.attacker,
							onChange: (side) => setBrief((p) => pickAttacker(p, side))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								"Defender ",
								nameOf(defender),
								" deploys first, then ",
								nameOf(brief.attacker),
								"."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] tracking-[0.14em] text-muted-foreground uppercase",
							children: "First turn"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidePair, {
							a: myName,
							b: oppName,
							value: brief.firstTurn,
							onChange: (side) => setBrief((p) => ({
								...p,
								firstTurn: side,
								deploysFirst: p.deploysFirst
							}))
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase",
						children: "4 · Battlefield"
					}),
					maps.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Set force dispositions on both lists to load the three Event Companion maps for this pairing."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								rosterDisposition(mine),
								" vs ",
								rosterDisposition(theirs),
								" · 44×60 · pick Layout A, B, or C. Roll D3 if the organiser has not locked one."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-3 gap-1.5",
							children: maps.map((layout) => {
								const on = brief.mapId === layout.id;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setBrief((p) => ({
										...p,
										mapId: layout.id
									})),
									className: cn("min-w-0 rounded-lg border p-1.5 text-left", on ? "border-primary bg-accent" : "border-border bg-card"),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BattleMap, {
											layout,
											compact: true
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 truncate text-[11px] font-medium leading-tight",
											children: layout.letter
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "truncate text-[10px] leading-tight text-muted-foreground",
											children: layout.name.replace(/^Layout [ABC] · /, "")
										})
									]
								}, layout.id);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-1.5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								className: "flex-1",
								onClick: () => {
									const pick = maps[Math.floor(Math.random() * maps.length)];
									if (pick) setBrief((p) => ({
										...p,
										mapId: pick.id
									}));
								},
								children: "Roll D3"
							})
						}),
						selectedMap ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-border bg-card p-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium",
									children: selectedMap.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-0.5 text-xs text-muted-foreground",
									children: selectedMap.blurb
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BattleMap, {
									layout: selectedMap,
									className: "mt-2"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-[11px] text-muted-foreground",
									children: "H home · E expansion · C centre · steel defender · crimson attacker. Event Companion ruins and deployment zones."
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "Select a map to continue."
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: brief.terrainNote,
						onChange: (e) => setBrief((p) => ({
							...p,
							terrainNote: e.target.value
						})),
						placeholder: "House terrain notes (optional)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: brief.formationNote,
						onChange: (e) => setBrief((p) => ({
							...p,
							formationNote: e.target.value
						})),
						placeholder: "Reserves, embarked units, assigned transports…"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase",
						children: "5 · Scout and Infiltrate"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "A unit cannot use both in the same battle. Tick what you actually used."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AbilityList, {
						label: myName,
						units: myAbilities,
						copies: myCopies,
						scoutIds: brief.scoutIds,
						infiltrateIds: brief.infiltrateIds,
						onToggle: toggleAbility
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AbilityList, {
						label: oppName,
						units: theirAbilities,
						copies: theirCopies,
						scoutIds: brief.scoutIds,
						infiltrateIds: brief.infiltrateIds,
						onToggle: toggleAbility
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2 pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: onBack,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" }), "Armies"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: !ready,
					onClick: () => onStart(brief, {
						me: toScore(meScore),
						opponent: toScore(themScore)
					}),
					children: "Open the ledger"
				})]
			})
		]
	});
}
function SidePair({ a, b, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-2 gap-1.5",
		children: ["me", "opponent"].map((side) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => onChange(side),
			className: cn("min-h-11 rounded-md border px-2 text-sm font-medium", value === side ? "border-primary bg-primary text-primary-foreground" : "border-border bg-muted text-muted-foreground"),
			children: side === "me" ? a : b
		}, side))
	});
}
function SecondaryDraft({ name, draft, onChange, onToggleFixed }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-border bg-card p-4 space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium",
				children: name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onChange({
						...draft,
						mode: "fixed"
					}),
					className: cn("min-h-11 rounded-md border text-sm font-medium", draft.mode === "fixed" ? "border-primary bg-primary text-primary-foreground" : "border-border bg-muted text-muted-foreground"),
					children: "Fixed"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onChange({
						...draft,
						mode: "tactical",
						fixedIds: []
					}),
					className: cn("min-h-11 rounded-md border text-sm font-medium", draft.mode === "tactical" ? "border-primary bg-primary text-primary-foreground" : "border-border bg-muted text-muted-foreground"),
					children: "Tactical"
				})]
			}),
			draft.mode === "fixed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-1.5",
				children: FIXED_SECONDARIES.map((c) => {
					const on = draft.fixedIds.includes(c.id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: !on && draft.fixedIds.length >= 2,
						onClick: () => onToggleFixed(c.id),
						className: cn("min-h-11 rounded-md border px-2 py-1.5 text-left text-xs font-medium", on ? "border-primary bg-accent" : "border-border bg-muted text-muted-foreground"),
						children: c.name
					}, c.id);
				})
			}) : draft.mode === "tactical" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Draw two at the start of your turn. Score or discard during the game."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Fixed: pick two for the whole game. Tactical: draw each turn."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => onChange({
					...draft,
					painted: !draft.painted
				}),
				className: cn("text-[11px] tracking-wide uppercase", draft.painted ? "text-ok" : "text-muted-foreground"),
				children: draft.painted ? "Painted +10" : "Unpainted"
			})
		]
	});
}
function AbilityList({ label, units, copies, scoutIds, infiltrateIds, onToggle }) {
	if (!units.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "text-sm text-muted-foreground",
		children: [label, ": no Scout or Infiltrate units on this list."]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-border bg-card p-3 space-y-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] tracking-[0.14em] text-muted-foreground uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-2",
			children: units.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex min-w-0 flex-wrap items-center gap-1.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1 truncate text-sm",
						children: [u.def.name, copies[u.ru.id] ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "ml-1 text-[10px] tracking-widest text-steel",
							children: [
								"[",
								copies[u.ru.id],
								"]"
							]
						}) : null]
					}),
					u.infiltrate ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onToggle("infiltrate", u.ru.id),
						className: cn("h-8 rounded-md border px-2 text-[11px] uppercase", infiltrateIds.includes(u.ru.id) ? "border-primary bg-accent" : "border-border text-muted-foreground"),
						children: "Infiltrate"
					}) : null,
					u.scout ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onToggle("scout", u.ru.id),
						className: cn("h-8 rounded-md border px-2 text-[11px] uppercase", scoutIds.includes(u.ru.id) ? "border-primary bg-accent" : "border-border text-muted-foreground"),
						children: "Scout"
					}) : null
				]
			}, u.ru.id))
		})]
	});
}
function preBattleLine(game) {
	const b = game.preBattle;
	if (!b) return null;
	const who = (s) => s === "me" ? game.myName : game.opponentName;
	const mode = (s) => s.secondaryMode === "fixed" ? "Fixed" : s.secondaryMode === "tactical" ? "Tactical" : "—";
	const map = getMap(b.mapId);
	const mapBit = map ? ` · ${map.name}` : "";
	return `Attacker ${who(b.attacker)} · first ${who(b.firstTurn)} · ${mode(game.scores.me)} / ${mode(game.scores.opponent)}${mapBit}`;
}
var ROLE_RANK = {
	character: 0,
	battleline: 1,
	infantry: 2,
	mounted: 3,
	monster: 4,
	vehicle: 5,
	transport: 6
};
function defaultDetachmentIds(factionId) {
	const first = getFaction(factionId)?.detachments[0];
	return first ? [first.id] : [];
}
function tableRoster(factionId, detachmentIds, disposition) {
	const faction = getFaction(factionId);
	if (!faction) return null;
	const dets = detachmentIds.length ? detachmentIds : defaultDetachmentIds(factionId);
	const units = [...faction.units].sort((a, b) => {
		const ra = ROLE_RANK[a.role] - ROLE_RANK[b.role];
		if (ra) return ra;
		return a.name.localeCompare(b.name);
	}).map((u) => {
		const size = u.sizes?.[0];
		return {
			id: uid("u"),
			unitId: u.id,
			models: size?.models ?? 1,
			points: size?.points ?? u.points
		};
	});
	const warlord = units.find((ru) => faction.units.find((u) => u.id === ru.unitId)?.keywords.includes("Epic Hero")) ?? units.find((ru) => faction.units.find((u) => u.id === ru.unitId)?.role === "character");
	if (warlord) warlord.warlord = true;
	const now = Date.now();
	const roster = {
		id: uid("tbl"),
		name: faction.name,
		factionId,
		battleSize: "strike",
		pointsLimit: BATTLE_SIZES.strike.points,
		detachmentIds: dets,
		disposition: disposition ?? null,
		units,
		notes: "Table army — full codex, not a built list.",
		favorite: false,
		saved: false,
		createdAt: now,
		updatedAt: now
	};
	roster.disposition = rosterDisposition(roster);
	return roster;
}
/** 11th edition: one model uses wounds; a unit uses model count. Odd totals cannot be exactly half. */
function strengthState(input) {
	if (input.destroyed || input.modelsNow <= 0 || input.woundsNow <= 0) return {
		belowStarting: false,
		atHalf: false,
		belowHalf: false,
		atOrBelowHalf: false
	};
	const single = input.modelsStart <= 1;
	const start = single ? input.woundsMax : input.modelsStart;
	const now = single ? input.woundsNow : input.modelsNow;
	const belowStarting = now < start;
	const atHalf = start % 2 === 0 && now === start / 2;
	const belowHalf = now < start / 2;
	return {
		belowStarting,
		atHalf,
		belowHalf,
		atOrBelowHalf: atHalf || belowHalf
	};
}
function kindOf(text) {
	return /−\d|subtract\s+1|-\d to/i.test(text) ? "penalty" : "buff";
}
function shortEffect(text) {
	const has = text.match(/it has ([^.]+)/i)?.[1];
	if (has) return has.replace(/^a /i, "").replace(/\.$/, "");
	const fnp = text.match(/(\d\+\s+Feel No Pain(?:[^.]*)?)/i)?.[1];
	if (fnp) return fnp.replace(/\.$/, "").replace(/\s+while it is below starting strength/i, "");
	const penalty = text.match(/(−\d[^.]*)/)?.[1];
	if (penalty) return penalty.replace(/\.$/, "");
	return text.replace(/\s+/g, " ").slice(0, 90);
}
function woundEffects(input) {
	const { state, unit, woundsNow } = input;
	if (woundsNow <= 0) return [];
	const effects = [];
	if (input.battleShocked) effects.push({
		name: "Battle-shock",
		text: "OC 0 · Stratagems cannot affect this unit",
		kind: "penalty"
	});
	else if (state.atOrBelowHalf) effects.push({
		name: "Half-strength",
		text: "Test Battle-shock",
		kind: "penalty"
	});
	for (const ability of unit.abilities) {
		if (/enemy units/i.test(ability.text)) continue;
		const at = ability.text.match(/reduced to (\d+) wounds remaining/i);
		if (at) {
			if (woundsNow <= Number(at[1])) {
				const text = shortEffect(ability.text);
				effects.push({
					name: ability.name,
					text,
					kind: kindOf(text)
				});
			}
			continue;
		}
		if (/below half-strength/i.test(ability.text) && state.belowHalf) {
			const text = shortEffect(ability.text);
			effects.push({
				name: ability.name,
				text,
				kind: kindOf(text)
			});
		} else if (/below (its |the )?starting strength/i.test(ability.text) && state.belowStarting) {
			const text = shortEffect(ability.text);
			effects.push({
				name: ability.name,
				text,
				kind: kindOf(text)
			});
		}
	}
	for (const id of input.roster.detachmentIds) {
		const det = getDetachment(input.roster.factionId, id);
		if (!det) continue;
		const rule = det.rule.text;
		if (/below (its |the )?starting strength|below half-strength/i.test(rule)) {
			const monsterOnly = /monster/i.test(rule);
			const vehicleOnly = /vehicle/i.test(rule) && !monsterOnly;
			if ((!monsterOnly || unit.keywords.some((k) => k.toLowerCase() === "monster")) && (!vehicleOnly || unit.keywords.some((k) => k.toLowerCase() === "vehicle")) && state.belowStarting && /below (its |the )?starting strength/i.test(rule)) {
				const parts = [];
				if (/\+1 to Hit/i.test(rule)) parts.push("+1 to Hit");
				if (/\+1 to Wound/i.test(rule)) parts.push("+1 to Wound");
				if (state.belowHalf && /\+1 Attack/i.test(rule)) parts.push("+1 Attack");
				const text = parts.length > 0 ? parts.join(", ") : shortEffect(rule);
				effects.push({
					name: det.rule.name,
					text,
					kind: kindOf(text)
				});
			}
		}
		const enh = input.enhancementId ? det.enhancements.find((e) => e.id === input.enhancementId) : void 0;
		if (!enh) continue;
		if (/below (its |the )?starting strength/i.test(enh.text) && state.belowStarting) {
			const text = shortEffect(enh.text);
			effects.push({
				name: enh.name,
				text,
				kind: kindOf(text)
			});
		} else if (/below half-strength/i.test(enh.text) && state.belowHalf) {
			const text = shortEffect(enh.text);
			effects.push({
				name: enh.name,
				text,
				kind: kindOf(text)
			});
		}
	}
	if (input.enemy && state.belowHalf) {
		const seen = /* @__PURE__ */ new Set();
		for (const ru of input.enemy.units) {
			if (seen.has(ru.unitId)) continue;
			const st = input.unitState[ru.id];
			if (!st || st.destroyed || st.modelsRemaining <= 0) continue;
			seen.add(ru.unitId);
			const sheet = getUnit(input.enemy.factionId, ru.unitId);
			if (!sheet) continue;
			for (const ability of sheet.abilities) {
				if (!/enemy units/i.test(ability.text) || !/below half-strength/i.test(ability.text)) continue;
				const text = shortEffect(ability.text);
				effects.push({
					name: ability.name,
					text: `${text} if within 6"`,
					kind: "penalty"
				});
			}
		}
	}
	return effects;
}
function BattlePage() {
	const game = useActiveGame();
	const { setup } = Route$4.useSearch();
	const leaveGame = useWarStore((s) => s.leaveGame);
	const openingNew = Boolean(setup) && (!game || game.status === "complete");
	(0, import_react.useEffect)(() => {
		if (setup && game?.status === "complete") leaveGame();
	}, [
		setup,
		game?.status,
		leaveGame
	]);
	if (!game || openingNew) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BattleSetup, { presetListId: setup });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BattleTable, { game });
}
function resolveArmy(source, lists) {
	if (source.kind === "list") return lists.find((l) => l.id === source.listId) ?? null;
	return tableRoster(source.factionId, source.detachmentIds, source.disposition);
}
function sourceKey(source) {
	if (source.kind === "list") return `list:${source.listId}`;
	return `codex:${source.factionId}:${[...source.detachmentIds].sort().join(",")}:${source.disposition ?? ""}`;
}
function armyTitle(source, lists) {
	if (source.kind === "list") return lists.find((l) => l.id === source.listId)?.name ?? "List";
	return getFaction(source.factionId)?.name ?? "Codex army";
}
function armyMeta(source, lists) {
	if (source.kind === "list") {
		const roster = lists.find((l) => l.id === source.listId);
		if (!roster) return "";
		return [
			getFaction(roster.factionId)?.name,
			roster.detachmentIds.map((id) => getDetachment(roster.factionId, id)?.name).filter(Boolean).join(" · "),
			`${rosterPoints(roster)} pts`
		].filter(Boolean).join(" · ");
	}
	return [
		getFaction(source.factionId)?.name,
		source.detachmentIds.map((id) => getDetachment(source.factionId, id)?.name).filter(Boolean).join(" · "),
		source.disposition ?? getDetachment(source.factionId, source.detachmentIds[0] ?? "")?.disposition ?? null,
		"Codex"
	].filter(Boolean).join(" · ");
}
function defaultCodex(factionId) {
	const ids = defaultDetachmentIds(factionId);
	return {
		kind: "codex",
		factionId,
		detachmentIds: ids,
		disposition: getDetachment(factionId, ids[0] ?? "")?.disposition ?? null
	};
}
function BattleSetup({ presetListId }) {
	const lists = useWarStore((s) => s.lists);
	const startGame = useWarStore((s) => s.startGame);
	const navigate = useNavigate();
	const [step, setStep] = (0, import_react.useState)("pool");
	const [myName, setMyName] = (0, import_react.useState)("You");
	const [oppName, setOppName] = (0, import_react.useState)("Opponent");
	const [pool, setPool] = (0, import_react.useState)([]);
	const [draft, setDraft] = (0, import_react.useState)(() => defaultCodex("um"));
	const [codexArmed, setCodexArmed] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!presetListId || !lists.some((l) => l.id === presetListId)) return;
		setPool((prev) => prev.some((s) => s.kind === "list" && s.listId === presetListId) ? prev : [{
			kind: "list",
			listId: presetListId
		}, ...prev]);
	}, [presetListId, lists]);
	const you = pool[0] ?? null;
	const them = pool[1] ?? null;
	const myRoster = you ? resolveArmy(you, lists) : null;
	const oppRoster = them ? resolveArmy(them, lists) : null;
	const codexQuiet = pool.length >= 2;
	const toggleList = (listId) => {
		if (pool.some((s) => s.kind === "list" && s.listId === listId)) {
			setPool(pool.filter((s) => !(s.kind === "list" && s.listId === listId)));
			return;
		}
		if (pool.length >= 2) {
			toast("Only two armies. Untick one first.");
			return;
		}
		setPool([...pool, {
			kind: "list",
			listId
		}]);
	};
	const addDraft = () => {
		if (pool.length >= 2) {
			toast("Only two armies. Untick one first.");
			return;
		}
		if (draft.detachmentIds.length === 0) {
			toast("Select at least one detachment");
			return;
		}
		const key = sourceKey(draft);
		setPool((prev) => prev.some((s) => sourceKey(s) === key) ? prev : [...prev, draft]);
	};
	const removeFromPool = (key) => {
		setPool((prev) => prev.filter((s) => sourceKey(s) !== key));
	};
	if (step === "briefing" && myRoster && oppRoster) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreBattleForm, {
		myName,
		oppName,
		mine: myRoster,
		theirs: oppRoster,
		onBack: () => setStep("pool"),
		onStart: (briefing, scores) => {
			if (startGame({
				mine: myRoster,
				theirs: oppRoster,
				myName,
				opponentName: oppName,
				briefing,
				scores
			})) navigate({ to: "/battle" });
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-lg space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium tracking-[0.22em] text-muted-foreground uppercase",
					children: "War Journal · Armies"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display mt-1 text-3xl font-semibold",
					children: "Pick armies"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Tick the two lists for this game, or add a faction from the codex with up to 3 DP of detachments."
				})
			] }),
			lists.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase",
					children: "Saved lists"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid grid-cols-2 gap-1.5",
					children: lists.map((l) => {
						const on = pool.some((s) => s.kind === "list" && s.listId === l.id);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => toggleList(l.id),
							className: cn("flex min-h-11 w-full min-w-0 items-center gap-2 rounded-md border px-2.5 py-2 text-left", on ? "border-primary bg-accent" : "border-border bg-muted"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("flex size-3.5 shrink-0 items-center justify-center rounded-sm border", on ? "border-primary bg-primary text-primary-foreground" : "border-border"),
								children: on ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-2.5" }) : null
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate text-xs font-medium",
									children: l.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate text-[11px] text-muted-foreground",
									children: getFaction(l.factionId)?.name
								})]
							})]
						}) }, l.id);
					})
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodexDraft, {
				source: draft,
				quiet: codexQuiet,
				open: codexArmed && !codexQuiet,
				onSource: (next) => {
					setCodexArmed(true);
					setDraft(next);
				}
			}),
			codexArmed && !codexQuiet ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				className: "w-full",
				disabled: draft.detachmentIds.length === 0,
				onClick: addDraft,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Add to this game"]
			}) : null,
			pool.filter((s) => s.kind === "codex").length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase",
					children: "Codex armies added"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-1.5",
					children: pool.filter((s) => s.kind === "codex").map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-2 rounded-md border border-border bg-card px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-sm",
								children: armyTitle(s, lists)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-[11px] text-muted-foreground",
								children: armyMeta(s, lists)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon-sm",
							variant: "ghost",
							"aria-label": "Remove army",
							onClick: () => removeFromPool(sourceKey(s)),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						})]
					}, sourceKey(s)))
				})]
			}) : null,
			pool.length === 2 && you && them ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "You" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: myName,
							onChange: (e) => setMyName(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-[11px] text-muted-foreground",
							children: armyTitle(you, lists)
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Opponent" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: oppName,
							onChange: (e) => setOppName(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-[11px] text-muted-foreground",
							children: armyTitle(them, lists)
						})
					]
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					disabled: pool.length !== 2,
					onClick: () => setPool((prev) => prev.length === 2 ? [prev[1], prev[0]] : prev),
					children: "Swap sides"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "w-full",
					disabled: pool.length < 2 || !myRoster || !oppRoster,
					onClick: () => setStep("briefing"),
					children: "Pre-battle"
				})]
			}),
			pool.length < 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-sm text-muted-foreground",
				children: "Add at least two armies to continue."
			}) : null
		]
	});
}
function CodexDraft({ source, quiet, open, onSource }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-xl border border-border bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase",
				children: "Add a codex army"
			}),
			quiet ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Two armies are selected. Untick one to use the codex."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-1.5",
				children: FACTIONS.map((f) => {
					const on = open && source.factionId === f.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							if (quiet) {
								toast("Two armies are already selected. Untick one first.");
								return;
							}
							onSource(defaultCodex(f.id));
						},
						className: cn("min-h-11 rounded-md border px-2 py-1.5 text-left text-xs font-medium", on ? "border-primary bg-accent" : "border-border bg-muted text-muted-foreground"),
						children: f.name
					}, f.id);
				})
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodexDetachmentPicker, {
				factionId: source.factionId,
				detachmentIds: source.detachmentIds,
				disposition: source.disposition,
				onChange: (next) => onSource({
					kind: "codex",
					factionId: source.factionId,
					...next
				})
			}) : null
		]
	});
}
function CodexDetachmentPicker({ factionId, detachmentIds, disposition, onChange }) {
	const faction = getFaction(factionId);
	if (!faction) return null;
	const dp = detachmentIds.reduce((sum, id) => sum + (getDetachment(factionId, id)?.dp ?? 0), 0);
	const availableDisp = [...new Set(detachmentIds.map((id) => getDetachment(factionId, id)?.disposition).filter(Boolean))];
	const current = disposition && availableDisp.includes(disposition) ? disposition : availableDisp[0] ?? null;
	const toggle = (d) => {
		if (detachmentIds.includes(d.id)) {
			const next = detachmentIds.filter((id) => id !== d.id);
			const disps = next.map((id) => getDetachment(factionId, id)?.disposition).filter(Boolean);
			onChange({
				detachmentIds: next,
				disposition: current && disps.includes(current) ? current : disps[0] ?? null
			});
			return;
		}
		if (dp + d.dp > 3) {
			toast(`That would be ${dp + d.dp} DP — max is 3 DP`);
			return;
		}
		if (detachmentIds.map((id) => getDetachment(factionId, id)?.uniqueTag).filter(Boolean).includes(d.uniqueTag)) {
			toast(`Unique: ${d.uniqueTag} — already have a detachment with that tag`);
			return;
		}
		onChange({
			detachmentIds: [...detachmentIds, d.id],
			disposition: d.disposition
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase",
				children: [
					"Detachments · ",
					dp,
					"/3 DP"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid max-h-64 grid-cols-2 items-start gap-1 overflow-y-auto",
				children: faction.detachments.map((d) => {
					const on = detachmentIds.includes(d.id);
					const over = !on && dp + d.dp > 3;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: cn("min-w-0 rounded-md border", on ? "border-primary bg-accent" : "border-border bg-card", over && "opacity-50"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							"aria-label": on ? `Remove ${d.name}` : `Add ${d.name}`,
							onClick: () => toggle(d),
							className: "flex min-h-11 w-full min-w-0 items-center gap-1.5 px-2 py-1.5 text-left",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("flex size-3.5 shrink-0 items-center justify-center rounded-sm border", on ? "border-primary bg-primary text-primary-foreground" : "border-border"),
									children: on ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-2.5" }) : null
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate text-xs font-medium",
										children: d.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate text-[10px] text-muted-foreground",
										children: d.disposition
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									className: "h-4 shrink-0 px-1.5 py-0 text-[10px] tracking-wider",
									children: [d.dp, " DP"]
								})
							]
						})
					}, d.id);
				})
			}),
			availableDisp.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase",
					children: "Force disposition"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-1.5",
					children: availableDisp.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onChange({
							detachmentIds,
							disposition: d
						}),
						className: cn("h-8 rounded-md border px-2.5 text-xs font-medium", current === d ? "border-primary bg-primary text-primary-foreground" : "border-border bg-muted text-muted-foreground"),
						children: d
					}, d))
				})]
			}) : availableDisp.length === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted-foreground",
				children: ["Force disposition · ", availableDisp[0]]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Select at least one detachment (max 3 DP)."
			})
		]
	});
}
function useSecondClock(active) {
	const [now, setNow] = (0, import_react.useState)(() => Date.now());
	(0, import_react.useEffect)(() => {
		if (!active) return;
		const id = window.setInterval(() => setNow(Date.now()), 1e3);
		return () => window.clearInterval(id);
	}, [active]);
	return now;
}
function BattleClock({ game, locked }) {
	const pauseClock = useWarStore((s) => s.pauseClock);
	const resumeClock = useWarStore((s) => s.resumeClock);
	const endGame = useWarStore((s) => s.endGame);
	const turnsRunning = !!game.runningSince && game.status === "active";
	const now = useSecondClock(!locked && game.status === "active");
	const battle = formatClock(battleElapsedMs(game, now));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center justify-end gap-x-2 gap-y-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-mono text-sm tabular-nums",
			children: battle
		}), game.status === "active" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [turnsRunning ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			size: "sm",
			className: "h-7 px-2 text-[11px]",
			variant: "outline",
			disabled: locked,
			onClick: pauseClock,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-3.5" }), " Pause"]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			size: "sm",
			className: "h-7 px-2 text-[11px]",
			variant: "outline",
			disabled: locked,
			onClick: resumeClock,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-3.5" }), " Resume"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "sm",
			className: "h-7 px-2 text-[11px]",
			variant: "outline",
			disabled: locked,
			onClick: endGame,
			children: "End battle"
		})] }) : null]
	});
}
function SideClock({ game, side }) {
	const now = useSecondClock(game.status === "active" && !!game.runningSince && game.activeSide === side);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "font-mono shrink-0 text-xs tabular-nums",
		children: formatClock(turnElapsedMs(game, side, now))
	});
}
function liveRoster(snap, lists) {
	const live = lists.find((l) => l.id === snap.id);
	const base = live ? {
		...snap,
		detachmentIds: live.detachmentIds,
		disposition: live.disposition
	} : snap;
	return {
		...base,
		disposition: rosterDisposition(base)
	};
}
function BattleTable({ game }) {
	const setViewing = useWarStore((s) => s.setViewing);
	const endTurn = useWarStore((s) => s.endTurn);
	const prevTurn = useWarStore((s) => s.prevTurn);
	const jumpRound = useWarStore((s) => s.jumpRound);
	const undoLast = useWarStore((s) => s.undoLast);
	const dismissStrat = useWarStore((s) => s.dismissStrat);
	const endGame = useWarStore((s) => s.endGame);
	const leaveGame = useWarStore((s) => s.leaveGame);
	const reopenGame = useWarStore((s) => s.reopenGame);
	const viewing = game.viewing;
	const lists = useWarStore((s) => s.lists);
	const mine = liveRoster(game.myRoster, lists);
	const theirs = liveRoster(game.opponentRoster, lists);
	const roster = viewing === "me" ? mine : theirs;
	const faction = getFaction(roster.factionId);
	const myPrimary = primaryForSide(mine, theirs);
	const oppPrimary = primaryForSide(theirs, mine);
	const viewedPrimary = viewing === "me" ? myPrimary : oppPrimary;
	const myObjectives = myPrimary ? myPrimary.info.scoring.map(parseObjective) : null;
	const oppObjectives = oppPrimary ? oppPrimary.info.scoring.map(parseObjective) : null;
	const myTotal = sideVp(game.scores.me, myObjectives);
	const oppTotal = sideVp(game.scores.opponent, oppObjectives);
	const patchGame = useWarStore((s) => s.patchGame);
	const adjustCp = useWarStore((s) => s.adjustCp);
	const [tab, setTab] = (0, import_react.useState)("army");
	const [screen, setScreen] = (0, import_react.useState)("score");
	const [sheetId, setSheetId] = (0, import_react.useState)(null);
	const sheetDef = sheetId ? getUnit(roster.factionId, sheetId) : void 0;
	const locked = game.status === "complete";
	const log = game.log ?? [];
	const undoStack = game.undoStack ?? [];
	const activeStrats = game.activeStrats ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3 rounded-xl border border-border bg-card px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase",
					children: "Closed ledger"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg",
					children: "This battle is recorded. Reopen it to keep scoring."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex shrink-0 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						onClick: leaveGame,
						children: "Leave ledger"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						onClick: reopenGame,
						children: "Reopen"
					})]
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "sticky top-14 z-20 -mx-4 border-b border-border bg-background px-4 py-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-1 rounded-lg bg-muted p-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setScreen("score"),
						className: cn("h-11 rounded-md text-sm font-medium", screen === "score" ? "bg-primary text-primary-foreground" : "text-muted-foreground"),
						children: "Score"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setScreen("units"),
						className: cn("h-11 rounded-md text-sm font-medium", screen === "units" ? "bg-primary text-primary-foreground" : "text-muted-foreground"),
						children: "Units"
					})]
				})
			}),
			screen === "units" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center justify-between gap-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex min-w-0 gap-1",
							children: ["me", "opponent"].map((side) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setViewing(side),
								className: cn("h-10 max-w-[9.5rem] truncate rounded-md border px-3 text-sm font-medium", viewing === side ? side === "opponent" ? "border-blood bg-blood text-primary-foreground" : "border-primary bg-primary text-primary-foreground" : "border-border bg-muted text-muted-foreground"),
								children: side === "me" ? game.myName : game.opponentName
							}, side))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[11px] tracking-[0.16em] text-muted-foreground uppercase",
						children: [
							faction?.name,
							" · ",
							roster.disposition ?? "No disposition",
							viewing !== game.activeSide ? " · peeking" : ""
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArmyPanel, {
						game,
						roster,
						enemy: viewing === "me" ? theirs : mine,
						locked,
						onOpen: setSheetId
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-border bg-card p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase",
								children: "Score"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BattleClock, {
								game,
								locked
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 grid grid-cols-[1fr_auto_1fr] items-start gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: game.myName
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-mono text-4xl font-semibold tabular-nums leading-none",
										children: myTotal
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 flex items-center gap-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												size: "icon",
												variant: "outline",
												className: "h-7 w-7",
												"aria-label": "Spend CP",
												disabled: locked,
												onClick: () => adjustCp("me", -1),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-3.5" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-mono min-w-10 text-center text-sm tabular-nums",
												children: [game.cp.me, " CP"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												size: "icon",
												variant: "outline",
												className: "h-7 w-7",
												"aria-label": "Gain CP",
												disabled: locked,
												onClick: () => adjustCp("me", 1),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" })
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										disabled: locked,
										onClick: () => patchGame(game.id, { scores: {
											...game.scores,
											me: {
												...game.scores.me,
												painted: game.scores.me.painted > 0 ? 0 : 10
											}
										} }),
										className: cn("mt-1.5 text-[11px] tracking-wide uppercase", game.scores.me.painted > 0 ? "text-ok" : "text-muted-foreground"),
										children: game.scores.me.painted > 0 ? "Painted +10" : "Painted army"
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "pt-5 text-xs text-muted-foreground",
									children: "VP"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-right",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-muted-foreground",
											children: game.opponentName
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-mono text-4xl font-semibold tabular-nums leading-none text-blood",
											children: oppTotal
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-2 flex items-center justify-end gap-1",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													size: "icon",
													variant: "outline",
													className: "h-7 w-7",
													"aria-label": "Spend opponent CP",
													disabled: locked,
													onClick: () => adjustCp("opponent", -1),
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-3.5" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "font-mono min-w-10 text-center text-sm tabular-nums",
													children: [game.cp.opponent, " CP"]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													size: "icon",
													variant: "outline",
													className: "h-7 w-7",
													"aria-label": "Gain opponent CP",
													disabled: locked,
													onClick: () => adjustCp("opponent", 1),
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" })
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											disabled: locked,
											onClick: () => patchGame(game.id, { scores: {
												...game.scores,
												opponent: {
													...game.scores.opponent,
													painted: game.scores.opponent.painted > 0 ? 0 : 10
												}
											} }),
											className: cn("mt-1.5 text-[11px] tracking-wide uppercase", game.scores.opponent.painted > 0 ? "text-ok" : "text-muted-foreground"),
											children: game.scores.opponent.painted > 0 ? "Painted +10" : "Painted army"
										})
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[11px] tracking-[0.16em] text-muted-foreground uppercase",
									children: [
										"Round ",
										game.round,
										" ·",
										" ",
										(game.activeSide === "me" ? game.myName : game.opponentName).trim().toLowerCase() === "you" ? "Your turn" : `${game.activeSide === "me" ? game.myName : game.opponentName}'s turn`,
										(game.liveRound ?? game.round) !== game.round || (game.liveSide ?? game.activeSide) !== game.activeSide ? " · reviewing" : ""
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-3 flex gap-1 overflow-x-auto",
									children: [
										1,
										2,
										3,
										4,
										5
									].map((r) => {
										const reached = r <= (game.liveRound ?? game.round);
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											disabled: !reached,
											onClick: () => jumpRound(r),
											className: cn("h-9 w-9 shrink-0 rounded-full text-xs font-medium tabular-nums", game.round === r ? "bg-primary text-primary-foreground" : reached ? "bg-muted text-muted-foreground" : "bg-muted/40 text-muted-foreground/40"),
											children: r
										}, r);
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										variant: "outline",
										className: "w-full",
										disabled: game.round === 1 && game.activeSide === "me",
										onClick: prevTurn,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" }), "Previous turn"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										className: "w-full",
										disabled: locked && game.round === (game.liveRound ?? game.round) && game.activeSide === (game.liveSide ?? game.activeSide),
										onClick: endTurn,
										children: game.round === (game.liveRound ?? game.round) && game.activeSide === (game.liveSide ?? game.activeSide) ? game.round >= 5 && game.activeSide === "opponent" ? "End battle" : "End turn" : "Next turn"
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setViewing("me"),
								className: cn("flex h-12 items-center justify-between gap-2 rounded-lg border px-3 text-sm font-medium", game.activeSide === "me" ? "border-primary bg-primary text-primary-foreground" : game.viewing === "me" ? "border-steel bg-accent" : "border-border bg-muted"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate",
									children: game.myName
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideClock, {
									game,
									side: "me"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setViewing("opponent"),
								className: cn("flex h-12 items-center justify-between gap-2 rounded-lg border px-3 text-sm font-medium", game.activeSide === "opponent" ? "border-blood bg-blood text-primary-foreground" : game.viewing === "opponent" ? "border-steel bg-accent" : "border-border bg-muted"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate",
									children: game.opponentName
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideClock, {
									game,
									side: "opponent"
								})]
							})]
						}),
						game.viewing !== game.activeSide ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1.5 text-[11px] tracking-[0.12em] text-muted-foreground uppercase",
							children: [
								"Viewing ",
								game.viewing === "me" ? game.myName : game.opponentName,
								" ·",
								" ",
								(game.activeSide === "me" ? game.myName : game.opponentName).trim().toLowerCase() === "you" ? "your turn" : `${game.activeSide === "me" ? game.myName : game.opponentName}'s turn`
							]
						}) : null
					]
				}),
				game.preBattle ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(RuleFold, {
					kicker: "Pre-battle",
					title: preBattleLine(game) ?? "Muster",
					text: game.preBattle.terrainNote || void 0,
					children: [
						game.preBattle.mapId && getMap(game.preBattle.mapId) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BattleMap, {
							layout: getMap(game.preBattle.mapId),
							className: "mt-1"
						}) : null,
						game.preBattle.formationNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: game.preBattle.formationNote
						}) : null,
						game.preBattle.scoutIds.length + game.preBattle.infiltrateIds.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted-foreground",
							children: [
								"Scout ",
								game.preBattle.scoutIds.length,
								" · Infiltrate ",
								game.preBattle.infiltrateIds.length
							]
						}) : null
					]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScorePanel, {
					game,
					mission: viewedPrimary?.info ?? null,
					mineDisp: viewedPrimary?.mine ?? null,
					theirDisp: viewedPrimary?.theirs ?? null,
					locked
				}),
				activeStrats.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase",
						children: "Active stratagems"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-2",
						children: activeStrats.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "rounded-xl border border-steel/40 bg-card p-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap items-center gap-1.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "font-medium",
													children: s.name
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
													variant: "outline",
													children: [s.cp, " CP"]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: s.source })
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-1 text-xs text-muted-foreground",
											children: [
												s.side === "me" ? game.myName : game.opponentName,
												" · Round ",
												s.round,
												" · ",
												PHASES.find((p) => p.id === s.phase)?.label
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-sm text-muted-foreground",
											children: s.text
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "icon-sm",
									variant: "ghost",
									"aria-label": "Dismiss stratagem",
									onClick: () => dismissStrat(s.id),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
								})]
							})
						}, s.id))
					})]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
					value: tab,
					onValueChange: setTab,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
									value: "army",
									children: "Army"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
									value: "strats",
									children: "Strats"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex shrink-0 gap-1",
								children: ["me", "opponent"].map((side) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setViewing(side),
									className: cn("h-8 rounded-md border px-2.5 text-xs font-medium", viewing === side ? side === "opponent" ? "border-blood bg-blood text-primary-foreground" : "border-primary bg-primary text-primary-foreground" : "border-border bg-muted text-muted-foreground"),
									children: side === "me" ? game.myName : game.opponentName
								}, side))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
							value: "army",
							className: "mt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mb-2 text-[11px] tracking-[0.16em] text-muted-foreground uppercase",
								children: [
									faction?.name,
									" · ",
									roster.disposition ?? "No disposition",
									viewing !== game.activeSide ? " · peeking" : ""
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArmyPanel, {
								game,
								roster,
								enemy: viewing === "me" ? theirs : mine,
								locked,
								onOpen: setSheetId
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
							value: "strats",
							className: "mt-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StratPanel, {
								game,
								roster,
								locked
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2 pt-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" }), " Lists"]
						})
					}), locked ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						className: "ml-auto",
						onClick: endGame,
						children: "Close ledger"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LedgerTape, {
					game,
					log,
					undoCount: undoStack.length,
					onUndo: undoLast
				})
			] }),
			sheetDef ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-40 flex items-end bg-background/70 p-3 sm:items-center sm:justify-center",
				onClick: () => setSheetId(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-h-[88vh] w-full max-w-2xl overflow-y-auto",
					onClick: (e) => e.stopPropagation(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Datasheet, {
						unit: sheetDef,
						accent: faction?.accent
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-3 w-full",
						variant: "secondary",
						onClick: () => setSheetId(null),
						children: "Close"
					})]
				})
			}) : null
		]
	});
}
function TapeClock({ game }) {
	const now = useSecondClock(game.status === "active");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: formatClock(battleElapsedMs(game, now)) });
}
function tapeDot(kind) {
	if (kind === "destroyed") return "bg-blood";
	if (kind === "battleShock") return "bg-steel";
	if (kind === "stratagem") return "bg-primary";
	if (kind === "prebattle") return "bg-ok";
	if (kind === "turn") return "bg-foreground";
	return "bg-muted-foreground";
}
function tapeContext(ev, game) {
	if (ev.round == null && !ev.phase && !ev.turn) return null;
	return [
		ev.turn ? ev.turn === "me" ? game.myName : game.opponentName : null,
		ev.round != null ? `R${ev.round}` : null,
		ev.phase ? PHASES.find((p) => p.id === ev.phase)?.label ?? ev.phase : null
	].filter(Boolean).join(" · ");
}
function tapeClock(ev, game) {
	const ms = ev.clockMs ?? Math.max(0, ev.at - game.startedAt);
	return formatClock(ms);
}
function LedgerTape({ game, log, undoCount, onUndo }) {
	const [full, setFull] = (0, import_react.useState)(false);
	const shown = full ? log : log.slice(0, 5);
	const turnName = game.activeSide === "me" ? game.myName : game.opponentName;
	const phaseName = PHASES.find((p) => p.id === game.phase)?.label ?? game.phase;
	const turnLine = turnName.trim().toLowerCase() === "you" ? "Your turn" : `${turnName}'s turn`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl border border-border bg-card p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase",
					children: "Ledger tape"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1.5",
					children: [log.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => setFull((v) => !v),
						children: full ? "Last 5" : `Full ledger${log.length > 5 ? ` · ${log.length}` : ""}`
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "outline",
						disabled: undoCount === 0,
						onClick: onUndo,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, { className: "size-4" }),
							"Undo",
							undoCount ? ` · ${undoCount}` : ""
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 rounded-lg border border-border bg-muted/40 px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] tracking-[0.14em] text-muted-foreground uppercase",
						children: game.status === "complete" ? "Closed" : "Live"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs tabular-nums text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TapeClock, { game })
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-0.5 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: turnLine
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground",
						children: [
							" ",
							"· Round ",
							game.round,
							" · ",
							phaseName
						]
					})]
				})]
			}),
			log.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Phase, turn, Battle-shock, destroyed, and stratagems land here."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: cn("space-y-1.5", full && "max-h-80 overflow-y-auto"),
				children: shown.map((ev) => {
					const ctx = tapeContext(ev, game);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-start gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("mt-1.5 size-1.5 shrink-0 rounded-full", tapeDot(ev.kind)) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1 leading-snug",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "min-w-0",
									children: ev.summary
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "shrink-0 font-mono text-[11px] tabular-nums text-muted-foreground",
									children: tapeClock(ev, game)
								})]
							}), ctx ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] tracking-[0.12em] text-muted-foreground uppercase",
								children: ctx
							}) : null]
						})]
					}, ev.id);
				})
			})
		]
	});
}
function patchWounds(ru, def, st, delta) {
	const max = unitMaxWounds(def.stats.w);
	let models = st.destroyed ? 0 : st.modelsRemaining;
	let remaining = remainingWounds(st, max);
	if (delta > 0) {
		if (models <= 0) {
			models = 1;
			remaining = 1;
		} else if (remaining < max) remaining += 1;
		else if (models < ru.models) {
			models += 1;
			remaining = max;
		} else remaining = max;
		return {
			modelsRemaining: models,
			woundsOnCurrent: remaining,
			destroyed: false
		};
	}
	if (models <= 0) return {
		modelsRemaining: 0,
		woundsOnCurrent: 0,
		destroyed: true
	};
	remaining -= 1;
	if (remaining > 0) return {
		woundsOnCurrent: remaining,
		destroyed: false,
		modelsRemaining: models
	};
	models -= 1;
	if (models <= 0) return {
		modelsRemaining: 0,
		woundsOnCurrent: 0,
		destroyed: true
	};
	return {
		modelsRemaining: models,
		woundsOnCurrent: max,
		destroyed: false
	};
}
function WoundStepper({ value, max, locked, alert, onDec, onInc }) {
	const empty = value <= 0;
	const full = value >= max;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "ml-auto flex shrink-0 items-center gap-0.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "icon-sm",
				className: "size-7",
				variant: "outline",
				"aria-label": "Remove wound",
				disabled: locked || empty,
				onClick: onDec,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-3.5" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: cn("w-14 text-center font-mono text-xs tabular-nums", empty || alert ? "text-blood" : "text-foreground"),
				children: [
					value,
					"/",
					max
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "icon-sm",
				className: "size-7",
				variant: "outline",
				"aria-label": "Add wound",
				disabled: locked || full,
				onClick: onInc,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" })
			})
		]
	});
}
function ArmyPanel({ game, roster, enemy, locked, onOpen }) {
	const setUnitState = useWarStore((s) => s.setUnitState);
	const ordered = (0, import_react.useMemo)(() => {
		const rank = (id) => {
			const st = game.unitState[id];
			if (!st) return 1;
			if (st.destroyed) return 2;
			if (st.battleShocked) return 0;
			return 1;
		};
		return [...roster.units].sort((a, b) => rank(a.id) - rank(b.id));
	}, [roster.units, game.unitState]);
	const copies = (0, import_react.useMemo)(() => unitCopyMarks(roster.units), [roster.units]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "space-y-2",
		children: ordered.map((ru) => {
			const def = getUnit(roster.factionId, ru.unitId);
			const st = game.unitState[ru.id];
			if (!def || !st) return null;
			const maxW = unitMaxWounds(def.stats.w);
			const wounds = remainingWounds(st, maxW);
			const applyWounds = (delta) => setUnitState(ru.id, patchWounds(ru, def, st, delta));
			const ranged = [...new Set(def.ranged.map((w) => w.name))].join(" · ");
			const melee = [...new Set(def.melee.map((w) => w.name))].join(" · ");
			const extras = wargearSummary(def, ru.wargearIds).map((g) => g.name).join(" · ");
			const level = strengthState({
				modelsStart: ru.models,
				modelsNow: st.destroyed ? 0 : st.modelsRemaining,
				woundsMax: maxW,
				woundsNow: wounds,
				destroyed: st.destroyed
			});
			const effects = woundEffects({
				unit: def,
				roster,
				enemy,
				unitState: game.unitState,
				enhancementId: ru.enhancementId,
				state: level,
				woundsNow: wounds,
				battleShocked: st.battleShocked
			});
			const penalised = effects.some((e) => e.kind === "penalty");
			const buffed = effects.some((e) => e.kind === "buff");
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: cn("army-row rounded-lg border border-border bg-card px-2.5 py-1.5", st.destroyed && "opacity-50", !st.destroyed && st.battleShocked && "border-blood/50 bg-blood/10", !st.destroyed && !st.battleShocked && penalised && "border-blood/40 bg-blood/10", !st.destroyed && !penalised && buffed && "border-ok/50 bg-ok/10"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-w-0 items-center gap-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "min-w-0 truncate text-left text-sm font-medium leading-5",
								onClick: () => onOpen(def.id),
								children: [
									def.name,
									copies[ru.id] ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "ml-1.5 text-[10px] tracking-widest text-steel",
										children: [
											"[",
											copies[ru.id],
											"]"
										]
									}) : null,
									ru.warlord ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-1.5 text-[10px] tracking-widest uppercase text-steel",
										children: "WL"
									}) : null
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								className: "h-7 shrink-0 px-2 text-[11px]",
								variant: st.battleShocked ? "blood" : "outline",
								disabled: locked,
								onClick: () => setUnitState(ru.id, { battleShocked: !st.battleShocked }),
								children: "BS"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								className: "h-7 shrink-0 px-2 text-[11px]",
								variant: st.destroyed ? "secondary" : "outline",
								disabled: locked,
								"aria-label": "Destroyed",
								onClick: () => setUnitState(ru.id, st.destroyed ? {
									destroyed: false,
									modelsRemaining: ru.models,
									woundsOnCurrent: maxW
								} : {
									destroyed: true,
									modelsRemaining: 0,
									woundsOnCurrent: 0
								}),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skull, { className: "size-3.5" })
							}),
							ru.models > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "ml-auto flex shrink-0 items-center gap-0.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "icon-sm",
										className: "size-7",
										variant: "outline",
										"aria-label": "Remove model",
										disabled: locked || st.destroyed || st.modelsRemaining <= 0,
										onClick: () => {
											const next = Math.max(0, st.modelsRemaining - 1);
											setUnitState(ru.id, {
												modelsRemaining: next,
												destroyed: next === 0,
												woundsOnCurrent: next === 0 ? 0 : maxW
											});
										},
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-3.5" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "w-8 text-center font-mono text-xs tabular-nums",
										children: [
											st.destroyed ? 0 : st.modelsRemaining,
											"/",
											ru.models
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "icon-sm",
										className: "size-7",
										variant: "outline",
										"aria-label": "Add model",
										disabled: locked || !st.destroyed && st.modelsRemaining >= ru.models,
										onClick: () => setUnitState(ru.id, {
											modelsRemaining: Math.min(ru.models, Math.max(st.modelsRemaining, 0) + 1),
											destroyed: false,
											woundsOnCurrent: st.destroyed ? maxW : remainingWounds(st, maxW)
										}),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" })
									})
								]
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-0.5 flex min-w-0 items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-w-0 flex-1 text-left",
							onClick: () => onOpen(def.id),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-xs leading-4 text-muted-foreground",
								children: `M${typeof def.stats.m === "number" ? `${def.stats.m}"` : def.stats.m} T${def.stats.t} Sv${def.stats.sv}+ W${def.stats.w}${def.invuln ? ` ${def.invuln}++` : ""} OC${def.stats.oc} · ${ru.points} pts`
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WoundStepper, {
							value: wounds,
							max: maxW,
							locked,
							alert: penalised,
							onDec: () => applyWounds(-1),
							onInc: () => applyWounds(1)
						})]
					}),
					ranged || melee || extras || ru.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "mt-0.5 w-full min-w-0 text-left",
						onClick: () => onOpen(def.id),
						children: [
							ranged ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "truncate text-xs leading-4 text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] tracking-[0.12em] text-muted-foreground/80 uppercase",
									children: "R "
								}), ranged]
							}) : null,
							melee ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "truncate text-xs leading-4 text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] tracking-[0.12em] text-muted-foreground/80 uppercase",
									children: "M "
								}), melee]
							}) : null,
							extras ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-xs leading-4 text-muted-foreground",
								children: extras
							}) : null,
							ru.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-xs leading-4 text-muted-foreground",
								children: ru.notes
							}) : null
						]
					}) : null,
					effects.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn("mt-1 text-xs leading-4", penalised ? "text-blood" : "text-ok"),
						children: effects.map((e) => `${e.name}: ${e.text}`).join(" · ")
					}) : null
				]
			}, ru.id);
		})
	});
}
function ScoreLines({ lines, checks, locked, focusRound, liveRound, onToggle }) {
	const viewed = focusRound ?? 1;
	const frontier = liveRound ?? viewed;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-2 space-y-2",
		children: lines.map((line, i) => {
			const obj = parseObjective(line);
			const row = checks?.[i] ?? [];
			const max = obj.each ? Math.max(2, Math.min(4, Math.floor(15 / Math.max(1, obj.vp)))) : 1;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "min-w-0 sm:flex sm:items-center sm:gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 flex-1 items-start justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs leading-snug",
						children: obj.text.replace(/\s*\([^)]*\)\s*$/, "")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "shrink-0 font-mono text-[10px] tabular-nums text-muted-foreground",
						children: [
							"+",
							obj.vp,
							obj.each ? " ea" : ""
						]
					})]
				}), obj.once ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					disabled: locked,
					"aria-pressed": checkCount(row, 0) > 0,
					onClick: () => onToggle(i, 0, 1),
					className: cn("mt-1 flex h-8 w-full shrink-0 items-center justify-center gap-1.5 rounded-md border px-2 text-[11px] sm:mt-0 sm:w-44", checkCount(row, 0) > 0 ? "border-ok/50 bg-ok/15 text-foreground" : "border-border bg-muted text-muted-foreground"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("flex size-3.5 items-center justify-center rounded-sm border", checkCount(row, 0) > 0 ? "border-ok bg-ok text-background" : "border-border"),
						children: checkCount(row, 0) > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-2.5" }) : null
					}), "End of battle"]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-1 grid w-full shrink-0 grid-cols-5 gap-0.5 sm:mt-0 sm:w-44",
					children: [
						0,
						1,
						2,
						3,
						4
					].map((slot) => {
						const r = slot + 1;
						const inMission = obj.rounds.includes(r);
						const reached = r <= frontier;
						const canEdit = !locked && inMission && reached && r === viewed;
						const n = checkCount(row, slot);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: !canEdit,
							"aria-pressed": n > 0,
							"aria-label": `Round ${r} ${obj.vp} VP`,
							onClick: () => onToggle(i, slot, max),
							className: cn("flex h-8 items-center justify-center gap-0.5 rounded-md border text-[10px] font-medium", !inMission ? "cursor-not-allowed border-border/50 bg-muted/40 text-muted-foreground/40" : n > 0 ? "border-ok/50 bg-ok/15 text-foreground" : canEdit ? "border-steel/70 bg-muted text-foreground" : reached ? "cursor-not-allowed border-border bg-muted/70 text-muted-foreground" : "cursor-not-allowed border-border/50 bg-muted/40 text-muted-foreground/40"),
							children: [`R${r}`, n > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono",
								children: ["×", n]
							}) : n === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-2.5" }) : null]
						}, slot);
					})
				})]
			}, `${obj.text}-${i}`);
		})
	});
}
function SecondaryScore({ lines, value, locked, compact, onPick }) {
	const options = scoreOptions(lines);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-2 space-y-2",
		children: [compact ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "list-disc space-y-1 pl-4 text-xs text-muted-foreground",
			children: lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: parseObjective(line).text.replace(/\s*\([^)]*\)\s*$/, "") }, line))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap gap-1.5",
			children: options.map((vp) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				disabled: locked,
				"aria-pressed": value === vp,
				onClick: () => onPick(value === vp ? 0 : vp),
				className: cn("h-8 min-w-12 rounded-md border px-2.5 text-xs font-medium", value === vp ? "border-ok/50 bg-ok/15 text-foreground" : "border-border bg-muted text-muted-foreground"),
				children: [vp, " VP"]
			}, vp))
		})]
	});
}
function cardScored(checks) {
	return cardAward(checks) > 0;
}
function unscoredFirst(ids, checks) {
	return [...ids].sort((a, b) => Number(cardScored(checks?.[a])) - Number(cardScored(checks?.[b])));
}
function SecondaryPanel({ game, locked }) {
	const side = game.viewing;
	const score = game.scores[side];
	const setSecondaryMode = useWarStore((s) => s.setSecondaryMode);
	const toggleFixedSecondary = useWarStore((s) => s.toggleFixedSecondary);
	const toggleTacticalActive = useWarStore((s) => s.toggleTacticalActive);
	const setSecondaryScore = useWarStore((s) => s.setSecondaryScore);
	const ensureSecondaryMeta = useWarStore((s) => s.ensureSecondaryMeta);
	const [openIds, setOpenIds] = (0, import_react.useState)({});
	const mode = score.secondaryMode ?? null;
	const fixedIds = score.fixedIds ?? [];
	const active = score.tacticalActive ?? [];
	const ids = mode === "fixed" ? fixedIds : mode === "tactical" ? active : [];
	const pts = secondaryVp(mode, ids, score.secondaryChecks);
	(0, import_react.useEffect)(() => {
		ensureSecondaryMeta(side);
	}, [
		ensureSecondaryMeta,
		side,
		ids.join("|")
	]);
	const selectedCard = (id, discard) => {
		const card = (mode === "fixed" ? FIXED_SECONDARIES : SECONDARIES).find((c) => c.id === id);
		if (!card) return null;
		const scored = cardScored(score.secondaryChecks?.[id]);
		const open = !!openIds[id];
		const award = cardAward(score.secondaryChecks?.[id]);
		const stamp = score.secondaryMeta?.[id];
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("min-w-0 rounded-lg border border-border px-2.5 py-1.5", open && "p-3", scored && "opacity-70"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "min-w-0 flex-1 truncate text-left text-sm font-medium",
						onClick: () => setOpenIds((m) => ({
							...m,
							[id]: !m[id]
						})),
						children: [card.name, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "ml-1.5 font-mono text-xs font-normal tabular-nums text-muted-foreground",
							children: [award, " VP"]
						})]
					}), discard ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						className: "h-7 px-2 text-[11px]",
						variant: "ghost",
						disabled: locked,
						onClick: () => toggleTacticalActive(side, id),
						children: "Discard"
					}) : null]
				}),
				stamp ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-0.5 text-[11px] tracking-[0.12em] text-muted-foreground uppercase",
					children: [
						"Selected R",
						stamp.selectedRound,
						stamp.completedRound != null ? ` · Completed R${stamp.completedRound}` : ""
					]
				}) : null,
				open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-muted-foreground",
					children: card.blurb
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryScore, {
					lines: secondaryLines(card, mode === "fixed" ? "fixed" : "tactical"),
					value: award,
					locked,
					compact: !open,
					onPick: (vp) => setSecondaryScore(side, id, vp)
				})
			]
		}, id);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-[11px] tracking-[0.16em] text-muted-foreground uppercase",
				children: ["Secondary · ", side === "me" ? game.myName : game.opponentName]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-[11px] tracking-[0.12em] text-muted-foreground uppercase",
				children: [
					mode === "fixed" ? "20 VP / card · 40 cap" : "15 VP / round · 45 cap",
					" · ",
					pts,
					" VP"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: locked,
					onClick: () => setSecondaryMode(side, "fixed"),
					className: cn("h-10 rounded-lg border text-sm font-medium", mode === "fixed" ? "border-primary bg-primary text-primary-foreground" : "border-border bg-muted"),
					children: "Fixed"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: locked,
					onClick: () => setSecondaryMode(side, "tactical"),
					className: cn("h-10 rounded-lg border text-sm font-medium", mode === "tactical" ? "border-primary bg-primary text-primary-foreground" : "border-border bg-muted"),
					children: "Tactical"
				})]
			}),
			mode === "fixed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Pick two. They stay active all game."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-1.5",
						children: unscoredFirst(FIXED_SECONDARIES.map((c) => c.id), score.secondaryChecks).map((id) => {
							const card = FIXED_SECONDARIES.find((c) => c.id === id);
							if (!card) return null;
							const on = fixedIds.includes(card.id);
							const scored = cardScored(score.secondaryChecks?.[card.id]);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: locked || !on && fixedIds.length >= 2,
								onClick: () => toggleFixedSecondary(side, card.id),
								className: cn("h-8 rounded-md border px-2.5 text-xs font-medium", on ? "border-ok/50 bg-ok/15 text-foreground" : "border-border bg-muted text-muted-foreground", scored && "opacity-60"),
								children: card.name
							}, card.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 items-start gap-1.5",
						children: unscoredFirst(fixedIds, score.secondaryChecks).map((id) => selectedCard(id))
					})
				]
			}) : null,
			mode === "tactical" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Draw two each Command phase. Tap a card when you draw it. Score it once, then it drops to the bottom."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-1.5",
						children: unscoredFirst(SECONDARIES.map((c) => c.id), score.secondaryChecks).map((id) => {
							const card = SECONDARIES.find((c) => c.id === id);
							if (!card) return null;
							const on = active.includes(card.id);
							const scored = cardScored(score.secondaryChecks?.[card.id]);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: locked,
								onClick: () => toggleTacticalActive(side, card.id),
								className: cn("h-8 rounded-md border px-2.5 text-xs font-medium", on ? "border-ok/50 bg-ok/15 text-foreground" : "border-border bg-muted text-muted-foreground", scored && "opacity-60"),
								children: card.name
							}, card.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 items-start gap-1.5",
						children: unscoredFirst(active, score.secondaryChecks).map((id) => selectedCard(id, true))
					})
				]
			}) : null
		]
	});
}
function ScorePanel({ game, mission, mineDisp, theirDisp, locked }) {
	const side = game.viewing;
	const score = game.scores[side];
	const togglePrimaryCheck = useWarStore((s) => s.togglePrimaryCheck);
	const primaryPts = mission ? objectiveVp(score.primaryChecks, mission.scoring.map(parseObjective)) : score.primaryByRound.reduce((a, b) => a + b, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [mission ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[11px] tracking-[0.16em] text-muted-foreground uppercase",
					children: ["Primary · 11th edition · ", side === "me" ? game.myName : game.opponentName]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display mt-1 text-xl",
					children: mission.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-xs text-muted-foreground",
					children: [
						mineDisp,
						" vs ",
						theirDisp
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: mission.blurb
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-[11px] tracking-[0.12em] text-muted-foreground uppercase",
					children: [
						"15 VP / round · 45 primary max · ",
						primaryPts,
						" VP"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreLines, {
					lines: mission.scoring,
					checks: score.primaryChecks,
					locked,
					focusRound: game.round,
					liveRound: game.liveRound ?? game.round,
					onToggle: (line, slot, max) => togglePrimaryCheck(side, line, slot, max)
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "Set dispositions on both lists to generate a primary mission."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryPanel, {
			game,
			locked
		})]
	});
}
function StratPanel({ game, roster, locked }) {
	const side = game.viewing;
	const playStratagem = useWarStore((s) => s.playStratagem);
	const [fullByPhase, setFullByPhase] = (0, import_react.useState)({});
	const dets = roster.detachmentIds.map((id) => getDetachment(roster.factionId, id)).filter(Boolean);
	const faction = getFaction(roster.factionId);
	const active = game.activeStrats ?? [];
	const list = [...dets.flatMap((d) => d.stratagems.map((s) => ({
		...s,
		source: d.name
	}))), ...CORE_STRATAGEMS.map((s) => ({
		...s,
		source: "Core"
	}))];
	const grouped = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		for (const s of list) {
			const key = stratagemPrimaryPhase(s.when);
			const arr = map.get(key) ?? [];
			arr.push(s);
			map.set(key, arr);
		}
		for (const arr of map.values()) arr.sort((a, b) => Number(a.source === "Core") - Number(b.source === "Core") || a.name.localeCompare(b.name));
		return ["any", ...PHASES.map((p) => p.id)].filter((k) => map.has(k)).map((k) => [k, map.get(k)]);
	}, [list]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Tap a stratagem to play it and spend the CP."
			}),
			grouped.map(([phase, strats]) => {
				const compact = !fullByPhase[phase];
				const label = phase === "any" ? "Any phase" : PHASES.find((p) => p.id === phase)?.label ?? phase;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-xs tracking-[0.16em] text-muted-foreground uppercase",
						children: label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-[11px] tracking-wide text-muted-foreground uppercase",
						onClick: () => setFullByPhase((m) => ({
							...m,
							[phase]: !m[phase]
						})),
						children: compact ? "Full text" : "1 line"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: strats.map((s) => {
						const playCount = active.filter((a) => a.stratId === s.id && a.side === side).length;
						const showFull = !compact;
						const unaffordable = locked || game.cp[side] < s.cp;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: unaffordable,
							onClick: () => playStratagem(side, s, s.source),
							className: cn("w-full rounded-lg border bg-card text-left", playCount > 0 ? "border-steel/50" : "border-border", showFull ? "p-3" : "px-2 py-1.5", unaffordable && "opacity-50"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "min-w-0 flex-1",
									children: showFull ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "font-medium",
										children: [s.name, playCount > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "ml-1.5 font-mono text-[11px] text-muted-foreground",
											children: ["×", playCount]
										}) : null]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: s.when
									})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "truncate text-sm font-medium",
										children: [
											s.name,
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "ml-1.5 font-normal text-muted-foreground",
												children: [
													"· ",
													s.when,
													s.source !== "Core" ? ` · ${s.source}` : ""
												]
											}),
											playCount > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "ml-1.5 font-mono text-[11px] text-muted-foreground",
												children: ["×", playCount]
											}) : null
										]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "shrink-0 font-mono text-xs tabular-nums text-muted-foreground",
									children: [s.cp, " CP"]
								})]
							}), showFull ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: s.text
							}) : null]
						}) }, s.id);
					})
				})] }, phase);
			}),
			faction ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RuleFold, {
				kicker: "Army rule",
				title: faction.rule.name,
				text: faction.rule.text
			}) : null,
			dets.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RuleFold, {
				kicker: "Detachment",
				title: d.name,
				text: `${d.rule.name}. ${d.rule.text}`,
				badges: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "outline",
					children: d.disposition
				})
			}, d.id))
		]
	});
}
//#endregion
export { BattlePage as component };
