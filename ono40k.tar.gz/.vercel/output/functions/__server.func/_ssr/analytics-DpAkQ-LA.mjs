import { i as __toESM } from "../_runtime.mjs";
import { a as formatClock, i as cn, r as battleElapsedMs, s as getFaction } from "./utils-hP9YwH9-.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { l as ScrollText } from "../_libs/lucide-react.mjs";
import { F as SEED_LISTS, M as totalScore, a as useWarStore } from "./router-cdYjUO9_.mjs";
import { t as Badge } from "./badge-DTfl_mpk.mjs";
import { n as Card, t as Button } from "./card-6JO_WVWA.mjs";
import { a as Bar, i as CartesianGrid, n as YAxis, o as ResponsiveContainer, r as XAxis, s as Tooltip, t as BarChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/analytics-DpAkQ-LA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var empty = {
	primaryByRound: [
		0,
		0,
		0,
		0,
		0
	],
	primaryChecks: [],
	secondaryMode: "tactical",
	fixedIds: [],
	tacticalActive: [],
	secondaryChecks: {},
	secondaryMeta: {},
	tactical: 0,
	painted: 10
};
function score(primary, tactical, painted = 10) {
	return {
		...empty,
		primaryByRound: primary,
		tactical,
		painted
	};
}
function ev(id, kind, summary, round, clockMs) {
	return {
		id,
		at: 1,
		kind,
		summary,
		round,
		phase: "shooting",
		turn: "me",
		clockMs
	};
}
function list(id) {
	const found = SEED_LISTS.find((l) => l.id === id);
	if (!found) throw new Error(`missing seed ${id}`);
	return found;
}
var DAY = 864e5;
var now = Date.UTC(2026, 8, 20);
function game(partial) {
	return {
		round: 5,
		phase: "end",
		activeSide: "opponent",
		viewing: "me",
		cp: {
			me: 1,
			opponent: 0
		},
		unitState: {},
		activeStrats: [],
		undoStack: [],
		notes: "",
		status: "complete",
		liveRound: 5,
		liveSide: "opponent",
		livePhase: "end",
		...partial
	};
}
var SAMPLE_LEDGERS = [
	game({
		id: "sample-um-nids",
		myName: "You",
		opponentName: "Marcus",
		myRoster: list("seed-um-blade"),
		opponentRoster: list("seed-nids-vanguard"),
		scores: {
			me: score([
				8,
				12,
				15,
				10,
				8
			], 25),
			opponent: score([
				5,
				8,
				10,
				12,
				15
			], 20)
		},
		startedAt: now - 6 * DAY,
		finishedAt: now - 6 * DAY + 936e4,
		elapsedMs: 936e4,
		turnMs: {
			me: 468e4,
			opponent: 426e4
		},
		log: [
			ev("a1", "stratagem", "You · Fire Overwatch (1 CP)", 1, 72e4),
			ev("a2", "destroyed", "Marcus · Hormagaunts destroyed", 2, 24e5),
			ev("a3", "stratagem", "You · Armour of Contempt (1 CP)", 2, 288e4),
			ev("a4", "destroyed", "You · Termagants destroyed", 3, 48e5),
			ev("a5", "stratagem", "Marcus · Insane Bravery (1 CP)", 3, 552e4),
			ev("a6", "destroyed", "Marcus · Redemptor Dreadnought destroyed", 4, 78e5),
			ev("a7", "stratagem", "You · Command Re-roll (1 CP)", 5, 9e6)
		]
	}),
	game({
		id: "sample-sm-tau",
		myName: "You",
		opponentName: "Priya",
		myRoster: list("seed-sm-gladius"),
		opponentRoster: {
			...list("seed-um-blade"),
			id: "sample-tau-proxy",
			name: "Kauyon Cadre",
			factionId: "tau",
			detachmentIds: [],
			disposition: "Take and Hold"
		},
		scores: {
			me: score([
				5,
				8,
				10,
				8,
				12
			], 18),
			opponent: score([
				8,
				10,
				12,
				15,
				8
			], 22)
		},
		startedAt: now - 13 * DAY,
		finishedAt: now - 13 * DAY + 1044e4,
		elapsedMs: 1044e4,
		turnMs: {
			me: 492e4,
			opponent: 528e4
		},
		log: [
			ev("b1", "stratagem", "You · Go to Ground (1 CP)", 1, 108e4),
			ev("b2", "destroyed", "Priya · Intercessor Squad destroyed", 2, 33e5),
			ev("b3", "stratagem", "Priya · Fire Overwatch (1 CP)", 2, 366e4),
			ev("b4", "stratagem", "You · Command Re-roll (1 CP)", 3, 57e5),
			ev("b5", "destroyed", "You · Crisis Battlesuits destroyed", 4, 84e5)
		]
	}),
	game({
		id: "sample-nids-um",
		myName: "You",
		opponentName: "Diego",
		myRoster: list("seed-nids-vanguard"),
		opponentRoster: list("seed-um-blade"),
		scores: {
			me: score([
				10,
				15,
				12,
				8,
				5
			], 30),
			opponent: score([
				8,
				8,
				10,
				12,
				10
			], 15)
		},
		startedAt: now - 20 * DAY,
		finishedAt: now - 20 * DAY + 792e4,
		elapsedMs: 792e4,
		turnMs: {
			me: 384e4,
			opponent: 42e5
		},
		log: [
			ev("c1", "stratagem", "You · Insane Bravery (1 CP)", 1, 48e4),
			ev("c2", "destroyed", "Diego · Infiltrator Squad destroyed", 1, 132e4),
			ev("c3", "destroyed", "You · Bladeguard Veterans destroyed", 2, 3e6),
			ev("c4", "stratagem", "You · Command Re-roll (1 CP)", 3, 528e4),
			ev("c5", "stratagem", "Diego · Armour of Contempt (1 CP)", 4, 72e5),
			ev("c6", "destroyed", "Diego · Hive Tyrant destroyed", 5, 888e4)
		]
	}),
	game({
		id: "sample-um-sm",
		myName: "You",
		opponentName: "Chris",
		myRoster: list("seed-um-blade"),
		opponentRoster: list("seed-sm-gladius"),
		scores: {
			me: score([
				8,
				10,
				10,
				10,
				8
			], 20),
			opponent: score([
				8,
				10,
				10,
				10,
				8
			], 20)
		},
		startedAt: now - 27 * DAY,
		finishedAt: now - 27 * DAY + 1116e4,
		elapsedMs: 1116e4,
		turnMs: {
			me: 54e5,
			opponent: 516e4
		},
		log: [
			ev("d1", "stratagem", "You · Command Re-roll (1 CP)", 2, 24e5),
			ev("d2", "stratagem", "Chris · Command Re-roll (1 CP)", 2, 264e4),
			ev("d3", "destroyed", "Chris · Hellblaster Squad destroyed", 3, 57e5),
			ev("d4", "destroyed", "You · Eradicator Squad destroyed", 4, 768e4)
		]
	})
];
function sideScore(game, side) {
	const s = game.scores[side];
	return totalScore(s.primaryByRound ?? [
		0,
		0,
		0,
		0,
		0
	], s.tactical ?? 0, s.painted ?? 0);
}
function resultOf(game) {
	const me = sideScore(game, "me");
	const them = sideScore(game, "opponent");
	if (me > them) return "win";
	if (me < them) return "loss";
	return "draw";
}
function factionName(id) {
	return getFaction(id)?.name ?? id;
}
function avg(nums) {
	if (!nums.length) return 0;
	return nums.reduce((a, b) => a + b, 0) / nums.length;
}
function tally(items, limit = 6) {
	const map = /* @__PURE__ */ new Map();
	for (const item of items) map.set(item, (map.get(item) ?? 0) + 1);
	return [...map.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0])).slice(0, limit).map(([name, n]) => ({
		name,
		n
	}));
}
function stratLabel(summary) {
	return (summary.split(" · ").slice(1).join(" · ").replace(/\s*\(\d+\s*CP\)\s*$/i, "").trim() || summary).trim();
}
function killLabel(summary) {
	return summary.replace(/\s+destroyed$/i, "").replace(/^.*?·\s*/, "").trim() || summary;
}
function closedGames(games) {
	return games.filter((g) => g.status === "complete").slice().sort((a, b) => (b.finishedAt ?? b.startedAt) - (a.finishedAt ?? a.startedAt));
}
function summarize(games) {
	const played = games.length;
	const results = games.map(resultOf);
	const wins = results.filter((r) => r === "win").length;
	const losses = results.filter((r) => r === "loss").length;
	const draws = results.filter((r) => r === "draw").length;
	const roundAvg = [
		1,
		2,
		3,
		4,
		5
	].map((r) => ({
		round: `R${r}`,
		me: Math.round(avg(games.map((g) => g.scores.me.primaryByRound[r - 1] ?? 0)) * 10) / 10,
		them: Math.round(avg(games.map((g) => g.scores.opponent.primaryByRound[r - 1] ?? 0)) * 10) / 10
	}));
	const split = [
		{
			name: "Primary",
			me: Math.round(avg(games.map((g) => (g.scores.me.primaryByRound ?? []).reduce((a, b) => a + b, 0)))),
			them: Math.round(avg(games.map((g) => (g.scores.opponent.primaryByRound ?? []).reduce((a, b) => a + b, 0))))
		},
		{
			name: "Secondaries",
			me: Math.round(avg(games.map((g) => g.scores.me.tactical ?? 0))),
			them: Math.round(avg(games.map((g) => g.scores.opponent.tactical ?? 0)))
		},
		{
			name: "Painted",
			me: Math.round(avg(games.map((g) => g.scores.me.painted ?? 0))),
			them: Math.round(avg(games.map((g) => g.scores.opponent.painted ?? 0)))
		}
	];
	const matchMap = /* @__PURE__ */ new Map();
	for (const g of games) {
		const me = factionName(g.myRoster.factionId);
		const them = factionName(g.opponentRoster.factionId);
		const key = `${me} vs ${them}`;
		const cur = matchMap.get(key) ?? {
			me,
			them,
			n: 0,
			wins: 0
		};
		cur.n += 1;
		if (resultOf(g) === "win") cur.wins += 1;
		matchMap.set(key, cur);
	}
	const strats = tally(games.flatMap((g) => (g.log ?? []).filter((e) => e.kind === "stratagem").map((e) => stratLabel(e.summary))));
	const kills = tally(games.flatMap((g) => (g.log ?? []).filter((e) => e.kind === "destroyed" && /destroyed$/i.test(e.summary)).map((e) => killLabel(e.summary))));
	const pace = {
		me: Math.round(avg(games.map((g) => g.turnMs?.me ?? 0))),
		them: Math.round(avg(games.map((g) => g.turnMs?.opponent ?? 0)))
	};
	return {
		played,
		wins,
		losses,
		draws,
		avgMe: Math.round(avg(games.map((g) => sideScore(g, "me")))),
		avgThem: Math.round(avg(games.map((g) => sideScore(g, "opponent")))),
		avgMs: Math.round(avg(games.map((g) => battleElapsedMs(g)))),
		roundAvg,
		split,
		matchups: [...matchMap.entries()].map(([key, v]) => ({
			key,
			...v
		})).sort((a, b) => b.n - a.n),
		strats,
		kills,
		pace
	};
}
function AnnalsPage() {
	const stored = useWarStore((s) => s.games);
	const resumeGame = useWarStore((s) => s.resumeGame);
	const navigate = useNavigate();
	const real = (0, import_react.useMemo)(() => closedGames(stored), [stored]);
	const [useSample, setUseSample] = (0, import_react.useState)(false);
	const showingSample = real.length === 0 || useSample;
	const source = showingSample ? SAMPLE_LEDGERS : real;
	const stats = (0, import_react.useMemo)(() => summarize(source), [source]);
	const [openId, setOpenId] = (0, import_react.useState)(source[0]?.id ?? null);
	const open = source.find((g) => g.id === openId) ?? source[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-medium tracking-[0.22em] text-muted-foreground uppercase",
						children: "War Journal"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display mt-1 text-3xl font-semibold tracking-wide",
						children: "Annals"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 max-w-xl text-sm text-muted-foreground",
						children: "After-action from closed ledgers: score, pace, matchups, and what the tape recorded."
					})
				] }), real.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: useSample ? "secondary" : "outline",
					onClick: () => setUseSample((v) => !v),
					children: useSample ? "Your ledgers" : "Sample record"
				}) : null]
			}),
			real.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium",
					children: "Sample record"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-0.5 text-sm text-muted-foreground",
					children: "Close a battle to replace this with your own games."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/battle",
						children: "Open the ledger"
					})
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Battles",
						value: String(stats.played)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Record",
						value: `${stats.wins}–${stats.losses}${stats.draws ? `–${stats.draws}` : ""}`,
						hint: "W–L–D"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Avg score",
						value: `${stats.avgMe}–${stats.avgThem}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Avg length",
						value: formatClock(stats.avgMs)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase",
							children: "Primary by round"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: "Average VP scored in each battle round."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 h-52",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
								width: "100%",
								height: "100%",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
									data: stats.roundAvg,
									barGap: 4,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
											stroke: "var(--color-border)",
											vertical: false
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
											dataKey: "round",
											tick: {
												fill: "var(--color-muted-foreground)",
												fontSize: 11
											},
											axisLine: false,
											tickLine: false
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
											tick: {
												fill: "var(--color-muted-foreground)",
												fontSize: 11
											},
											axisLine: false,
											tickLine: false,
											width: 28
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
											content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTip, {}),
											cursor: { fill: "color-mix(in oklab, var(--color-foreground) 6%, transparent)" }
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
											dataKey: "me",
											name: "You",
											fill: "var(--color-steel)",
											radius: [
												4,
												4,
												0,
												0
											],
											maxBarSize: 18
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
											dataKey: "them",
											name: "Opponent",
											fill: "var(--color-blood)",
											radius: [
												4,
												4,
												0,
												0
											],
											maxBarSize: 18
										})
									]
								})
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase",
							children: "Score split"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: "Where the points actually came from."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 h-52",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
								width: "100%",
								height: "100%",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
									data: stats.split,
									barGap: 4,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
											stroke: "var(--color-border)",
											vertical: false
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
											dataKey: "name",
											tick: {
												fill: "var(--color-muted-foreground)",
												fontSize: 11
											},
											axisLine: false,
											tickLine: false
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
											tick: {
												fill: "var(--color-muted-foreground)",
												fontSize: 11
											},
											axisLine: false,
											tickLine: false,
											width: 28
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
											content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTip, {}),
											cursor: { fill: "color-mix(in oklab, var(--color-foreground) 6%, transparent)" }
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
											dataKey: "me",
											name: "You",
											fill: "var(--color-steel)",
											radius: [
												4,
												4,
												0,
												0
											],
											maxBarSize: 22
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
											dataKey: "them",
											name: "Opponent",
											fill: "var(--color-blood)",
											radius: [
												4,
												4,
												0,
												0
											],
											maxBarSize: 22
										})
									]
								})
							})
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 lg:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-4 lg:col-span-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase",
							children: "Matchups"
						}), stats.matchups.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-muted-foreground",
							children: "No closed games yet."
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-3 space-y-2",
							children: stats.matchups.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-baseline justify-between gap-3 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0 truncate",
									children: [
										m.me,
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground",
											children: "vs"
										}),
										" ",
										m.them
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-mono shrink-0 tabular-nums text-muted-foreground",
									children: [
										m.wins,
										"/",
										m.n
									]
								})]
							}, m.key))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase",
							children: "Stratagems played"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankList, {
							items: stats.strats,
							empty: "No stratagems on the tape."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase",
							children: "Units destroyed"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankList, {
							items: stats.kills,
							empty: "No kills recorded on the tape."
						})]
					})
				]
			}),
			stats.pace.me + stats.pace.them > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [
					"Clock on the table: you ",
					formatClock(stats.pace.me),
					" per game, opponent ",
					formatClock(stats.pace.them),
					"."
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-semibold tracking-wide",
						children: "Closed ledgers"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-2",
						children: source.map((g) => {
							const on = open?.id === g.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setOpenId(g.id),
								className: cn("flex w-full min-h-11 items-center justify-between gap-3 rounded-lg border px-4 py-3 text-left", on ? "border-primary bg-accent" : "border-border bg-card"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "block truncate text-sm font-medium",
										children: [
											g.myName,
											" vs ",
											g.opponentName
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "block truncate text-[11px] text-muted-foreground",
										children: [
											factionName(g.myRoster.factionId),
											" vs ",
											factionName(g.opponentRoster.factionId)
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex shrink-0 items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultMark, { game: g }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-mono text-sm tabular-nums",
										children: [
											sideScore(g, "me"),
											"–",
											sideScore(g, "opponent")
										]
									})]
								})]
							}) }, g.id);
						})
					}),
					open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AfterAction, {
						game: open,
						sample: showingSample,
						onOpen: () => {
							if (showingSample && real.every((g) => g.id !== open.id)) return;
							resumeGame(open.id);
							navigate({ to: "/battle" });
						}
					}) : null
				]
			})
		]
	});
}
function Stat({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display mt-2 text-2xl font-semibold tracking-wide",
				children: value
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-[11px] text-muted-foreground",
				children: hint
			}) : null
		]
	});
}
function RankList({ items, empty }) {
	if (!items.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-3 text-sm text-muted-foreground",
		children: empty
	});
	const max = items[0]?.n ?? 1;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-3 space-y-2",
		children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-baseline justify-between gap-2 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "min-w-0 truncate",
				children: item.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono shrink-0 tabular-nums text-muted-foreground",
				children: item.n
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1 h-1 rounded-full bg-muted",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-1 rounded-full bg-steel",
				style: { width: `${Math.round(item.n / max * 100)}%` }
			})
		})] }, item.name))
	});
}
function ResultMark({ game }) {
	const r = resultOf(game);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		variant: r === "win" ? "ok" : r === "loss" ? "blood" : "outline",
		children: r === "win" ? "Win" : r === "loss" ? "Loss" : "Draw"
	});
}
function AfterAction({ game, sample, onOpen }) {
	const me = sideScore(game, "me");
	const them = sideScore(game, "opponent");
	const rounds = [
		1,
		2,
		3,
		4,
		5
	].map((r) => ({
		round: `R${r}`,
		me: game.scores.me.primaryByRound[r - 1] ?? 0,
		them: game.scores.opponent.primaryByRound[r - 1] ?? 0
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "space-y-4 p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase",
						children: "After-action"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "font-display mt-1 text-xl",
						children: [
							game.myName,
							" vs ",
							game.opponentName
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: [
							factionName(game.myRoster.factionId),
							" vs ",
							factionName(game.opponentRoster.factionId),
							" · ",
							formatClock(battleElapsedMs(game))
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-3xl font-semibold tabular-nums leading-none",
						children: [
							me,
							"–",
							them
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-[11px] tracking-wide text-muted-foreground uppercase",
						children: [
							"Primary ",
							game.scores.me.primaryByRound.reduce((a, b) => a + b, 0),
							" · Sec ",
							game.scores.me.tactical,
							" · Paint ",
							game.scores.me.painted
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-40",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: "100%",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
						data: rounds,
						barGap: 3,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
								stroke: "var(--color-border)",
								vertical: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "round",
								tick: {
									fill: "var(--color-muted-foreground)",
									fontSize: 11
								},
								axisLine: false,
								tickLine: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								tick: {
									fill: "var(--color-muted-foreground)",
									fontSize: 11
								},
								axisLine: false,
								tickLine: false,
								width: 24
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
								content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTip, {}),
								cursor: { fill: "color-mix(in oklab, var(--color-foreground) 6%, transparent)" }
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: "me",
								name: "You",
								fill: "var(--color-steel)",
								radius: [
									3,
									3,
									0,
									0
								],
								maxBarSize: 16
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: "them",
								name: "Opponent",
								fill: "var(--color-blood)",
								radius: [
									3,
									3,
									0,
									0
								],
								maxBarSize: 16
							})
						]
					})
				})
			}),
			(game.log ?? []).filter((e) => e.kind === "stratagem" || e.kind === "destroyed").length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-1.5",
				children: (game.log ?? []).filter((e) => e.kind === "stratagem" || e.kind === "destroyed").slice(0, 8).map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-start justify-between gap-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "min-w-0 truncate",
						children: e.summary
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-mono shrink-0 text-[11px] tabular-nums text-muted-foreground",
						children: ["R", e.round]
					})]
				}, e.id))
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				className: "w-full",
				variant: "outline",
				disabled: sample,
				onClick: onOpen,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollText, { className: "size-4" }), sample ? "Sample — close a real ledger to reopen" : "Open this ledger"]
			})
		]
	});
}
function ChartTip({ active, payload, label }) {
	if (!active || !payload?.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md border border-border bg-popover px-3 py-2 text-xs text-popover-foreground shadow-md",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-medium",
			children: label
		}), payload.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-0.5 tabular-nums",
			children: [
				p.name,
				": ",
				p.value
			]
		}, p.name))]
	});
}
//#endregion
export { AnnalsPage as component };
