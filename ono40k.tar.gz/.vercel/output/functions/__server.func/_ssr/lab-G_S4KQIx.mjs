import { i as __toESM } from "../_runtime.mjs";
import { c as getUnit, i as cn, n as allUnits } from "./utils-hP9YwH9-.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { C as Calculator, a as Swords, c as Search, d as Plus, h as LoaderCircle, m as Minus, t as X } from "../_libs/lucide-react.mjs";
import { t as Badge } from "./badge-DTfl_mpk.mjs";
import { n as Card, t as Button } from "./card-6JO_WVWA.mjs";
import { t as Input } from "./input-D-dBVxfd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/lab-G_S4KQIx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function expectedDice(expr) {
	if (typeof expr === "number") return expr;
	const s = expr.replace(/\s/g, "").toUpperCase();
	const m = s.match(/^(\d*)D(\d+)([+-]\d+)?$/);
	if (!m) {
		const n = Number(s);
		return Number.isFinite(n) ? n : 1;
	}
	const count = m[1] ? Number(m[1]) : 1;
	const faces = Number(m[2]);
	const mod = m[3] ? Number(m[3]) : 0;
	return count * ((faces + 1) / 2) + mod;
}
function rollExpr(expr) {
	if (typeof expr === "number") return expr;
	const s = expr.replace(/\s/g, "").toUpperCase();
	const m = s.match(/^(\d*)D(\d+)([+-]\d+)?$/);
	if (!m) {
		const n = Number(s);
		return Number.isFinite(n) ? n : 1;
	}
	const count = m[1] ? Number(m[1]) : 1;
	const faces = Number(m[2]);
	const mod = m[3] ? Number(m[3]) : 0;
	let total = 0;
	for (let i = 0; i < count; i++) total += 1 + Math.floor(Math.random() * faces);
	return total + mod;
}
function d6() {
	return 1 + Math.floor(Math.random() * 6);
}
function clampChance(p) {
	return Math.min(1, Math.max(0, p));
}
function hitChance(skill, mod, torrent) {
	if (torrent) return 1;
	const needed = skill - mod;
	if (needed <= 1) return 5 / 6;
	if (needed >= 7) return 1 / 6;
	return (7 - needed) / 6;
}
function woundOn(strength, toughness) {
	if (strength >= toughness * 2) return 2;
	if (strength > toughness) return 3;
	if (strength === toughness) return 4;
	if (strength * 2 <= toughness) return 6;
	return 5;
}
function antiWoundOn(weapon, target) {
	let best = null;
	for (const k of weapon.keywords) {
		const m = k.match(/^Anti-(.+)\s+(\d+)\+$/i);
		if (!m) continue;
		const tag = m[1];
		if (target.keywords.some((tk) => tk === tag || tk.startsWith(tag) || tag.startsWith(tk))) {
			const n = Number(m[2]);
			best = best === null ? n : Math.min(best, n);
		}
	}
	return best;
}
function woundChance(strength, toughness, mod, weapon, target) {
	let needed = woundOn(strength, toughness);
	if (weapon && target) {
		const anti = antiWoundOn(weapon, target);
		if (anti !== null) needed = Math.min(needed, anti);
	}
	needed -= mod;
	if (needed <= 1) return 5 / 6;
	if (needed >= 7) return 1 / 6;
	return (7 - needed) / 6;
}
/** 11th edition: Cover no longer improves the save — it is a −1 to hit. */
function saveChance(sv, ap, invuln) {
	const needed = sv - ap;
	let p = needed >= 7 ? 0 : needed <= 1 ? 5 / 6 : (7 - needed) / 6;
	if (invuln) {
		const ip = invuln <= 1 ? 5 / 6 : (7 - invuln) / 6;
		p = Math.max(p, ip);
	}
	return clampChance(p);
}
function saveNeeded(sv, ap, invuln) {
	const armour = sv - ap;
	if (invuln && (armour > invuln || armour > 6)) return {
		armour,
		used: invuln,
		invuln
	};
	return {
		armour,
		used: armour,
		invuln: invuln ?? void 0
	};
}
function resolveInvuln(target, ctx) {
	if (ctx.invuln === null) return void 0;
	if (typeof ctx.invuln === "number") return ctx.invuln;
	return target.invuln;
}
function resolveFnp(target, ctx) {
	if (ctx.fnp === null) return void 0;
	if (typeof ctx.fnp === "number") return ctx.fnp;
	return target.fnp;
}
function weaponHitMod(weapon, ctx) {
	let hitMod = ctx.hitMod;
	if (weapon.kind === "ranged") {
		const ignoresCover = weapon.keywords.includes("Ignores Cover");
		if (ctx.cover && !ignoresCover) hitMod -= 1;
		if (ctx.plunging) hitMod += 1;
	}
	if (ctx.stationary && weapon.keywords.includes("Heavy")) hitMod += 1;
	return hitMod;
}
function attacksFor(weapon, models, ctx) {
	let attacks = expectedDice(weapon.attacks) * models + ctx.extraAttacks;
	if (weapon.keywords.includes("Blast")) attacks += Math.floor(ctx.targetModels / 5);
	const rapid = weapon.keywords.find((k) => k.startsWith("Rapid Fire"));
	if (rapid && ctx.halfRangeMelta) {
		const extra = rapid.replace("Rapid Fire", "").trim();
		attacks += extra ? expectedDice(Number(extra) || extra) * models : expectedDice(weapon.attacks) * models;
	}
	return attacks;
}
function applyHitReroll(pHit, skill, hitMod, torrent, ctx) {
	if (torrent) return pHit;
	if (ctx.rerollAllHits) return 1 - (1 - pHit) * (1 - pHit);
	if (ctx.rerollHitOnes) return pHit + 1 / 6 * hitChance(skill, hitMod, false);
	return pHit;
}
function applyWoundReroll(pWound, ctx, twin) {
	let p = pWound;
	if (ctx.rerollWoundOnes) p = p + 1 / 6 * pWound;
	if (twin) p = 1 - (1 - p) * (1 - p);
	return clampChance(p);
}
function expectedDamage(weapon, models, target, ctx) {
	const torrent = weapon.keywords.some((k) => k === "Torrent");
	const lethal = weapon.keywords.some((k) => k.startsWith("Lethal"));
	const sustained = weapon.keywords.find((k) => k.startsWith("Sustained Hits"));
	const sustainedN = sustained ? Number(sustained.replace(/[^\d]/g, "") || "1") : 0;
	const twin = weapon.keywords.includes("Twin-linked");
	const dev = weapon.keywords.includes("Devastating Wounds");
	const melta = weapon.keywords.find((k) => k.startsWith("Melta"));
	const invuln = resolveInvuln(target, ctx);
	const fnp = resolveFnp(target, ctx);
	const attacks = attacksFor(weapon, models, ctx);
	const hitMod = weaponHitMod(weapon, ctx);
	const pHit = applyHitReroll(hitChance(weapon.skill, hitMod, torrent), weapon.skill, hitMod, torrent, ctx);
	let hits = attacks * pHit;
	if (sustainedN) hits += attacks * (1 / 6) * sustainedN;
	const sixes = attacks * (1 / 6);
	const lethalHits = lethal ? sixes : 0;
	const toWoundHits = Math.max(0, hits - lethalHits);
	const neededWound = (() => {
		let n = woundOn(weapon.strength, target.stats.t);
		const anti = antiWoundOn(weapon, target);
		if (anti !== null) n = Math.min(n, anti);
		return n - ctx.woundMod;
	})();
	const pWound = applyWoundReroll(woundChance(weapon.strength, target.stats.t, ctx.woundMod, weapon, target), ctx, twin);
	const wounds = toWoundHits * pWound + lethalHits;
	const save = saveNeeded(target.stats.sv, weapon.ap, invuln);
	const pSave = saveChance(target.stats.sv, weapon.ap, invuln);
	let unsaved = wounds * (1 - pSave);
	const critWounds = dev ? toWoundHits * pWound * (1 / 6) : 0;
	if (dev) unsaved = (wounds - critWounds) * (1 - pSave) + critWounds;
	if (fnp) {
		const pFnp = (7 - fnp) / 6;
		unsaved *= 1 - pFnp;
	}
	let dmg = expectedDice(weapon.damage);
	if (melta && ctx.halfRangeMelta) {
		const extra = Number(melta.replace(/[^\d]/g, "") || "2");
		dmg += extra;
	}
	const damage = unsaved * dmg;
	const woundsPerModel = typeof target.stats.w === "number" ? target.stats.w : 1;
	const modelsKilled = damage / Math.max(1, woundsPerModel);
	const hitOn = torrent ? 0 : Math.max(2, Math.min(6, weapon.skill - hitMod));
	return {
		attacks,
		hits,
		wounds,
		unsaved,
		damage,
		modelsKilled,
		lethalHits,
		devWounds: critWounds,
		hitModApplied: hitMod,
		pHit,
		pWound,
		pFailSave: 1 - pSave,
		hitOn,
		woundOnValue: Math.max(2, Math.min(6, neededWound)),
		saveOn: save.used
	};
}
function expectedVolley(fires, target, ctx) {
	const parts = fires.map((f) => ({
		name: f.weapon.name,
		kind: f.weapon.kind,
		...expectedDamage(f.weapon, f.models, target, ctx)
	}));
	const sum = (key) => parts.reduce((n, p) => n + p[key], 0);
	const first = parts[0];
	return {
		attacks: sum("attacks"),
		hits: sum("hits"),
		wounds: sum("wounds"),
		unsaved: sum("unsaved"),
		damage: sum("damage"),
		modelsKilled: sum("modelsKilled"),
		lethalHits: sum("lethalHits"),
		devWounds: sum("devWounds"),
		hitModApplied: first?.hitModApplied ?? 0,
		pHit: first?.pHit ?? 0,
		pWound: first?.pWound ?? 0,
		pFailSave: first?.pFailSave ?? 0,
		hitOn: first?.hitOn ?? 0,
		woundOnValue: first?.woundOnValue ?? 0,
		saveOn: first?.saveOn ?? 0,
		parts
	};
}
function hitSucceeds(roll, needed, torrent) {
	if (torrent) return true;
	if (roll === 1) return false;
	if (roll === 6) return true;
	return roll >= needed;
}
function woundSucceeds(roll, needed) {
	if (roll === 1) return false;
	if (roll === 6) return true;
	return roll >= needed;
}
function saveSucceeds(roll, needed) {
	if (needed > 6) return false;
	if (roll === 1) return false;
	return roll >= needed;
}
function rollHit(needed, torrent, ctx) {
	if (torrent) return {
		hit: true,
		crit: false
	};
	let roll = d6();
	if (!hitSucceeds(roll, needed, false)) {
		if (ctx.rerollAllHits || ctx.rerollHitOnes && roll === 1) {
			roll = d6();
			if (!hitSucceeds(roll, needed, false)) return {
				hit: false,
				crit: false
			};
		} else return {
			hit: false,
			crit: false
		};
	}
	return {
		hit: true,
		crit: roll === 6
	};
}
function rollWound(needed, twin, ctx) {
	const tryOnce = () => {
		let roll = d6();
		if (!woundSucceeds(roll, needed) && ctx.rerollWoundOnes && roll === 1) roll = d6();
		return {
			ok: woundSucceeds(roll, needed),
			roll
		};
	};
	let attempt = tryOnce();
	if (!attempt.ok && twin) attempt = tryOnce();
	return {
		wound: attempt.ok,
		crit: attempt.ok && attempt.roll === 6
	};
}
function simulateWeapon(weapon, models, target, ctx, state) {
	const torrent = weapon.keywords.some((k) => k === "Torrent");
	const lethal = weapon.keywords.some((k) => k.startsWith("Lethal"));
	const sustained = weapon.keywords.find((k) => k.startsWith("Sustained Hits"));
	const sustainedN = sustained ? Number(sustained.replace(/[^\d]/g, "") || "1") : 0;
	const twin = weapon.keywords.includes("Twin-linked");
	const dev = weapon.keywords.includes("Devastating Wounds");
	const melta = weapon.keywords.find((k) => k.startsWith("Melta"));
	const hitMod = weaponHitMod(weapon, ctx);
	const neededHit = weapon.skill - hitMod;
	let neededWound = woundOn(weapon.strength, target.stats.t);
	const anti = antiWoundOn(weapon, target);
	if (anti !== null) neededWound = Math.min(neededWound, anti);
	neededWound -= ctx.woundMod;
	const invuln = resolveInvuln(target, ctx);
	const fnpNeeded = resolveFnp(target, ctx);
	const save = saveNeeded(target.stats.sv, weapon.ap, invuln);
	let attacks = rollExpr(weapon.attacks) * models + ctx.extraAttacks;
	if (weapon.keywords.includes("Blast")) attacks += Math.floor(ctx.targetModels / 5);
	const rapid = weapon.keywords.find((k) => k.startsWith("Rapid Fire"));
	if (rapid && ctx.halfRangeMelta) {
		const extra = rapid.replace("Rapid Fire", "").trim();
		attacks += extra ? rollExpr(Number(extra) || extra) * models : rollExpr(weapon.attacks) * models;
	}
	const woundsPerModel = typeof target.stats.w === "number" ? target.stats.w : 1;
	const applyDamage = (pts) => {
		let remaining = pts;
		if (fnpNeeded) {
			let kept = 0;
			for (let i = 0; i < remaining; i++) if (d6() < fnpNeeded) kept += 1;
			remaining = kept;
		}
		state.rawDamage += remaining;
		while (remaining > 0 && state.modelsLeft > 0) {
			const taken = Math.min(remaining, state.woundsOnCurrent);
			state.woundsOnCurrent -= taken;
			remaining -= taken;
			if (state.woundsOnCurrent <= 0) {
				state.modelsLeft -= 1;
				remaining = 0;
				state.woundsOnCurrent = woundsPerModel;
			}
		}
	};
	for (let a = 0; a < attacks; a++) {
		if (state.modelsLeft <= 0) return;
		const { hit, crit } = rollHit(neededHit, torrent, ctx);
		if (!hit) continue;
		const extraHits = crit && sustainedN ? sustainedN : 0;
		const resolveHit = (autoWound) => {
			if (state.modelsLeft <= 0) return;
			if (!autoWound) {
				const { wound, crit: critWound } = rollWound(neededWound, twin, ctx);
				if (!wound) return;
				if (dev && critWound) {
					let dmg = rollExpr(weapon.damage);
					if (melta && ctx.halfRangeMelta) dmg += Number(melta.replace(/[^\d]/g, "") || "2");
					applyDamage(dmg);
					return;
				}
			}
			if (saveSucceeds(d6(), save.used)) return;
			let dmg = rollExpr(weapon.damage);
			if (melta && ctx.halfRangeMelta) dmg += Number(melta.replace(/[^\d]/g, "") || "2");
			applyDamage(dmg);
		};
		resolveHit(Boolean(lethal && crit));
		for (let e = 0; e < extraHits; e++) resolveHit(false);
	}
}
function simulateVolley(fires, target, ctx, iterations = 4e3) {
	const startModels = Math.max(1, ctx.targetModels);
	const woundsPerModel = typeof target.stats.w === "number" ? target.stats.w : 1;
	const slainHist = Array.from({ length: startModels + 1 }, () => 0);
	const damageCounts = /* @__PURE__ */ new Map();
	let totalDamage = 0;
	let totalSlain = 0;
	let wipes = 0;
	for (let i = 0; i < iterations; i++) {
		const state = {
			modelsLeft: startModels,
			woundsOnCurrent: woundsPerModel,
			rawDamage: 0
		};
		for (const fire of fires) simulateWeapon(fire.weapon, fire.models, target, ctx, state);
		const slain = startModels - state.modelsLeft;
		slainHist[slain] += 1;
		damageCounts.set(state.rawDamage, (damageCounts.get(state.rawDamage) ?? 0) + 1);
		totalDamage += state.rawDamage;
		totalSlain += slain;
		if (state.modelsLeft <= 0) wipes += 1;
	}
	const maxDmg = damageCounts.size ? Math.max(...damageCounts.keys()) : 0;
	const damageHist = Array.from({ length: maxDmg + 1 }, (_, n) => damageCounts.get(n) ?? 0);
	return {
		meanDamage: totalDamage / iterations,
		meanSlain: totalSlain / iterations,
		wipeChance: wipes / iterations,
		slainHist,
		damageHist,
		iterations
	};
}
function formatNum(n, digits = 2) {
	if (!Number.isFinite(n)) return "–";
	return n.toFixed(digits).replace(/\.00$/, "").replace(/(\.\d)0$/, "$1");
}
function formatPct(n) {
	if (!Number.isFinite(n)) return "–";
	return `${(n * 100).toFixed(n >= .1 ? 0 : 1)}%`;
}
var CATALOG = allUnits();
var FNP_OPTS = [
	4,
	5,
	6
];
var INV_OPTS = [
	4,
	5,
	6
];
function weaponKey(w) {
	return `${w.kind}:${w.name}`;
}
function sheetOf(picked) {
	if (!picked) return void 0;
	const cat = CATALOG.find((u) => u.id === picked.id && u.factionId === picked.factionId);
	const sheet = getUnit(picked.factionId, picked.id);
	if (!sheet || !cat) return void 0;
	return {
		...sheet,
		factionId: cat.factionId,
		factionName: cat.factionName,
		accent: cat.accent
	};
}
function defaultWeapons(sheet) {
	return (sheet.ranged.length ? sheet.ranged : sheet.melee).slice(0, 1).map(weaponKey);
}
function LabPage() {
	const [atkPick, setAtkPick] = (0, import_react.useState)({
		factionId: "sm",
		id: "sm-intercessors"
	});
	const [defPick, setDefPick] = (0, import_react.useState)({
		factionId: "nids",
		id: "nids-termagants"
	});
	const atkSheet = sheetOf(atkPick);
	const defSheet = sheetOf(defPick);
	const [selectedWeapons, setSelectedWeapons] = (0, import_react.useState)(() => {
		const sheet = getUnit("sm", "sm-intercessors");
		return sheet ? defaultWeapons(sheet) : [];
	});
	const [atkModels, setAtkModels] = (0, import_react.useState)(5);
	const [defModels, setDefModels] = (0, import_react.useState)(10);
	const [plusHit, setPlusHit] = (0, import_react.useState)(false);
	const [minusHit, setMinusHit] = (0, import_react.useState)(false);
	const [plusWound, setPlusWound] = (0, import_react.useState)(false);
	const [minusWound, setMinusWound] = (0, import_react.useState)(false);
	const [cover, setCover] = (0, import_react.useState)(false);
	const [plunging, setPlunging] = (0, import_react.useState)(false);
	const [halfRange, setHalfRange] = (0, import_react.useState)(true);
	const [rerollOnes, setRerollOnes] = (0, import_react.useState)(false);
	const [rerollAllHits, setRerollAllHits] = (0, import_react.useState)(false);
	const [rerollWoundOnes, setRerollWoundOnes] = (0, import_react.useState)(false);
	const [stationary, setStationary] = (0, import_react.useState)(false);
	const [fnp, setFnp] = (0, import_react.useState)(() => getUnit("nids", "nids-termagants")?.fnp ?? null);
	const [invuln, setInvuln] = (0, import_react.useState)(() => getUnit("nids", "nids-termagants")?.invuln ?? null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [outcome, setOutcome] = (0, import_react.useState)(null);
	const resultsRef = (0, import_react.useRef)(null);
	const pickAttacker = (u) => {
		setAtkPick({
			factionId: u.factionId,
			id: u.id
		});
		const sheet = getUnit(u.factionId, u.id);
		setSelectedWeapons(sheet ? defaultWeapons(sheet) : []);
		setAtkModels(sheet?.sizes?.[0]?.models ?? 1);
		setOutcome(null);
	};
	const pickDefender = (u) => {
		setDefPick({
			factionId: u.factionId,
			id: u.id
		});
		const sheet = getUnit(u.factionId, u.id);
		setDefModels(sheet?.sizes?.[0]?.models ?? 1);
		setFnp(sheet?.fnp ?? null);
		setInvuln(sheet?.invuln ?? null);
		setOutcome(null);
	};
	const clearAttacker = () => {
		setAtkPick(null);
		setSelectedWeapons([]);
		setOutcome(null);
	};
	const clearDefender = () => {
		setDefPick(null);
		setOutcome(null);
	};
	const toggleWeapon = (w) => {
		const key = weaponKey(w);
		setSelectedWeapons((cur) => {
			if (cur.includes(key)) return cur.filter((k) => k !== key);
			return [...cur.filter((k) => k.startsWith(`${w.kind}:`)), key];
		});
		setOutcome(null);
	};
	const fires = (0, import_react.useMemo)(() => {
		if (!atkSheet) return [];
		return [...atkSheet.ranged, ...atkSheet.melee].filter((w) => selectedWeapons.includes(weaponKey(w))).map((weapon) => ({
			weapon,
			models: atkModels
		}));
	}, [
		atkSheet,
		selectedWeapons,
		atkModels
	]);
	const ctx = {
		hitMod: (plusHit ? 1 : 0) + (minusHit ? -1 : 0),
		woundMod: (plusWound ? 1 : 0) + (minusWound ? -1 : 0),
		cover,
		plunging,
		extraAttacks: 0,
		halfRangeMelta: halfRange,
		targetModels: defModels,
		rerollHitOnes: rerollOnes && !rerollAllHits,
		rerollAllHits,
		rerollWoundOnes,
		stationary,
		invuln,
		fnp
	};
	const ready = Boolean(atkSheet && defSheet && fires.length > 0);
	const hint = !atkSheet ? "Select an attacking unit" : !defSheet ? "Select a defending unit" : fires.length === 0 ? "Select a melee weapon or at least one ranged weapon" : `${atkSheet.name} into ${defSheet.name}`;
	const calculate = () => {
		if (!defSheet || fires.length === 0) return;
		setBusy(true);
		setOutcome(null);
		window.setTimeout(() => {
			const expected = expectedVolley(fires, defSheet, ctx);
			const sim = simulateVolley(fires, defSheet, ctx, 4e3);
			setOutcome({
				expected,
				sim
			});
			setBusy(false);
			window.setTimeout(() => resultsRef.current?.scrollIntoView({
				behavior: "smooth",
				block: "start"
			}), 40);
		}, 30);
	};
	const resetBoth = () => {
		setAtkPick(null);
		setDefPick(null);
		setSelectedWeapons([]);
		setAtkModels(1);
		setDefModels(1);
		setPlusHit(false);
		setMinusHit(false);
		setPlusWound(false);
		setMinusWound(false);
		setCover(false);
		setPlunging(false);
		setHalfRange(true);
		setRerollOnes(false);
		setRerollAllHits(false);
		setRerollWoundOnes(false);
		setStationary(false);
		setFnp(null);
		setInvuln(null);
		setOutcome(null);
	};
	const loadExample = () => {
		const atk = CATALOG.find((u) => u.id === "sm-intercessors");
		const def = CATALOG.find((u) => u.id === "nids-termagants");
		if (atk) pickAttacker(atk);
		if (def) pickDefender(def);
		setHalfRange(true);
		setCover(false);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-w-0 max-w-5xl flex-col gap-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col items-center gap-3 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-3xl font-bold tracking-wide uppercase md:text-4xl",
							children: "Combat Calculator"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							className: "border-transparent bg-blood/15 text-blood",
							children: "11th Edition · Beta"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-xl text-sm leading-relaxed text-muted-foreground md:text-base",
						children: "Select an attacking unit and a defending unit to calculate combat outcomes. Search by name or browse the full unit list."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-full max-w-xl rounded-lg border border-border bg-card/60 px-4 py-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-[10px] font-semibold tracking-[0.2em] text-muted-foreground uppercase",
									children: "Game Edition"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "inline-flex items-center rounded-md border border-border bg-background p-1",
									role: "group",
									"aria-label": "Game edition",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded px-3 py-1.5 font-display text-xs font-semibold text-muted-foreground",
										children: "10th"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded bg-blood px-3 py-1.5 font-display text-xs font-semibold text-primary-foreground",
										children: "11th"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "outline",
									className: "text-[10px]",
									children: "Beta"
								})
							]
						})
					}),
					!atkPick && !defPick ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: loadExample,
						className: "text-sm text-muted-foreground underline-offset-4 hover:text-foreground hover:underline",
						children: "Load example: Intercessors vs Termagants"
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid min-w-0 items-start gap-6 pb-36 lg:grid-cols-2 lg:gap-8 lg:pb-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "min-w-0 overflow-hidden p-5 md:p-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UnitPicker, {
							title: "Attacker",
							role: "attacker",
							selected: atkSheet,
							onSelect: pickAttacker,
							onClear: clearAttacker,
							children: atkSheet ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-1 flex flex-col gap-2 border-t border-border/40 pt-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, {
										accent: "blood",
										children: "Attacking Models"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
										value: atkModels,
										min: 1,
										max: Math.max(20, ...atkSheet.sizes?.map((s) => s.models) ?? [10]),
										onChange: (n) => {
											setAtkModels(n);
											setOutcome(null);
										},
										testId: "attacker-model-count"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeaponSection, {
									title: "Ranged Weapons",
									empty: "No ranged weapon profiles found for this unit.",
									weapons: atkSheet.ranged,
									selected: selectedWeapons,
									onToggle: toggleWeapon
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeaponSection, {
									title: "Melee Weapons",
									empty: "No melee weapon profiles found for this unit.",
									weapons: atkSheet.melee,
									selected: selectedWeapons,
									onToggle: toggleWeapon
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col gap-2 border-t border-border/40 pt-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, {
										accent: "blood",
										children: "Roll Modifiers"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap gap-1.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModChip, {
												label: "+1 to Hit",
												on: plusHit,
												onClick: () => {
													setPlusHit(!plusHit);
													setOutcome(null);
												}
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModChip, {
												label: "+1 to Wound",
												on: plusWound,
												onClick: () => {
													setPlusWound(!plusWound);
													setOutcome(null);
												}
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModChip, {
												label: "Re-roll Hit 1s",
												on: rerollOnes,
												onClick: () => {
													setRerollOnes(!rerollOnes);
													if (!rerollOnes) setRerollAllHits(false);
													setOutcome(null);
												}
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModChip, {
												label: "Re-roll All Hit Failures",
												on: rerollAllHits,
												onClick: () => {
													setRerollAllHits(!rerollAllHits);
													if (!rerollAllHits) setRerollOnes(false);
													setOutcome(null);
												}
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModChip, {
												label: "Re-roll Wound 1s",
												on: rerollWoundOnes,
												onClick: () => {
													setRerollWoundOnes(!rerollWoundOnes);
													setOutcome(null);
												}
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModChip, {
												label: "Remained Stationary",
												on: stationary,
												onClick: () => {
													setStationary(!stationary);
													setOutcome(null);
												}
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModChip, {
												label: "Half range",
												on: halfRange,
												onClick: () => {
													setHalfRange(!halfRange);
													setOutcome(null);
												}
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModChip, {
												label: "Plunging Fire",
												on: plunging,
												onClick: () => {
													setPlunging(!plunging);
													setOutcome(null);
												}
											})
										]
									})]
								})
							] }) : null
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center justify-center lg:hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-px w-12 bg-border" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex size-10 items-center justify-center rounded-full border-2 border-blood/40 bg-card",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swords, { className: "size-4 text-blood" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-px w-12 bg-border" })
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "min-w-0 overflow-hidden p-5 md:p-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UnitPicker, {
							title: "Defender",
							role: "defender",
							selected: defSheet,
							onSelect: pickDefender,
							onClear: clearDefender,
							children: defSheet ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-1 flex flex-col gap-2 border-t border-border/40 pt-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, {
										accent: "steel",
										children: "Defending Models"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
										value: defModels,
										min: 1,
										max: Math.max(20, ...defSheet.sizes?.map((s) => s.models) ?? [10]),
										onChange: (n) => {
											setDefModels(n);
											setOutcome(null);
										},
										testId: "defender-model-count"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col gap-2 border-t border-border/40 pt-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, {
										accent: "steel",
										children: "Feel No Pain"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
										value: fnp,
										options: FNP_OPTS,
										onChange: (n) => {
											setFnp(n);
											setOutcome(null);
										},
										suffix: "+"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col gap-2 border-t border-border/40 pt-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, {
										accent: "steel",
										children: "Invulnerable Save"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
										value: invuln,
										options: INV_OPTS,
										onChange: (n) => {
											setInvuln(n);
											setOutcome(null);
										},
										suffix: "+"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col gap-2 border-t border-border/40 pt-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, {
											accent: "steel",
											children: "Roll Modifiers"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap gap-1.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModChip, {
													label: "Cover (−1 hit)",
													on: cover,
													onClick: () => {
														setCover(!cover);
														setOutcome(null);
													}
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModChip, {
													label: "−1 to Hit",
													on: minusHit,
													onClick: () => {
														setMinusHit(!minusHit);
														setOutcome(null);
													}
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModChip, {
													label: "−1 to Wound",
													on: minusWound,
													onClick: () => {
														setMinusWound(!minusWound);
														setOutcome(null);
													}
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[10px] text-muted-foreground",
											children: "11th edition: Cover is −1 to hit, not +1 save. Datasheet invulnerable and Feel No Pain start selected when present."
										})
									]
								})
							] }) : null
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sticky bottom-16 z-20 -mx-4 flex flex-col items-center gap-3 bg-gradient-to-t from-background via-background to-transparent px-4 pt-4 pb-4 md:bottom-0 lg:static lg:mx-0 lg:bg-none lg:px-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "w-full max-w-xl",
					size: "lg",
					disabled: !ready || busy,
					onClick: calculate,
					children: busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }), "Simulating…"] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calculator, {}), "Calculate Combat"] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: resetBoth,
						className: "inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" }), "Reset both"]
					}), !busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: hint
					}) : null]
				})]
			}),
			outcome && atkSheet && defSheet ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: resultsRef,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Results, {
					attacker: atkSheet,
					defender: defSheet,
					expected: outcome.expected,
					sim: outcome.sim,
					defModels
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-8 border-t border-border pt-8 md:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display mb-2 text-sm font-semibold tracking-widest uppercase",
						children: "What is MathHammer?"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs leading-relaxed text-muted-foreground",
						children: "Closed-form averages plus a 4,000-pass Monte Carlo of the 11th edition attack sequence — hit, wound, save, damage — using Ono40k datasheets."
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display mb-2 text-sm font-semibold tracking-widest uppercase",
						children: "How to Use"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs leading-relaxed text-muted-foreground",
						children: "Search an attacker and a defender, choose weapon profiles, set models and modifiers, then hit Calculate Combat for expected hits, wounds, failed saves and average damage."
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display mb-2 text-sm font-semibold tracking-widest uppercase",
						children: "Why it lives here"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs leading-relaxed text-muted-foreground",
						children: "Compare target priority while you build lists. Leftover damage does not spill. Cover is −1 to hit. Half range turns on Rapid Fire and Melta."
					})] })
				]
			})
		]
	});
}
function UnitPicker({ title, role, selected, onSelect, onClear, children }) {
	const [query, setQuery] = (0, import_react.useState)("");
	const [open, setOpen] = (0, import_react.useState)(false);
	const [active, setActive] = (0, import_react.useState)(0);
	const boxRef = (0, import_react.useRef)(null);
	const inputRef = (0, import_react.useRef)(null);
	const attacker = role === "attacker";
	const shown = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		const list = CATALOG.filter((u) => {
			if (!q) return true;
			return u.name.toLowerCase().includes(q) || u.factionName.toLowerCase().includes(q) || u.keywords.some((k) => k.toLowerCase().includes(q));
		});
		return q ? list.slice(0, 40) : list.slice(0, 18);
	}, [query]);
	(0, import_react.useEffect)(() => {
		const onDoc = (e) => {
			if (!boxRef.current?.contains(e.target)) setOpen(false);
		};
		document.addEventListener("mousedown", onDoc);
		return () => document.removeEventListener("mousedown", onDoc);
	}, []);
	(0, import_react.useEffect)(() => {
		setActive(0);
	}, [query]);
	const choose = (u) => {
		onSelect(u);
		setQuery("");
		setOpen(false);
	};
	const onKeyDown = (e) => {
		if (!open && (e.key === "ArrowDown" || e.key === "Enter")) {
			setOpen(true);
			return;
		}
		if (e.key === "ArrowDown") {
			e.preventDefault();
			setActive((i) => Math.min(shown.length - 1, i + 1));
		} else if (e.key === "ArrowUp") {
			e.preventDefault();
			setActive((i) => Math.max(0, i - 1));
		} else if (e.key === "Enter") {
			e.preventDefault();
			const u = shown[active];
			if (u) choose(u);
		} else if (e.key === "Escape") setOpen(false);
	};
	const ring = attacker ? "border-blood/40 focus-within:border-blood" : "border-steel/40 focus-within:border-steel";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex w-full min-w-0 flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("flex h-8 items-center rounded-md px-3 font-display text-xs font-bold tracking-widest uppercase", attacker ? "bg-blood text-primary-foreground" : "bg-steel text-primary-foreground"),
					children: title
				}), selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onClear,
					className: "flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground",
					"aria-label": "Clear selection",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" }), "Clear"]
				}) : null]
			}),
			selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("rounded-lg border-2 bg-card p-4", ring),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-lg leading-tight font-bold text-balance",
								children: selected.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-medium text-muted-foreground",
								children: selected.factionName
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onClear,
							className: "flex size-9 shrink-0 items-center justify-center rounded-md text-muted-foreground hover:bg-muted hover:text-foreground",
							"aria-label": "Remove unit",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatStrip, { unit: selected }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							setOpen(true);
							window.setTimeout(() => inputRef.current?.focus(), 0);
						},
						className: "mt-3 text-xs text-muted-foreground underline-offset-4 hover:text-foreground hover:underline",
						children: "Search a different unit"
					})
				]
			}) : null,
			(!selected || open) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				ref: boxRef,
				className: "relative min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("relative flex items-center rounded-lg border-2 bg-card transition-colors", ring),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 size-4 text-muted-foreground" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							ref: inputRef,
							value: query,
							onChange: (e) => {
								setQuery(e.target.value);
								setOpen(true);
							},
							onFocus: () => setOpen(true),
							onKeyDown,
							placeholder: "Search units...",
							"aria-label": `Search ${title} units`,
							"aria-expanded": open,
							role: "combobox",
							autoComplete: "off",
							className: "h-11 border-0 bg-transparent pr-10 pl-10 focus-visible:ring-0"
						}),
						query ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								setQuery("");
								inputRef.current?.focus();
							},
							className: "absolute right-3 text-muted-foreground hover:text-foreground",
							"aria-label": "Clear search",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						}) : null
					]
				}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "absolute z-20 mt-1 max-h-64 w-full overflow-y-auto rounded-lg border border-border bg-popover shadow-lg",
					role: "listbox",
					children: shown.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "px-3 py-3 text-sm text-muted-foreground",
						children: "No units found"
					}) : shown.map((u, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						role: "option",
						"aria-selected": i === active,
						onMouseEnter: () => setActive(i),
						onClick: () => choose(u),
						className: cn("flex w-full items-center justify-between gap-3 px-3 py-2.5 text-left text-sm", i === active ? "bg-accent" : "hover:bg-muted"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 truncate",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: u.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted-foreground",
								children: [" · ", u.factionName]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "shrink-0 font-mono text-xs text-muted-foreground tabular-nums",
							children: [u.points, " pts"]
						})]
					}) }, `${u.factionId}-${u.id}`))
				}) : null]
			}),
			selected ? children : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Type to search or browse the list."
			})
		]
	});
}
function StatStrip({ unit }) {
	const m = typeof unit.stats.m === "number" ? `${unit.stats.m}"` : unit.stats.m;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-3 flex min-w-0 flex-wrap gap-2",
		children: [
			["M", m],
			["T", unit.stats.t],
			["SV", `${unit.stats.sv}+`],
			["W", unit.stats.w],
			["LD", `${unit.stats.ld}+`],
			["OC", unit.stats.oc]
		].map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-w-9 flex-col items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mb-0.5 text-[10px] leading-none font-medium tracking-wider text-muted-foreground uppercase",
				children: k
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-sm font-semibold tabular-nums",
				children: v
			})]
		}, k))
	});
}
function WeaponSection({ title, empty, weapons, selected, onToggle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2 border-t border-border/40 pt-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: title }),
			weapons.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: empty
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-1.5",
				children: weapons.map((w) => {
					const on = selected.includes(weaponKey(w));
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onToggle(w),
						className: cn("w-full min-w-0 rounded-md px-2.5 py-2 text-left transition-colors", on ? "bg-blood/15" : "hover:bg-muted/60"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate text-xs font-semibold",
									children: w.name
								}), on ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "outline",
									className: "h-4 py-0 text-[10px] normal-case",
									children: "selected"
								}) : null]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-1.5 flex min-w-0 flex-wrap gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
										label: "RNG",
										value: w.kind === "melee" ? "Melee" : `${w.range}"`
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
										label: "A",
										value: String(w.attacks)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
										label: w.kind === "melee" ? "WS" : "BS",
										value: `${w.skill}+`
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
										label: "S",
										value: String(w.strength)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
										label: "AP",
										value: String(w.ap)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
										label: "D",
										value: String(w.damage)
									})
								]
							}),
							w.keywords.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1.5 flex flex-wrap gap-1",
								children: w.keywords.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-sm border border-border px-1.5 py-0.5 text-[10px] tracking-wide text-muted-foreground uppercase",
									children: k
								}, k))
							}) : null
						]
					}) }, weaponKey(w));
				})
			})
		]
	});
}
function MiniStat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-9 flex-col items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-0.5 text-[10px] leading-none font-medium tracking-wider text-muted-foreground uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-mono text-xs font-semibold tabular-nums",
			children: value
		})]
	});
}
function SectionLabel({ children, accent }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center border-l-2 pl-2 font-display text-[11px] font-bold tracking-[0.15em] uppercase", accent === "blood" && "border-blood text-blood", accent === "steel" && "border-steel text-steel", !accent && "border-border text-muted-foreground"),
		children
	});
}
function Stepper({ value, min, max, onChange, testId }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "inline-flex items-center gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				size: "icon-sm",
				variant: "outline",
				"aria-label": "Decrease model count",
				disabled: value <= min,
				onClick: () => onChange(Math.max(min, value - 1)),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				"data-testid": testId,
				className: "min-w-10 text-center font-mono text-lg font-semibold tabular-nums",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				size: "icon-sm",
				variant: "outline",
				"aria-label": "Increase model count",
				disabled: value >= max,
				onClick: () => onChange(Math.min(max, value + 1)),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {})
			})
		]
	});
}
function Segmented({ value, options, onChange, suffix }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "inline-flex w-fit flex-wrap items-center gap-1 rounded-md border border-border bg-background p-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-pressed": value === null,
			onClick: () => onChange(null),
			className: cn("rounded px-3 py-1.5 font-display text-xs font-semibold", value === null ? "bg-blood text-primary-foreground" : "text-muted-foreground hover:text-foreground"),
			children: "Off"
		}), options.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			"aria-pressed": value === n,
			onClick: () => onChange(n),
			className: cn("rounded px-3 py-1.5 font-display text-xs font-semibold", value === n ? "bg-blood text-primary-foreground" : "text-muted-foreground hover:text-foreground"),
			children: [n, suffix]
		}, n))]
	});
}
function ModChip({ label, on, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		"aria-pressed": on,
		className: cn("h-9 rounded-md border px-3 text-xs font-medium", on ? "border-blood/40 bg-blood/15 text-foreground" : "border-border text-muted-foreground hover:text-foreground"),
		children: label
	});
}
function Results({ attacker, defender, expected, sim, defModels }) {
	const slainPct = defModels > 0 ? sim.meanSlain / defModels * 100 : 0;
	const maxDmgBin = Math.max(...sim.damageHist, 1);
	const dmgMax = Math.max(sim.damageHist.length - 1, 0);
	const shownDamage = sim.damageHist.map((count, dmg) => ({
		dmg,
		count,
		p: count / sim.iterations
	})).filter((row) => row.count > 0);
	const compactDamage = shownDamage.length > 16 ? shownDamage.filter((_, i) => i % Math.ceil(shownDamage.length / 14) === 0 || i === shownDamage.length - 1) : shownDamage;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg font-bold tracking-wide uppercase",
					children: "Combat Results"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: [sim.iterations.toLocaleString(), " iterations · leftover damage does not spill"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "overflow-hidden p-5 md:p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[11px] tracking-[0.16em] text-muted-foreground uppercase",
					children: [
						attacker.name,
						" vs ",
						defender.name
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid min-w-0 grid-cols-2 gap-3 sm:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatBox, {
							k: "Mean Damage Dealt",
							v: sim.meanDamage.toFixed(2),
							accent: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatBox, {
							k: "Models Killed",
							v: `${formatNum(sim.meanSlain)} (${slainPct.toFixed(1)}%)`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatBox, {
							k: "One-shot Chance",
							v: formatPct(sim.wipeChance)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatBox, {
							k: "Expected Damage",
							v: formatNum(expected.damage)
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid min-w-0 gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "min-w-0 overflow-hidden p-5 md:p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "Attack sequence" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted-foreground",
							children: "Closed-form averages across selected profiles."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 overflow-x-auto",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", {
								className: "w-full min-w-[260px] text-sm",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeqRow, {
										label: "Attacks",
										detail: "dice × models",
										value: formatNum(expected.attacks, 1)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeqRow, {
										label: "Hits",
										detail: expected.hitOn === 0 ? "Torrent" : `${expected.hitOn}+ (${formatPct(expected.pHit)})`,
										value: formatNum(expected.hits)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeqRow, {
										label: "Wounds",
										detail: `${expected.woundOnValue}+ (${formatPct(expected.pWound)})`,
										value: formatNum(expected.wounds)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeqRow, {
										label: "Failed saves",
										detail: `${expected.saveOn > 6 ? "no save" : `${expected.saveOn}+`} fail ${formatPct(expected.pFailSave)}`,
										value: formatNum(expected.unsaved)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeqRow, {
										label: "Damage",
										detail: "after FNP",
										value: formatNum(expected.damage),
										strong: true
									})
								] })
							})
						}),
						expected.parts.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 space-y-1 text-xs text-muted-foreground",
							children: expected.parts.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: p.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-mono tabular-nums",
									children: [formatNum(p.damage), " dmg"]
								})]
							}, `${p.kind}-${p.name}`))
						}) : null
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "min-w-0 overflow-hidden p-5 md:p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "Damage Dealt Distribution" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted-foreground",
							children: "Monte Carlo spread of total damage."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 flex h-36 min-w-0 items-end gap-px overflow-hidden",
							children: sim.damageHist.map((count, n) => {
								const p = count / sim.iterations;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex min-w-0 flex-1 flex-col items-center justify-end",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "w-full rounded-t-sm bg-steel/80",
										style: { height: `${Math.max(p > 0 ? 4 : 0, count / maxDmgBin * 100)}%` },
										title: `${n} dmg · ${formatPct(p)}`
									})
								}, n);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 flex justify-between text-[10px] tracking-wide text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [dmgMax, " dmg"] })]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "min-w-0 overflow-hidden p-5 md:p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLabel, { children: "Probability table" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-[280px] text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "text-[10px] tracking-wider text-muted-foreground uppercase",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "pb-2 text-left font-medium",
									children: "Damage Dealt"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "pb-2 text-right font-medium",
									children: "Rolls"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "pb-2 text-right font-medium",
									children: "Probability"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: compactDamage.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-border/70",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-1.5 font-mono tabular-nums",
									children: row.dmg
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-1.5 text-right font-mono tabular-nums",
									children: row.count.toLocaleString()
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-1.5 text-right font-mono tabular-nums",
									children: formatPct(row.p)
								})
							]
						}, row.dmg)) })]
					})
				})]
			})
		]
	});
}
function SeqRow({ label, detail, value, strong }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
		className: "border-t border-border/70",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
			className: "py-2 pr-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: strong ? "font-medium" : "",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "ml-2 text-xs text-muted-foreground",
				children: detail
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
			className: cn("py-2 text-right font-mono tabular-nums", strong && "text-steel"),
			children: value
		})]
	});
}
function StatBox({ k, v, accent }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-muted p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[10px] tracking-[0.14em] text-muted-foreground uppercase",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: cn("mt-1 font-mono text-2xl tabular-nums", accent && "text-steel"),
			children: v
		})]
	});
}
//#endregion
export { LabPage as component };
