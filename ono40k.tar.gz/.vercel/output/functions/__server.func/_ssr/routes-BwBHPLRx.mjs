import { i as __toESM } from "../_runtime.mjs";
import { a as formatClock, i as cn, r as battleElapsedMs, s as getFaction, t as FACTIONS } from "./utils-hP9YwH9-.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { _ as Import, a as Swords, d as Plus, i as Trash2, o as Star, t as X, w as BookOpen, y as Copy } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { M as totalScore, N as BATTLE_SIZES, a as useWarStore, l as rosterPoints } from "./router-cdYjUO9_.mjs";
import { t as Badge } from "./badge-DTfl_mpk.mjs";
import { n as Card, t as Button } from "./card-6JO_WVWA.mjs";
import { n as Textarea, t as Input } from "./input-D-dBVxfd.mjs";
import { t as Label } from "./label-FG9JJXgY.mjs";
import { a as DialogOverlay, i as DialogDescription$1, n as DialogClose, o as DialogPortal, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, o as decodeRoster, r as SelectItem, t as Select } from "./share-DnE0XE2v.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BwBHPLRx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Dialog = Dialog$1;
function DialogContent({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-background/70 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed top-1/2 left-1/2 z-50 w-[calc(100%-2rem)] max-w-lg -translate-x-1/2 -translate-y-1/2 rounded-xl border border-border bg-card p-6 shadow-lg outline-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
			className: "absolute top-4 right-4 rounded-md p-1 text-muted-foreground hover:bg-accent hover:text-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "Close"
			})]
		})]
	})] });
}
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mb-4 flex flex-col gap-1", className),
		...props
	});
}
function DialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
		className: cn("font-display text-xl font-semibold tracking-wide", className),
		...props
	});
}
function DialogDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
		className: cn("text-sm text-muted-foreground", className),
		...props
	});
}
function Home() {
	const lists = useWarStore((s) => s.lists);
	const games = useWarStore((s) => s.games);
	const toggleFavorite = useWarStore((s) => s.toggleFavorite);
	const duplicateList = useWarStore((s) => s.duplicateList);
	const deleteList = useWarStore((s) => s.deleteList);
	const importList = useWarStore((s) => s.importList);
	const activeGameId = useWarStore((s) => s.activeGameId);
	const resumeGame = useWarStore((s) => s.resumeGame);
	const navigate = useNavigate();
	const [createOpen, setCreateOpen] = (0, import_react.useState)(false);
	const [importOpen, setImportOpen] = (0, import_react.useState)(false);
	const [importCode, setImportCode] = (0, import_react.useState)("");
	const shown = (0, import_react.useMemo)(() => {
		return lists.slice().sort((a, b) => Number(b.favorite) - Number(a.favorite) || b.updatedAt - a.updatedAt);
	}, [lists]);
	const saved = shown.filter((l) => l.saved !== false);
	const drafts = shown.filter((l) => l.saved === false);
	const history = games.filter((g) => g.status === "complete").slice(0, 6);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-w-0 space-y-8",
		children: [
			activeGameId ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/battle",
				className: "flex items-center justify-between gap-3 rounded-xl border border-blood/40 bg-blood/10 px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium tracking-[0.16em] text-blood uppercase",
					children: "Active battle"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg",
					children: "View ledger"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swords, { className: "size-5 text-blood" })]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-medium tracking-[0.22em] text-muted-foreground uppercase",
						children: "Muster"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "font-display mt-1 text-3xl font-semibold tracking-wide",
						children: ["Army Lists", lists.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-2 font-mono text-base font-normal tabular-nums text-muted-foreground",
							children: lists.length
						}) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 max-w-xl text-sm text-muted-foreground",
						children: "Build as many 11th edition strike forces as you need, then open a battle with two lists on the table."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid w-full grid-cols-2 gap-2 sm:flex sm:w-auto sm:flex-wrap",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							className: "col-span-2 sm:col-span-1",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/battle",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-4" }), " View ledger"]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							onClick: () => setImportOpen(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Import, { className: "size-4" }), " Import"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: () => setCreateOpen(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " New list"]
						})
					]
				})]
			}),
			shown.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-8 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xl",
						children: "No lists yet"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: "Muster your first strike force, then tap Save to pin it here."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-5",
						onClick: () => setCreateOpen(true),
						children: "Create list"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-display text-xl font-semibold tracking-wide",
					children: ["Saved armies", saved.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-2 font-mono text-sm font-normal tabular-nums text-muted-foreground",
						children: saved.length
					}) : null]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-0.5 text-sm text-muted-foreground",
					children: "Pinned lists from Save in the builder. They stay on this device."
				})] }), saved.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "p-6 text-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "No saved armies yet. Open a list and tap Save."
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid min-w-0 gap-3 sm:grid-cols-2",
					children: saved.map((list) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListCard, {
						list,
						onFavorite: () => toggleFavorite(list.id),
						onDuplicate: () => {
							if (duplicateList(list.id)) toast("List duplicated");
						},
						onDelete: () => {
							deleteList(list.id);
							toast("List deleted");
						}
					}, list.id))
				})]
			}), drafts.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-display text-xl font-semibold tracking-wide",
					children: ["Drafts", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-2 font-mono text-sm font-normal tabular-nums text-muted-foreground",
						children: drafts.length
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-0.5 text-sm text-muted-foreground",
					children: "Working lists that have not been saved yet."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid min-w-0 gap-3 sm:grid-cols-2",
					children: drafts.map((list) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListCard, {
						list,
						onFavorite: () => toggleFavorite(list.id),
						onDuplicate: () => {
							if (duplicateList(list.id)) toast("List duplicated");
						},
						onDelete: () => {
							deleteList(list.id);
							toast("List deleted");
						}
					}, list.id))
				})]
			}) : null] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "rounded-xl border border-border bg-card p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase",
							children: "War Journal"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display mt-1 text-xl font-semibold tracking-wide",
							children: "Annals"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: "Wins, VP by round, matchups, and the tape from closed ledgers."
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/analytics",
							children: "Open"
						})
					})]
				})
			}),
			history.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-semibold tracking-wide",
					children: "Closed ledgers"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "sm",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/analytics",
						children: "Annals"
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 space-y-2",
				children: history.map((g) => {
					const me = totalScore(g.scores.me.primaryByRound, g.scores.me.tactical, g.scores.me.painted);
					const them = totalScore(g.scores.opponent.primaryByRound, g.scores.opponent.tactical, g.scores.opponent.painted);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between gap-3 rounded-lg border border-border bg-card px-4 py-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 truncate",
							children: [
								g.myName,
								" vs ",
								g.opponentName
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex shrink-0 items-center gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-xs tabular-nums text-muted-foreground",
									children: formatClock(battleElapsedMs(g))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-mono tabular-nums",
									children: [
										me,
										" – ",
										them
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "outline",
									onClick: () => {
										resumeGame(g.id);
										navigate({ to: "/battle" });
									},
									children: "View ledger"
								})
							]
						})]
					}, g.id);
				})
			})] }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreateListDialog, {
				open: createOpen,
				onOpenChange: setCreateOpen
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: importOpen,
				onOpenChange: setImportOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Import share code" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Paste a WL1 share code from another Ono40k list." })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: importCode,
						onChange: (e) => setImportCode(e.target.value),
						placeholder: "WL1.…"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-3 w-full",
						onClick: () => {
							const decoded = decodeRoster(importCode);
							if (!decoded) {
								toast.error("Could not read that code");
								return;
							}
							const id = importList(decoded);
							setImportOpen(false);
							setImportCode("");
							toast("List imported");
							navigate({
								to: "/lists/$listId",
								params: { listId: id }
							});
						},
						children: "Import"
					})
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "pb-2 text-center text-[11px] leading-relaxed text-muted-foreground",
				children: "Unofficial fan companion. Not affiliated with Games Workshop. Points and rules are a table reference, not a substitute for the current Munitorum Field Manual."
			})
		]
	});
}
function ListCard({ list, onFavorite, onDuplicate, onDelete }) {
	const faction = getFaction(list.factionId);
	const pts = rosterPoints(list);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
		className: "min-w-0",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "flex h-full min-w-0 flex-col overflow-hidden p-4",
			style: {
				borderLeftWidth: 3,
				borderLeftColor: faction?.accent
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/lists/$listId",
						params: { listId: list.id },
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] tracking-[0.14em] text-muted-foreground uppercase",
							children: faction?.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display mt-0.5 truncate text-lg font-semibold",
							children: list.name
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Favorite",
						onClick: onFavorite,
						className: cn("rounded-md p-2", list.favorite ? "text-steel" : "text-muted-foreground"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: cn("size-4", list.favorite && "fill-current") })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-1.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "outline",
							children: BATTLE_SIZES[list.battleSize].label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							className: "tabular-nums",
							children: [
								pts,
								"/",
								list.pointsLimit
							]
						}),
						list.disposition ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: list.disposition }) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							variant: "outline",
							children: [list.units.length, " units"]
						}),
						list.saved === false ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "outline",
							children: "Draft"
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex items-center gap-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "secondary",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/lists/$listId",
								params: { listId: list.id },
								children: "Edit"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon-sm",
							variant: "ghost",
							"aria-label": "Duplicate",
							onClick: onDuplicate,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon-sm",
							variant: "ghost",
							"aria-label": "Delete",
							onClick: onDelete,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
						})
					]
				})
			]
		})
	});
}
function CreateListDialog({ open, onOpenChange }) {
	const createList = useWarStore((s) => s.createList);
	const navigate = useNavigate();
	const [name, setName] = (0, import_react.useState)("");
	const [factionId, setFactionId] = (0, import_react.useState)("um");
	const [battleSize, setBattleSize] = (0, import_react.useState)("strike");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "New army list" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Pick a faction and battle size, then muster the roster." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "list-name",
						children: "Name"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "list-name",
						value: name,
						onChange: (e) => setName(e.target.value),
						placeholder: "III Company"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Faction" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: factionId,
						onValueChange: setFactionId,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: FACTIONS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
							value: f.id,
							children: [f.name, f.short ? ` · ${f.short}` : ""]
						}, f.id)) })]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Battle size" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: battleSize,
						onValueChange: (v) => setBattleSize(v),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "incursion",
							children: "Incursion · 1000 pts · 2 DP"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "strike",
							children: "Strike Force · 2000 pts · 3 DP"
						})] })]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "w-full",
					onClick: () => {
						const id = createList({
							name: name.trim() || "Untitled list",
							factionId,
							battleSize
						});
						onOpenChange(false);
						setName("");
						navigate({
							to: "/lists/$listId",
							params: { listId: id }
						});
					},
					children: "Open builder"
				})
			]
		})] })
	});
}
//#endregion
export { Home as component };
