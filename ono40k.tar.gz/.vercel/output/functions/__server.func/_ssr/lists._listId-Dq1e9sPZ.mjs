import { i as __toESM } from "../_runtime.mjs";
import { c as getUnit, i as cn, o as getDetachment, p as unitCopyMarks, s as getFaction, u as roleLabel } from "./utils-hP9YwH9-.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { S as Check, c as Search, d as Plus, i as Trash2, m as Minus, o as Star, t as X, u as Save, w as BookOpen, x as ChevronDown } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { E as DISPOSITIONS, N as BATTLE_SIZES, O as missionFor, a as useWarStore, c as rosterDp, d as validateRoster, f as resolvedWargearIds, h as wargearGroups, l as rosterPoints, m as setWargearGroup, n as Route, p as rosterLoadout, u as unitTotalPoints } from "./router-cdYjUO9_.mjs";
import { t as Badge } from "./badge-DTfl_mpk.mjs";
import { n as Card, t as Button } from "./card-6JO_WVWA.mjs";
import { n as RuleFold, t as Datasheet } from "./RuleFold-BYMBt6uO.mjs";
import { n as Textarea, t as Input } from "./input-D-dBVxfd.mjs";
import { t as Label } from "./label-FG9JJXgY.mjs";
import { a as DialogOverlay, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, s as encodeRoster, t as Select } from "./share-DnE0XE2v.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/lists._listId-Dq1e9sPZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Sheet = Dialog;
function SheetContent({ className, children, side = "right", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-background/70 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
		className: cn("fixed z-50 flex flex-col bg-card border-border shadow-lg outline-none data-[state=open]:animate-in data-[state=closed]:animate-out", side === "right" && "inset-y-0 right-0 h-full w-full max-w-md border-l", side === "left" && "inset-y-0 left-0 h-full w-full max-w-md border-r", side === "bottom" && "inset-x-0 bottom-0 max-h-[88vh] rounded-t-xl border-t", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
			className: "absolute top-4 right-4 rounded-md p-1 text-muted-foreground hover:bg-accent",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "Close"
			})]
		})]
	})] });
}
function SheetHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("border-b border-border p-5 pr-12", className),
		...props
	});
}
function SheetTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
		className: cn("font-display text-lg font-semibold", className),
		...props
	});
}
var ADD_UNIT_SECTIONS = [
	{
		title: "Characters",
		roles: ["character"]
	},
	{
		title: "Battleline",
		roles: ["battleline"]
	},
	{
		title: "Infantry",
		roles: ["infantry"]
	},
	{
		title: "Monsters",
		roles: ["monster"]
	},
	{
		title: "Mounted",
		roles: ["mounted"]
	},
	{
		title: "Vehicles",
		roles: ["vehicle", "transport"]
	}
];
function ListBuilder() {
	const { listId } = Route.useParams();
	const list = useWarStore((s) => s.lists.find((l) => l.id === listId));
	const updateList = useWarStore((s) => s.updateList);
	const saveList = useWarStore((s) => s.saveList);
	const addUnit = useWarStore((s) => s.addUnit);
	const updateUnit = useWarStore((s) => s.updateUnit);
	const removeUnit = useWarStore((s) => s.removeUnit);
	const toggleFavorite = useWarStore((s) => s.toggleFavorite);
	const [addOpen, setAddOpen] = (0, import_react.useState)(false);
	const [query, setQuery] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)({});
	const [inspectId, setInspectId] = (0, import_react.useState)(null);
	const [detOpen, setDetOpen] = (0, import_react.useState)({});
	const [oppDisp, setOppDisp] = (0, import_react.useState)(null);
	const faction = list ? getFaction(list.factionId) : void 0;
	const copies = (0, import_react.useMemo)(() => list ? unitCopyMarks(list.units) : {}, [list]);
	const catalogSections = (0, import_react.useMemo)(() => {
		if (!faction) return [];
		const q = query.trim().toLowerCase();
		const matches = (u) => !q || u.name.toLowerCase().includes(q) || u.keywords.some((k) => k.toLowerCase().includes(q));
		return ADD_UNIT_SECTIONS.map((section) => ({
			...section,
			units: faction.units.filter((u) => section.roles.includes(u.role) && matches(u)).slice().sort((a, b) => a.points - b.points || a.name.localeCompare(b.name))
		})).filter((section) => section.units.length > 0);
	}, [faction, query]);
	if (!list) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-16 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-xl",
			children: "List not found"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			asChild: true,
			className: "mt-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				children: "Back to lists"
			})
		})]
	});
	if (!faction) return null;
	const pts = rosterPoints(list);
	const dp = rosterDp(list);
	const size = BATTLE_SIZES[list.battleSize];
	const issues = validateRoster(list);
	const errors = issues.filter((i) => i.level === "error");
	const selectedDets = list.detachmentIds.map((id) => getDetachment(list.factionId, id)).filter(Boolean);
	const availableDisp = [...new Set(selectedDets.map((d) => d.disposition))];
	const myDisp = list.disposition && availableDisp.includes(list.disposition) ? list.disposition : availableDisp[0] ?? list.disposition;
	const vsDisp = oppDisp ?? DISPOSITIONS.find((d) => d !== myDisp) ?? DISPOSITIONS[0];
	const paired = myDisp ? {
		info: missionFor(myDisp, vsDisp).me,
		mine: myDisp,
		theirs: vsDisp
	} : null;
	const enhancements = selectedDets.flatMap((d) => d.enhancements);
	const inspectRu = inspectId ? list.units.find((u) => u.id === inspectId) : void 0;
	const inspectUnit = inspectRu ? getUnit(list.factionId, inspectRu.unitId) : void 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "text-xs tracking-[0.16em] text-muted-foreground uppercase hover:text-foreground",
							children: "Lists"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListTitle, {
							listId: list.id,
							name: list.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: faction.name
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap justify-end gap-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "ghost",
							onClick: () => toggleFavorite(list.id),
							"aria-label": "Favorite",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: cn("size-4", list.favorite && "fill-current text-steel") })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							onClick: () => {
								saveList(list.id);
								toast.success("List saved", { description: list.name });
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-4" }), " Save"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "sm",
							onClick: async () => {
								const code = encodeRoster(list);
								await navigator.clipboard.writeText(code);
								toast("Share code copied");
							},
							children: "Copy code"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "sm",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/battle",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-4" }), " View ledger"]
							})
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Battle size" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: list.battleSize,
							onValueChange: (v) => updateList(list.id, {
								battleSize: v,
								pointsLimit: BATTLE_SIZES[v].points
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								className: "mt-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "incursion",
								children: "Incursion 1000"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "strike",
								children: "Strike Force 2000"
							})] })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-[0.14em] text-muted-foreground uppercase",
							children: "Points"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: cn("mt-2 font-mono text-2xl tabular-nums", pts > size.points && "text-blood"),
							children: [pts, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-sm text-muted-foreground",
								children: ["/", size.points]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-[0.14em] text-muted-foreground uppercase",
							children: "Detachment points"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: cn("mt-2 font-mono text-2xl tabular-nums", dp > size.dp && "text-blood"),
							children: [dp, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-sm text-muted-foreground",
								children: [
									"/",
									size.dp,
									" DP"
								]
							})]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg font-semibold",
					children: "Detachments"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 mb-3 space-y-1.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "px-0.5 text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase",
							children: "Army abilities"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RuleFold, {
							kicker: "Army rule",
							title: faction.rule.name,
							text: faction.rule.text
						}),
						selectedDets.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RuleFold, {
							kicker: d.name,
							title: d.rule.name,
							text: d.rule.text
						}, `rule-${d.id}`))
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid grid-cols-2 items-start gap-1",
					children: faction.detachments.map((d) => {
						const on = list.detachmentIds.includes(d.id);
						const expanded = detOpen[d.id] === true;
						const over = !on && dp + d.dp > size.dp;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: cn("min-w-0 rounded-md border", on ? "border-primary bg-accent" : "border-border bg-card", over && "opacity-50"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-0.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": on ? `Remove ${d.name}` : `Add ${d.name}`,
									onClick: () => {
										if (on) {
											const next = list.detachmentIds.filter((id) => id !== d.id);
											const disp = next.map((id) => getDetachment(list.factionId, id)?.disposition).filter(Boolean);
											updateList(list.id, {
												detachmentIds: next,
												disposition: list.disposition && disp.includes(list.disposition) ? list.disposition : disp[0] ?? null
											});
											return;
										}
										if (dp + d.dp > size.dp) {
											toast(`That would be ${dp + d.dp} DP — max is ${size.dp} DP`);
											return;
										}
										if (list.detachmentIds.map((id) => getDetachment(list.factionId, id)?.uniqueTag).filter(Boolean).includes(d.uniqueTag)) {
											toast(`Unique: ${d.uniqueTag} — already have a detachment with that tag`);
											return;
										}
										updateList(list.id, {
											detachmentIds: [...list.detachmentIds, d.id],
											disposition: d.disposition
										});
									},
									className: "flex size-11 shrink-0 items-center justify-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: cn("flex size-3.5 items-center justify-center rounded-sm border", on ? "border-primary bg-primary text-primary-foreground" : "border-border"),
										children: on ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-2.5" }) : null
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									"aria-expanded": expanded,
									onClick: () => setDetOpen((prev) => ({
										...prev,
										[d.id]: !expanded
									})),
									className: "min-h-11 min-w-0 flex-1 py-1.5 pr-2 text-left",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "min-w-0 truncate text-xs font-medium",
												children: d.name
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
												className: "h-4 shrink-0 px-1.5 py-0 text-[10px] tracking-wider",
												children: [d.dp, " DP"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												variant: "outline",
												className: "hidden h-4 max-w-[7rem] shrink truncate px-1.5 py-0 text-[10px] tracking-wider sm:inline-flex",
												children: d.disposition
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: cn("ml-auto size-3.5 shrink-0 text-muted-foreground transition-transform", expanded && "rotate-180") })
										]
									}), expanded ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
										className: "mt-1.5 list-disc space-y-1 pl-4 text-xs leading-snug text-muted-foreground",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-foreground",
											children: [d.rule.name, ". "]
										}), d.rule.text] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["Unique tag: ", d.uniqueTag] })]
									}) : null]
								})]
							})
						}, d.id);
					})
				}),
				availableDisp.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase",
							children: "Force disposition · from detachments"
						}),
						availableDisp.length === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm",
							children: [availableDisp[0], /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted-foreground",
								children: [" · ", selectedDets.find((d) => d.disposition === availableDisp[0])?.name]
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-1.5",
							children: availableDisp.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => updateList(list.id, { disposition: d }),
								className: cn("h-8 rounded-md border px-2.5 text-xs font-medium", (list.disposition ?? availableDisp[0]) === d ? "border-primary bg-primary text-primary-foreground" : "border-border bg-muted text-muted-foreground"),
								children: d
							}, d))
						}),
						paired ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-border bg-card p-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] font-medium tracking-[0.14em] text-muted-foreground uppercase",
									children: "Primary mission"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: vsDisp,
									onValueChange: (v) => setOppDisp(v),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: "mt-2 h-8 text-xs",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: DISPOSITIONS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
										value: d,
										children: ["vs ", d]
									}, d)) })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display mt-2 text-base font-semibold",
									children: paired.info.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [
										paired.mine,
										" vs ",
										paired.theirs
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs leading-relaxed text-muted-foreground",
									children: paired.info.blurb
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-2 list-disc space-y-1 pl-4 text-xs leading-snug",
									children: paired.info.scoring.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: line }, line))
								})
							]
						}) : null
					]
				}) : null
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-display flex items-baseline gap-2 text-lg font-semibold",
					children: ["Roster", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: cn("font-mono text-sm font-normal tabular-nums", pts > size.points && "text-blood"),
						children: [pts, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted-foreground",
							children: ["/", size.points]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: () => setAddOpen(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " Add unit"]
				})]
			}), list.units.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "p-6 text-center text-sm text-muted-foreground",
				children: "No units yet. Add from the catalog."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid grid-cols-2 items-start gap-1",
				children: [...list.units].sort((a, b) => {
					if (Boolean(a.warlord) !== Boolean(b.warlord)) return a.warlord ? -1 : 1;
					const na = getUnit(list.factionId, a.unitId)?.name ?? "";
					const nb = getUnit(list.factionId, b.unitId)?.name ?? "";
					const byName = na.localeCompare(nb);
					if (byName !== 0) return byName;
					return (copies[a.id] ?? "").localeCompare(copies[b.id] ?? "");
				}).map((ru) => {
					const def = getUnit(list.factionId, ru.unitId);
					if (!def) return null;
					const total = unitTotalPoints(list, ru);
					const loadout = rosterLoadout(def, ru.wargearIds);
					const enh = ru.enhancementId ? enhancements.find((e) => e.id === ru.enhancementId) : void 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "min-w-0 rounded-lg border border-border bg-card px-2.5 py-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex min-w-0 flex-wrap items-center gap-1.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "min-w-0 truncate text-left text-sm font-medium leading-5",
									onClick: () => setInspectId(ru.id),
									children: [def.name, copies[ru.id] ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "ml-1.5 text-[10px] tracking-widest text-steel",
										children: [
											"[",
											copies[ru.id],
											"]"
										]
									}) : null]
								}),
								def.role === "character" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									className: "h-7 shrink-0 px-2 text-[11px]",
									variant: ru.warlord ? "default" : "outline",
									onClick: () => {
										useWarStore.setState({ lists: useWarStore.getState().lists.map((l) => l.id === list.id ? {
											...l,
											units: l.units.map((u) => ({
												...u,
												warlord: u.id === ru.id
											}))
										} : l) });
									},
									children: "WL"
								}) : null,
								enhancements.length > 0 && def.role === "character" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: ru.enhancementId ?? "none",
									onValueChange: (v) => updateUnit(list.id, ru.id, { enhancementId: v === "none" ? void 0 : v }),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: "h-7 w-[8.5rem] shrink-0 px-2 text-[11px]",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Enhancement" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "none",
										children: "No enhancement"
									}), enhancements.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
										value: e.id,
										children: [
											e.name,
											" +",
											e.points
										]
									}, e.id))] })]
								}) : null,
								def.sizes && def.sizes.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: String(ru.models),
									onValueChange: (v) => {
										const sizeOpt = def.sizes.find((s) => s.models === Number(v));
										if (sizeOpt) updateUnit(list.id, ru.id, {
											models: sizeOpt.models,
											points: sizeOpt.points
										});
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: "h-7 w-[5.5rem] shrink-0 px-2 text-[11px]",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: def.sizes.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
										value: String(s.models),
										children: [
											s.models,
											" · ",
											s.points
										]
									}, s.models)) })]
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-auto shrink-0 font-mono text-sm tabular-nums leading-5",
									children: total
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "icon-sm",
									variant: "ghost",
									className: "shrink-0",
									"aria-label": "Remove",
									onClick: () => removeUnit(list.id, ru.id),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "mt-0.5 w-full min-w-0 text-left",
							onClick: () => setInspectId(ru.id),
							children: [
								ru.models > 1 || enh ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-xs leading-4 text-muted-foreground",
									children: [ru.models > 1 ? `${ru.models} models` : null, enh?.name].filter(Boolean).join(" · ")
								}) : null,
								loadout ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-xs leading-4 text-muted-foreground",
									children: loadout
								}) : null,
								ru.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-xs leading-4 text-muted-foreground",
									children: ru.notes
								}) : null
							]
						})]
					}, ru.id);
				})
			})] }),
			issues.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-1 text-sm",
				children: issues.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: i.level === "error" ? "text-blood" : "text-muted-foreground",
					children: [i.level === "error" ? "Error · " : "Note · ", i.text]
				}, i.text))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-ok",
				children: [
					"List is legal for ",
					size.label,
					"."
				]
			}),
			errors.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				className: "w-full sm:w-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/battle",
					search: { setup: list.id },
					children: "Start battle with this list"
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: addOpen,
				onOpenChange: (open) => {
					setAddOpen(open);
					if (!open) {
						setQuery("");
						setPending({});
					}
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
					side: "bottom",
					className: "h-[88vh]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "Add unit" }) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 px-5 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: query,
								onChange: (e) => setQuery(e.target.value),
								placeholder: "Search datasheets",
								className: "h-10"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "min-h-0 flex-1 overflow-y-auto px-5 pb-8",
							children: catalogSections.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "py-10 text-center text-sm text-muted-foreground",
								children: "No datasheets match."
							}) : catalogSections.map((section) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
								className: "mb-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "sticky top-0 z-10 -mx-5 mb-2 border-b border-border/70 bg-card px-5 py-2 font-display text-xs font-semibold tracking-[0.16em] text-muted-foreground uppercase",
									children: [section.title, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-2 font-mono text-[11px] font-normal tracking-normal tabular-nums",
										children: section.units.length
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "space-y-2",
									children: section.units.map((u) => {
										const n = pending[u.id] ?? 0;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: cn("flex w-full items-center gap-2 rounded-lg border px-2 py-2", n > 0 ? "border-primary bg-accent" : "border-border bg-background"),
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													className: "min-w-0 flex-1 text-left",
													onClick: () => setPending((p) => ({
														...p,
														[u.id]: (p[u.id] ?? 0) + 1
													})),
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "block truncate font-medium",
														children: u.name
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-xs text-muted-foreground",
														children: u.sizes && u.sizes.length > 1 ? `${u.sizes[0].models}–${u.sizes[u.sizes.length - 1].models} models` : roleLabel(u.role)
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "shrink-0 font-mono text-sm tabular-nums",
													children: u.points
												}),
												n > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex shrink-0 items-center gap-0.5",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
															size: "icon-sm",
															variant: "outline",
															"aria-label": `Remove ${u.name}`,
															onClick: () => setPending((p) => {
																const next = {
																	...p,
																	[u.id]: Math.max(0, (p[u.id] ?? 0) - 1)
																};
																if (next[u.id] === 0) delete next[u.id];
																return next;
															}),
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-4" })
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "w-6 text-center font-mono text-sm tabular-nums",
															children: n
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
															size: "icon-sm",
															variant: "outline",
															"aria-label": `Add another ${u.name}`,
															onClick: () => setPending((p) => ({
																...p,
																[u.id]: (p[u.id] ?? 0) + 1
															})),
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
														})
													]
												}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "flex size-7 items-center justify-center rounded-sm border border-border",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5 opacity-0" })
												})
											]
										}) }, u.id);
									})
								})]
							}, section.title))
						}),
						Object.values(pending).reduce((a, b) => a + b, 0) > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 border-t border-border px-5 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "min-w-0 flex-1 text-sm",
								children: [
									Object.values(pending).reduce((a, b) => a + b, 0),
									" selected",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-muted-foreground",
										children: [
											" · ",
											Object.entries(pending).reduce((sum, [id, n]) => {
												return sum + n * (faction.units.find((x) => x.id === id)?.points ?? 0);
											}, 0),
											" ",
											"pts"
										]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => {
									let added = 0;
									for (const [id, n] of Object.entries(pending)) {
										const u = faction.units.find((x) => x.id === id);
										if (!u) continue;
										for (let i = 0; i < n; i++) {
											addSized(u, list.id, addUnit);
											added += 1;
										}
									}
									toast(`Added ${added} ${added === 1 ? "unit" : "units"}`);
									setPending({});
								},
								children: "Add to list"
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "border-t border-border px-5 py-3 text-sm text-muted-foreground",
							children: "Tap datasheets to select several, then add them together."
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: !!inspectUnit && !!inspectRu,
				onOpenChange: (o) => !o && setInspectId(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
					side: "bottom",
					className: "h-[88vh]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "Datasheet" }) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "min-h-0 flex-1 space-y-4 overflow-y-auto p-4",
							children: inspectUnit && inspectRu ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Datasheet, {
									unit: inspectUnit,
									accent: faction.accent,
									points: unitTotalPoints(list, inspectRu)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-3 rounded-xl border border-border bg-card p-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase",
										children: "Wargear"
									}), wargearGroups(inspectUnit).map((group) => {
										const current = resolvedWargearIds(inspectUnit, inspectRu.wargearIds).find((id) => group.options.some((opt) => opt.id === id));
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: group.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
												value: current ?? group.options[0]?.id,
												onValueChange: (v) => updateUnit(list.id, inspectRu.id, { wargearIds: setWargearGroup(inspectUnit, inspectRu.wargearIds, group.id, v) }),
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: group.options.map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
													value: opt.id,
													children: [opt.name, opt.points ? ` +${opt.points}` : " · 0 pts"]
												}, opt.id)) })]
											})]
										}, group.id);
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5 rounded-xl border border-border bg-card p-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: "unit-notes",
											children: "Notes"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
											id: "unit-notes",
											value: inspectRu.notes ?? "",
											placeholder: "Deployment, target priority, house rules…",
											onChange: (e) => updateUnit(list.id, inspectRu.id, { notes: e.target.value })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-muted-foreground",
											children: "Shown under this unit on the list."
										})
									]
								})
							] }) : null
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2 border-t border-border p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								className: "flex-1",
								onClick: () => {
									saveList(list.id);
									toast.success("List saved", { description: list.name });
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-4" }), " Save"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "flex-1",
								variant: "outline",
								onClick: () => setInspectId(null),
								children: "Return to list"
							})]
						})
					]
				})
			})
		]
	});
}
function ListTitle({ listId, name }) {
	const updateList = useWarStore((s) => s.updateList);
	const [value, setValue] = (0, import_react.useState)(name);
	const focused = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (!focused.current) setValue(name);
	}, [name, listId]);
	const commit = (next) => {
		if (next !== name) updateList(listId, { name: next });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		value,
		onFocus: () => {
			focused.current = true;
		},
		onBlur: () => {
			focused.current = false;
			commit(value);
		},
		onChange: (e) => setValue(e.target.value),
		className: "font-display mt-1 block w-full bg-transparent text-3xl font-semibold tracking-wide outline-none"
	});
}
function addSized(u, listId, addUnit) {
	const size = u.sizes?.[0];
	addUnit(listId, {
		unitId: u.id,
		models: size?.models ?? 1,
		points: size?.points ?? u.points
	});
}
//#endregion
export { ListBuilder as component };
