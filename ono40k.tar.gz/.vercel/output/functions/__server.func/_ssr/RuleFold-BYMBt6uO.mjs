import { i as __toESM } from "../_runtime.mjs";
import { i as cn, u as roleLabel } from "./utils-hP9YwH9-.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { x as ChevronDown } from "../_libs/lucide-react.mjs";
import { t as Badge } from "./badge-DTfl_mpk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/RuleFold-BYMBt6uO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-10 flex-col items-center gap-0.5 rounded-md bg-muted px-2 py-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-[10px] font-medium tracking-[0.16em] text-muted-foreground uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-mono text-sm font-semibold tabular-nums",
			children: value
		})]
	});
}
function WeaponRow({ w }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
		className: "border-t border-border/70",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "py-1.5 pr-2 font-medium",
				children: w.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "py-1.5 pr-2 text-muted-foreground tabular-nums",
				children: w.range === "Melee" ? "Melee" : `${w.range}"`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "py-1.5 pr-2 tabular-nums",
				children: w.attacks
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
				className: "py-1.5 pr-2 tabular-nums",
				children: [w.skill, "+"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "py-1.5 pr-2 tabular-nums",
				children: w.strength
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "py-1.5 pr-2 tabular-nums",
				children: w.ap
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "py-1.5 pr-2 tabular-nums",
				children: w.damage
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "py-1.5 text-[11px] text-muted-foreground",
				children: w.keywords.join(", ") || "—"
			})
		]
	});
}
function Datasheet({ unit, accent, compact, className, points }) {
	const shownPts = points ?? unit.points;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("overflow-hidden rounded-xl border border-border bg-card", className),
		style: accent ? {
			borderLeftColor: accent,
			borderLeftWidth: 3
		} : void 0,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "flex items-start justify-between gap-3 p-4 pb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-lg font-semibold tracking-wide",
					children: unit.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-1.5 flex flex-wrap gap-1.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "outline",
							children: roleLabel(unit.role)
						}),
						unit.invuln ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, { children: [unit.invuln, "+ invuln"] }) : null,
						unit.fnp ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, { children: [unit.fnp, "+ FNP"] }) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							variant: "outline",
							children: [shownPts, " pts"]
						})
					]
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-1.5 px-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "M",
						value: typeof unit.stats.m === "number" ? `${unit.stats.m}"` : unit.stats.m
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "T",
						value: unit.stats.t
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "SV",
						value: `${unit.stats.sv}+`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "W",
						value: unit.stats.w
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "LD",
						value: `${unit.stats.ld}+`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "OC",
						value: unit.stats.oc
					})
				]
			}),
			!compact && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [(unit.ranged.length > 0 || unit.melee.length > 0) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 overflow-x-auto px-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[540px] text-left text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "text-[10px] tracking-[0.12em] text-muted-foreground uppercase",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "pb-1 font-medium",
								children: "Weapon"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "pb-1 font-medium",
								children: "Rng"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "pb-1 font-medium",
								children: "A"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "pb-1 font-medium",
								children: "BS/WS"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "pb-1 font-medium",
								children: "S"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "pb-1 font-medium",
								children: "AP"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "pb-1 font-medium",
								children: "D"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "pb-1 font-medium",
								children: "Keywords"
							})
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [unit.ranged.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeaponRow, { w }, `r-${w.name}`)), unit.melee.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeaponRow, { w }, `m-${w.name}`))] })]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 p-4",
				children: [unit.abilities.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "list-disc space-y-1.5 pl-4 text-sm leading-relaxed",
					children: unit.abilities.map((ab) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-medium text-steel",
						children: [ab.name, ". "]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted-foreground",
						children: ab.text
					})] }, ab.name))
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] text-muted-foreground",
					children: unit.keywords.join(" · ")
				})]
			})] })
		]
	});
}
function RuleFold({ kicker, title, text, badges, defaultOpen = false, className, children }) {
	const [open, setOpen] = (0, import_react.useState)(defaultOpen);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("rounded-xl border border-border bg-card", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			"aria-expanded": open,
			onClick: () => setOpen((v) => !v),
			className: "flex min-h-11 w-full items-center gap-2 px-3 py-2 text-left sm:px-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [kicker ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase",
					children: kicker
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 flex-wrap items-center gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "min-w-0 truncate font-medium",
						children: title
					}), badges]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: cn("size-4 shrink-0 text-muted-foreground transition-transform", open && "rotate-180") })]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3 px-3 pb-3 sm:px-4",
			children: [text ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-relaxed text-muted-foreground",
				children: text
			}) : null, children]
		}) : null]
	});
}
//#endregion
export { RuleFold as n, Datasheet as t };
