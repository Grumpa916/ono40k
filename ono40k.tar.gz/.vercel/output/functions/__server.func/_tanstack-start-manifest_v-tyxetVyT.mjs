//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-tyxetVyT.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/analytics",
			"/battle",
			"/codex",
			"/lab",
			"/lists/$listId",
			"/lists/"
		],
		preloads: [
			"/assets/index-D6-4geaz.js",
			"/assets/utils-DMwKFtLz.js",
			"/assets/react-dom-DwcDmKiv.js",
			"/assets/store-BZ8MRJPA.js",
			"/assets/preload-helper-82RHMy27.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-D6-4geaz.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CBLTkj1G.js",
			"/assets/label-DMlI2Djl.js",
			"/assets/x-C7XWXO71.js",
			"/assets/share-DZU9r9Gb.js",
			"/assets/dist-Cut76ISd.js",
			"/assets/card-DzbWHNpA.js",
			"/assets/input-DFh85Wz8.js"
		]
	},
	"/analytics": {
		filePath: "/workspace/src/routes/analytics.tsx",
		children: void 0,
		preloads: [
			"/assets/analytics-DMVgewWv.js",
			"/assets/dist-Cut76ISd.js",
			"/assets/card-DzbWHNpA.js"
		]
	},
	"/battle": {
		filePath: "/workspace/src/routes/battle.tsx",
		children: void 0,
		preloads: [
			"/assets/battle-BDJbHHw5.js",
			"/assets/label-DMlI2Djl.js",
			"/assets/minus-CksuOUZD.js",
			"/assets/x-C7XWXO71.js",
			"/assets/dist-Cut76ISd.js",
			"/assets/card-DzbWHNpA.js",
			"/assets/RuleFold-c1AMWjg2.js",
			"/assets/input-DFh85Wz8.js",
			"/assets/core-DYb6x6dG.js"
		]
	},
	"/codex": {
		filePath: "/workspace/src/routes/codex.tsx",
		children: void 0,
		preloads: [
			"/assets/codex-CrsrZnTW.js",
			"/assets/search-B0bsfqL8.js",
			"/assets/dist-Cut76ISd.js",
			"/assets/RuleFold-c1AMWjg2.js",
			"/assets/input-DFh85Wz8.js",
			"/assets/core-DYb6x6dG.js"
		]
	},
	"/lab": {
		filePath: "/workspace/src/routes/lab.tsx",
		children: void 0,
		preloads: [
			"/assets/lab-DQRP9zz1.js",
			"/assets/minus-CksuOUZD.js",
			"/assets/x-C7XWXO71.js",
			"/assets/search-B0bsfqL8.js",
			"/assets/dist-Cut76ISd.js",
			"/assets/card-DzbWHNpA.js",
			"/assets/input-DFh85Wz8.js"
		]
	},
	"/lists/$listId": {
		filePath: "/workspace/src/routes/lists.$listId.tsx",
		children: void 0,
		preloads: [
			"/assets/lists._listId-B_daNBt8.js",
			"/assets/label-DMlI2Djl.js",
			"/assets/dist-C-5rETX4.js",
			"/assets/minus-CksuOUZD.js",
			"/assets/x-C7XWXO71.js",
			"/assets/search-B0bsfqL8.js",
			"/assets/share-DZU9r9Gb.js",
			"/assets/dist-Cut76ISd.js",
			"/assets/card-DzbWHNpA.js",
			"/assets/RuleFold-c1AMWjg2.js",
			"/assets/input-DFh85Wz8.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
