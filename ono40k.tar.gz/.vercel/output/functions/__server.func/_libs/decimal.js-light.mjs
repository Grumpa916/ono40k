//#region node_modules/decimal.js-light/decimal.mjs
var MAX_DIGITS = 1e9;
var defaults = {
	precision: 20,
	rounding: 4,
	toExpNeg: -7,
	toExpPos: 21,
	LN10: "2.302585092994045684017991454684364207601101488628772976033327900967572609677352480235997205089598298341967784042286"
};
var Decimal;
var external = true;
var decimalError = "[DecimalError] ";
var invalidArgument = decimalError + "Invalid argument: ";
var exponentOutOfRange = decimalError + "Exponent out of range: ";
var mathfloor = Math.floor;
var mathpow = Math.pow;
var isDecimal = /^(\d+(\.\d*)?|\.\d+)(e[+-]?\d+)?$/i;
var ONE;
var BASE = 1e7;
var LOG_BASE = 7;
var MAX_SAFE_INTEGER = 9007199254740991;
var MAX_E = mathfloor(MAX_SAFE_INTEGER / LOG_BASE);
var P = {};
P.absoluteValue = P.abs = function() {
	var x = new this.constructor(this);
	if (x.s) x.s = 1;
	return x;
};
P.comparedTo = P.cmp = function(y) {
	var i, j, xdL, ydL, x = this;
	y = new x.constructor(y);
	if (x.s !== y.s) return x.s || -y.s;
	if (x.e !== y.e) return x.e > y.e ^ x.s < 0 ? 1 : -1;
	xdL = x.d.length;
	ydL = y.d.length;
	for (i = 0, j = xdL < ydL ? xdL : ydL; i < j; ++i) if (x.d[i] !== y.d[i]) return x.d[i] > y.d[i] ^ x.s < 0 ? 1 : -1;
	return xdL === ydL ? 0 : xdL > ydL ^ x.s < 0 ? 1 : -1;
};
P.decimalPlaces = P.dp = function() {
	var x = this, w = x.d.length - 1, dp = (w - x.e) * LOG_BASE;
	w = x.d[w];
	if (w) for (; w % 10 == 0; w /= 10) dp--;
	return dp < 0 ? 0 : dp;
};
P.dividedBy = P.div = function(y) {
	return divide(this, new this.constructor(y));
};
P.dividedToIntegerBy = P.idiv = function(y) {
	var x = this, Ctor = x.constructor;
	return round(divide(x, new Ctor(y), 0, 1), Ctor.precision);
};
P.equals = P.eq = function(y) {
	return !this.cmp(y);
};
P.exponent = function() {
	return getBase10Exponent(this);
};
P.greaterThan = P.gt = function(y) {
	return this.cmp(y) > 0;
};
P.greaterThanOrEqualTo = P.gte = function(y) {
	return this.cmp(y) >= 0;
};
P.isInteger = P.isint = function() {
	return this.e > this.d.length - 2;
};
P.isNegative = P.isneg = function() {
	return this.s < 0;
};
P.isPositive = P.ispos = function() {
	return this.s > 0;
};
P.isZero = function() {
	return this.s === 0;
};
P.lessThan = P.lt = function(y) {
	return this.cmp(y) < 0;
};
P.lessThanOrEqualTo = P.lte = function(y) {
	return this.cmp(y) < 1;
};
P.logarithm = P.log = function(base) {
	var r, x = this, Ctor = x.constructor, pr = Ctor.precision, wpr = pr + 5;
	if (base === void 0) base = new Ctor(10);
	else {
		base = new Ctor(base);
		if (base.s < 1 || base.eq(ONE)) throw Error(decimalError + "NaN");
	}
	if (x.s < 1) throw Error(decimalError + (x.s ? "NaN" : "-Infinity"));
	if (x.eq(ONE)) return new Ctor(0);
	external = false;
	r = divide(ln(x, wpr), ln(base, wpr), wpr);
	external = true;
	return round(r, pr);
};
P.minus = P.sub = function(y) {
	var x = this;
	y = new x.constructor(y);
	return x.s == y.s ? subtract(x, y) : add(x, (y.s = -y.s, y));
};
P.modulo = P.mod = function(y) {
	var q, x = this, Ctor = x.constructor, pr = Ctor.precision;
	y = new Ctor(y);
	if (!y.s) throw Error(decimalError + "NaN");
	if (!x.s) return round(new Ctor(x), pr);
	external = false;
	q = divide(x, y, 0, 1).times(y);
	external = true;
	return x.minus(q);
};
P.naturalExponential = P.exp = function() {
	return exp(this);
};
P.naturalLogarithm = P.ln = function() {
	return ln(this);
};
P.negated = P.neg = function() {
	var x = new this.constructor(this);
	x.s = -x.s || 0;
	return x;
};
P.plus = P.add = function(y) {
	var x = this;
	y = new x.constructor(y);
	return x.s == y.s ? add(x, y) : subtract(x, (y.s = -y.s, y));
};
P.precision = P.sd = function(z) {
	var e, sd, w, x = this;
	if (z !== void 0 && z !== !!z && z !== 1 && z !== 0) throw Error(invalidArgument + z);
	e = getBase10Exponent(x) + 1;
	w = x.d.length - 1;
	sd = w * LOG_BASE + 1;
	w = x.d[w];
	if (w) {
		for (; w % 10 == 0; w /= 10) sd--;
		for (w = x.d[0]; w >= 10; w /= 10) sd++;
	}
	return z && e > sd ? e : sd;
};
P.squareRoot = P.sqrt = function() {
	var e, n, pr, r, s, t, wpr, x = this, Ctor = x.constructor;
	if (x.s < 1) {
		if (!x.s) return new Ctor(0);
		throw Error(decimalError + "NaN");
	}
	e = getBase10Exponent(x);
	external = false;
	s = Math.sqrt(+x);
	if (s == 0 || s == 1 / 0) {
		n = digitsToString(x.d);
		if ((n.length + e) % 2 == 0) n += "0";
		s = Math.sqrt(n);
		e = mathfloor((e + 1) / 2) - (e < 0 || e % 2);
		if (s == 1 / 0) n = "5e" + e;
		else {
			n = s.toExponential();
			n = n.slice(0, n.indexOf("e") + 1) + e;
		}
		r = new Ctor(n);
	} else r = new Ctor(s.toString());
	pr = Ctor.precision;
	s = wpr = pr + 3;
	for (;;) {
		t = r;
		r = t.plus(divide(x, t, wpr + 2)).times(.5);
		if (digitsToString(t.d).slice(0, wpr) === (n = digitsToString(r.d)).slice(0, wpr)) {
			n = n.slice(wpr - 3, wpr + 1);
			if (s == wpr && n == "4999") {
				round(t, pr + 1, 0);
				if (t.times(t).eq(x)) {
					r = t;
					break;
				}
			} else if (n != "9999") break;
			wpr += 4;
		}
	}
	external = true;
	return round(r, pr);
};
P.times = P.mul = function(y) {
	var carry, e, i, k, r, rL, t, xdL, ydL, x = this, Ctor = x.constructor, xd = x.d, yd = (y = new Ctor(y)).d;
	if (!x.s || !y.s) return new Ctor(0);
	y.s *= x.s;
	e = x.e + y.e;
	xdL = xd.length;
	ydL = yd.length;
	if (xdL < ydL) {
		r = xd;
		xd = yd;
		yd = r;
		rL = xdL;
		xdL = ydL;
		ydL = rL;
	}
	r = [];
	rL = xdL + ydL;
	for (i = rL; i--;) r.push(0);
	for (i = ydL; --i >= 0;) {
		carry = 0;
		for (k = xdL + i; k > i;) {
			t = r[k] + yd[i] * xd[k - i - 1] + carry;
			r[k--] = t % BASE | 0;
			carry = t / BASE | 0;
		}
		r[k] = (r[k] + carry) % BASE | 0;
	}
	for (; !r[--rL];) r.pop();
	if (carry) ++e;
	else r.shift();
	y.d = r;
	y.e = e;
	return external ? round(y, Ctor.precision) : y;
};
P.toDecimalPlaces = P.todp = function(dp, rm) {
	var x = this, Ctor = x.constructor;
	x = new Ctor(x);
	if (dp === void 0) return x;
	checkInt32(dp, 0, MAX_DIGITS);
	if (rm === void 0) rm = Ctor.rounding;
	else checkInt32(rm, 0, 8);
	return round(x, dp + getBase10Exponent(x) + 1, rm);
};
P.toExponential = function(dp, rm) {
	var str, x = this, Ctor = x.constructor;
	if (dp === void 0) str = toString(x, true);
	else {
		checkInt32(dp, 0, MAX_DIGITS);
		if (rm === void 0) rm = Ctor.rounding;
		else checkInt32(rm, 0, 8);
		x = round(new Ctor(x), dp + 1, rm);
		str = toString(x, true, dp + 1);
	}
	return str;
};
P.toFixed = function(dp, rm) {
	var str, y, x = this, Ctor = x.constructor;
	if (dp === void 0) return toString(x);
	checkInt32(dp, 0, MAX_DIGITS);
	if (rm === void 0) rm = Ctor.rounding;
	else checkInt32(rm, 0, 8);
	y = round(new Ctor(x), dp + getBase10Exponent(x) + 1, rm);
	str = toString(y.abs(), false, dp + getBase10Exponent(y) + 1);
	return x.isneg() && !x.isZero() ? "-" + str : str;
};
P.toInteger = P.toint = function() {
	var x = this, Ctor = x.constructor;
	return round(new Ctor(x), getBase10Exponent(x) + 1, Ctor.rounding);
};
P.toNumber = function() {
	return +this;
};
P.toPower = P.pow = function(y) {
	var e, k, pr, r, sign, yIsInt, x = this, Ctor = x.constructor, guard = 12, yn = +(y = new Ctor(y));
	if (!y.s) return new Ctor(ONE);
	x = new Ctor(x);
	if (!x.s) {
		if (y.s < 1) throw Error(decimalError + "Infinity");
		return x;
	}
	if (x.eq(ONE)) return x;
	pr = Ctor.precision;
	if (y.eq(ONE)) return round(x, pr);
	e = y.e;
	k = y.d.length - 1;
	yIsInt = e >= k;
	sign = x.s;
	if (!yIsInt) {
		if (sign < 0) throw Error(decimalError + "NaN");
	} else if ((k = yn < 0 ? -yn : yn) <= MAX_SAFE_INTEGER) {
		r = new Ctor(ONE);
		e = Math.ceil(pr / LOG_BASE + 4);
		external = false;
		for (;;) {
			if (k % 2) {
				r = r.times(x);
				truncate(r.d, e);
			}
			k = mathfloor(k / 2);
			if (k === 0) break;
			x = x.times(x);
			truncate(x.d, e);
		}
		external = true;
		return y.s < 0 ? new Ctor(ONE).div(r) : round(r, pr);
	}
	sign = sign < 0 && y.d[Math.max(e, k)] & 1 ? -1 : 1;
	x.s = 1;
	external = false;
	r = y.times(ln(x, pr + guard));
	external = true;
	r = exp(r);
	r.s = sign;
	return r;
};
P.toPrecision = function(sd, rm) {
	var e, str, x = this, Ctor = x.constructor;
	if (sd === void 0) {
		e = getBase10Exponent(x);
		str = toString(x, e <= Ctor.toExpNeg || e >= Ctor.toExpPos);
	} else {
		checkInt32(sd, 1, MAX_DIGITS);
		if (rm === void 0) rm = Ctor.rounding;
		else checkInt32(rm, 0, 8);
		x = round(new Ctor(x), sd, rm);
		e = getBase10Exponent(x);
		str = toString(x, sd <= e || e <= Ctor.toExpNeg, sd);
	}
	return str;
};
P.toSignificantDigits = P.tosd = function(sd, rm) {
	var x = this, Ctor = x.constructor;
	if (sd === void 0) {
		sd = Ctor.precision;
		rm = Ctor.rounding;
	} else {
		checkInt32(sd, 1, MAX_DIGITS);
		if (rm === void 0) rm = Ctor.rounding;
		else checkInt32(rm, 0, 8);
	}
	return round(new Ctor(x), sd, rm);
};
P.toString = P.valueOf = P.val = P.toJSON = P[Symbol.for("nodejs.util.inspect.custom")] = function() {
	var x = this, e = getBase10Exponent(x), Ctor = x.constructor;
	return toString(x, e <= Ctor.toExpNeg || e >= Ctor.toExpPos);
};
function add(x, y) {
	var carry, d, e, i, k, len, xd, yd, Ctor = x.constructor, pr = Ctor.precision;
	if (!x.s || !y.s) {
		if (!y.s) y = new Ctor(x);
		return external ? round(y, pr) : y;
	}
	xd = x.d;
	yd = y.d;
	k = x.e;
	e = y.e;
	xd = xd.slice();
	i = k - e;
	if (i) {
		if (i < 0) {
			d = xd;
			i = -i;
			len = yd.length;
		} else {
			d = yd;
			e = k;
			len = xd.length;
		}
		k = Math.ceil(pr / LOG_BASE);
		len = k > len ? k + 1 : len + 1;
		if (i > len) {
			i = len;
			d.length = 1;
		}
		d.reverse();
		for (; i--;) d.push(0);
		d.reverse();
	}
	len = xd.length;
	i = yd.length;
	if (len - i < 0) {
		i = len;
		d = yd;
		yd = xd;
		xd = d;
	}
	for (carry = 0; i;) {
		carry = (xd[--i] = xd[i] + yd[i] + carry) / BASE | 0;
		xd[i] %= BASE;
	}
	if (carry) {
		xd.unshift(carry);
		++e;
	}
	for (len = xd.length; xd[--len] == 0;) xd.pop();
	y.d = xd;
	y.e = e;
	return external ? round(y, pr) : y;
}
function checkInt32(i, min, max) {
	if (i !== ~~i || i < min || i > max) throw Error(invalidArgument + i);
}
function digitsToString(d) {
	var i, k, ws, indexOfLastWord = d.length - 1, str = "", w = d[0];
	if (indexOfLastWord > 0) {
		str += w;
		for (i = 1; i < indexOfLastWord; i++) {
			ws = d[i] + "";
			k = LOG_BASE - ws.length;
			if (k) str += getZeroString(k);
			str += ws;
		}
		w = d[i];
		ws = w + "";
		k = LOG_BASE - ws.length;
		if (k) str += getZeroString(k);
	} else if (w === 0) return "0";
	for (; w % 10 === 0;) w /= 10;
	return str + w;
}
var divide = (function() {
	function multiplyInteger(x, k) {
		var temp, carry = 0, i = x.length;
		for (x = x.slice(); i--;) {
			temp = x[i] * k + carry;
			x[i] = temp % BASE | 0;
			carry = temp / BASE | 0;
		}
		if (carry) x.unshift(carry);
		return x;
	}
	function compare(a, b, aL, bL) {
		var i, r;
		if (aL != bL) r = aL > bL ? 1 : -1;
		else for (i = r = 0; i < aL; i++) if (a[i] != b[i]) {
			r = a[i] > b[i] ? 1 : -1;
			break;
		}
		return r;
	}
	function subtract(a, b, aL) {
		var i = 0;
		for (; aL--;) {
			a[aL] -= i;
			i = a[aL] < b[aL] ? 1 : 0;
			a[aL] = i * BASE + a[aL] - b[aL];
		}
		for (; !a[0] && a.length > 1;) a.shift();
	}
	return function(x, y, pr, dp) {
		var cmp, e, i, k, prod, prodL, q, qd, rem, remL, rem0, sd, t, xi, xL, yd0, yL, yz, Ctor = x.constructor, sign = x.s == y.s ? 1 : -1, xd = x.d, yd = y.d;
		if (!x.s) return new Ctor(x);
		if (!y.s) throw Error(decimalError + "Division by zero");
		e = x.e - y.e;
		yL = yd.length;
		xL = xd.length;
		q = new Ctor(sign);
		qd = q.d = [];
		for (i = 0; yd[i] == (xd[i] || 0);) ++i;
		if (yd[i] > (xd[i] || 0)) --e;
		if (pr == null) sd = pr = Ctor.precision;
		else if (dp) sd = pr + (getBase10Exponent(x) - getBase10Exponent(y)) + 1;
		else sd = pr;
		if (sd < 0) return new Ctor(0);
		sd = sd / LOG_BASE + 2 | 0;
		i = 0;
		if (yL == 1) {
			k = 0;
			yd = yd[0];
			sd++;
			for (; (i < xL || k) && sd--; i++) {
				t = k * BASE + (xd[i] || 0);
				qd[i] = t / yd | 0;
				k = t % yd | 0;
			}
		} else {
			k = BASE / (yd[0] + 1) | 0;
			if (k > 1) {
				yd = multiplyInteger(yd, k);
				xd = multiplyInteger(xd, k);
				yL = yd.length;
				xL = xd.length;
			}
			xi = yL;
			rem = xd.slice(0, yL);
			remL = rem.length;
			for (; remL < yL;) rem[remL++] = 0;
			yz = yd.slice();
			yz.unshift(0);
			yd0 = yd[0];
			if (yd[1] >= BASE / 2) ++yd0;
			do {
				k = 0;
				cmp = compare(yd, rem, yL, remL);
				if (cmp < 0) {
					rem0 = rem[0];
					if (yL != remL) rem0 = rem0 * BASE + (rem[1] || 0);
					k = rem0 / yd0 | 0;
					if (k > 1) {
						if (k >= BASE) k = BASE - 1;
						prod = multiplyInteger(yd, k);
						prodL = prod.length;
						remL = rem.length;
						cmp = compare(prod, rem, prodL, remL);
						if (cmp == 1) {
							k--;
							subtract(prod, yL < prodL ? yz : yd, prodL);
						}
					} else {
						if (k == 0) cmp = k = 1;
						prod = yd.slice();
					}
					prodL = prod.length;
					if (prodL < remL) prod.unshift(0);
					subtract(rem, prod, remL);
					if (cmp == -1) {
						remL = rem.length;
						cmp = compare(yd, rem, yL, remL);
						if (cmp < 1) {
							k++;
							subtract(rem, yL < remL ? yz : yd, remL);
						}
					}
					remL = rem.length;
				} else if (cmp === 0) {
					k++;
					rem = [0];
				}
				qd[i++] = k;
				if (cmp && rem[0]) rem[remL++] = xd[xi] || 0;
				else {
					rem = [xd[xi]];
					remL = 1;
				}
			} while ((xi++ < xL || rem[0] !== void 0) && sd--);
		}
		if (!qd[0]) qd.shift();
		q.e = e;
		return round(q, dp ? pr + getBase10Exponent(q) + 1 : pr);
	};
})();
function exp(x, sd) {
	var denominator, guard, pow, sum, t, wpr, i = 0, k = 0, Ctor = x.constructor, pr = Ctor.precision;
	if (getBase10Exponent(x) > 16) throw Error(exponentOutOfRange + getBase10Exponent(x));
	if (!x.s) return new Ctor(ONE);
	if (sd == null) {
		external = false;
		wpr = pr;
	} else wpr = sd;
	t = new Ctor(.03125);
	while (x.abs().gte(.1)) {
		x = x.times(t);
		k += 5;
	}
	guard = Math.log(mathpow(2, k)) / Math.LN10 * 2 + 5 | 0;
	wpr += guard;
	denominator = pow = sum = new Ctor(ONE);
	Ctor.precision = wpr;
	for (;;) {
		pow = round(pow.times(x), wpr);
		denominator = denominator.times(++i);
		t = sum.plus(divide(pow, denominator, wpr));
		if (digitsToString(t.d).slice(0, wpr) === digitsToString(sum.d).slice(0, wpr)) {
			while (k--) sum = round(sum.times(sum), wpr);
			Ctor.precision = pr;
			return sd == null ? (external = true, round(sum, pr)) : sum;
		}
		sum = t;
	}
}
function getBase10Exponent(x) {
	var e = x.e * LOG_BASE, w = x.d[0];
	for (; w >= 10; w /= 10) e++;
	return e;
}
function getLn10(Ctor, sd, pr) {
	if (sd > Ctor.LN10.sd()) {
		external = true;
		if (pr) Ctor.precision = pr;
		throw Error(decimalError + "LN10 precision limit exceeded");
	}
	return round(new Ctor(Ctor.LN10), sd);
}
function getZeroString(k) {
	var zs = "";
	for (; k--;) zs += "0";
	return zs;
}
function ln(y, sd) {
	var c, c0, denominator, e, numerator, sum, t, wpr, x2, n = 1, guard = 10, x = y, xd = x.d, Ctor = x.constructor, pr = Ctor.precision;
	if (x.s < 1) throw Error(decimalError + (x.s ? "NaN" : "-Infinity"));
	if (x.eq(ONE)) return new Ctor(0);
	if (sd == null) {
		external = false;
		wpr = pr;
	} else wpr = sd;
	if (x.eq(10)) {
		if (sd == null) external = true;
		return getLn10(Ctor, wpr);
	}
	wpr += guard;
	Ctor.precision = wpr;
	c = digitsToString(xd);
	c0 = c.charAt(0);
	e = getBase10Exponent(x);
	if (Math.abs(e) < 0x5543df729c000) {
		while (c0 < 7 && c0 != 1 || c0 == 1 && c.charAt(1) > 3) {
			x = x.times(y);
			c = digitsToString(x.d);
			c0 = c.charAt(0);
			n++;
		}
		e = getBase10Exponent(x);
		if (c0 > 1) {
			x = new Ctor("0." + c);
			e++;
		} else x = new Ctor(c0 + "." + c.slice(1));
	} else {
		t = getLn10(Ctor, wpr + 2, pr).times(e + "");
		x = ln(new Ctor(c0 + "." + c.slice(1)), wpr - guard).plus(t);
		Ctor.precision = pr;
		return sd == null ? (external = true, round(x, pr)) : x;
	}
	sum = numerator = x = divide(x.minus(ONE), x.plus(ONE), wpr);
	x2 = round(x.times(x), wpr);
	denominator = 3;
	for (;;) {
		numerator = round(numerator.times(x2), wpr);
		t = sum.plus(divide(numerator, new Ctor(denominator), wpr));
		if (digitsToString(t.d).slice(0, wpr) === digitsToString(sum.d).slice(0, wpr)) {
			sum = sum.times(2);
			if (e !== 0) sum = sum.plus(getLn10(Ctor, wpr + 2, pr).times(e + ""));
			sum = divide(sum, new Ctor(n), wpr);
			Ctor.precision = pr;
			return sd == null ? (external = true, round(sum, pr)) : sum;
		}
		sum = t;
		denominator += 2;
	}
}
function parseDecimal(x, str) {
	var e, i, len;
	if ((e = str.indexOf(".")) > -1) str = str.replace(".", "");
	if ((i = str.search(/e/i)) > 0) {
		if (e < 0) e = i;
		e += +str.slice(i + 1);
		str = str.substring(0, i);
	} else if (e < 0) e = str.length;
	for (i = 0; str.charCodeAt(i) === 48;) ++i;
	for (len = str.length; str.charCodeAt(len - 1) === 48;) --len;
	str = str.slice(i, len);
	if (str) {
		len -= i;
		e = e - i - 1;
		x.e = mathfloor(e / LOG_BASE);
		x.d = [];
		i = (e + 1) % LOG_BASE;
		if (e < 0) i += LOG_BASE;
		if (i < len) {
			if (i) x.d.push(+str.slice(0, i));
			for (len -= LOG_BASE; i < len;) x.d.push(+str.slice(i, i += LOG_BASE));
			str = str.slice(i);
			i = LOG_BASE - str.length;
		} else i -= len;
		for (; i--;) str += "0";
		x.d.push(+str);
		if (external && (x.e > MAX_E || x.e < -MAX_E)) throw Error(exponentOutOfRange + e);
	} else {
		x.s = 0;
		x.e = 0;
		x.d = [0];
	}
	return x;
}
function round(x, sd, rm) {
	var i, j, k, n, rd, doRound, w, xdi, xd = x.d;
	for (n = 1, k = xd[0]; k >= 10; k /= 10) n++;
	i = sd - n;
	if (i < 0) {
		i += LOG_BASE;
		j = sd;
		w = xd[xdi = 0];
	} else {
		xdi = Math.ceil((i + 1) / LOG_BASE);
		k = xd.length;
		if (xdi >= k) return x;
		w = k = xd[xdi];
		for (n = 1; k >= 10; k /= 10) n++;
		i %= LOG_BASE;
		j = i - LOG_BASE + n;
	}
	if (rm !== void 0) {
		k = mathpow(10, n - j - 1);
		rd = w / k % 10 | 0;
		doRound = sd < 0 || xd[xdi + 1] !== void 0 || w % k;
		doRound = rm < 4 ? (rd || doRound) && (rm == 0 || rm == (x.s < 0 ? 3 : 2)) : rd > 5 || rd == 5 && (rm == 4 || doRound || rm == 6 && (i > 0 ? j > 0 ? w / mathpow(10, n - j) : 0 : xd[xdi - 1]) % 10 & 1 || rm == (x.s < 0 ? 8 : 7));
	}
	if (sd < 1 || !xd[0]) {
		if (doRound) {
			k = getBase10Exponent(x);
			xd.length = 1;
			sd = sd - k - 1;
			xd[0] = mathpow(10, (LOG_BASE - sd % LOG_BASE) % LOG_BASE);
			x.e = mathfloor(-sd / LOG_BASE) || 0;
		} else {
			xd.length = 1;
			xd[0] = x.e = x.s = 0;
		}
		return x;
	}
	if (i == 0) {
		xd.length = xdi;
		k = 1;
		xdi--;
	} else {
		xd.length = xdi + 1;
		k = mathpow(10, LOG_BASE - i);
		xd[xdi] = j > 0 ? (w / mathpow(10, n - j) % mathpow(10, j) | 0) * k : 0;
	}
	if (doRound) for (;;) if (xdi == 0) {
		if ((xd[0] += k) == BASE) {
			xd[0] = 1;
			++x.e;
		}
		break;
	} else {
		xd[xdi] += k;
		if (xd[xdi] != BASE) break;
		xd[xdi--] = 0;
		k = 1;
	}
	for (i = xd.length; xd[--i] === 0;) xd.pop();
	if (external && (x.e > MAX_E || x.e < -MAX_E)) throw Error(exponentOutOfRange + getBase10Exponent(x));
	return x;
}
function subtract(x, y) {
	var d, e, i, j, k, len, xd, xe, xLTy, yd, Ctor = x.constructor, pr = Ctor.precision;
	if (!x.s || !y.s) {
		if (y.s) y.s = -y.s;
		else y = new Ctor(x);
		return external ? round(y, pr) : y;
	}
	xd = x.d;
	yd = y.d;
	e = y.e;
	xe = x.e;
	xd = xd.slice();
	k = xe - e;
	if (k) {
		xLTy = k < 0;
		if (xLTy) {
			d = xd;
			k = -k;
			len = yd.length;
		} else {
			d = yd;
			e = xe;
			len = xd.length;
		}
		i = Math.max(Math.ceil(pr / LOG_BASE), len) + 2;
		if (k > i) {
			k = i;
			d.length = 1;
		}
		d.reverse();
		for (i = k; i--;) d.push(0);
		d.reverse();
	} else {
		i = xd.length;
		len = yd.length;
		xLTy = i < len;
		if (xLTy) len = i;
		for (i = 0; i < len; i++) if (xd[i] != yd[i]) {
			xLTy = xd[i] < yd[i];
			break;
		}
		k = 0;
	}
	if (xLTy) {
		d = xd;
		xd = yd;
		yd = d;
		y.s = -y.s;
	}
	len = xd.length;
	for (i = yd.length - len; i > 0; --i) xd[len++] = 0;
	for (i = yd.length; i > k;) {
		if (xd[--i] < yd[i]) {
			for (j = i; j && xd[--j] === 0;) xd[j] = BASE - 1;
			--xd[j];
			xd[i] += BASE;
		}
		xd[i] -= yd[i];
	}
	for (; xd[--len] === 0;) xd.pop();
	for (; xd[0] === 0; xd.shift()) --e;
	if (!xd[0]) return new Ctor(0);
	y.d = xd;
	y.e = e;
	return external ? round(y, pr) : y;
}
function toString(x, isExp, sd) {
	var k, e = getBase10Exponent(x), str = digitsToString(x.d), len = str.length;
	if (isExp) {
		if (sd && (k = sd - len) > 0) str = str.charAt(0) + "." + str.slice(1) + getZeroString(k);
		else if (len > 1) str = str.charAt(0) + "." + str.slice(1);
		str = str + (e < 0 ? "e" : "e+") + e;
	} else if (e < 0) {
		str = "0." + getZeroString(-e - 1) + str;
		if (sd && (k = sd - len) > 0) str += getZeroString(k);
	} else if (e >= len) {
		str += getZeroString(e + 1 - len);
		if (sd && (k = sd - e - 1) > 0) str = str + "." + getZeroString(k);
	} else {
		if ((k = e + 1) < len) str = str.slice(0, k) + "." + str.slice(k);
		if (sd && (k = sd - len) > 0) {
			if (e + 1 === len) str += ".";
			str += getZeroString(k);
		}
	}
	return x.s < 0 ? "-" + str : str;
}
function truncate(arr, len) {
	if (arr.length > len) {
		arr.length = len;
		return true;
	}
}
function clone(obj) {
	var i, p, ps;
	function Decimal(value) {
		var x = this;
		if (!(x instanceof Decimal)) return new Decimal(value);
		x.constructor = Decimal;
		if (value instanceof Decimal) {
			x.s = value.s;
			x.e = value.e;
			x.d = (value = value.d) ? value.slice() : value;
			return;
		}
		if (typeof value === "number") {
			if (value * 0 !== 0) throw Error(invalidArgument + value);
			if (value > 0) x.s = 1;
			else if (value < 0) {
				value = -value;
				x.s = -1;
			} else {
				x.s = 0;
				x.e = 0;
				x.d = [0];
				return;
			}
			if (value === ~~value && value < 1e7) {
				x.e = 0;
				x.d = [value];
				return;
			}
			return parseDecimal(x, value.toString());
		} else if (typeof value !== "string") throw Error(invalidArgument + value);
		if (value.charCodeAt(0) === 45) {
			value = value.slice(1);
			x.s = -1;
		} else x.s = 1;
		if (isDecimal.test(value)) parseDecimal(x, value);
		else throw Error(invalidArgument + value);
	}
	Decimal.prototype = P;
	Decimal.ROUND_UP = 0;
	Decimal.ROUND_DOWN = 1;
	Decimal.ROUND_CEIL = 2;
	Decimal.ROUND_FLOOR = 3;
	Decimal.ROUND_HALF_UP = 4;
	Decimal.ROUND_HALF_DOWN = 5;
	Decimal.ROUND_HALF_EVEN = 6;
	Decimal.ROUND_HALF_CEIL = 7;
	Decimal.ROUND_HALF_FLOOR = 8;
	Decimal.clone = clone;
	Decimal.config = Decimal.set = config;
	if (obj === void 0) obj = {};
	if (obj) {
		ps = [
			"precision",
			"rounding",
			"toExpNeg",
			"toExpPos",
			"LN10"
		];
		for (i = 0; i < ps.length;) if (!obj.hasOwnProperty(p = ps[i++])) obj[p] = this[p];
	}
	Decimal.config(obj);
	return Decimal;
}
function config(obj) {
	if (!obj || typeof obj !== "object") throw Error(decimalError + "Object expected");
	var i, p, v, ps = [
		"precision",
		1,
		MAX_DIGITS,
		"rounding",
		0,
		8,
		"toExpNeg",
		-1 / 0,
		0,
		"toExpPos",
		0,
		1 / 0
	];
	for (i = 0; i < ps.length; i += 3) if ((v = obj[p = ps[i]]) !== void 0) {
		if (mathfloor(v) === v && v >= ps[i + 1] && v <= ps[i + 2]) this[p] = v;
		else throw Error(invalidArgument + p + ": " + v);
	}
	if ((v = obj[p = "LN10"]) !== void 0) {
		if (v == Math.LN10) this[p] = new this(v);
		else throw Error(invalidArgument + p + ": " + v);
	}
	return this;
}
var Decimal = clone(defaults);
ONE = new Decimal(1);
var decimal_default = Decimal;
//#endregion
export { decimal_default as t };
