# Ono40k

Unofficial 11th-edition Warhammer 40,000 list builder, battle ledger, and mathhammer lab.

Lists and games stay in this browser (IndexedDB). No account or database is required.

## Run on your computer

Needs Node.js 22 (https://nodejs.org/).

    npm install
    npm run dev

Open the URL it prints (usually http://localhost:8080).

Production build:

    npm run build
    npm run preview

## Host it yourself

The build targets Vercel/Nitro:

    npx vercel

Or connect a GitHub repo to Vercel. Leave auth/database off. Keep VITE_AUTH_ENABLED=false.

## Moving lists from Grok

Use Copy code on a list, then paste it into Ono40k on the new site. Browser storage does not follow a new domain automatically.

Grok preview chrome is not required. PreviewHostBridge is a no-op outside Grok.
