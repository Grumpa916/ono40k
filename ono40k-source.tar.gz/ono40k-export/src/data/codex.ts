import type { Detachment, Faction, UnitDef } from "./types";
import { chaosSpaceMarines } from "./factions/chaos-space-marines";
import { custodes } from "./factions/custodes";
import { spaceMarines } from "./factions/space-marines";
import { tauEmpire } from "./factions/tau";
import { tyranids } from "./factions/tyranids";
import { ultramarines } from "./factions/ultramarines";

export const FACTIONS: Faction[] = [
  spaceMarines,
  ultramarines,
  custodes,
  chaosSpaceMarines,
  tyranids,
  tauEmpire,
];

export const FACTION_BY_ID: Record<string, Faction> = Object.fromEntries(FACTIONS.map((f) => [f.id, f]));

export function getFaction(id: string): Faction | undefined {
  return FACTION_BY_ID[id];
}

export function getUnit(factionId: string, unitId: string): UnitDef | undefined {
  return getFaction(factionId)?.units.find((u) => u.id === unitId);
}

export function getDetachment(factionId: string, detId: string): Detachment | undefined {
  return getFaction(factionId)?.detachments.find((d) => d.id === detId);
}

export function allUnits(): Array<UnitDef & { factionId: string; factionName: string; accent: string }> {
  return FACTIONS.flatMap((f) => f.units.map((u) => ({ ...u, factionId: f.id, factionName: f.name, accent: f.accent })));
}
