import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Check, ChevronLeft, Minus, Pause, Play, Plus, Skull, Undo2, X } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Datasheet } from "@/components/Datasheet";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CORE_STRATAGEMS, PHASE_TIPS, stratagemPrimaryPhase, type StratPhaseKey } from "@/data/core";
import { getDetachment, getFaction, getUnit } from "@/data/codex";
import { checkCount, objectiveVp, parseObjective, sideVp, type MissionInfo } from "@/data/missions";
import { FIXED_SECONDARIES, SECONDARIES, cardAward, scoreOptions, secondaryLines, secondaryVp } from "@/data/secondaries";
import { PHASES, type Game, type LedgerEvent, type LedgerEventKind, type Roster, type RosterUnit, type Stratagem, type UnitBattleState, type UnitDef } from "@/data/types";
import { useActiveGame, useWarStore } from "@/lib/store";
import { cn, battleElapsedMs, formatClock, remainingWounds, turnElapsedMs, unitCopyMarks, unitMaxWounds } from "@/lib/utils";
import { wargearSummary } from "@/data/wargear";
import { primaryForSide, rosterDisposition } from "@/lib/validation";

type Search = { setup?: string };

export const Route = createFileRoute("/battle")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    setup: typeof s.setup === "string" ? s.setup : undefined,
  }),
  component: BattlePage,
});

function BattlePage() {
  const game = useActiveGame();
  const { setup } = Route.useSearch();
  const leaveGame = useWarStore((s) => s.leaveGame);
  const openingNew = Boolean(setup) && (!game || game.status === "complete");
  useEffect(() => {
    if (setup && game?.status === "complete") leaveGame();
  }, [setup, game?.status, leaveGame]);
  if (!game || openingNew) return <BattleSetup presetListId={setup} />;
  return <BattleTable game={game} />;
}

function BattleSetup({ presetListId }: { presetListId?: string }) {
  const lists = useWarStore((s) => s.lists);
  const startGame = useWarStore((s) => s.startGame);
  const navigate = useNavigate();
  const preset = presetListId && lists.some((l) => l.id === presetListId) ? presetListId : lists[0]?.id ?? "";
  const fallbackOpp = lists.find((l) => l.id !== preset)?.id ?? "";
  const [myId, setMyId] = useState(preset);
  const [oppId, setOppId] = useState(fallbackOpp);
  const [myName, setMyName] = useState("You");
  const [oppName, setOppName] = useState("Opponent");
  useEffect(() => {
    if (!preset) return;
    setMyId(preset);
    setOppId(lists.find((l) => l.id !== preset)?.id ?? "");
  }, [preset, lists]);

  if (lists.length < 2) {
    return (
      <Card className="p-8 text-center">
        <h1 className="font-display text-2xl">Need two lists</h1>
        <p className="mt-2 text-sm text-muted-foreground">Create two army lists, then return here to open the table.</p>
        <Button asChild className="mt-5">
          <Link to="/">Go to lists</Link>
        </Button>
      </Card>
    );
  }

  return (
    <div className="mx-auto max-w-lg space-y-6">
      <div>
        <p className="text-[11px] font-medium tracking-[0.22em] text-muted-foreground uppercase">War Journal</p>
        <h1 className="font-display mt-1 text-3xl font-semibold">Open the ledger</h1>
        <p className="mt-1 text-sm text-muted-foreground">Pick both sides. You can switch between the two armies at any time once the game is live.</p>
      </div>
      <div className="space-y-4">
        <div className="space-y-1.5">
          <Label>Your name</Label>
          <Input value={myName} onChange={(e) => setMyName(e.target.value)} />
        </div>
        <div className="space-y-1.5">
          <Label>Your list</Label>
          <Select value={myId} onValueChange={setMyId}>
            <SelectTrigger>
              <SelectValue placeholder="Select" />
            </SelectTrigger>
            <SelectContent>
              {lists.map((l) => (
                <SelectItem key={l.id} value={l.id}>
                  {l.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label>Opponent name</Label>
          <Input value={oppName} onChange={(e) => setOppName(e.target.value)} />
        </div>
        <div className="space-y-1.5">
          <Label>Opponent list</Label>
          <Select value={oppId} onValueChange={setOppId}>
            <SelectTrigger>
              <SelectValue placeholder="Select" />
            </SelectTrigger>
            <SelectContent>
              {lists.map((l) => (
                <SelectItem key={l.id} value={l.id}>
                  {l.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <Button
          className="w-full"
          disabled={!myId || !oppId || myId === oppId}
          onClick={() => {
            const id = startGame({ myRosterId: myId, opponentRosterId: oppId, myName, opponentName: oppName });
            if (id) void navigate({ to: "/battle" });
          }}
        >
          Start battle
        </Button>
      </div>
    </div>
  );
}

function BattleClock({ game, locked, now }: { game: Game; locked: boolean; now: number }) {
  const pauseClock = useWarStore((s) => s.pauseClock);
  const resumeClock = useWarStore((s) => s.resumeClock);
  const endGame = useWarStore((s) => s.endGame);
  const turnsRunning = !!game.runningSince && game.status === "active";
  const battle = formatClock(battleElapsedMs(game, now));
  return (
    <div className="flex flex-wrap items-center justify-end gap-x-2 gap-y-1">
      <span className="font-mono text-sm tabular-nums">{battle}</span>
      {game.status === "active" ? (
        <>
          {turnsRunning ? (
            <Button size="sm" className="h-7 px-2 text-[11px]" variant="outline" disabled={locked} onClick={pauseClock}>
              <Pause className="size-3.5" /> Pause
            </Button>
          ) : (
            <Button size="sm" className="h-7 px-2 text-[11px]" variant="outline" disabled={locked} onClick={resumeClock}>
              <Play className="size-3.5" /> Resume
            </Button>
          )}
          <Button size="sm" className="h-7 px-2 text-[11px]" variant="outline" disabled={locked} onClick={endGame}>
            End battle
          </Button>
        </>
      ) : null}
    </div>
  );
}

function liveRoster(snap: Roster, lists: Roster[]): Roster {
  const live = lists.find((l) => l.id === snap.id);
  const base = live ? { ...snap, detachmentIds: live.detachmentIds, disposition: live.disposition } : snap;
  return { ...base, disposition: rosterDisposition(base) };
}

function BattleTable({ game }: { game: Game }) {
  const setViewing = useWarStore((s) => s.setViewing);
  const setPhase = useWarStore((s) => s.setPhase);
  const endTurn = useWarStore((s) => s.endTurn);
  const prevTurn = useWarStore((s) => s.prevTurn);
  const jumpRound = useWarStore((s) => s.jumpRound);
  const undoLast = useWarStore((s) => s.undoLast);
  const dismissStrat = useWarStore((s) => s.dismissStrat);
  const endGame = useWarStore((s) => s.endGame);
  const leaveGame = useWarStore((s) => s.leaveGame);
  const reopenGame = useWarStore((s) => s.reopenGame);
  const viewing = game.viewing;
  const lists = useWarStore((s) => s.lists);
  const mine = liveRoster(game.myRoster, lists);
  const theirs = liveRoster(game.opponentRoster, lists);
  const roster = viewing === "me" ? mine : theirs;
  const faction = getFaction(roster.factionId);
  const myPrimary = primaryForSide(mine, theirs);
  const oppPrimary = primaryForSide(theirs, mine);
  const viewedPrimary = viewing === "me" ? myPrimary : oppPrimary;
  const myObjectives = myPrimary ? myPrimary.info.scoring.map(parseObjective) : null;
  const oppObjectives = oppPrimary ? oppPrimary.info.scoring.map(parseObjective) : null;
  const myTotal = sideVp(game.scores.me, myObjectives);
  const oppTotal = sideVp(game.scores.opponent, oppObjectives);
  const patchGame = useWarStore((s) => s.patchGame);
  const adjustCp = useWarStore((s) => s.adjustCp);
  const [tab, setTab] = useState("army");
  const [sheetId, setSheetId] = useState<string | null>(null);
  const sheetDef = sheetId ? getUnit(roster.factionId, sheetId) : undefined;
  const locked = game.status === "complete";
  const log = game.log ?? [];
  const undoStack = game.undoStack ?? [];
  const activeStrats = game.activeStrats ?? [];
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    if (locked) return;
    const id = window.setInterval(() => setNow(Date.now()), 250);
    return () => window.clearInterval(id);
  }, [locked]);
  const tick = locked ? Date.now() : now;

  return (
    <div className="space-y-4">
      {locked ? (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-border bg-card px-4 py-3">
          <div>
            <p className="text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase">Closed ledger</p>
            <p className="font-display text-lg">This battle is recorded. Reopen it to keep scoring.</p>
          </div>
          <Button size="sm" onClick={reopenGame}>
            Reopen
          </Button>
        </div>
      ) : null}

          <div className="rounded-xl border border-border bg-card p-4">
            <div className="flex items-center justify-between gap-3">
              <p className="text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase">Score</p>
              <BattleClock game={game} locked={locked} now={tick} />
            </div>
            <div className="mt-3 grid grid-cols-[1fr_auto_1fr] items-start gap-3">
              <div>
                <p className="text-xs text-muted-foreground">{game.myName}</p>
                <p className="font-mono text-4xl font-semibold tabular-nums leading-none">{myTotal}</p>
                <div className="mt-2 flex items-center gap-1">
                  <Button
                    size="icon"
                    variant="outline"
                    className="h-7 w-7"
                    aria-label="Spend CP"
                    disabled={locked}
                    onClick={() => adjustCp("me", -1)}
                  >
                    <Minus className="size-3.5" />
                  </Button>
                  <span className="font-mono min-w-10 text-center text-sm tabular-nums">{game.cp.me} CP</span>
                  <Button
                    size="icon"
                    variant="outline"
                    className="h-7 w-7"
                    aria-label="Gain CP"
                    disabled={locked}
                    onClick={() => adjustCp("me", 1)}
                  >
                    <Plus className="size-3.5" />
                  </Button>
                </div>
                <button
                  type="button"
                  disabled={locked}
                  onClick={() =>
                    patchGame(game.id, {
                      scores: { ...game.scores, me: { ...game.scores.me, painted: game.scores.me.painted > 0 ? 0 : 10 } },
                    })
                  }
                  className={cn(
                    "mt-1.5 text-[11px] tracking-wide uppercase",
                    game.scores.me.painted > 0 ? "text-ok" : "text-muted-foreground",
                  )}
                >
                  {game.scores.me.painted > 0 ? "Painted +10" : "Painted army"}
                </button>
              </div>
              <p className="pt-5 text-xs text-muted-foreground">VP</p>
              <div className="text-right">
                <p className="text-xs text-muted-foreground">{game.opponentName}</p>
                <p className="font-mono text-4xl font-semibold tabular-nums leading-none text-blood">{oppTotal}</p>
                <div className="mt-2 flex items-center justify-end gap-1">
                  <Button
                    size="icon"
                    variant="outline"
                    className="h-7 w-7"
                    aria-label="Spend opponent CP"
                    disabled={locked}
                    onClick={() => adjustCp("opponent", -1)}
                  >
                    <Minus className="size-3.5" />
                  </Button>
                  <span className="font-mono min-w-10 text-center text-sm tabular-nums">{game.cp.opponent} CP</span>
                  <Button
                    size="icon"
                    variant="outline"
                    className="h-7 w-7"
                    aria-label="Gain opponent CP"
                    disabled={locked}
                    onClick={() => adjustCp("opponent", 1)}
                  >
                    <Plus className="size-3.5" />
                  </Button>
                </div>
                <button
                  type="button"
                  disabled={locked}
                  onClick={() =>
                    patchGame(game.id, {
                      scores: { ...game.scores, opponent: { ...game.scores.opponent, painted: game.scores.opponent.painted > 0 ? 0 : 10 } },
                    })
                  }
                  className={cn(
                    "mt-1.5 text-[11px] tracking-wide uppercase",
                    game.scores.opponent.painted > 0 ? "text-ok" : "text-muted-foreground",
                  )}
                >
                  {game.scores.opponent.painted > 0 ? "Painted +10" : "Painted army"}
                </button>
              </div>
            </div>
            <div className="mt-4">
              <p className="text-[11px] tracking-[0.16em] text-muted-foreground uppercase">
                Round {game.round} ·{" "}
                {(game.activeSide === "me" ? game.myName : game.opponentName).trim().toLowerCase() === "you"
                  ? "Your turn"
                  : `${game.activeSide === "me" ? game.myName : game.opponentName}'s turn`}
                {(game.liveRound ?? game.round) !== game.round || (game.liveSide ?? game.activeSide) !== game.activeSide
                  ? " · reviewing"
                  : ""}
              </p>
              <div className="mt-3 flex gap-1 overflow-x-auto">
                {([1, 2, 3, 4, 5] as const).map((r) => {
                  const reached = r <= (game.liveRound ?? game.round);
                  return (
                    <button
                      key={r}
                      type="button"
                      disabled={!reached}
                      onClick={() => jumpRound(r)}
                      className={cn(
                        "h-9 w-9 shrink-0 rounded-full text-xs font-medium tabular-nums",
                        game.round === r ? "bg-primary text-primary-foreground" : reached ? "bg-muted text-muted-foreground" : "bg-muted/40 text-muted-foreground/40",
                      )}
                    >
                      {r}
                    </button>
                  );
                })}
              </div>
              <div className="mt-3 flex gap-1 overflow-x-auto">
                {PHASES.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    disabled={locked}
                    onClick={() => setPhase(p.id)}
                    className={cn(
                      "h-9 shrink-0 rounded-full px-3 text-xs font-medium tracking-wide uppercase",
                      game.phase === p.id ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground",
                    )}
                  >
                    {p.label}
                  </button>
                ))}
              </div>
              <div className="mt-3 grid grid-cols-2 gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  className="w-full"
                  disabled={(game.round === 1 && game.activeSide === "me")}
                  onClick={prevTurn}
                >
                  <ChevronLeft className="size-4" />
                  Previous turn
                </Button>
                <Button
                  size="sm"
                  className="w-full"
                  disabled={locked && game.round === (game.liveRound ?? game.round) && game.activeSide === (game.liveSide ?? game.activeSide)}
                  onClick={endTurn}
                >
                  {game.round === (game.liveRound ?? game.round) && game.activeSide === (game.liveSide ?? game.activeSide)
                    ? game.round >= 5 && game.activeSide === "opponent"
                      ? "End battle"
                      : "End turn"
                    : "Next turn"}
                </Button>
              </div>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setViewing("me")}
                className={cn(
                  "flex h-12 items-center justify-between gap-2 rounded-lg border px-3 text-sm font-medium",
                  game.activeSide === "me"
                    ? "border-primary bg-primary text-primary-foreground"
                    : game.viewing === "me"
                      ? "border-steel bg-accent"
                      : "border-border bg-muted",
                )}
              >
                <span className="truncate">{game.myName}</span>
                <span className="font-mono shrink-0 text-xs tabular-nums">{formatClock(turnElapsedMs(game, "me", tick))}</span>
              </button>
              <button
                type="button"
                onClick={() => setViewing("opponent")}
                className={cn(
                  "flex h-12 items-center justify-between gap-2 rounded-lg border px-3 text-sm font-medium",
                  game.activeSide === "opponent"
                    ? "border-blood bg-blood text-primary-foreground"
                    : game.viewing === "opponent"
                      ? "border-steel bg-accent"
                      : "border-border bg-muted",
                )}
              >
                <span className="truncate">{game.opponentName}</span>
                <span className="font-mono shrink-0 text-xs tabular-nums">{formatClock(turnElapsedMs(game, "opponent", tick))}</span>
              </button>
            </div>
            {game.viewing !== game.activeSide ? (
              <p className="mt-1.5 text-[11px] tracking-[0.12em] text-muted-foreground uppercase">
                Viewing {game.viewing === "me" ? game.myName : game.opponentName} ·{" "}
                {(game.activeSide === "me" ? game.myName : game.opponentName).trim().toLowerCase() === "you"
                  ? "your turn"
                  : `${game.activeSide === "me" ? game.myName : game.opponentName}'s turn`}
              </p>
            ) : null}
          </div>
          <ScorePanel
            game={game}
            mission={viewedPrimary?.info ?? null}
            mineDisp={viewedPrimary?.mine ?? null}
            theirDisp={viewedPrimary?.theirs ?? null}
            locked={locked}
          />

          <p className="rounded-lg border border-border bg-card px-3 py-2 text-xs leading-relaxed text-muted-foreground">
            {PHASE_TIPS[game.phase]}
          </p>

          {activeStrats.length > 0 ? (
            <section className="space-y-2">
              <p className="text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase">Active stratagems</p>
              <ul className="space-y-2">
                {activeStrats.map((s) => (
                  <li key={s.id} className="rounded-xl border border-steel/40 bg-card p-3">
                    <div className="flex items-start gap-2">
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <p className="font-medium">{s.name}</p>
                          <Badge variant="outline">{s.cp} CP</Badge>
                          <Badge>{s.source}</Badge>
                        </div>
                        <p className="mt-1 text-xs text-muted-foreground">
                          {s.side === "me" ? game.myName : game.opponentName} · Round {s.round} · {PHASES.find((p) => p.id === s.phase)?.label}
                        </p>
                        <p className="mt-1 text-sm text-muted-foreground">{s.text}</p>
                      </div>
                      <Button size="icon-sm" variant="ghost" aria-label="Dismiss stratagem" onClick={() => dismissStrat(s.id)}>
                        <X className="size-4" />
                      </Button>
                    </div>
                  </li>
                ))}
              </ul>
            </section>
          ) : null}

          <Tabs value={tab} onValueChange={setTab}>
            <div className="flex flex-wrap items-center gap-2">
              <TabsList className="min-w-0 flex-1">
                <TabsTrigger value="army">Army</TabsTrigger>
                <TabsTrigger value="strats">Strats</TabsTrigger>
              </TabsList>
              <div className="flex shrink-0 gap-1">
                {(["me", "opponent"] as const).map((side) => (
                  <button
                    key={side}
                    type="button"
                    onClick={() => setViewing(side)}
                    className={cn(
                      "h-8 rounded-md border px-2.5 text-xs font-medium",
                      viewing === side
                        ? side === "opponent"
                          ? "border-blood bg-blood text-primary-foreground"
                          : "border-primary bg-primary text-primary-foreground"
                        : "border-border bg-muted text-muted-foreground",
                    )}
                  >
                    {side === "me" ? game.myName : game.opponentName}
                  </button>
                ))}
              </div>
            </div>
            <TabsContent value="army" className="mt-4">
              <p className="mb-2 text-[11px] tracking-[0.16em] text-muted-foreground uppercase">
                {faction?.name} · {roster.disposition ?? "No disposition"}
                {viewing !== game.activeSide ? " · peeking" : ""}
              </p>
              <ArmyPanel game={game} roster={roster} locked={locked} onOpen={setSheetId} />
            </TabsContent>
            <TabsContent value="strats" className="mt-4">
              <StratPanel game={game} roster={roster} locked={locked} />
            </TabsContent>
          </Tabs>

      {sheetDef ? (
        <div className="fixed inset-0 z-40 flex items-end bg-background/70 p-3 sm:items-center sm:justify-center" onClick={() => setSheetId(null)}>
          <div className="max-h-[88vh] w-full max-w-2xl overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <Datasheet unit={sheetDef} accent={faction?.accent} />
            <Button className="mt-3 w-full" variant="secondary" onClick={() => setSheetId(null)}>
              Close
            </Button>
          </div>
        </div>
      ) : null}

      <div className="flex gap-2 pt-2">
        <Button variant="outline" asChild>
          <Link to="/">
            <ChevronLeft className="size-4" /> Lists
          </Link>
        </Button>
        <Button
          variant="outline"
          className="ml-auto"
          onClick={() => {
            if (game.status === "complete") leaveGame();
            else endGame();
          }}
        >
          {game.status === "complete" ? "Leave ledger" : "Close ledger"}
        </Button>
      </div>

      <LedgerTape game={game} log={log} now={tick} undoCount={undoStack.length} onUndo={undoLast} />
    </div>
  );
}

function tapeDot(kind: LedgerEventKind) {
  if (kind === "destroyed") return "bg-blood";
  if (kind === "battleShock") return "bg-steel";
  if (kind === "stratagem") return "bg-primary";
  if (kind === "turn") return "bg-foreground";
  return "bg-muted-foreground";
}

function tapeContext(ev: LedgerEvent, game: Game): string | null {
  if (ev.round == null && !ev.phase && !ev.turn) return null;
  const who = ev.turn ? (ev.turn === "me" ? game.myName : game.opponentName) : null;
  const round = ev.round != null ? `R${ev.round}` : null;
  const phase = ev.phase ? (PHASES.find((p) => p.id === ev.phase)?.label ?? ev.phase) : null;
  return [who, round, phase].filter(Boolean).join(" · ");
}

function tapeClock(ev: LedgerEvent, game: Game): string {
  const ms = ev.clockMs ?? Math.max(0, ev.at - game.startedAt);
  return formatClock(ms);
}

function LedgerTape({
  game,
  log,
  now,
  undoCount,
  onUndo,
}: {
  game: Game;
  log: LedgerEvent[];
  now: number;
  undoCount: number;
  onUndo: () => void;
}) {
  const [full, setFull] = useState(false);
  const shown = full ? log : log.slice(0, 5);
  const turnName = game.activeSide === "me" ? game.myName : game.opponentName;
  const phaseName = PHASES.find((p) => p.id === game.phase)?.label ?? game.phase;
  const turnLine = turnName.trim().toLowerCase() === "you" ? "Your turn" : `${turnName}'s turn`;
  const liveClock = formatClock(battleElapsedMs(game, now));
  return (
    <section className="rounded-xl border border-border bg-card p-3">
      <div className="mb-2 flex items-center justify-between gap-2">
        <p className="text-[11px] font-medium tracking-[0.16em] text-muted-foreground uppercase">Ledger tape</p>
        <div className="flex items-center gap-1.5">
          {log.length > 0 ? (
            <Button size="sm" variant="ghost" onClick={() => setFull((v) => !v)}>
              {full ? "Last 5" : `Full ledger${log.length > 5 ? ` · ${log.length}` : ""}`}
            </Button>
          ) : null}
          <Button size="sm" variant="outline" disabled={undoCount === 0} onClick={onUndo}>
            <Undo2 className="size-4" />
            Undo{undoCount ? ` · ${undoCount}` : ""}
          </Button>
        </div>
      </div>
      <div className="mb-3 rounded-lg border border-border bg-muted/40 px-3 py-2">
        <div className="flex items-baseline justify-between gap-3">
          <p className="text-[11px] tracking-[0.14em] text-muted-foreground uppercase">
            {game.status === "complete" ? "Closed" : "Live"}
          </p>
          <p className="font-mono text-xs tabular-nums text-muted-foreground">{liveClock}</p>
        </div>
        <p className="mt-0.5 text-sm">
          <span className="font-medium">{turnLine}</span>
          <span className="text-muted-foreground">
            {" "}
            · Round {game.round} · {phaseName}
          </span>
        </p>
      </div>
      {log.length === 0 ? (
        <p className="text-sm text-muted-foreground">Phase, turn, Battle-shock, destroyed, and stratagems land here.</p>
      ) : (
        <ol className={cn("space-y-1.5", full && "max-h-80 overflow-y-auto")}>
          {shown.map((ev) => {
            const ctx = tapeContext(ev, game);
            return (
              <li key={ev.id} className="flex items-start gap-2 text-sm">
                <span className={cn("mt-1.5 size-1.5 shrink-0 rounded-full", tapeDot(ev.kind))} />
                <div className="min-w-0 flex-1 leading-snug">
                  <div className="flex items-start justify-between gap-2">
                    <span className="min-w-0">{ev.summary}</span>
                    <span className="shrink-0 font-mono text-[11px] tabular-nums text-muted-foreground">{tapeClock(ev, game)}</span>
                  </div>
                  {ctx ? <p className="text-[11px] tracking-[0.12em] text-muted-foreground uppercase">{ctx}</p> : null}
                </div>
              </li>
            );
          })}
        </ol>
      )}
    </section>
  );
}

function patchWounds(
  ru: RosterUnit,
  def: UnitDef,
  st: UnitBattleState,
  delta: number,
): Partial<UnitBattleState> {
  const max = unitMaxWounds(def.stats.w);
  let models = st.destroyed ? 0 : st.modelsRemaining;
  let remaining = remainingWounds(st, max);
  if (delta > 0) {
    if (models <= 0) {
      models = 1;
      remaining = 1;
    } else if (remaining < max) {
      remaining += 1;
    } else if (models < ru.models) {
      models += 1;
      remaining = max;
    } else {
      remaining = max;
    }
    return { modelsRemaining: models, woundsOnCurrent: remaining, destroyed: false };
  }
  if (models <= 0) return { modelsRemaining: 0, woundsOnCurrent: 0, destroyed: true };
  remaining -= 1;
  if (remaining > 0) return { woundsOnCurrent: remaining, destroyed: false, modelsRemaining: models };
  models -= 1;
  if (models <= 0) return { modelsRemaining: 0, woundsOnCurrent: 0, destroyed: true };
  return { modelsRemaining: models, woundsOnCurrent: max, destroyed: false };
}

function WoundStepper({
  value,
  max,
  locked,
  onDec,
  onInc,
}: {
  value: number;
  max: number;
  locked: boolean;
  onDec: () => void;
  onInc: () => void;
}) {
  const empty = value <= 0;
  const full = value >= max;
  return (
    <div className="ml-auto flex shrink-0 items-center gap-0.5">
      <Button
        size="icon-sm"
        className="size-7"
        variant="outline"
        aria-label="Remove wound"
        disabled={locked || empty}
        onClick={onDec}
      >
        <Minus className="size-3.5" />
      </Button>
      <span
        className={cn(
          "w-14 text-center font-mono text-xs tabular-nums",
          empty ? "text-blood" : value < max ? "text-blood" : "text-foreground",
        )}
      >
        {value}/{max}
      </span>
      <Button
        size="icon-sm"
        className="size-7"
        variant="outline"
        aria-label="Add wound"
        disabled={locked || full}
        onClick={onInc}
      >
        <Plus className="size-3.5" />
      </Button>
    </div>
  );
}

function ArmyPanel({
  game,
  roster,
  locked,
  onOpen,
}: {
  game: Game;
  roster: Roster;
  locked: boolean;
  onOpen: (unitId: string) => void;
}) {
  const setUnitState = useWarStore((s) => s.setUnitState);
  const ordered = useMemo(() => {
    const rank = (id: string) => {
      const st = game.unitState[id];
      if (!st) return 1;
      if (st.destroyed) return 2;
      if (st.battleShocked) return 0;
      return 1;
    };
    return [...roster.units].sort((a, b) => rank(a.id) - rank(b.id));
  }, [roster.units, game.unitState]);
  const copies = useMemo(() => unitCopyMarks(roster.units), [roster.units]);

  return (
    <ul className="space-y-2">
      {ordered.map((ru) => {
        const def = getUnit(roster.factionId, ru.unitId);
        const st = game.unitState[ru.id];
        if (!def || !st) return null;
        const maxW = unitMaxWounds(def.stats.w);
        const wounds = remainingWounds(st, maxW);
        const applyWounds = (delta: number) => setUnitState(ru.id, patchWounds(ru, def, st, delta));
        const ranged = [...new Set(def.ranged.map((w) => w.name))].join(" · ");
        const melee = [...new Set(def.melee.map((w) => w.name))].join(" · ");
        const extras = wargearSummary(def, ru.wargearIds)
          .map((g) => g.name)
          .join(" · ");
        return (
          <li
            key={ru.id}
            className={cn(
              "rounded-lg border border-border bg-card px-2.5 py-1.5",
              st.destroyed && "opacity-50",
              st.battleShocked && !st.destroyed && "border-blood/50 bg-blood/10",
            )}
          >
            <div className="flex min-w-0 items-center gap-1.5">
              <button type="button" className="min-w-0 truncate text-left text-sm font-medium leading-5" onClick={() => onOpen(def.id)}>
                {def.name}
                {copies[ru.id] ? <span className="ml-1.5 text-[10px] tracking-widest text-steel">[{copies[ru.id]}]</span> : null}
                {ru.warlord ? <span className="ml-1.5 text-[10px] tracking-widest uppercase text-steel">WL</span> : null}
              </button>
              <Button
                size="sm"
                className="h-7 shrink-0 px-2 text-[11px]"
                variant={st.battleShocked ? "blood" : "outline"}
                disabled={locked}
                onClick={() => setUnitState(ru.id, { battleShocked: !st.battleShocked })}
              >
                BS
              </Button>
              <Button
                size="sm"
                className="h-7 shrink-0 px-2 text-[11px]"
                variant={st.destroyed ? "secondary" : "outline"}
                disabled={locked}
                aria-label="Destroyed"
                onClick={() =>
                  setUnitState(
                    ru.id,
                    st.destroyed
                      ? { destroyed: false, modelsRemaining: ru.models, woundsOnCurrent: maxW }
                      : { destroyed: true, modelsRemaining: 0, woundsOnCurrent: 0 },
                  )
                }
              >
                <Skull className="size-3.5" />
              </Button>
              {ru.models > 1 ? (
                <div className="ml-auto flex shrink-0 items-center gap-0.5">
                  <Button
                    size="icon-sm"
                    className="size-7"
                    variant="outline"
                    aria-label="Remove model"
                    disabled={locked || st.destroyed || st.modelsRemaining <= 0}
                    onClick={() => {
                      const next = Math.max(0, st.modelsRemaining - 1);
                      setUnitState(ru.id, {
                        modelsRemaining: next,
                        destroyed: next === 0,
                        woundsOnCurrent: next === 0 ? 0 : maxW,
                      });
                    }}
                  >
                    <Minus className="size-3.5" />
                  </Button>
                  <span className="w-8 text-center font-mono text-xs tabular-nums">
                    {st.destroyed ? 0 : st.modelsRemaining}/{ru.models}
                  </span>
                  <Button
                    size="icon-sm"
                    className="size-7"
                    variant="outline"
                    aria-label="Add model"
                    disabled={locked || (!st.destroyed && st.modelsRemaining >= ru.models)}
                    onClick={() =>
                      setUnitState(ru.id, {
                        modelsRemaining: Math.min(ru.models, Math.max(st.modelsRemaining, 0) + 1),
                        destroyed: false,
                        woundsOnCurrent: st.destroyed ? maxW : remainingWounds(st, maxW),
                      })
                    }
                  >
                    <Plus className="size-3.5" />
                  </Button>
                </div>
              ) : null}
            </div>
            <div className="mt-0.5 flex min-w-0 items-center gap-1.5">
              <button type="button" className="min-w-0 flex-1 text-left" onClick={() => onOpen(def.id)}>
                <p className="truncate text-xs leading-4 text-muted-foreground">
                  {`M${typeof def.stats.m === "number" ? `${def.stats.m}"` : def.stats.m} T${def.stats.t} Sv${def.stats.sv}+ W${def.stats.w}${def.invuln ? ` ${def.invuln}++` : ""} OC${def.stats.oc} · ${ru.points} pts`}
                </p>
              </button>
              <WoundStepper
                value={wounds}
                max={maxW}
                locked={locked}
                onDec={() => applyWounds(-1)}
                onInc={() => applyWounds(1)}
              />
            </div>
            {ranged || melee || extras || ru.notes ? (
                <button type="button" className="mt-0.5 w-full min-w-0 text-left" onClick={() => onOpen(def.id)}>
                  {ranged ? (
                    <p className="truncate text-xs leading-4 text-muted-foreground">
                      <span className="text-[10px] tracking-[0.12em] text-muted-foreground/80 uppercase">R </span>
                      {ranged}
                    </p>
                  ) : null}
                  {melee ? (
                    <p className="truncate text-xs leading-4 text-muted-foreground">
                      <span className="text-[10px] tracking-[0.12em] text-muted-foreground/80 uppercase">M </span>
                      {melee}
                    </p>
                  ) : null}
                  {extras ? <p className="truncate text-xs leading-4 text-muted-foreground">{extras}</p> : null}
                  {ru.notes ? <p className="truncate text-xs leading-4 text-muted-foreground">{ru.notes}</p> : null}
                </button>
              ) : null}
          </li>
        );
      })}
    </ul>
  );
}

function ScoreLines({
  lines,
  checks,
  locked,
  focusRound,
  liveRound,
  onToggle,
}: {
  lines: string[];
  checks?: Array<Array<number | boolean>>;
  locked: boolean;
  focusRound?: number;
  liveRound?: number;
  onToggle: (line: number, slot: number, max: number) => void;
}) {
  const viewed = focusRound ?? 1;
  const frontier = liveRound ?? viewed;
  return (
    <ul className="mt-2 space-y-2">
      {lines.map((line, i) => {
        const obj = parseObjective(line);
        const row = checks?.[i] ?? [];
        const max = obj.each ? Math.max(2, Math.min(4, Math.floor(15 / Math.max(1, obj.vp)))) : 1;
        return (
          <li key={`${obj.text}-${i}`} className="min-w-0 sm:flex sm:items-center sm:gap-2">
            <div className="flex min-w-0 flex-1 items-start justify-between gap-2">
              <p className="text-xs leading-snug">{obj.text.replace(/\s*\([^)]*\)\s*$/, "")}</p>
              <span className="shrink-0 font-mono text-[10px] tabular-nums text-muted-foreground">
                +{obj.vp}
                {obj.each ? " ea" : ""}
              </span>
            </div>
            {obj.once ? (
              <button
                type="button"
                disabled={locked}
                aria-pressed={checkCount(row, 0) > 0}
                onClick={() => onToggle(i, 0, 1)}
                className={cn(
                  "mt-1 flex h-8 w-full shrink-0 items-center justify-center gap-1.5 rounded-md border px-2 text-[11px] sm:mt-0 sm:w-44",
                  checkCount(row, 0) > 0 ? "border-ok/50 bg-ok/15 text-foreground" : "border-border bg-muted text-muted-foreground",
                )}
              >
                <span className={cn("flex size-3.5 items-center justify-center rounded-sm border", checkCount(row, 0) > 0 ? "border-ok bg-ok text-background" : "border-border")}>
                  {checkCount(row, 0) > 0 ? <Check className="size-2.5" /> : null}
                </span>
                End of battle
              </button>
            ) : (
              <div className="mt-1 grid w-full shrink-0 grid-cols-5 gap-0.5 sm:mt-0 sm:w-44">
                {[0, 1, 2, 3, 4].map((slot) => {
                  const r = slot + 1;
                  const inMission = obj.rounds.includes(r);
                  const reached = r <= frontier;
                  const canEdit = !locked && inMission && reached && r === viewed;
                  const n = checkCount(row, slot);
                  return (
                    <button
                      key={slot}
                      type="button"
                      disabled={!canEdit}
                      aria-pressed={n > 0}
                      aria-label={`Round ${r} ${obj.vp} VP`}
                      onClick={() => onToggle(i, slot, max)}
                      className={cn(
                        "flex h-8 items-center justify-center gap-0.5 rounded-md border text-[10px] font-medium",
                        !inMission
                          ? "cursor-not-allowed border-border/50 bg-muted/40 text-muted-foreground/40"
                          : n > 0
                            ? "border-ok/50 bg-ok/15 text-foreground"
                            : canEdit
                              ? "border-steel/70 bg-muted text-foreground"
                              : reached
                                ? "cursor-not-allowed border-border bg-muted/70 text-muted-foreground"
                                : "cursor-not-allowed border-border/50 bg-muted/40 text-muted-foreground/40",
                      )}
                    >
                      {`R${r}`}
                      {n > 1 ? <span className="font-mono">×{n}</span> : n === 1 ? <Check className="size-2.5" /> : null}
                    </button>
                  );
                })}
              </div>
            )}
          </li>
        );
      })}
    </ul>
  );
}

function SecondaryScore({
  lines,
  value,
  locked,
  compact,
  onPick,
}: {
  lines: string[];
  value: number;
  locked: boolean;
  compact?: boolean;
  onPick: (vp: number) => void;
}) {
  const options = scoreOptions(lines);
  return (
    <div className="mt-2 space-y-2">
      {compact ? null : (
        <ul className="list-disc space-y-1 pl-4 text-xs text-muted-foreground">
          {lines.map((line) => (
            <li key={line}>{parseObjective(line).text.replace(/\s*\([^)]*\)\s*$/, "")}</li>
          ))}
        </ul>
      )}
      <div className="flex flex-wrap gap-1.5">
        {options.map((vp) => (
          <button
            key={vp}
            type="button"
            disabled={locked}
            aria-pressed={value === vp}
            onClick={() => onPick(value === vp ? 0 : vp)}
            className={cn(
              "h-8 min-w-12 rounded-md border px-2.5 text-xs font-medium",
              value === vp ? "border-ok/50 bg-ok/15 text-foreground" : "border-border bg-muted text-muted-foreground",
            )}
          >
            {vp} VP
          </button>
        ))}
      </div>
    </div>
  );
}

function cardScored(checks?: Array<Array<number | boolean>>): boolean {
  return cardAward(checks) > 0;
}

function unscoredFirst<T extends string>(ids: T[], checks: Record<string, number[][]> | undefined): T[] {
  return [...ids].sort((a, b) => Number(cardScored(checks?.[a])) - Number(cardScored(checks?.[b])));
}

function SecondaryPanel({ game, locked }: { game: Game; locked: boolean }) {
  const side = game.viewing;
  const score = game.scores[side];
  const setSecondaryMode = useWarStore((s) => s.setSecondaryMode);
  const toggleFixedSecondary = useWarStore((s) => s.toggleFixedSecondary);
  const toggleTacticalActive = useWarStore((s) => s.toggleTacticalActive);
  const setSecondaryScore = useWarStore((s) => s.setSecondaryScore);
  const ensureSecondaryMeta = useWarStore((s) => s.ensureSecondaryMeta);
  const [openIds, setOpenIds] = useState<Record<string, boolean>>({});
  const mode = score.secondaryMode ?? null;
  const fixedIds = score.fixedIds ?? [];
  const active = score.tacticalActive ?? [];
  const ids = mode === "fixed" ? fixedIds : mode === "tactical" ? active : [];
  const pts = secondaryVp(mode, ids, score.secondaryChecks);
  useEffect(() => {
    ensureSecondaryMeta(side);
  }, [ensureSecondaryMeta, side, ids.join("|")]);

  const selectedCard = (id: string, discard?: boolean) => {
    const card = (mode === "fixed" ? FIXED_SECONDARIES : SECONDARIES).find((c) => c.id === id);
    if (!card) return null;
    const scored = cardScored(score.secondaryChecks?.[id]);
    const open = !!openIds[id];
    const award = cardAward(score.secondaryChecks?.[id]);
    const stamp = score.secondaryMeta?.[id];
    return (
      <div key={id} className={cn("min-w-0 rounded-lg border border-border px-2.5 py-1.5", open && "p-3", scored && "opacity-70")}>
        <div className="flex items-center gap-2">
          <button
            type="button"
            className="min-w-0 flex-1 truncate text-left text-sm font-medium"
            onClick={() => setOpenIds((m) => ({ ...m, [id]: !m[id] }))}
          >
            {card.name}
            <span className="ml-1.5 font-mono text-xs font-normal tabular-nums text-muted-foreground">{award} VP</span>
          </button>
          {discard ? (
            <Button size="sm" className="h-7 px-2 text-[11px]" variant="ghost" disabled={locked} onClick={() => toggleTacticalActive(side, id)}>
              Discard
            </Button>
          ) : null}
        </div>
        {stamp ? (
          <p className="mt-0.5 text-[11px] tracking-[0.12em] text-muted-foreground uppercase">
            Selected R{stamp.selectedRound}
            {stamp.completedRound != null ? ` · Completed R${stamp.completedRound}` : ""}
          </p>
        ) : null}
        {open ? <p className="mt-1 text-xs text-muted-foreground">{card.blurb}</p> : null}
        <SecondaryScore
          lines={secondaryLines(card, mode === "fixed" ? "fixed" : "tactical")}
          value={award}
          locked={locked}
          compact={!open}
          onPick={(vp) => setSecondaryScore(side, id, vp)}
        />
      </div>
    );
  };

  return (
    <Card className="p-4">
      <p className="text-[11px] tracking-[0.16em] text-muted-foreground uppercase">
        Secondary · {side === "me" ? game.myName : game.opponentName}
      </p>
      <p className="mt-2 text-[11px] tracking-[0.12em] text-muted-foreground uppercase">
        {mode === "fixed" ? "20 VP / card · 40 cap" : "15 VP / round · 45 cap"} · {pts} VP
      </p>
      <div className="mt-3 grid grid-cols-2 gap-2">
        <button
          type="button"
          disabled={locked}
          onClick={() => setSecondaryMode(side, "fixed")}
          className={cn(
            "h-10 rounded-lg border text-sm font-medium",
            mode === "fixed" ? "border-primary bg-primary text-primary-foreground" : "border-border bg-muted",
          )}
        >
          Fixed
        </button>
        <button
          type="button"
          disabled={locked}
          onClick={() => setSecondaryMode(side, "tactical")}
          className={cn(
            "h-10 rounded-lg border text-sm font-medium",
            mode === "tactical" ? "border-primary bg-primary text-primary-foreground" : "border-border bg-muted",
          )}
        >
          Tactical
        </button>
      </div>
      {mode === "fixed" ? (
        <div className="mt-3 space-y-3">
          <p className="text-xs text-muted-foreground">Pick two. They stay active all game.</p>
          <div className="flex flex-wrap gap-1.5">
            {unscoredFirst(FIXED_SECONDARIES.map((c) => c.id), score.secondaryChecks).map((id) => {
              const card = FIXED_SECONDARIES.find((c) => c.id === id);
              if (!card) return null;
              const on = fixedIds.includes(card.id);
              const scored = cardScored(score.secondaryChecks?.[card.id]);
              return (
                <button
                  key={card.id}
                  type="button"
                  disabled={locked || (!on && fixedIds.length >= 2)}
                  onClick={() => toggleFixedSecondary(side, card.id)}
                  className={cn(
                    "h-8 rounded-md border px-2.5 text-xs font-medium",
                    on ? "border-ok/50 bg-ok/15 text-foreground" : "border-border bg-muted text-muted-foreground",
                    scored && "opacity-60",
                  )}
                >
                  {card.name}
                </button>
              );
            })}
          </div>
          <div className="grid grid-cols-2 items-start gap-1.5">
            {unscoredFirst(fixedIds, score.secondaryChecks).map((id) => selectedCard(id))}
          </div>
        </div>
      ) : null}
      {mode === "tactical" ? (
        <div className="mt-3 space-y-3">
          <p className="text-xs text-muted-foreground">Draw two each Command phase. Tap a card when you draw it. Score it once, then it drops to the bottom.</p>
          <div className="flex flex-wrap gap-1.5">
            {unscoredFirst(SECONDARIES.map((c) => c.id), score.secondaryChecks).map((id) => {
              const card = SECONDARIES.find((c) => c.id === id);
              if (!card) return null;
              const on = active.includes(card.id);
              const scored = cardScored(score.secondaryChecks?.[card.id]);
              return (
                <button
                  key={card.id}
                  type="button"
                  disabled={locked}
                  onClick={() => toggleTacticalActive(side, card.id)}
                  className={cn(
                    "h-8 rounded-md border px-2.5 text-xs font-medium",
                    on ? "border-ok/50 bg-ok/15 text-foreground" : "border-border bg-muted text-muted-foreground",
                    scored && "opacity-60",
                  )}
                >
                  {card.name}
                </button>
              );
            })}
          </div>
          <div className="grid grid-cols-2 items-start gap-1.5">
            {unscoredFirst(active, score.secondaryChecks).map((id) => selectedCard(id, true))}
          </div>
        </div>
      ) : null}
    </Card>
  );
}

function ScorePanel({
  game,
  mission,
  mineDisp,
  theirDisp,
  locked,
}: {
  game: Game;
  mission: MissionInfo | null;
  mineDisp: string | null;
  theirDisp: string | null;
  locked: boolean;
}) {
  const side = game.viewing;
  const score = game.scores[side];
  const togglePrimaryCheck = useWarStore((s) => s.togglePrimaryCheck);
  const primaryPts = mission ? objectiveVp(score.primaryChecks, mission.scoring.map(parseObjective)) : score.primaryByRound.reduce((a, b) => a + b, 0);

  return (
    <div className="space-y-4">
      {mission ? (
        <Card className="p-4">
          <p className="text-[11px] tracking-[0.16em] text-muted-foreground uppercase">
            Primary · 11th edition · {side === "me" ? game.myName : game.opponentName}
          </p>
          <h3 className="font-display mt-1 text-xl">{mission.name}</h3>
          <p className="mt-1 text-xs text-muted-foreground">
            {mineDisp} vs {theirDisp}
          </p>
          <p className="mt-1 text-sm text-muted-foreground">{mission.blurb}</p>
          <p className="mt-2 text-[11px] tracking-[0.12em] text-muted-foreground uppercase">
            15 VP / round · 45 primary max · {primaryPts} VP
          </p>
          <ScoreLines
            lines={mission.scoring}
            checks={score.primaryChecks}
            locked={locked}
            focusRound={game.round}
            liveRound={game.liveRound ?? game.round}
            onToggle={(line, slot, max) => togglePrimaryCheck(side, line, slot, max)}
          />
        </Card>
      ) : (
        <p className="text-sm text-muted-foreground">Set dispositions on both lists to generate a primary mission.</p>
      )}
      <SecondaryPanel game={game} locked={locked} />
    </div>
  );
}

function StratPanel({
  game,
  roster,
  locked,
}: {
  game: Game;
  roster: Roster;
  locked: boolean;
}) {
  const side = game.viewing;
  const playStratagem = useWarStore((s) => s.playStratagem);
  const [fullByPhase, setFullByPhase] = useState<Record<string, boolean>>({});
  const dets = roster.detachmentIds.map((id) => getDetachment(roster.factionId, id)).filter(Boolean);
  const faction = getFaction(roster.factionId);
  const active = game.activeStrats ?? [];
  const list: Array<Stratagem & { source: string }> = [
    ...dets.flatMap((d) => d!.stratagems.map((s) => ({ ...s, source: d!.name }))),
    ...CORE_STRATAGEMS.map((s) => ({ ...s, source: "Core" })),
  ];
  const grouped = useMemo(() => {
    const map = new Map<StratPhaseKey, typeof list>();
    for (const s of list) {
      const key = stratagemPrimaryPhase(s.when);
      const arr = map.get(key) ?? [];
      arr.push(s);
      map.set(key, arr);
    }
    for (const arr of map.values()) {
      arr.sort((a, b) => Number(a.source === "Core") - Number(b.source === "Core") || a.name.localeCompare(b.name));
    }
    const order: StratPhaseKey[] = ["any", ...PHASES.map((p) => p.id)];
    return order.filter((k) => map.has(k)).map((k) => [k, map.get(k)!] as const);
  }, [list]);

  return (
    <div className="space-y-4">
      <p className="text-xs text-muted-foreground">Tap a stratagem to play it and spend the CP.</p>
      {grouped.map(([phase, strats]) => {
        const compact = !fullByPhase[phase];
        const label = phase === "any" ? "Any phase" : (PHASES.find((p) => p.id === phase)?.label ?? phase);
        return (
          <section key={phase}>
            <div className="mb-2 flex items-center justify-between gap-2">
              <h3 className={cn("text-xs tracking-[0.16em] uppercase", phase === game.phase ? "text-steel" : "text-muted-foreground")}>
                {label}
                {phase === game.phase ? " · now" : ""}
              </h3>
              <button
                type="button"
                className="text-[11px] tracking-wide text-muted-foreground uppercase"
                onClick={() => setFullByPhase((m) => ({ ...m, [phase]: !m[phase] }))}
              >
                {compact ? "Full text" : "1 line"}
              </button>
            </div>
            <ul className="space-y-2">
              {strats.map((s) => {
                const playCount = active.filter((a) => a.stratId === s.id && a.side === side).length;
                const showFull = !compact;
                const unaffordable = locked || game.cp[side] < s.cp;
                return (
                  <li key={s.id}>
                    <button
                      type="button"
                      disabled={unaffordable}
                      onClick={() => playStratagem(side, s, s.source)}
                      className={cn(
                        "w-full rounded-lg border bg-card text-left",
                        playCount > 0 ? "border-steel/50" : "border-border",
                        showFull ? "p-3" : "px-2 py-1.5",
                        unaffordable && "opacity-50",
                      )}
                    >
                      <div className="flex items-center gap-2">
                        <div className="min-w-0 flex-1">
                          {showFull ? (
                            <div>
                              <p className="font-medium">
                                {s.name}
                                {playCount > 1 ? <span className="ml-1.5 font-mono text-[11px] text-muted-foreground">×{playCount}</span> : null}
                              </p>
                              <p className="text-xs text-muted-foreground">{s.when}</p>
                            </div>
                          ) : (
                            <p className="truncate text-sm font-medium">
                              {s.name}
                              <span className="ml-1.5 font-normal text-muted-foreground">
                                · {s.when}
                                {s.source !== "Core" ? ` · ${s.source}` : ""}
                              </span>
                              {playCount > 1 ? <span className="ml-1.5 font-mono text-[11px] text-muted-foreground">×{playCount}</span> : null}
                            </p>
                          )}
                        </div>
                        <span className="shrink-0 font-mono text-xs tabular-nums text-muted-foreground">{s.cp} CP</span>
                      </div>
                      {showFull ? <p className="mt-2 text-sm text-muted-foreground">{s.text}</p> : null}
                    </button>
                  </li>
                );
              })}
            </ul>
          </section>
        );
      })}
      {faction ? (
        <Card className="p-4">
          <p className="text-[11px] tracking-[0.16em] text-muted-foreground uppercase">Army rule</p>
          <p className="mt-1 font-medium">{faction.rule.name}</p>
          <p className="mt-1 text-sm text-muted-foreground">{faction.rule.text}</p>
        </Card>
      ) : null}
      {dets.map((d) => (
        <Card key={d!.id} className="p-4">
          <div className="flex flex-wrap gap-2">
            <p className="font-medium">{d!.name}</p>
            <Badge variant="outline">{d!.disposition}</Badge>
          </div>
          <p className="mt-1 text-sm text-muted-foreground">
            <span className="text-foreground">{d!.rule.name}. </span>
            {d!.rule.text}
          </p>
        </Card>
      ))}
    </div>
  );
}
